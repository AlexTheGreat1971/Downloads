﻿# Helivanta Build155 — Packaging Thread handoff

## Current state
- Base lineage: Build154 / version 2.5.154; current experimental branch remains version 2.5.155.
- Packaging/Bottle Thread policy, ribbon command, modeless parameter/selection dialog, geometry builder, copyable error report, and persistent diagnostic log are in the source tree.
- User-confirmed regression gate from the latest supplied log: 1/2/3-start external construction succeeds for right- and left-hand selection from both ends of the same cylindrical face; the requested hand maps to opposite `ClockwiseRotation` values independently of selected end.
- Current package extends the working external positive coil with an internal positive inward ridge (`kJoinOperation`) and separate start/end Loft run-outs. The user confirmed that internal geometry and run-outs build; the newly shortened run-out lengths and automatic outer/inner classification still need a Windows/Inventor regression check.
- The UI exposes independent checkboxes for a smooth run-in and run-out; both default to enabled. The internal option is explicitly a positive rib into the bore, not a cut groove.


## Latest diagnostic-driven fix (2026-10-21)
- User supplied a later runtime Gist from D=22 mm, P=2.7 mm, 3-start external thread, 4 × 14° vent slots. For end-2, a 17.444° fragment in a 76° free sector is 22.953% and therefore must be removed; the 23° fragments are 30.263% and must remain. This confirms the strict `<25%` plan is the correct gate.
- In the five local axial/angular face candidates, the log reports two `kPlaneSurface` faces and three `kBSplineSurface` faces. The previous crest-radius filter excluded all five because their vertices were around the stock radius (~11.0 mm), not the modeled crest radius (11.55 mm), preventing any API call.
- Current source now offers only the three local `kBSplineSurface` faces to `DeleteFaceFeatures.Add(faceCollection, true)`. It retains the plan gate, local axial/angle window, exact-three requirement, health/volume/body-count checks, safe rollback of failed deletion, and no sector-cut fallback. The new log should report `splineTopSurfaceCandidates=3` and then either a successful `delete-face-heal-verified` event or the exact reason the API operation failed.
- Validation remains pending in Inventor 2027. Do not treat build success alone as proof the tail was removed; visually inspect the specific <25% tail and neighboring full thread surfaces.

## Verification
- User-provided log confirms the previous external RH/LH and end-edge combinations reach `build-success` with unchanged body count and increased volume.
- Current source changes have been inspected against Autodesk Inventor 2027 API documentation and pure-policy regression cases were added. The current environment does not contain the .NET SDK or Inventor runtime, so compile, test-run, and the new Loft/Internal CAD geometry are NOT RUN here.
- For the next user-side regression, validate the changed automatic inner/outer classification and exact shortened run-out lengths on a disposable part: external 1/12 turn, internal 1/6 turn, RH/LH, 1/2/3 starts, both end edges, run-ins enabled/disabled, solid-body count, volume increase, feature health, and single-transaction Undo/Abort.


## Historical implementation notes (chronological; current state above takes precedence)

The following sections document earlier Build155 iterations. Some statements (for example, that internal geometry was blocked) describe the state at that time and are superseded by the current state at the top of this file.

## Build155 — additive geometry test step (2026-10-19)

Implemented in source after the ribbon-preflight archive:
- `src/PackagingThreadGeometryBuilder.cs` adds an experimental external, positive helical ridge using `CoilFeatures.AddByPitchAndRevolution` with `kJoinOperation`.
- `PackagingThreadDialog` now exposes **Построить наружную резьбу**. It requires one selected cylindrical face and uses the existing parameter policy.
- Build runs inside an Inventor transaction and checks volume increase and unchanged solid-body count; exceptions attempt transaction abort. Requested length is clipped to the selected face's available axial span.
- Multi-start geometry is attempted as separate coils shifted by one pitch.
- At this historical point in the iteration, the internal positive-inward rib was blocked in the UI and not implemented. Later current-state changes above add the positive inward rib and optional start/end run-out Loft features. Print clearance remains a separate setting and is not applied to nominal geometry.

### Validation status
- Source-level balance checks: PASS (rough lexical checks only).
- ZIP integrity and SHA-256 manifest: to be regenerated with this package.
- `dotnet build`, the Windows test projects, and Inventor 2027 geometry smoke test: NOT RUN in this environment (no .NET SDK or Inventor runtime available).
- This is an experimental test build, not release-qualified. First test on a disposable copy of a simple part with one clearly external cylindrical face, one start, and a short length. Inspect the feature tree, solid-body count, volume, handedness and endpoints. If Inventor rejects the Coil join, the transaction should abort and report the error.

## Build155 compile-error follow-up (2026-10-19)

Fixed the reported compile-time name collisions in `PackagingThreadDialog.cs` by aliasing `System.Drawing.Color` and `System.Windows.Forms.Application`, and made the transaction document argument explicit as `Inventor._Document` in `PackagingThreadGeometryBuilder.cs`.

These are source-level fixes for the reported CS0104 and CS1503 diagnostics. This environment does not have the .NET SDK or Autodesk Inventor, so a Windows build and Inventor runtime test are still required. Do not treat the experimental geometry as validated until those tests pass.


## Build155 multi-start and start-edge correction (2026-10-19)

- Added an explicit start-edge selector to the packaging-thread dialog: low axial coordinate or high axial coordinate.
- Passed the selected edge into the external additive builder and mirrored the axial placement for the opposite edge while accounting for the axial offsets of additional starts.
- Updated the result message to report the selected start edge and axial length.
- This is a source-level correction only. Inventor runtime geometry has not been executed in this environment; verify 1-, 2-, and 3-start cases and both edge choices in Inventor before treating the geometry as production-ready.


## Build155 selected-edge correction (2026-10-19)

- Replaced the confusing low/high-axis dropdown with selection of the actual circular edge at the desired thread end. The command resolves the adjacent cylindrical face from the selected edge and derives the axial start from that edge.
- This is a source-level correction only. The current environment has no .NET SDK or Inventor runtime, so compilation and geometric continuity remain unverified. The previous screenshot indicates the multi-start coil algorithm still requires a real Inventor validation; do not treat this build as production-ready until 1/2/3-start tests confirm continuous, evenly phased helices.


## Build155 geometry-builder correction — sketch plane orientation (2026-10-19)

The user reported that changing edge selection did not change the generated thread. Inspection found a core geometry defect: the fixed sketch plane was created with the radial vector as its normal, while the profile coordinates also used that radial vector for the thread height. The radial coordinates were therefore normal to the sketch plane and could be projected away, explaining the collapsed/strip-like thread geometry. The builder now uses the circumferential tangent as the sketch-plane normal so the sketch plane contains the cylinder axis and radial direction. Applied to both the first start and additional starts.

Static source checks and archive integrity can be checked here; Autodesk Inventor runtime geometry and Windows compilation have not been run in this environment. This is a targeted algorithm correction, not a claim of runtime validation.


## Build155 E_INVALIDARG follow-up — sketch coordinate correction (2026-10-19)

The user reported that the Geometry-Fix package stopped generating the thread and returned `0x80070057 (E_INVALIDARG)`. Reviewing Autodesk's `WorkPlanes.AddFixed` contract confirms its two vectors are the plane's **X and Y axes**, not a plane normal plus an axis. The prior patch incorrectly supplied the circumferential tangent as X while profile points were still generated from the radial direction; those points therefore did not lie in the sketch plane and the profile collapsed during sketch creation. Corrected both the first-start and additional-start work planes to use `radial` for X and the cylinder `axis` for Y, which matches the `ModelToSketchSpace` point construction.

This is a source-level fix based on the API contract. Build and Inventor 2027 runtime validation are unavailable in this environment. It addresses the new E_INVALIDARG regression only; it does not establish that the multi-start helix is geometrically acceptable.


## Build155 multi-start geometry root-cause correction — angular phasing (2026-10-19)

A later source-to-source audit found that the earlier “sketch plane orientation” explanation was not a valid root-cause claim: the original experimental builder already used the radial vector as the workplane X axis and the cylinder axis as Y. The interim tangent-vector edit was a regression and Geometry-Fix2 only restored the earlier basis; it did not address the user's visual complaint.

The relevant finite-length defect was in multi-start placement: extra starts were created by translating the whole profile/axis forward by `i * pitch`. That leaves each helix with a different axial start/end station, so a finite 3-start thread can look like separated groups instead of three starts distributed around the circumference. The revised builder places every start at the same selected-edge-relative axial start/end stations and rotates the radial profile plane around the cylinder axis by `360° * i / starts`. The per-coil helix pitch is the lead (`pitch * starts`) and each coil uses the same revolution count (`axial length / lead`).

The selected circular end edge now also controls the actual inward build direction: the axis line points inward from that edge, the opposite end reverses the axis vector, and the clockwise flag is compensated so the requested RH/LH meaning remains consistent. The available axial length is calculated from the selected edge inward; it is no longer shortened by artificial `starts - 1` axial shifts.

Additional safeguards report the start index, phase, pitch, lead, revolutions, profile width/radii, handedness and selected end if `CoilFeatures.AddByPitchAndRevolution` throws. Each coil is individually updated and checked for UpToDate health, measurable volume addition and unchanged solid-body count before the next start is applied. A pure vector-rotation helper and regression test verify equal angular phase spacing.

Validation status for this package: source-level algorithm checks and mathematical phase tests are prepared; ZIP manifest/integrity will be regenerated. The local environment does not contain the .NET SDK or Inventor 2027, so neither Windows compilation nor Inventor runtime geometry can be honestly marked PASS. The decisive acceptance test remains a 1-/2-/3-start build in Inventor from both selected end edges, checking that starts are circumferentially phased 360°/N and share the same axial extent.


### Additional edge-to-cylinder disambiguation

Both the dialog preview and builder now resolve an adjacent cylindrical face by matching its analytic radius to the selected circular edge radius, rather than accepting the first adjacent cylinder in COM enumeration order. This reduces the risk of selecting the wrong cylinder at a stepped shoulder. Selection text was also updated for the modeless dialog flow.


## Build155 right-hand helix polarity correction (2026-10-19)

The user inspected the three-start result with RH selected and reported that the helix hand looked reversed. The builder previously used `edgeIsLow ? !rightHand : rightHand`; the user-reported Inventor result showed the requested RH thread visually winding in the opposite direction. Added `PackagingThreadPhaseMath.ResolveClockwiseRotation` with the inverted mapping (`edgeIsLow ? rightHand : !rightHand`) and a regression test covering RH/LH at both end choices. The opposite-end compensation remains in place, so selecting the other end flips the API flag while preserving the requested physical thread hand.

This is a targeted correction based on the user's visual report. The boolean mapping and edge-compensation truth table are covered by source tests, but no .NET SDK or Inventor runtime is available here; compile and real RH/LH geometry must be verified in Inventor 2027. Do not mark the handedness fix as runtime-validated until that check is complete.


## Build155 diameter-dependent Coil failure follow-up (2026-10-19)

Reported behavior: the same packaging thread builds at Ø22 mm but fails with E_FAIL at Ø31 mm and Ø52 mm. Source inspection found that height increased with diameter while section width stayed fixed at 0.55 × pitch and the crest remained 62% of root width; this creates a deep, steep profile at fixed pitch. Added a pitch-relative depth limit, dynamic root width, narrower crest, longer axis sketch line, and per-start post-Coil diagnostic context. See `docs/BUILD155-DIAMETER-DEPENDENT-COIL-FAILURE.md`. These are defensive geometry changes; actual successful regeneration must still be verified in Inventor 2027.


## Build155 follow-up — copyable error details and persistent diagnostics (2026-10-19)

- New `src/PackagingThreadDiagnostics.cs` presents failures in a resizable, scrollable detail window with **Копировать ошибку** and **Открыть лог** actions. The copied report includes stage, model/parameter context, HRESULT, complete `Exception.ToString()` (including inner exceptions and stack trace), and log path.
- Failures and stage breadcrumbs are appended to `%LOCALAPPDATA%\Helivanta\Logs\packaging-thread-diagnostics.log` through `DiagnosticLogMaintenance.Append`, inheriting the bounded 1 MiB log and archive retention behavior.
- `PackagingThreadGeometryBuilder` records stages including cylinder/edge resolution, each start's plane/sketch/profile/Coil, per-start verification, final validation, commit and transaction abort.
- The dialog also logs policy rejection, parameter context, build start and completion.
- Validation status in this environment: static source checks only; Windows/.NET compilation and Inventor 2027 UI/runtime remain unverified.


## Build155 diagnostic follow-up — feature-name collision on opposite end (2026-10-19)

The user's copied error identifies `Inventor.CoilFeature.set_Name(String)` as the failing COM call, not `CoilFeatures.AddByPitchAndRevolution`, `doc.Update`, or the shoulder geometry. The previous code assigned deterministic names such as `Helivanta — упаковочная резьба, заход 1/3, фаза 0°` for every build. Building the same three-start thread from the opposite end of the same document therefore attempts to reuse the feature name already assigned by the first successful build; Inventor feature names must be unique in document scope. The slash/degree symbol/non-ASCII punctuation were also removed from feature labels as a conservative naming policy.

Correction: feature names now include a short GUID token and ASCII-only characters. More importantly, assigning the browser label is now a non-fatal cosmetic step: the new Coil is registered for verification first, naming errors are logged but do not abort otherwise valid geometry. Geometry is still independently validated by document update, health status, volume increase and unchanged solid-body count. Diagnostics now separate `assign-feature-name` from `verify-coil`, so future logs cannot misattribute name errors to geometry regeneration. Added pure regression tests for safe name characters and distinct labels across repeated builds.

Validation in this environment: source-level assertions, test-source consistency, ZIP integrity and SHA-256 manifests are checked. The .NET SDK and Inventor runtime are unavailable here, so the compiled metadata test and Inventor 2027 geometry test remain NOT RUN. The copied log does not demonstrate a shoulder/edge geometric failure; after this name-collision fix, any remaining geometry failure should appear at a separate Coil/update/health/volume/body validation stage.


## Build155 handedness correction from diagnostic log (2026-10-19)

The user reported that a right-hand thread built from one end and a left-hand thread built from the other end both appeared right-handed. The uploaded diagnostic log identifies the exact logic collision: `ResolveClockwiseRotation(edgeIsLow, rightHand)` returned `false` for both `RH=True, edgeIsLow=False` and `RH=False, edgeIsLow=True`. Both Coil calls therefore received the same `ClockwiseRotation` setting despite opposite requested handedness.

Correction: `ResolveClockwiseRotation` now maps the selected hand directly and independently of the selected end (`RH => false`, `LH => true`) based on the user's runtime result. The selected edge controls the axial build direction and start station, not the hand flag. Builder diagnostics explicitly log `requestedHand`, `edgeIsLow`, `buildDirection`, and the actual `ClockwiseRotation` value. Regression checks assert RH/LH produce opposite flags, including the pair that previously collapsed to the same value.

Evidence basis: user-provided `packaging-thread-diagnostics.log`, especially entries around 21:38:32 and 21:38:41. Both requested hands previously passed `ClockwiseRotation=false` and both looked right-handed. Autodesk defines this boolean as clockwise/counter-clockwise rotation, not directly as a right/left thread designation; for this profile/axis convention the runtime-observed correct mapping is RH=false and LH=true. This source change directly addresses the collision in the log, but does not prove the final physical thread handedness for all edge/hand combinations. Verify RH and LH from both end edges in Inventor 2027 before marking the behavior accepted.


## Build155 — internal positive rib and smooth end run-outs (2026-10-19)

- Implemented the inner variant as an additive helical rib. For a bore radius `R`, the rib root is placed at `R + embed`, while its crest is at `R - height`; the feature operation stays `kJoinOperation`. No cut operation is used for the inner variant. A pure profile-radius policy and wall/embedding safety check guard the radial direction and dimensions.
- Added independent **Плавный сбег в начале** / **Плавный сбег в конце** controls, enabled by default. The total requested thread interval is split into a core Coil plus one `LoftFeature` per enabled end and start. Identical four-vertex profiles are rotated along the helix; the exposed crest depth follows a smoothstep curve down to a small non-zero terminal factor, while a minimum root overlap keeps the added material fused to the stock.
- Run-out lengths are auto-resolved from pitch, height and base width and are capped so at least 0.25 lead of the full-depth core remains. All core Coils and run-out LoftFeatures are created inside the same Inventor transaction; each is checked for health, volume delta and unchanged solid-body count. Failure aborts the transaction and is recorded with station/phase/hand/profile details.
- Added pure regression checks for inner/outer radius direction, unsafe radii, one/two run-outs, core-length preservation, bounded Loft sections, smoothstep direction and root overlap.
- Evidence/limits: the attached diagnostic log supports the prior external RH/LH/end-edge behavior. Autodesk documentation confirms `LoftFeatures.CreateLoftDefinition` accepts ordered profile sections and `kJoinOperation`, and `LoftFeature` exposes `HealthStatus`. This environment cannot compile .NET or launch Inventor, so the actual internal feature/Loft geometry remains unverified pending the user's Windows run.


## Current implementation — internal positive rib and smooth run-outs (2026-10-19)

- Internal geometry uses a positive inward-facing trapezoid: root radius is bore radius + embed; crest radius is bore radius - profile height. The operation remains `kJoinOperation`; no internal cut/groove is used.
- The full-depth helical core is generated by Coil. Optional start and end run-outs are additive Loft features, with ordered rotating radial/axial section profiles following the handed helix phase.
- The crest factor and root-overlap factor both use SmoothStep interpolation. The small terminal root overlap is retained intentionally so the run-out remains fused to the bore wall.
- Run-out checkboxes are independent and enabled by default. Planning preserves at least one quarter of lead as full-depth Coil core and limits section count. If the available length cannot support this, the builder rejects the request before starting the transaction.
- New pure-policy regression checks cover internal profile radii, inward projection, run-out allocation/toggles, endpoint values and smooth monotonic root/crest factors.
- **Unverified in this environment:** C# compilation, Windows policy test execution, and all internal/Loft geometry in Inventor 2027. Before release, use a disposable part and test internal/external, RH/LH, 1/2/3 starts, both selected ends, each run-out toggle, unchanged solid-body count, volume growth, feature health and one-step Undo/transaction rollback.


## Build155 follow-up — auto-detected surface type and concise run-outs (2026-10-20)

- UI no longer presents a manual outer/inner selector. It classifies the circular edge's adjacent cylindrical face: `Face.IsParamReversed == true` maps to an external shaft, `false` to an internal bore, following `ThreadBuilder.Analyze`. The detected type appears in the selection status, is passed to the geometry policy, and is independently rechecked in the builder.
- External end run-outs target exactly 1/12 of the helix revolution (`lead/12`); internal positive-rib run-outs target 1/6 (`lead/6`). For P=2.7 mm and 3 starts (`lead=8.1 mm`), the targets are 0.675 and 1.350 mm respectively per enabled end. Insufficient lengths are rejected instead of silently shrinking the selected run-outs.
- Regression tests added for automatic type mapping, exact run-out fractions, and minimum core refusal. Source/ZIP checks can be performed in this environment; Windows/.NET and Inventor 2027 runtime are unavailable here, so those acceptance checks remain open.

## Build155 follow-up — optional longitudinal ventilation slots (2026-10-20)

- Added the **Вентиляционные пропилы по резьбе до исходного цилиндра** checkbox (off by default). Count and angular width are editable. External default is four slots, 28° each, as interpreted from the PCO1881 neck drawing. Internal default is eight slots as a configurable hypothesis based on the user's estimate; the drawing does not establish this as a standard requirement for a cap.
- Added `src/PackagingThreadVentSlotPolicy.cs` and linked its pure input/spacing tests into `ThreadMetadataTest`. Count range: 1–20. Width range: 0.5–120 degrees and must be smaller than spacing `360/count`.
- Geometry builder now creates one axial, sector-revolved rectangular `kCutOperation` per slot *after* all core Coil and run-out Loft features. External cutter radial extent starts at the stock-cylinder radius and reaches past the crest; internal cutter runs from just beyond the inward crest to the bore radius. This targets only the positive ridge, rather than cutting through the shaft/bore wall. Each cut is body-scoped and checked for `UpToDate`, measurable volume removal and unchanged body count; any failure aborts the same overall transaction.
- UI defaults the slot count to 4 on an external face and 8 on an internal face unless the user has manually edited the count. The width starts at 28° but remains editable for either kind.
- Required runtime QA: compile on Windows/.NET 10, then test slots disabled/enabled on external and internal geometry; confirm 4×28° on the neck, try 8×28° on a bore as a provisional configuration, test both thread ends, RH/LH and 1/2/3 starts, inspect wall preservation and one-step Undo. Source-level checks are not proof of correct Inventor geometry; this feature has **not** been run in Inventor 2027 in this environment.


## Build155 optional ventilation slots — drawing-angle correction (2026-10-20)

A closer inspection of the supplied PCO1881 top-view dimensions corrects the earlier interpretation: the callout `28° (+0°/−1°) (4 PLACES)` is measured from the slot symmetry/radial reference, while `(56°)` is the full included reference sector. The default external slot width is therefore 56° with 4 slots. The cap/inside case is not specified by this neck drawing; 8 slots × 28° remains an editable provisional hypothesis, chosen to fit the 45° spacing without overlap.

The dialog now has type-specific default widths and preserves user-edited count/width when refreshing edge selection. The optional checkbox remains off by default. Partial revolved cuts target only the raised outer ridge or inward-facing inner rib; no cut into stock wall is intended. Static syntax/XML checks and manifest/ZIP integrity are required for this source package. Windows/.NET compilation and Inventor 2027 execution are not available in this environment, so do not claim the new slot geometry runtime-verified until the user tests it.


## Build155 ventilation slots — packaging/static validation note (2026-10-20)

Corrected the outer slot default after inspecting the large PCO1881 top-view render: the 28° (+0°/−1°) callout is the half-angle and (56°) is the full included reference sector. Defaults are now external 4 × 56° and internal 8 × 28° (inner width/count remain a configurable hypothesis). Slot width has its own “edited by user” tracking, independent of count, so changing selected edge type updates each unmodified default without overwriting a user-edited value. Removed an unused parameter from the slot-builder method and fixed an unbalanced trailing parenthesis in the success-message expression found during delimiter validation. Static validation only; .NET and Inventor runtime are unavailable here.

## Build155 ventilation-slot compile correction (2026-10-20)

The Vent-Slots package had one stale symbol reference in the builder overload: `DefaultSlotWidthDegrees` did not exist after the policy was split into external and internal defaults. The backward-compatible overload is for external threads and now references `DefaultExternalSlotWidthDegrees` (56°), matching the policy and dialog defaults. Policy tests already cover default external 4 × 56° and internal 8 × 28°. This is a source correction; Windows compilation and Inventor runtime remain to be confirmed by the user.


## Build155 follow-up — cancel, close and vent-cutter axial overrun (2026-10-20)

Current source package adds a cancel-build control separate from Close. Cancellation is polled only between Inventor API calls; on request, the shared transaction is aborted and the modeless window stays open. The dialog disables all geometry/settings controls while building to avoid re-entry; Close/Alt+F4 while busy requests cancellation and keeps the window open until safe rollback. The Close button also calls `Close()` explicitly when idle (DialogResult alone does not close a modeless form).

Vent-slot default angular width is 14° for external and internal choices; the PCO1881 full-angle reference of 56° is not used as the default cut width. Vent cutter travel is asymmetric and edge-aware: it begins 0.25 mm before the selected cylinder edge after accounting for the helix origin inset. On the far end it prefers `max(1 mm, lead)` overrun but is capped at 0.25 mm beyond the far boundary of the selected cylindrical face, so it does not cut far into a neighbouring shoulder. Tests cover the 14° defaults, start offset and far-side cap. Runtime cancellation responsiveness, rollback and cutter reach still require confirmation in Inventor 2027 because this environment has no .NET SDK/Inventor runtime.


### Vent cutter end reach follow-up

The longitudinal cut profile now uses separate start/end overrun values. The start extends 0.25 mm before the selected circular edge (the builder's inset is included); the end prefers one full lead but respects the selected cylindrical face's far boundary plus 0.25 mm. This avoids leaving a partial first/last ridge while preventing a long cutter excursion across a nearby shoulder. Verify on a disposable part in Inventor before release.


### Vent cutter reach refinement

The longitudinal cutter begins 0.25 mm before the selected physical circular edge (the thread-origin inset is included in the tool station). The far-side cutter travel prefers one full lead after the nominal thread but is capped to the selected cylindrical face boundary plus 0.25 mm. This is intended to remove the first and last thread-ridge portions without the cutter travelling a full lead into a neighbouring shoulder. Runtime geometry has not been validated in this environment.


## Current state after usability and vent-cut reach fixes (2026-10-20)

- Build155 current vent-slot defaults are 14° for both external and internal threads (external count 4; provisional internal count 8). The earlier 56° full-sector setting is retained as a drawing reference/history, not the current default.
- The modeless packaging dialog has a dedicated “Отменить построение” control; cancellation is polled between Inventor API operations and aborts the shared transaction while keeping the dialog open. Closing while idle uses an explicit close/dispose path; during a build, close requests cancellation and defers shutdown until safe rollback.
- Vent cutter start/end overrun is edge-aware and independent: the start is placed 0.25 mm before the selected physical edge, accounting for the helix origin inset; the end prefers `max(1 mm, lead)` after the thread but is capped to the selected cylinder boundary plus 0.25 mm.
- Source-level C# delimiter, project XML, overrun-policy and interaction wiring checks pass in this environment. Windows .NET 10 compilation, runtime cancel/close behavior, and actual cutter-end geometry still require confirmation in Inventor 2027.


## Build155 follow-up — terminal vent-fragment cleanup and responsive cancellation (2026-10-20)

- User reported that the cancel button did not visibly cancel a build and that short thread stubs remained at the axial beginning/end after vent-slot cuts. The previously modal success `MessageBox` was removed; the modeless dialog now returns directly to idle and tells the user to use Inventor Undo (Ctrl+Z) after a completed operation. During a running build, the cancel button stays enabled after the request and changes to “Ожидание отмены…”, with Escape routed to cancellation while busy. It polls the request at more intermediate checkpoints after plane/sketch/profile/Coil/Loft/vent-cut/update API calls. The active Inventor API call still cannot be interrupted mid-call; the transaction should abort at the next checkpoint. Runtime responsiveness remains unverified until the user tests it.
- Added pure `PackagingThreadVentFragmentPolicy`: for each start/end phase, it finds the next slot boundary in the direction along the helical path and compares the angular remainder with 1/4 of the free angular gap (`360°/slotCount - slotWidth`). Because axial travel and helical path length are both linear in angular travel for the same constant-pitch helix, the angle fraction is also the segment-length fraction. Remainders strictly below 25% receive a local short sector cut after regular vent slots. It extends slightly into the existing slot to avoid a seam, spans the corresponding axial travel plus half the profile width, and only affects the raised ridge (external) or inward positive rib (internal).
- Adjacent-start safety: a cleanup cut is suppressed with a diagnostic reason when its angular sector plus the mapped profile angular footprint could reach another start. This prioritizes preserving a valid neighbouring thread over blindly cutting the wrong ridge. The builder verifies health, measurable volume removal and unchanged body count for each cleanup cut; any failed cleanup transaction rolls back the entire thread operation. The log records phase, nearest slot boundary, fraction of free segment, axial travel, cut sweep and result.
- Added four policy regression checks: remove a <25% terminal remainder; preserve a >=25% segment; skip if already within an existing slot; suppress an unsafe cut near an adjacent start. If all pass, Metadata/Policy is expected to increase from the user-confirmed 311 to 315.
- Validation here: source/XML/manifest/ZIP checks only. The environment has no .NET SDK or Inventor 2027; no compilation or CAD runtime test is claimed. Required user validation: (1) cancel during Coil, Loft and a vent-cut batch, ensure rollback and window remains open; (2) with 3 starts, 4 slots × 14° and L=10 mm/P=2.7 mm, inspect terminal stubs and check the log for `terminal-fragment-verified`; (3) test internal 8×14° and RH/LH, one and three starts; (4) confirm a single Ctrl+Z removes a committed full build.


## Latest work candidate — guarded undo and Delete Face + Heal face selection (2026-10-21)
- The experimental action button is now dual-purpose: during build it requests cancellation; after successful build it becomes `Отменить последнее построение` if and only if the exact packaging transaction remains at the top of the committed transaction list and the same part is active. This prevents undoing an unrelated Inventor action.
- Terminal tail probe adds a radial crest constraint and detailed candidate diagnostics. The old sector-cut fallback is disabled in this candidate; if the three intended faces are not confidently identified, the optional cleanup is skipped and logged rather than risking a bad cut.
- Not compiled here and not run in Inventor 2027. User should test: (1) vent slots on and tails visible; (2) journal candidate counts for each tail; (3) Delete Face + Heal actually removes tails; (4) post-build undo removes only the most recent packaging build; (5) if another Inventor action happens first, Helivanta undo disables/refuses.


## 2026-10-21 — Start-end terminal-fragment correction
- Latest user Gist showed `end-2` Delete Face + Heal successfully removed the 17.444° fragment; start cleanup was skipped because the policy only considered one angular direction and treated a 23° start tail as 30.263% of the 76° clear opening.
- `PackagingThreadVentFragmentPolicy` now selects the nearest slot boundary on either side of an endpoint, reports both clear-gap and center-spacing ratios, and applies a 1° tolerance to one quarter of the nominal slot-to-slot sector. Thus 23° in a 90° pattern is a borderline trim candidate (threshold 23.5°); long fragments remain protected.
- This change is an experimental interpretation of the user’s “quarter-sector” rule; verify the resulting start-face deletion in Inventor 2027 before treating it as confirmed.


## 2026-10-21 — Start-side Delete Face candidate phase compensation

- Latest user screenshot confirms the tiny three-face remnant still exists at the axial beginning even though cleanup can succeed at the far end. The candidate picker had compared `Face.PointOnFace` raw azimuth directly to an endpoint fragment sector. Because that point can lie axially away from the endpoint, a helical surface's measured azimuth includes the helix phase accumulated at its station; the same angular window therefore behaved differently at start and end.
- Added `PackagingThreadVentFragmentPolicy.CorrectAngleToEndpoint` and applied it to candidate-face angular selection: measured face azimuth is de-rotated by `helixPhaseSign * 360 * (station-endpointStation) / lead`. Then the angular window is tested in decreasing phase, matching the direction of the Revolve cleanup sector (the prior test selected the opposite side of the endpoint). Diagnostics report raw and phase-corrected endpoint angles and use `phaseCorrectedSectorCandidates`.
- Added pure regression checks for start and end phase compensation. Existing length threshold policy and the previously working post-build undo/cancel path were left unchanged.
- This is a reasoned source-level fix, not an Inventor-validated result; recompile and retest on the same part. If the initial tail remains, the new log will show corrected endpoint phases for the nearby spline faces so the candidate sector can be narrowed without weakening the quarter-sector rule.


## 2026-10-21 — follow-up candidate after RH/LH endpoint asymmetry
- User reports the Start-Phase-Corrected build stopped trimming either end and produced thread artifacts. The prior version cleaned only far-end tails for RH and start tails for LH.
- Candidate change in `PackagingThreadGeometryBuilder.TryDeleteTerminalFacesWithHeal`: use `-helixPhaseSign` only when translating sampled `Face.PointOnFace` azimuth back to endpoint phase. Do not change the requested RH/LH geometry or the `CoilFeature` direction. Rationale: the observed RH/LH end swap is consistent with the sign of the generated Coil face progression being opposite the profile-station phase sign.
- Candidate diagnostics include `correctionSign` per nearby/candidate face. Two pure phase-mapping regression checks now cover RH-start and LH-end sign conventions. This is a hypothesis based on the observed runtime behavior and still needs Inventor 2027 validation.
