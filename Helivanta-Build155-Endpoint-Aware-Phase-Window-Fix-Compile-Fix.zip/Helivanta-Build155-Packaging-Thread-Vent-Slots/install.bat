@echo off
cd /d "%~dp0"
call build.bat
if errorlevel 1 exit /b 1
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0installer\setup.ps1"
