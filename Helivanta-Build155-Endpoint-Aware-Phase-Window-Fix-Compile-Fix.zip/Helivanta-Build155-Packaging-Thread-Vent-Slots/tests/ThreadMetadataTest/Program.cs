﻿using System;
using System.Text.Json;
using System.Linq;
using ThreadPro;

namespace ThreadPro.ThreadMetadataTest
{
    internal static class Program
    {
        private static int Main()
        {
            int pass = 0;
            int fail = 0;

            Check("TAPER-SUPPORT-FILTERS-ONLY-HIDDEN-TAGGED-MATCH", TaperedThreadSupportPolicy.IsMatchingHiddenSupportFeature(
                false, true, true, "cone-thread-id", "cone-thread-id", true, "NPT", "npt", "1/2", "1/2-14 NPT", "1/2-14 NPT"),
                ref pass, ref fail, "Из отчёта исключается только скрытая TaperedThreadInfo с тем же ThreadId, стандартом и полным обозначением группы Helivanta.");
            Check("TAPER-SUPPORT-FILTER-KEEPS-VISIBLE-NATIVE", !TaperedThreadSupportPolicy.IsMatchingHiddenSupportFeature(
                true, true, true, "cone-thread-id", "cone-thread-id", true, "NPT", "NPT", "1/2", "1/2-14 NPT", "1/2-14 NPT"),
                ref pass, ref fail, "Видимая штатная коническая резьба Inventor остаётся в отчёте даже при совпадении обозначения.");
            Check("TAPER-SUPPORT-FILTER-KEEPS-UNTAGGED", !TaperedThreadSupportPolicy.IsMatchingHiddenSupportFeature(
                false, true, false, "", "cone-thread-id", true, "NPT", "NPT", "1/2", "1/2-14 NPT", "1/2-14 NPT"),
                ref pass, ref fail, "Скрытая штатная резьба без подтверждённых метаданных Helivanta не фильтруется.");
            Check("TAPER-SUPPORT-FILTER-KEEPS-DIFFERENT-THREAD-ID", !TaperedThreadSupportPolicy.IsMatchingHiddenSupportFeature(
                false, true, true, "other-id", "cone-thread-id", true, "NPT", "NPT", "1/2", "1/2-14 NPT", "1/2-14 NPT"),
                ref pass, ref fail, "Другое скрытое коническое обозначение с собственным ThreadId остаётся в отчёте.");
            Check("TAPER-SUPPORT-FILTER-KEEPS-DIFFERENT-DESIGNATION", !TaperedThreadSupportPolicy.IsMatchingHiddenSupportFeature(
                false, true, true, "cone-thread-id", "cone-thread-id", true, "NPT", "NPT", "1/2", "1/2-14 NPT", "3/4-14 NPT"),
                ref pass, ref fail, "Несовпадение табличного обозначения не позволяет скрыть штатную резьбу из проверки.");
            Check("TAPER-SUPPORT-FILTER-KEEPS-NON-TAPERED", !TaperedThreadSupportPolicy.IsMatchingHiddenSupportFeature(
                false, false, true, "cone-thread-id", "cone-thread-id", true, "NPT", "NPT", "1/2", "1/2-14 NPT", "1/2-14 NPT"),
                ref pass, ref fail, "Обычная StandardThreadInfo не исключается правилами для конического support feature.");

            double taperRatio;
            Check("TAPER-STANDARD-NPT-RATIO", TaperedThreadGeometryPolicy.TryGetDiameterRatio("NPT", out taperRatio) &&
                Math.Abs(taperRatio - 1.0 / 16.0) < 1e-12, ref pass, ref fail,
                "NPT использует диаметральную конусность 1:16.");
            Check("TAPER-STANDARD-JIS-RATIO", TaperedThreadGeometryPolicy.TryGetDiameterRatio("JIS Taper", out taperRatio) &&
                Math.Abs(taperRatio - 1.0 / 16.0) < 1e-12, ref pass, ref fail,
                "JIS Taper использует диаметральную конусность 1:16.");
            Check("TAPER-STANDARD-UNKNOWN-REJECT", !TaperedThreadGeometryPolicy.TryGetDiameterRatio("ISO Metric", out taperRatio),
                ref pass, ref fail, "Неподдерживаемый стандарт не получает конусность по догадке.");
            Check("TAPER-ANGLE-NPT-60", TaperedThreadGeometryPolicy.TryGetThreadAngleDegrees("NPT", out double nptAngle) && Math.Abs(nptAngle - 60.0) < 1e-12,
                ref pass, ref fail, "Физический профиль NPT использует включённый угол 60°.");
            Check("TAPER-ANGLE-JIS-55", TaperedThreadGeometryPolicy.TryGetThreadAngleDegrees("JIS Taper", out double jisAngle) && Math.Abs(jisAngle - 55.0) < 1e-12,
                ref pass, ref fail, "Физический профиль JIS Taper использует включённый угол 55°.");
            Check("TAPER-ANGLE-UNKNOWN-REJECT", !TaperedThreadGeometryPolicy.TryGetThreadAngleDegrees("ISO Metric", out double unknownAngle),
                ref pass, ref fail, "Неизвестный угол профиля не подменяется предположением.");
            Check("TAPER-COIL-SIGN-EXTERNAL-GROWS", TaperedThreadGeometryPolicy.TryGetCoilTaperAngleRadians(1.0 / 16.0, true, out double externalCoilTaperAngle) &&
                externalCoilTaperAngle > 0.0 && Math.Abs(externalCoilTaperAngle - Math.Atan(1.0 / 32.0)) < 1e-12,
                ref pass, ref fail, "Физическая наружная спираль использует знак угла, соответствующий увеличению радиуса от выбранного малого торца к плечу.");
            Check("TAPER-COIL-SIGN-INTERNAL-SHRINKS", TaperedThreadGeometryPolicy.TryGetCoilTaperAngleRadians(1.0 / 16.0, false, out double internalCoilTaperAngle) &&
                internalCoilTaperAngle < 0.0 && Math.Abs(internalCoilTaperAngle + Math.Atan(1.0 / 32.0)) < 1e-12,
                ref pass, ref fail, "Физическая внутренняя спираль использует противоположный знак для сужения отверстия внутрь.");
            Check("TAPER-COIL-SIGN-INVALID-REJECT", !TaperedThreadGeometryPolicy.TryGetCoilTaperAngleRadians(double.NaN, true, out double invalidCoilTaperAngle),
                ref pass, ref fail, "Некорректная конусность не даёт построить спираль с углом по умолчанию.");
            Check("TAPER-RUNOUT-END-SHORTENS-CORE", TaperedThreadGeometryPolicy.TryGetRunoutStationsCm(
                0.0, 2.0, 0.2, 1.0, false, true, out double runoutEndCoreStart, out double runoutEndCoreEnd,
                out double runoutEndLength, out string runoutEndError) &&
                Math.Abs(runoutEndLength - 0.2) < 1e-12 && Math.Abs(runoutEndCoreStart) < 1e-12 &&
                Math.Abs(runoutEndCoreEnd - 1.8) < 1e-12,
                ref pass, ref fail, "Один конечный сбег укорачивает полноразмерную часть ровно на min(число шагов, 45% интервала).");
            Check("TAPER-RUNOUT-BOTH-ENDS-KEEP-CORE", TaperedThreadGeometryPolicy.TryGetRunoutStationsCm(
                1.0, 3.0, 0.2, 2.0, true, true, out double runoutBothStart, out double runoutBothEnd,
                out double runoutBothLength, out string runoutBothError) &&
                runoutBothStart > 1.0 && runoutBothEnd < 3.0 && runoutBothEnd - runoutBothStart > 0.2,
                ref pass, ref fail, "Два сбега оставляют между собой положительную полноразмерную винтовую часть.");
            Check("TAPER-RUNOUT-NO-FADE-PRESERVES-INTERVAL", TaperedThreadGeometryPolicy.TryGetRunoutStationsCm(
                0.5, 2.5, 0.2, 1.0, false, false, out double runoutNoneStart, out double runoutNoneEnd,
                out double runoutNoneLength, out string runoutNoneError) &&
                Math.Abs(runoutNoneStart - 0.5) < 1e-12 && Math.Abs(runoutNoneEnd - 2.5) < 1e-12 && runoutNoneLength == 0.0,
                ref pass, ref fail, "Если нет ни начального, ни конечного сбега, полная длина конической винтовой части сохраняется.");
            Check("TAPER-RUNOUT-TOO-SHORT-REJECT", !TaperedThreadGeometryPolicy.TryGetRunoutStationsCm(
                0.0, 0.18, 0.2, 1.0, false, true, out double runoutShortStart, out double runoutShortEnd,
                out double runoutShortLength, out string runoutShortError),
                ref pass, ref fail, "Слишком короткий участок отклоняется вместо схлопывания основного Coil.");
            Check("TAPER-RUNOUT-ZERO-STEPS-REJECT", !TaperedThreadGeometryPolicy.TryGetRunoutStationsCm(
                0.0, 2.0, 0.2, 0.0, false, true, out double runoutZeroStart, out double runoutZeroEnd,
                out double runoutZeroLength, out string runoutZeroError),
                ref pass, ref fail, "Запрошенный сбег с нулевым числом шагов отклоняется до начала геометрических операций.");
            Check("TAPER-RUNOUT-DENSITY-SMOOTH-BOUNDED", TaperedThreadGeometryPolicy.TryGetRunoutSectionsPerTurn(
                1.0, 0.01, out int smoothRunoutSections, out string smoothRunoutDensityError) &&
                smoothRunoutSections >= 14 && smoothRunoutSections <= 18,
                ref pass, ref fail, "Единственный поддерживаемый конический сбег использует ограниченную плотность 14–18 сечений на оборот.");
            Check("TAPER-RUNOUT-DENSITY-INVALID-REJECT", !TaperedThreadGeometryPolicy.TryGetRunoutSectionsPerTurn(
                double.NaN, 0.01, out int invalidRunoutSections, out string invalidRunoutDensityError),
                ref pass, ref fail, "Некорректный локальный радиус отклоняется до создания Loft.");
            int fallbackRunoutSegments;
            string fallbackRunoutError;
            Check("TAPER-RUNOUT-FALLBACK-SMOOTH-BOUNDED", TaperedThreadGeometryPolicy.TryGetFallbackRunoutSegmentCount(
                0.6, 0.2, out fallbackRunoutSegments, out fallbackRunoutError) && fallbackRunoutSegments == 32,
                ref pass, ref fail, "Резервный сегментный Coil использует 12 сегментов на оборот, ограниченных максимумом 32.");
            Check("TAPER-RUNOUT-FALLBACK-INVALID-REJECT", !TaperedThreadGeometryPolicy.TryGetFallbackRunoutSegmentCount(
                0.0, 0.2, out fallbackRunoutSegments, out fallbackRunoutError),
                ref pass, ref fail, "Нулевая длина сбега отклоняется до создания резервных Coil.");
            Check("TAPER-CHAMFER-DISABLED-ACCEPTS-NO-CUT", TaperedThreadGeometryPolicy.TryValidateChamfer(
                0, 0.0, 0.0, 3.0, 1.0, 0.9, true, false, false, out string taperChamferOffError),
                ref pass, ref fail, "При выключенной конической фаске не требуется радиальная глубина фаски.");
            Check("TAPER-CHAMFER-START-ACCEPTS-VALID", TaperedThreadGeometryPolicy.TryValidateChamfer(
                1, 1.0, 0.0, 3.0, 1.0, 0.9, true, false, false, out string taperChamferStartError),
                ref pass, ref fail, "Наружная круговая фаска 1 мм проходит пред-проверку на валидном коническом интервале.");
            Check("TAPER-CHAMFER-BOTH-ENDS-FIT", TaperedThreadGeometryPolicy.TryValidateChamfer(
                3, 1.0, 0.0, 3.0, 1.0, 0.9, true, false, false, out string taperChamferBothError),
                ref pass, ref fail, "Две конические фаски разрешены, только если обе помещаются на интервале.");
            Check("TAPER-CHAMFER-REJECTS-TOO-LARGE-RADIUS", !TaperedThreadGeometryPolicy.TryValidateChamfer(
                1, 11.0, 0.0, 3.0, 1.0, 0.9, true, false, false, out string taperChamferLargeError),
                ref pass, ref fail, "Наружная фаска не может достигать или превышать радиус конуса.");
            Check("TAPER-CHAMFER-REJECTS-SHOULDER", !TaperedThreadGeometryPolicy.TryValidateChamfer(
                1, 1.0, 0.0, 3.0, 1.0, 0.9, true, true, false, out string taperChamferShoulderError),
                ref pass, ref fail, "Фаска у упорного/вогнутого ребра блокируется до модификации модели.");
            Check("TAPER-CHAMFER-REJECTS-BOTH-TOO-CLOSE", !TaperedThreadGeometryPolicy.TryValidateChamfer(
                3, 9.0, 0.0, 1.5, 1.0, 0.9, true, false, false, out string taperChamferBothShortError),
                ref pass, ref fail, "Две фаски не допускаются, если их суммарный размер не помещается на коническом участке.");
            Check("TAPER-FOLDER-NPT-NATIVE-NAME", ThreadFolderNamePolicy.BuildTaperedThreadFolderName("NPT", "1/2 - 14 NPT x 18.796mm", "1/2-14", 1, true) ==
                "Резьба — 1/2 - 14 NPT x 18.796mm · 1 заход · Правая (R)", ref pass, ref fail,
                "Все операции конической NPT получают одну папку с полным обозначением, возвращённым таблицей Inventor.");
            Check("TAPER-FOLDER-JIS-LEFT-FALLBACK", ThreadFolderNamePolicy.BuildTaperedThreadFolderName("JIS Taper", "", "PT1/2", 1, false) ==
                "Резьба — JIS Taper · PT1/2 · 1 заход · Левая (L)", ref pass, ref fail,
                "При отсутствии читаемого обозначения JIS папка использует ключ таблицы и сохраняет направление.");
            Check("TAPER-PITCH-NPT-27-TPI", TaperedThreadGeometryPolicy.TryResolvePitchAndDepthMm(false, 0.0, "27", 0.0296,
                out double taperPitchMmTest, out double taperDepthMmTest, out string taperPitchError) &&
                Math.Abs(taperPitchMmTest - 25.4 / 27.0) < 1e-9 && Math.Abs(taperDepthMmTest - 0.0296 * 25.4) < 1e-9,
                ref pass, ref fail, "Дюймовая NPT получает шаг 25,4/TPI и высоту профиля из ThreadTable, а не от старого ISO-поля.");
            Check("TAPER-PITCH-NPT-HALF-14-TPI", TaperedThreadGeometryPolicy.TryResolvePitchAndDepthMm(false, 0.0, "14", 0.05714,
                out double taperHalfPitchMm, out double taperHalfDepthMm, out string taperHalfPitchError) &&
                Math.Abs(taperHalfPitchMm - 25.4 / 14.0) < 1e-9 && Math.Abs(taperHalfDepthMm - 0.05714 * 25.4) < 1e-9,
                ref pass, ref fail, "1/2-14 NPT использует табличные 14 TPI (шаг ≈1,814 мм), а не оставшийся шаг M22×1,5.");
            Check("TAPER-PHYSICAL-GROOVE-FITS-PITCH", TaperedThreadGeometryPolicy.TryGetPhysicalGrooveDimensionsMm(25.4 / 27.0, 0.0296 * 25.4,
                out double taperTopWidthMmTest, out double taperRootWidthMmTest, out string taperGrooveError) &&
                taperTopWidthMmTest > taperRootWidthMmTest && taperRootWidthMmTest > 0.01 * (25.4 / 27.0),
                ref pass, ref fail, "Физический профиль NPT имеет положительную ширину впадины и помещается в шаг.");
            Check("TAPER-PHYSICAL-GROOVE-JIS-55", TaperedThreadGeometryPolicy.TryGetPhysicalGrooveDimensionsMm(25.4 / 27.0, 0.0296 * 25.4, 55.0,
                out double jisTopWidth, out double jisRootWidth, out string jisGrooveError) &&
                jisTopWidth > jisRootWidth && jisRootWidth > taperRootWidthMmTest,
                ref pass, ref fail, "При той же таблице высоты профиль 55° шире во впадине, чем профиль NPT 60°.");
            Check("TAPER-PHYSICAL-GROOVE-KEEPS-CREST-LAND", TaperedThreadGeometryPolicy.TryGetPhysicalGrooveDimensionsMm(25.4 / 11.5, 0.8 * (25.4 / 11.5), 60.0,
                out double nptLargeTopWidth, out double nptLargeRootWidth, out string nptLargeGrooveError) &&
                Math.Abs(nptLargeTopWidth / (25.4 / 11.5) - 0.962) < 1e-9 &&
                (25.4 / 11.5 - nptLargeTopWidth) >= 0.03 * (25.4 / 11.5) &&
                nptLargeRootWidth >= 0.035 * (25.4 / 11.5),
                ref pass, ref fail, "Физическая NPT-канавка не занимает почти весь шаг: остаётся заметная площадка вершины и положительная площадка впадины.");
            Check("TAPER-THIN-WALL-BLOCKS-STOCK-CHANGE-PLUS-GROOVE", !ThreadWallThicknessPolicy.HasSafeRemainingWall(0.35, -0.28, 0.1767, 0.22087,
                out double thinTaperRemainingCm, out double thinTaperRequiredCm) && thinTaperRemainingCm < thinTaperRequiredCm,
                ref pass, ref fail, "Коническая резьба блокируется, если предварительное изменение радиуса и профиль канавки оставят стенку ниже минимума.");
            Check("TAPER-THICK-WALL-ALLOWS-STANDARD-GROOVE", ThreadWallThicknessPolicy.HasSafeRemainingWall(0.60, -0.10, 0.11767, 0.22087,
                out double thickTaperRemainingCm, out double thickTaperRequiredCm) && thickTaperRemainingCm >= thickTaperRequiredCm,
                ref pass, ref fail, "Достаточная исходная стенка допускает стандартную глубину конического профиля.");
            Check("TAPER-WALL-CHAMFER-USES-MAX-LOCAL-DEPTH", Math.Abs(ThreadWallThicknessPolicy.EffectiveCutDepthCm(
                0.08, true, 0.12) - 0.12) < 1e-12 && Math.Abs(ThreadWallThicknessPolicy.EffectiveCutDepthCm(
                0.14, true, 0.12) - 0.14) < 1e-12,
                ref pass, ref fail, "Коническая проверка стенки учитывает максимум локальной глубины профиля/фаски, а не их сумму.");
            Check("TAPER-WALL-SOLID-SHAFT-RAY-CAPPED", Math.Abs(ThreadWallThicknessPolicy.EffectiveRadialWallThicknessCm(true, 5.2, 2.6) - 2.6) < 1e-12,
                ref pass, ref fail, "Для сплошного наружного вала луч через весь диаметр не выдаётся за толщину стенки: используется радиальная глубина до оси.");
            Check("TAPER-WALL-THIN-OUTER-TUBE-PRESERVED", Math.Abs(ThreadWallThicknessPolicy.EffectiveRadialWallThicknessCm(true, 0.18, 2.6) - 0.18) < 1e-12,
                ref pass, ref fail, "Для тонкостенной наружной трубы реальная малая толщина до внутренней стенки не маскируется радиусом.");
            Check("TAPER-WALL-INTERNAL-RAY-PRESERVED", Math.Abs(ThreadWallThicknessPolicy.EffectiveRadialWallThicknessCm(false, 0.35, 1.0) - 0.35) < 1e-12,
                ref pass, ref fail, "Для внутреннего отверстия луч сохраняет прямое измерение стенки до наружной поверхности.");
            Check("TAPER-WALL-EXTERNAL-RAY-USES-FIRST-MATERIAL-INTERVAL", ThreadWallThicknessPolicy.TryGetFirstDistinctIntersectionIntervalCm(
                new[] { 0.005, 0.0050000001, 0.355, 0.905 }, out double externalWallIntervalCm) &&
                Math.Abs(externalWallIntervalCm - 0.35) < 1e-9,
                ref pass, ref fail, "Для наружной стенки используется расстояние между внешней поверхностью и ближайшей внутренней границей, а совпавшие реберные попадания сливаются.");
            Check("TAPER-WALL-EXTERNAL-OUTSIDE-RAY-REJECTS-ONE-HIT", !ThreadWallThicknessPolicy.TryGetFirstDistinctIntersectionIntervalCm(
                new[] { 0.005, 0.0050000001 }, out double externalMissingWallIntervalCm),
                ref pass, ref fail, "При старте луча снаружи одной точки недостаточно для определения интервала материала.");
            Check("TAPER-WALL-EXTERNAL-SOLID-SHAFT-SINGLE-HIT-ALLOWED", ThreadWallThicknessPolicy.TryGetExternalRadialWallThicknessCm(
                new[] { 5.1995 }, 0.0005, 2.6, out double externalSolidShaftWallCm) && Math.Abs(externalSolidShaftWallCm - 2.6) < 1e-9,
                ref pass, ref fail, "Луч, начатый внутри сплошного вала, может дать одну противоположную границу; оценка ограничивается радиусом, а не полным диаметром.");
            Check("TAPER-WALL-EXTERNAL-THIN-TUBE-SINGLE-HIT-PRESERVED", ThreadWallThicknessPolicy.TryGetExternalRadialWallThicknessCm(
                new[] { 0.1795, 5.0 }, 0.0005, 2.6, out double externalThinTubeWallCm) && Math.Abs(externalThinTubeWallCm - 0.18) < 1e-9,
                ref pass, ref fail, "Первое пересечение изнутри сохраняет фактическую тонкую стенку трубы и не подменяет её радиусом заготовки.");
            Check("TAPER-WALL-EXTERNAL-INSIDE-RAY-REJECTS-NO-HITS", !ThreadWallThicknessPolicy.TryGetExternalRadialWallThicknessCm(
                Array.Empty<double>(), 0.0005, 2.6, out double externalNoHitWallCm),
                ref pass, ref fail, "Если луч, начатый внутри материала, не даёт пересечений, проверка по-прежнему закрывается безопасным отказом.");
            Check("TAPER-DIAMETER-MISMATCH-DETECT", !TaperedThreadGeometryPolicy.IsStartingDiameterCompatible(22.0, 7.938, out double taperToleranceReject),
                ref pass, ref fail, "Сильно различающийся диаметр отмечается как требующий предупреждения; UI получает согласие пользователя вместо молчаливой подмены.");
            Check("TAPER-DIAMETER-NPT-HALF-NEAR", TaperedThreadGeometryPolicy.IsStartingDiameterCompatible(22.0, 21.336, out double taperToleranceMatch),
                ref pass, ref fail, "Диаметр Ø22 близок к типоразмеру около 1/2 NPT, но выбор всё равно подтверждается предупреждением изменения геометрии.");
            Check("TAPER-CLOSEST-DESIGNATION-22MM", TaperedThreadGeometryPolicy.FindClosestDesignation(22.0,
                new[] { Tuple.Create("1/16", 7.938), Tuple.Create("1/4", 13.716), Tuple.Create("3/8", 17.145), Tuple.Create("1/2", 21.336), Tuple.Create("3/4", 26.67), Tuple.Create("1", 33.401) }) == "1/2",
                ref pass, ref fail, "Для цилиндра Ø22 мм из предложенных таблицей NPT размеров выбирается ближайший большой подходящий типоразмер, а не первая строка 1/16.");
            Check("TAPER-CLOSEST-DESIGNATION-INVALID-REJECT", TaperedThreadGeometryPolicy.FindClosestDesignation(double.NaN,
                new[] { Tuple.Create("1/2", 19.885) }) == null &&
                TaperedThreadGeometryPolicy.FindClosestDesignation(22.0, Array.Empty<Tuple<string, double>>()) == null,
                ref pass, ref fail, "Подбор типа-размера отклоняет недопустимый диаметр и пустой список кандидатов.");

            double hostLengthCm;
            string taperLengthError;
            Check("TAPER-HOST-LENGTH-FULL", TaperedThreadGeometryPolicy.TryGetHostLengthCm(true, 4.0, 12.0, 5.0,
                out hostLengthCm, out taperLengthError) && Math.Abs(hostLengthCm - 4.0) < 1e-12,
                ref pass, ref fail, "Полный режим готовит конус от исходного ребра до дальнего торца.");
            Check("TAPER-HOST-LENGTH-LIMITED-OFFSET-ONCE", TaperedThreadGeometryPolicy.TryGetHostLengthCm(false, 4.0, 12.0, 5.0,
                out hostLengthCm, out taperLengthError) && Math.Abs(hostLengthCm - 1.7) < 1e-12,
                ref pass, ref fail, "Ограниченный конус включает отступ и длину резьбы ровно один раз.");
            Check("TAPER-HOST-LENGTH-OVERFLOW-REJECT", !TaperedThreadGeometryPolicy.TryGetHostLengthCm(false, 2.0, 13.0, 8.0,
                out hostLengthCm, out taperLengthError), ref pass, ref fail,
                "Длина конического участка за пределами исходной поверхности отклоняется.");

            Check("TAPER-END-RADIUS-CALC", TaperedThreadGeometryPolicy.TryGetEndRadiusCm(1.0, 3.2, 1.0 / 16.0,
                out hostLengthCm) && Math.Abs(hostLengthCm - 0.9) < 1e-12,
                ref pass, ref fail, "Изменение радиуса равно половине изменения диаметра при конусности 1:16.");
            Check("TAPER-END-RADIUS-INVALID-REJECT", !TaperedThreadGeometryPolicy.TryGetEndRadiusCm(0.01, 0.32, 1.0 / 16.0,
                out hostLengthCm), ref pass, ref fail, "Нулевой конечный радиус отклоняется до изменения модели.");
            Check("TAPER-EXTERNAL-DIAMETER-GROWS-TO-SHOULDER",
                TaperedThreadGeometryPolicy.TryGetEndRadiusCm(0.9668, 3.2, 1.0 / 16.0, true, out double externalEndRadius) &&
                Math.Abs(externalEndRadius - 1.0668) < 1e-9,
                ref pass, ref fail, "Наружная резьба от свободного малого торца увеличивается к плечу.");
            Check("TAPER-INTERNAL-DIAMETER-SHRINKS-INWARD",
                TaperedThreadGeometryPolicy.TryGetEndRadiusCm(1.0, 3.2, 1.0 / 16.0, false, out double internalEndRadius) &&
                Math.Abs(internalEndRadius - 0.9) < 1e-9,
                ref pass, ref fail, "Внутренняя резьба от широкой горловины сужается внутрь.");
            double standardStartRadius;
            Check("TAPER-START-RADIUS-EXTERNAL-SMALL-END", TaperedThreadGeometryPolicy.TryGetStandardStartRadiusCm(true, true,
                21.336, 19.885, 0.0, 3.2, 0.0, 1.0 / 16.0, out standardStartRadius) &&
                Math.Abs(standardStartRadius - 0.9668) < 1e-9,
                ref pass, ref fail, "Наружная резьба использует OutsidePipeDiameter, затем растёт от малого конца к плечу.");
            Check("TAPER-START-RADIUS-EXTERNAL-FALLBACK", TaperedThreadGeometryPolicy.TryGetStandardStartRadiusCm(true, true,
                double.NaN, 20.0, 0.0, 3.2, 0.0, 1.0 / 16.0, out standardStartRadius) &&
                Math.Abs(standardStartRadius - 0.9) < 1e-9,
                ref pass, ref fail, "NominalExternalDiameter используется только как fallback при отсутствии OutsidePipeDiameter.");
            Check("TAPER-START-RADIUS-EXTERNAL-INCH", TaperedThreadGeometryPolicy.TryGetStandardStartRadiusCm(true, false,
                0.840, 0.783, 0.0, 3.2, 0.0, 1.0 / 16.0, out standardStartRadius) &&
                Math.Abs(standardStartRadius - 0.9668) < 1e-9,
                ref pass, ref fail, "Дюймовой OutsidePipeDiameter переводится в мм до построения малого конца.");
            Check("TAPER-START-RADIUS-EXTERNAL-OFFSET-INCLUDED-ONCE", TaperedThreadGeometryPolicy.TryGetStandardStartRadiusCm(true, true,
                21.336, 19.885, 0.0, 3.2, 2.0, 1.0 / 16.0, out standardStartRadius) &&
                Math.Abs(standardStartRadius - 0.9668) < 1e-9,
                ref pass, ref fail, "Отступ включён в длину конуса ровно один раз.");
            Check("TAPER-START-RADIUS-INTERNAL-LARGE-END", TaperedThreadGeometryPolicy.TryGetStandardStartRadiusCm(false, true,
                0.0, 0.0, 10.0, 3.2, 0.0, 1.0 / 16.0, out standardStartRadius) &&
                Math.Abs(standardStartRadius - 0.6) < 1e-9,
                ref pass, ref fail, "Для внутреннего режима табличный малый конец увеличивается на конусность по длине.");
            Check("TAPER-START-RADIUS-REJECT-MISSING-INTERNAL", !TaperedThreadGeometryPolicy.TryGetStandardStartRadiusCm(false, true,
                0.0, 0.0, double.NaN, 3.2, 0.0, 1.0 / 16.0, out standardStartRadius),
                ref pass, ref fail, "Неизвестный внутренний табличный диаметр отклоняется, а не угадывается.");
            Check("TAPER-FREE-EXTERNAL-PRESERVES-FAR-END", TaperedThreadGeometryPolicy.TryGetStartRadiusFromEndCm(
                true, 2.6, 3.0, 1.0 / 16.0, out double freeExternalStart) &&
                Math.Abs(freeExternalStart - 2.50625) < 1e-12,
                ref pass, ref fail, "Свободный наружный режим сохраняет дальний диаметр и уменьшает входной радиус на L/32.");
            Check("TAPER-FREE-INTERNAL-PRESERVES-FAR-END", TaperedThreadGeometryPolicy.TryGetStartRadiusFromEndCm(
                false, 2.6, 3.0, 1.0 / 16.0, out double freeInternalStart) &&
                Math.Abs(freeInternalStart - 2.69375) < 1e-12,
                ref pass, ref fail, "Свободный внутренний режим сохраняет дальний диаметр и увеличивает входной радиус на L/32.");
            Check("TAPER-FREE-INVALID-RADIUS-REJECT", !TaperedThreadGeometryPolicy.TryGetStartRadiusFromEndCm(
                true, 0.0, 3.0, 1.0 / 16.0, out double freeInvalidStart),
                ref pass, ref fail, "Свободный режим не принимает нулевой исходный радиус.");
            bool joinOperation;
            string taperOperationError;
            Check("TAPER-EXTERNAL-CUT", TaperedThreadGeometryPolicy.TryChooseJoinOperation(true, 1.0, 1.0, 0.9,
                out joinOperation, out taperOperationError) && !joinOperation,
                ref pass, ref fail, "Наружный табличный профиль вырезается из заготовки совпадающего старта.");
            Check("TAPER-INTERNAL-JOIN", TaperedThreadGeometryPolicy.TryChooseJoinOperation(false, 1.0, 1.0, 0.9,
                out joinOperation, out taperOperationError) && joinOperation,
                ref pass, ref fail, "Внутренний профиль добавляет материал и сужает отверстие по конусу.");
            Check("TAPER-OUTER-UNDERSIZED-STOCK-JOIN", TaperedThreadGeometryPolicy.TryChooseJoinOperation(true, 0.8, 1.0, 0.9,
                out joinOperation, out taperOperationError) && joinOperation,
                ref pass, ref fail, "Недоразмерный наружный цилиндр можно нарастить до стандартного конуса.");
            Check("TAPER-INNER-UNDERSIZED-BORE-CUT", TaperedThreadGeometryPolicy.TryChooseJoinOperation(false, 0.8, 1.0, 0.9,
                out joinOperation, out taperOperationError) && !joinOperation,
                ref pass, ref fail, "Малое внутреннее отверстие можно расточить до стандартного конуса.");
            Check("TAPER-SINGLE-OPERATION-CROSSING-REQUIRES-SPLIT", !TaperedThreadGeometryPolicy.TryChooseJoinOperation(true, 0.95, 1.0, 0.9,
                out joinOperation, out taperOperationError),
                ref pass, ref fail, "Один булев Cut/Join не может обработать пересечение; runtime должен разбить конус на два участка.");
            Check("TAPER-EXTERNAL-CROSSING-STATION", TaperedThreadGeometryPolicy.TryGetStockCrossingStationCm(1.55, 1.4567, 1.5817, 4.0,
                out bool externalCrosses, out double externalCrossing, out string externalCrossingError) && externalCrosses &&
                Math.Abs(externalCrossing - 2.9856) < 1e-3 &&
                !TaperedThreadGeometryPolicy.RequiresJoinForRadialChange(true, 1.55, 1.4567) &&
                TaperedThreadGeometryPolicy.RequiresJoinForRadialChange(true, 1.55, 1.5817),
                ref pass, ref fail, "Наружный конус, пересекающий Ø31 заготовку, делится на Cut до пересечения и Join после него.");
            Check("TAPER-INTERNAL-CROSSING-STATION", TaperedThreadGeometryPolicy.TryGetStockCrossingStationCm(2.25, 2.2864, 2.19265, 4.0,
                out bool internalCrosses, out double internalCrossing, out string internalCrossingError) && internalCrosses &&
                Math.Abs(internalCrossing - (0.0364 * 4.0 / (2.2864 - 2.19265))) < 1e-6 &&
                !TaperedThreadGeometryPolicy.RequiresJoinForRadialChange(false, 2.25, 2.2864) &&
                TaperedThreadGeometryPolicy.RequiresJoinForRadialChange(false, 2.25, 2.19265),
                ref pass, ref fail, "Внутренний конус, пересекающий Ø45 отверстие, делится на Cut для входа и Join для сужения.");
            Check("TAPER-NON-CROSSING-STAYS-SINGLE-OP", TaperedThreadGeometryPolicy.TryGetStockCrossingStationCm(1.2, 1.0, 0.9, 4.0,
                out bool noCross, out double noCrossStation, out string noCrossError) && !noCross,
                ref pass, ref fail, "Если заготовка целиком толще или тоньше конуса, остаётся одна булева операция.");
            Check("TAPER-EXTERNAL-INCREASING-CONE-CUT", TaperedThreadGeometryPolicy.TryChooseJoinOperation(true, 1.1, 0.9, 1.0,
                out joinOperation, out taperOperationError) && !joinOperation,
                ref pass, ref fail, "Для растущего наружного конуса более крупная заготовка обрабатывается вырезанием.");
            Check("TAPER-INTERNAL-DECREASING-CONE-JOIN", TaperedThreadGeometryPolicy.TryChooseJoinOperation(false, 1.1, 1.0, 0.9,
                out joinOperation, out taperOperationError) && joinOperation,
                ref pass, ref fail, "Для сужающегося внутреннего отверстия larger stock radius приводит к добавлению материала.");
            Check("TAPER-INTERNAL-INCREASING-BULK-CUT", TaperedThreadGeometryPolicy.TryChooseJoinOperation(false, 0.8, 0.9, 1.0,
                out joinOperation, out taperOperationError) && !joinOperation,
                ref pass, ref fail, "Выбор булевой операции не зависит от того, растёт или уменьшается конус.");

            ThreadMetadataRecord original = new ThreadMetadataRecord
            {
                SchemaVersion = 1,
                ThreadId = "0123456789abcdef0123456789abcdef",
                ProducerVersion = "2.0.0-preview.15-alpha3",
                ObjectCount = 17,
                Parameters = new ThreadParametersSnapshot
                {
                    Standard = 3,
                    SizeName = "Tr20×4",
                    PitchMm = 4.0,
                    NominalDiaMm = 20.0,
                    Starts = 2,
                    ClearanceMm = 0.2,
                    External = true,
                    Round = true,
                    Smooth = true,
                    SimplifiedRunout = false,
                    RunSteps = 3.5,
                    Mirror = false,
                    SortThreadsIntoFolders = true,
                    FullLength = false,
                    LengthMm = 30.0,
                    OffsetMm = 1.25,
                    RunOut = false,
                    RightHand = true,
                    ChamferMode = 3,
                    ChamferMm = 0.75,
                    TaperThreadDepthMm = 0.75284,
                    TaperGeometryMode = 1,
                    TaperDisplayDesignation = "1/2 - 14 NPT x 18.796mm"
                },
                Target = new ThreadTargetSnapshot
                {
                    Center = new[] { 10.25, -4.5, 8.0 },
                    Axis = new[] { 0.0, 0.0, -1.0 },
                    RadiusCm = 1.0,
                    LengthCm = 6.2,
                    IsExternal = true,
                    BodyName = "Solid1",
                    StartIsShoulder = true,
                    EndIsShoulder = false
                }
            };

            Check("METADATA-VALID-RECORD", original.IsValid(), ref pass, ref fail,
                "Полная запись метаданных проходит проверку схемы и геометрического снимка.");

            string json = JsonSerializer.Serialize(original);
            ThreadMetadataRecord restored = JsonSerializer.Deserialize<ThreadMetadataRecord>(json);
            Check("METADATA-JSON-ROUNDTRIP", restored != null && restored.IsValid(), ref pass, ref fail,
                "JSON-запись можно восстановить и повторно проверить.");
            Check("METADATA-PARAMETERS-ROUNDTRIP", restored != null && restored.Parameters != null &&
                restored.Parameters.Standard == original.Parameters.Standard &&
                restored.Parameters.SizeName == original.Parameters.SizeName &&
                restored.Parameters.PitchMm == original.Parameters.PitchMm &&
                restored.Parameters.NominalDiaMm == original.Parameters.NominalDiaMm &&
                restored.Parameters.TaperThreadDepthMm == original.Parameters.TaperThreadDepthMm &&
                restored.Parameters.TaperDisplayDesignation == original.Parameters.TaperDisplayDesignation &&
                restored.Parameters.TaperGeometryMode == original.Parameters.TaperGeometryMode &&
                restored.Parameters.Starts == original.Parameters.Starts &&
                restored.Parameters.ClearanceMm == original.Parameters.ClearanceMm &&
                restored.Parameters.External == original.Parameters.External &&
                restored.Parameters.Round == original.Parameters.Round &&
                restored.Parameters.Smooth == original.Parameters.Smooth &&
                restored.Parameters.SimplifiedRunout == original.Parameters.SimplifiedRunout &&
                restored.Parameters.RunSteps == original.Parameters.RunSteps &&
                restored.Parameters.Mirror == original.Parameters.Mirror &&
                restored.Parameters.SortThreadsIntoFolders == original.Parameters.SortThreadsIntoFolders &&
                restored.Parameters.FullLength == original.Parameters.FullLength &&
                restored.Parameters.LengthMm == original.Parameters.LengthMm &&
                restored.Parameters.OffsetMm == original.Parameters.OffsetMm &&
                restored.Parameters.RunOut == original.Parameters.RunOut &&
                restored.Parameters.RightHand == original.Parameters.RightHand &&
                restored.Parameters.ChamferMode == original.Parameters.ChamferMode &&
                restored.Parameters.ChamferMm == original.Parameters.ChamferMm,
                ref pass, ref fail, "Все поля параметров сохраняются без изменения.");
            Check("METADATA-TARGET-ROUNDTRIP", restored != null && restored.Target != null &&
                restored.Target.Center != null && restored.Target.Center.Length == 3 &&
                restored.Target.Center[0] == original.Target.Center[0] &&
                restored.Target.Center[1] == original.Target.Center[1] &&
                restored.Target.Center[2] == original.Target.Center[2] &&
                restored.Target.Axis != null && restored.Target.Axis.Length == 3 &&
                restored.Target.Axis[0] == original.Target.Axis[0] &&
                restored.Target.Axis[1] == original.Target.Axis[1] &&
                restored.Target.Axis[2] == original.Target.Axis[2] &&
                restored.Target.RadiusCm == original.Target.RadiusCm &&
                restored.Target.LengthCm == original.Target.LengthCm &&
                restored.Target.IsExternal == original.Target.IsExternal &&
                restored.Target.BodyName == original.Target.BodyName &&
                restored.Target.StartIsShoulder == original.Target.StartIsShoulder &&
                restored.Target.EndIsShoulder == original.Target.EndIsShoulder,
                ref pass, ref fail, "Геометрический снимок восстанавливается с исходными единицами и направлением оси.");

            ThreadMetadataRecord incomplete = new ThreadMetadataRecord
            {
                ThreadId = "incomplete",
                ObjectCount = 1,
                Parameters = original.Parameters,
                Target = new ThreadTargetSnapshot
                {
                    Center = new[] { 0.0, 0.0, 0.0 },
                    Axis = new[] { 0.0, 0.0, 2.0 },
                    RadiusCm = 1.0,
                    LengthCm = 1.0,
                    IsExternal = true,
                    BodyName = "Solid1"
                }
            };
            Check("METADATA-REJECT-NONUNIT-AXIS", !incomplete.IsValid(), ref pass, ref fail,
                "Повреждённая или не нормализованная ось не принимается.");

            ThreadMetadataRecord mismatchedType = new ThreadMetadataRecord
            {
                SchemaVersion = 1,
                ThreadId = "mismatch",
                ProducerVersion = "test",
                ObjectCount = 1,
                Parameters = new ThreadParametersSnapshot { Standard = 0, SizeName = "M10×1,5", PitchMm = 1.5, NominalDiaMm = 10.0, Starts = 1, External = false },
                Target = new ThreadTargetSnapshot { Center = new[] { 0.0, 0.0, 0.0 }, Axis = new[] { 0.0, 0.0, 1.0 }, RadiusCm = 0.5, LengthCm = 2.0, IsExternal = true, BodyName = "Solid1" }
            };
            Check("METADATA-REJECT-TYPE-MISMATCH", !mismatchedType.IsValid(), ref pass, ref fail,
                "Тип параметров не может расходиться с типом сохранённой цилиндрической поверхности.");

            ThreadMetadataRecord offsetAtEnd = CloneRecord(original);
            offsetAtEnd.Parameters.FullLength = true;
            offsetAtEnd.Parameters.OffsetMm = offsetAtEnd.Target.LengthCm * 10.0;
            Check("METADATA-REJECT-OFFSET-AT-CYLINDER-END", !offsetAtEnd.IsValid(), ref pass, ref fail,
                "Отступ, достигающий конца исходного цилиндра, не допускается даже в режиме полной длины.");

            ThreadMetadataRecord zeroLimitedLength = CloneRecord(original);
            zeroLimitedLength.Parameters.FullLength = false;
            zeroLimitedLength.Parameters.LengthMm = 0.0;
            Check("METADATA-REJECT-ZERO-LIMITED-LENGTH", !zeroLimitedLength.IsValid(), ref pass, ref fail,
                "Ограниченная резьба с нулевой длиной не может считаться безопасно редактируемой.");

            ThreadMetadataRecord overflowingLength = CloneRecord(original);
            overflowingLength.Parameters.FullLength = false;
            overflowingLength.Parameters.LengthMm = overflowingLength.Target.LengthCm * 10.0 -
                overflowingLength.Parameters.OffsetMm + 0.01;
            Check("METADATA-REJECT-LIMITED-LENGTH-OVERFLOW", !overflowingLength.IsValid(), ref pass, ref fail,
                "Сохранённая ограниченная длина вместе с отступом не должна выходить за исходный цилиндр.");

            ThreadMetadataRecord boundaryLength = CloneRecord(original);
            boundaryLength.Parameters.FullLength = false;
            boundaryLength.Parameters.LengthMm = boundaryLength.Target.LengthCm * 10.0 -
                boundaryLength.Parameters.OffsetMm;
            Check("METADATA-ACCEPT-LIMITED-LENGTH-AT-BOUNDARY", boundaryLength.IsValid(), ref pass, ref fail,
                "Ограниченная резьба, точно заканчивающаяся на границе цилиндра, остаётся допустимой.");

            ThreadMetadataRecord fullLengthWithStaleManualLength = CloneRecord(original);
            fullLengthWithStaleManualLength.Parameters.FullLength = true;
            fullLengthWithStaleManualLength.Parameters.LengthMm = 0.0;
            Check("METADATA-FULL-LENGTH-IGNORES-MANUAL-LENGTH", fullLengthWithStaleManualLength.IsValid(), ref pass, ref fail,
                "В режиме полной длины сохранённое неактивное поле ограниченной длины не блокирует запись.");

            // Keep the preview extent policy pure and testable without Inventor COM.
            Check("PREVIEW-LENGTH-FULL", Math.Abs(ThreadPreviewLengthPolicy.ResolveLengthCm(true, 3.0, 5.0, 20.0) - 2.5) < 1e-9,
                ref pass, ref fail, "При полном режиме предпросмотр использует длину поверхности за вычетом отступа.");
            Check("PREVIEW-LENGTH-LIMITED", Math.Abs(ThreadPreviewLengthPolicy.ResolveLengthCm(false, 3.0, 5.0, 12.0) - 1.2) < 1e-9,
                ref pass, ref fail, "При выключенном полном режиме предпросмотр использует поле длины в мм.");
            Check("PREVIEW-LENGTH-OFFSET", Math.Abs(ThreadPreviewLengthPolicy.ResolveLengthCm(false, 3.0, 10.0, 15.0) - 1.5) < 1e-9,
                ref pass, ref fail, "Ограниченная длина начинается после указанного отступа.");
            Check("PREVIEW-LENGTH-REJECT-OVERFLOW", ThrowsInvalidOperation(() => ThreadPreviewLengthPolicy.ResolveLengthCm(false, 1.0, 0.0, 20.0)),
                ref pass, ref fail, "Отклоняется ограниченная длина, выходящая за поверхность.");
            Check("PREVIEW-LENGTH-REJECT-ZERO", ThrowsInvalidOperation(() => ThreadPreviewLengthPolicy.ResolveLengthCm(false, 3.0, 0.0, 0.0)),
                ref pass, ref fail, "Отклоняется нулевая длина предпросмотра.");

            // Native Inventor cosmetic ThreadFeatures are converted by the regular Helivanta
            // physical-geometry pipeline. Pure mapping rules are kept testable without COM.
            Check("NATIVE-THREAD-MM-TO-CM", NativeThreadConversionPolicy.NearlyEqual(
                NativeThreadConversionPolicy.MillimetersToDatabaseCentimeters(25.0), 2.5),
                ref pass, ref fail, "Глубина/смещение в мм переводятся в сантиметры базы Inventor.");
            Check("NATIVE-THREAD-CM-TO-MM", NativeThreadConversionPolicy.NearlyEqual(
                NativeThreadConversionPolicy.DatabaseCentimetersToMillimeters(1.25), 12.5),
                ref pass, ref fail, "Значения Parameter из базы Inventor отображаются в миллиметрах.");
            double nativeDepthMm, nativeOffsetMm, nativeLengthMm;
            string nativeLengthError;
            Check("NATIVE-LENGTH-FULL-DEPTH-ALLOWS-MISSING-DEPTH",
                NativeThreadConversionPolicy.TryResolveNativeThreadLengths(true, false, 0.0, true, 0.0, 2.5,
                    out nativeDepthMm, out nativeOffsetMm, out nativeLengthMm, out nativeLengthError) &&
                nativeDepthMm == 0.0 && nativeOffsetMm == 0.0 && Math.Abs(nativeLengthMm - 25.0) < 1e-9,
                ref pass, ref fail, "Полная штатная резьба может использовать длину цилиндра, если ThreadDepth Parameter недоступен.");
            Check("NATIVE-LENGTH-LIMITED-REQUIRES-DEPTH",
                !NativeThreadConversionPolicy.TryResolveNativeThreadLengths(false, false, 0.0, true, 0.0, 2.5,
                    out nativeDepthMm, out nativeOffsetMm, out nativeLengthMm, out nativeLengthError),
                ref pass, ref fail, "Ограниченная штатная резьба без ThreadDepth отклоняется до транзакции.");
            Check("NATIVE-LENGTH-MISSING-OFFSET-IS-ZERO",
                NativeThreadConversionPolicy.TryResolveNativeThreadLengths(false, true, 1.25, false, 0.0, 2.5,
                    out nativeDepthMm, out nativeOffsetMm, out nativeLengthMm, out nativeLengthError) &&
                Math.Abs(nativeDepthMm - 12.5) < 1e-9 && nativeOffsetMm == 0.0 && Math.Abs(nativeLengthMm - 12.5) < 1e-9,
                ref pass, ref fail, "Отсутствующий ThreadOffset трактуется как нулевое смещение, без разыменования null.");
            Check("NATIVE-LENGTH-REJECTS-NEGATIVE-OFFSET",
                !NativeThreadConversionPolicy.TryResolveNativeThreadLengths(true, false, 0.0, true, -0.1, 2.5,
                    out nativeDepthMm, out nativeOffsetMm, out nativeLengthMm, out nativeLengthError),
                ref pass, ref fail, "Отрицательное смещение штатной резьбы отклоняется до открытия транзакции.");
            // Reuse nativeDepthMm/nativeOffsetMm/nativeLengthMm/nativeLengthError declared above.
            double inferredStartStation;
            Check("NATIVE-START-EDGE-FALLBACK-FORWARD-STATION",
                NativeThreadConversionPolicy.TryResolveStartStation(new[] { 2.5, 0.0, 1.25 }, false, out inferredStartStation) &&
                Math.Abs(inferredStartStation - 0.0) < 1e-9,
                ref pass, ref fail, "Если StartEdge пуст, для обычного направления выбирается минимальная осевая позиция ThreadedFace.");
            Check("NATIVE-START-EDGE-FALLBACK-REVERSED-STATION",
                NativeThreadConversionPolicy.TryResolveStartStation(new[] { 2.5, 0.0, 1.25 }, true, out inferredStartStation) &&
                Math.Abs(inferredStartStation - 2.5) < 1e-9,
                ref pass, ref fail, "Для реверсированного направления выбирается максимальная осевая позиция ThreadedFace.");
            Check("NATIVE-START-EDGE-FALLBACK-REJECTS-EMPTY",
                !NativeThreadConversionPolicy.TryResolveStartStation(Array.Empty<double>(), false, out inferredStartStation),
                ref pass, ref fail, "Пустой набор границ ThreadedFace не даёт произвольно выбирать старт.");
            Check("NATIVE-START-EDGE-FALLBACK-REJECTS-NONFINITE",
                !NativeThreadConversionPolicy.TryResolveStartStation(new[] { 0.0, double.NaN }, false, out inferredStartStation),
                ref pass, ref fail, "Некорректные координаты границ ThreadedFace отклоняются.");

            Check("NATIVE-START-PREFERS-FREE-END-WHEN-NATIVE-START-IS-SHOULDER",
                NativeThreadConversionPolicy.ShouldReverseStartToPreferFreeEnd(true, false),
                ref pass, ref fail, "Если штатное начало оказалось у плеча, а противоположный край свободен, физическая резьба начинается со свободного края.");
            Check("NATIVE-START-PRESERVES-FREE-START",
                !NativeThreadConversionPolicy.ShouldReverseStartToPreferFreeEnd(false, true),
                ref pass, ref fail, "Уже выбранный свободный край остаётся началом, даже если противоположный конец является плечом.");
            Check("NATIVE-START-AMBIGUOUS-BOTH-SHOULDERS-DOES-NOT-FLIP",
                !NativeThreadConversionPolicy.ShouldReverseStartToPreferFreeEnd(true, true),
                ref pass, ref fail, "Если оба конца являются плечами, эвристика не меняет направление без однозначного свободного края.");

            Check("NATIVE-SEQUENCE-NOT-IN-CONVERSION-MODE",
                NativeThreadConversionSequencePolicy.Resolve(false, false, false) == NativeThreadConversionSequenceState.NotInConversionMode,
                ref pass, ref fail, "Обычный диалог Helivanta не переходит в последовательный выбор штатных резьб.");
            Check("NATIVE-SEQUENCE-FIRST-THREAD-READY-TO-CONVERT",
                NativeThreadConversionSequencePolicy.Resolve(true, false, false) == NativeThreadConversionSequenceState.ReadyToConvertCurrent,
                ref pass, ref fail, "Перед первым успешным преобразованием кнопка запускает конвертацию текущей ThreadFeature.");
            Check("NATIVE-SEQUENCE-UNDO-RETURNS-TO-CURRENT-THREAD",
                NativeThreadConversionSequencePolicy.Resolve(true, false, false) == NativeThreadConversionSequenceState.ReadyToConvertCurrent,
                ref pass, ref fail, "После отмены успешной конвертации текущая ThreadFeature снова доступна для изменения без повторного выбора.");
            Check("NATIVE-SEQUENCE-COMPLETED-REQUESTS-NEXT",
                NativeThreadConversionSequencePolicy.Resolve(true, true, false) == NativeThreadConversionSequenceState.RequestNextSelection,
                ref pass, ref fail, "После успешного преобразования действие кнопки запрашивает следующую штатную резьбу.");
            Check("NATIVE-SEQUENCE-WAITING-FOR-NEXT-FEATURE",
                NativeThreadConversionSequencePolicy.Resolve(true, true, true) == NativeThreadConversionSequenceState.AwaitingNextSelection,
                ref pass, ref fail, "После команды «Следующая» ожидается выбор другой ThreadFeature до загрузки нового плана.");
            Check("NATIVE-SEQUENCE-REJECTS-WAITING-WITHOUT-COMPLETION",
                NativeThreadConversionSequencePolicy.Resolve(true, false, true) == NativeThreadConversionSequenceState.InvalidState,
                ref pass, ref fail, "Нельзя запрашивать следующую резьбу, пока текущее преобразование не завершено.");
            Check("NATIVE-SEQUENCE-ACCEPTS-NEW-PLAN-ONLY-AFTER-NEXT",
                NativeThreadConversionSequencePolicy.CanAcceptNextFeature(true, true, true) &&
                !NativeThreadConversionSequencePolicy.CanAcceptNextFeature(true, true, false) &&
                !NativeThreadConversionSequencePolicy.CanAcceptNextFeature(true, false, true),
                ref pass, ref fail, "Новый план принимается только после успеха предыдущей конвертации и явного запроса следующего выбора.");

            Check("NATIVE-HISTORY-LAST-FEATURE-NO-DOWNSTREAM",
                NativeThreadConversionPolicy.ResolveDownstreamOperationCount(11, 10) == 0,
                ref pass, ref fail, "Последняя штатная резьба в истории не имеет последующих операций.");
            Check("NATIVE-HISTORY-FIRST-FEATURE-COUNT",
                NativeThreadConversionPolicy.ResolveDownstreamOperationCount(11, 0) == 10,
                ref pass, ref fail, "Для первой операции число последующих элементов равно общему числу минус один.");
            Check("NATIVE-HISTORY-MIDDLE-FEATURE-COUNT",
                NativeThreadConversionPolicy.ResolveDownstreamOperationCount(11, 5) == 5,
                ref pass, ref fail, "Для операции в середине истории считаются только элементы после неё.");
            Check("NATIVE-HISTORY-REJECTS-NEGATIVE-INDEX",
                NativeThreadConversionPolicy.ResolveDownstreamOperationCount(11, -1) == -1,
                ref pass, ref fail, "Отрицательный индекс истории не даёт ложного количества последующих операций.");
            Check("NATIVE-HISTORY-REJECTS-OUT-OF-RANGE-INDEX",
                NativeThreadConversionPolicy.ResolveDownstreamOperationCount(11, 11) == -1 &&
                NativeThreadConversionPolicy.ResolveDownstreamOperationCount(0, 0) == -1,
                ref pass, ref fail, "Пустая история и индекс за границей отклоняются.");

            NativeThreadConversionPolicy.ProfileDefinition nativeProfile;
            string nativeConversionError;
            Check("NATIVE-CONVERT-MAPS-ISO", NativeThreadConversionPolicy.TryResolveProfile(
                "ISO Metric profile", "M10x1.5", "10", true, 1.5,
                out nativeProfile, out nativeConversionError) && nativeProfile.Standard == ThreadStandard.ISO &&
                Math.Abs(nativeProfile.DiameterMm - 10.0) < 1e-9 && Math.Abs(nativeProfile.PitchMm - 1.5) < 1e-9,
                ref pass, ref fail, "Штатная ISO M10×1,5 сопоставляется с физическим профилем Helivanta ISO.");
            Check("NATIVE-CONVERT-MAPS-TR-MULTISTART", NativeThreadConversionPolicy.TryResolveProfile(
                "ISO Metric Trapezoidal", "Tr30x6(P3)", "30", true, 3.0,
                out nativeProfile, out nativeConversionError) && nativeProfile.Standard == ThreadStandard.Tr &&
                Math.Abs(nativeProfile.DiameterMm - 30.0) < 1e-9 && Math.Abs(nativeProfile.PitchMm - 3.0) < 1e-9 && nativeProfile.Starts == 2,
                ref pass, ref fail, "Tr30×6(P3) преобразуется с ходом 6 мм, шагом 3 мм и двумя заходами.");
            Check("NATIVE-CONVERT-MAPS-RD", NativeThreadConversionPolicy.TryResolveProfile(
                "DIN 405 Round Thread", "Rd45x4", "45", true, 4.0,
                out nativeProfile, out nativeConversionError) && nativeProfile.Standard == ThreadStandard.Rd &&
                Math.Abs(nativeProfile.DiameterMm - 45.0) < 1e-9 && Math.Abs(nativeProfile.PitchMm - 4.0) < 1e-9,
                ref pass, ref fail, "Штатная круглая резьба DIN 405 сопоставляется профилю Rd.");
            Check("NATIVE-CONVERT-MAPS-BUTTRESS-S", NativeThreadConversionPolicy.TryResolveProfile(
                "DIN 513 S Buttress", "S20x4", "20", true, 4.0,
                out nativeProfile, out nativeConversionError) && nativeProfile.Standard == ThreadStandard.S,
                ref pass, ref fail, "Штатная упорная резьба DIN 513 сопоставляется профилю S.");
            Check("NATIVE-CONVERT-MAPS-BSW-INCH", NativeThreadConversionPolicy.TryResolveProfile(
                "British Standard Whitworth", "1/2-12 BSW", "1/2", false, 1.0 / 12.0,
                out nativeProfile, out nativeConversionError) && nativeProfile.Standard == ThreadStandard.BSW &&
                Math.Abs(nativeProfile.DiameterMm - 12.7) < 1e-8 && Math.Abs(nativeProfile.PitchMm - 25.4 / 12.0) < 1e-8,
                ref pass, ref fail, "Дюймовая резьба BSW 1/2-12 переводится в миллиметры и профиль BSW.");
            Check("NATIVE-CONVERT-MAPS-ANSI-UNC", NativeThreadConversionPolicy.TryResolveProfile(
                "ANSI Unified Screw Threads", "1/2-13 UNC", "1/2", false, 1.0 / 13.0,
                out nativeProfile, out nativeConversionError) && nativeProfile.Standard == ThreadStandard.ANSI &&
                Math.Abs(nativeProfile.DiameterMm - 12.7) < 1e-8 && Math.Abs(nativeProfile.PitchMm - 25.4 / 13.0) < 1e-8,
                ref pass, ref fail, "Дюймовая резьба UNC переводится в миллиметры и профиль ANSI/UN.");
            Check("NATIVE-CONVERT-REJECTS-UNKNOWN-PROFILE", !NativeThreadConversionPolicy.TryResolveProfile(
                "National Pipe Taper", "1/2-14 NPT", "1/2", false, 1.0 / 14.0,
                out nativeProfile, out nativeConversionError) && nativeProfile == null,
                ref pass, ref fail, "Неизвестный или конический профиль не угадывается и не изменяется автоматически.");
            Check("NATIVE-CONVERT-REJECTS-UNIT-MISMATCH", !NativeThreadConversionPolicy.TryResolveProfile(
                "ISO Metric profile", "M10x1.5", "M10", false, 1.5,
                out nativeProfile, out nativeConversionError) && nativeProfile == null,
                ref pass, ref fail, "Несовпадение metric-флага и распознанного стандарта отклоняется без конвертации.");
            Check("NATIVE-CONVERT-REJECTS-ZERO-PITCH", !NativeThreadConversionPolicy.TryResolveProfile(
                "ISO Metric profile", "M10x1.5", "10", true, 0.0,
                out nativeProfile, out nativeConversionError) && nativeProfile == null,
                ref pass, ref fail, "Нулевой шаг отклоняется до начала транзакции.");
            double nativeDiameter;
            Check("NATIVE-CONVERT-PARSES-INCH-FRACTION", NativeThreadConversionPolicy.TryParseNominalDiameter(
                "1/2", "1/2-13 UNC", false, out nativeDiameter) && Math.Abs(nativeDiameter - 12.7) < 1e-8,
                ref pass, ref fail, "Номинальный диаметр 1/2 дюйма переводится в 12,7 мм.");
            Check("NATIVE-CONVERT-PARSES-MIXED-FRACTION", NativeThreadConversionPolicy.TryParseNominalDiameter(
                "1 1/8", "1 1/8-7 BSW", false, out nativeDiameter) && Math.Abs(nativeDiameter - 28.575) < 1e-8,
                ref pass, ref fail, "Смешанная дробь 1 1/8 дюйма разбирается без потери дробной части.");
            Check("NATIVE-CONVERT-RESOLVES-START-COUNT", NativeThreadConversionPolicy.ResolveStartsFromDesignation("Tr30x6(P3)", true, 3.0) == 2 &&
                NativeThreadConversionPolicy.ResolveStartsFromDesignation("Tr30x6", true, 3.0) == 2 &&
                NativeThreadConversionPolicy.ResolveStartsFromDesignation("M10x1.5", true, 1.5) == 1 &&
                NativeThreadConversionPolicy.ResolveStartsFromDesignation("1/2-13 UNC", false, 25.4 / 13.0) == 1,
                ref pass, ref fail, "Количество заходов определяется по lead/pitch и фактическому шагу ThreadInfo, а не по дюймовому TPI.");

            // Regression: selected edge diameter is the nominal diameter regardless of
            // internal/external type. Never auto-select a catalog size by matching the
            // internal minor/tap-drill diameter, and never snap to the nearest nominal size.
            Check("NOMINAL-DIAMETER-EXACT-MATCH", ThreadNominalDiameterPolicy.MatchesStandardDiameter(45.0, 45.0),
                ref pass, ref fail, "Табличный типоразмер совпадает только при совпадении номинального диаметра.");
            Check("NOMINAL-DIAMETER-NO-MINOR-MATCH", !ThreadNominalDiameterPolicy.MatchesStandardDiameter(45.0, 49.05),
                ref pass, ref fail, "Диаметр отверстия Ø45 не сопоставляется с номинальным Ø49,05 по внутреннему малому диаметру.");
            Check("NOMINAL-DIAMETER-NO-NEAREST-SNAP", !ThreadNominalDiameterPolicy.MatchesStandardDiameter(45.0, 46.0),
                ref pass, ref fail, "Ближайший табличный диаметр не заменяет выбранный Ø45 мм.");
            Check("NOMINAL-DIAMETER-PRESERVE-CUSTOM", Math.Abs(ThreadNominalDiameterPolicy.PreserveSelectedDiameter(45.0) - 45.0) < 1e-12,
                ref pass, ref fail, "Для пользовательского размера сохраняется номинальный диаметр выбранного ребра.");

            // A user-defined diameter has no exact table row, but its pitch dropdown
            // should still offer standard-family values plus common metric choices.
            var customRdPitches = ThreadPitchSuggestionPolicy.ForCustomDiameter(new[] { 25.4 / 6.0, 25.4 / 4.0 });
            Check("CUSTOM-PITCH-INCLUDES-2.5", customRdPitches.Any(p => Math.Abs(p - 2.5) < 1e-9),
                ref pass, ref fail, "Варианты шага для пользовательского размера включают ходовой шаг 2,5 мм.");
            Check("CUSTOM-PITCH-INCLUDES-CATALOGUE", customRdPitches.Any(p => Math.Abs(p - (25.4 / 6.0)) < 0.0001) &&
                customRdPitches.Any(p => Math.Abs(p - (25.4 / 4.0)) < 0.0001),
                ref pass, ref fail, "Варианты шага сохраняют шаги из таблицы активного стандарта.");
            Check("CUSTOM-PITCH-DESCENDING-UNIQUE", customRdPitches.SequenceEqual(customRdPitches.Distinct().OrderByDescending(p => p)),
                ref pass, ref fail, "Список пользовательских шагов отсортирован по убыванию и не содержит дубликатов.");

            // Editing must fail closed on incomplete membership, while downstream operations
            // require an explicit risk warning rather than an unconditional prohibition.
            Check("EDIT-GROUP-COMPLETE-INDICES", ThreadEditSafetyPolicy.HasCompleteIndices(4, new[] { 0, 1, 2, 3 }),
                ref pass, ref fail, "Полная группа с индексами 0..N-1 пригодна для дальнейшей проверки редактирования.");
            Check("EDIT-GROUP-REJECT-MISSING-INDEX", !ThreadEditSafetyPolicy.HasCompleteIndices(4, new[] { 0, 1, 3 }),
                ref pass, ref fail, "Группа с отсутствующим объектом отклоняется.");
            Check("EDIT-GROUP-REJECT-DUPLICATE-INDEX", !ThreadEditSafetyPolicy.HasCompleteIndices(3, new[] { 0, 1, 1 }),
                ref pass, ref fail, "Повторяющийся индекс не может маскировать неполную группу.");
            Check("EDIT-HISTORY-TAIL-ALLOWED", ThreadEditSafetyPolicy.IsAtHistoryTail(9, 10),
                ref pass, ref fail, "Группа у последней операции истории проходит консервативную проверку.");
            Check("EDIT-HISTORY-DOWNSTREAM-REQUIRES-WARNING", ThreadEditSafetyPolicy.RequiresDownstreamWarning(7, 10),
                ref pass, ref fail, "При наличии последующих операций разрешение на замену запрашивается у пользователя.");
            Check("EDIT-HISTORY-TAIL-NEEDS-NO-WARNING", !ThreadEditSafetyPolicy.RequiresDownstreamWarning(9, 10) &&
                !ThreadEditSafetyPolicy.RequiresDownstreamWarning(-1, 10),
                ref pass, ref fail, "Операция в конце истории не требует предупреждения, а неизвестный индекс не классифицируется как зависимость.");
            Check("EDIT-FOLDER-SELECTS-SINGLE-THREAD", ThreadEditSafetyPolicy.TryChooseSingleThreadId(
                new[] { "thread-A", "thread-A", "thread-A" }, out string folderThreadA) && folderThreadA == "thread-A",
                ref pass, ref fail, "Папка с несколькими объектами одной резьбы разрешается в единый ThreadId.");
            Check("EDIT-FOLDER-REJECTS-MIXED-THREADS", !ThreadEditSafetyPolicy.TryChooseSingleThreadId(
                new[] { "thread-A", "thread-B" }, out _),
                ref pass, ref fail, "Папка с объектами разных резьб блокируется как неоднозначная.");
            Check("EDIT-FOLDER-REJECTS-UNTAGGED", !ThreadEditSafetyPolicy.TryChooseSingleThreadId(
                new[] { null, "", "  " }, out _),
                ref pass, ref fail, "Пустая папка или папка без метаданных не запускает редактирование.");

            Check("EDIT-UNIQUE-TARGET-REQUIRED", ThreadEditSafetyPolicy.IsUniqueCandidateCount(1) &&
                !ThreadEditSafetyPolicy.IsUniqueCandidateCount(0) && !ThreadEditSafetyPolicy.IsUniqueCandidateCount(2),
                ref pass, ref fail, "Исходный цилиндр принимается только при одном однозначном совпадении.");
            Check("EDIT-OVERLAP-DETECTED", ThreadEditSafetyPolicy.IntervalsOverlap(0.0, 2.0, 1.9, 3.0),
                ref pass, ref fail, "Пересекающиеся осевые интервалы распознаются как конфликт.");
            Check("EDIT-OVERLAP-REVERSED-INTERVALS", ThreadEditSafetyPolicy.IntervalsOverlap(2.0, 0.0, 1.0, 3.0),
                ref pass, ref fail, "Пересечение обнаруживается даже если один интервал передан в обратном направлении.");
            Check("EDIT-OVERLAP-IGNORES-SUBTOLERANCE-TOUCH", !ThreadEditSafetyPolicy.IntervalsOverlap(0.0, 1.0, 0.99995, 2.0),
                ref pass, ref fail, "Микроперекрытие меньше установленного допуска не создаёт ложный конфликт.");
            Check("EDIT-OVERLAP-DETECTS-ABOVE-TOLERANCE", ThreadEditSafetyPolicy.IntervalsOverlap(0.0, 1.0, 0.9998, 2.0),
                ref pass, ref fail, "Фактическое перекрытие больше допуска блокируется.");
            Check("EDIT-OVERLAP-NONFINITE-FAILS-CLOSED", ThreadEditSafetyPolicy.IntervalsOverlap(double.NaN, 1.0, 0.5, 1.5),
                ref pass, ref fail, "Некорректные координаты интервала считаются конфликтом, а не разрешением на редактирование.");
            Check("EDIT-SEPARATED-ZONES-ALLOWED", !ThreadEditSafetyPolicy.IntervalsOverlap(0.0, 1.0, 1.01, 2.0),
                ref pass, ref fail, "Непересекающиеся осевые интервалы разрешены.");
            double integrityStart, integrityEnd;
            Check("INTEGRITY-INTERVAL-USES-REFERENCE-AXIS", ThreadIntegrityPolicy.TryGetInterval(original, new[] { 0.0, 0.0, 1.0 }, out integrityStart, out integrityEnd) &&
                Math.Abs(integrityStart - 7.875) < 1e-9 && Math.Abs(integrityEnd - 4.875) < 1e-9,
                ref pass, ref fail, "Интервал резьбы переводится в общую ось сравнения даже при обратном направлении исходной оси.");
            Check("INTEGRITY-INTERVAL-REJECTS-NONUNIT-REFERENCE", !ThreadIntegrityPolicy.TryGetInterval(original, new[] { 0.0, 0.0, 0.0 }, out integrityStart, out integrityEnd),
                ref pass, ref fail, "Невалидная ось сравнения не разрешает вычисление интервала.");
            Check("INTEGRITY-INTERVAL-REJECTS-OUT-OF-BOUNDS", !ThreadIntegrityPolicy.TryGetInterval(new ThreadMetadataRecord {
                SchemaVersion = 1, ThreadId = "bad-range", ObjectCount = 1,
                Parameters = new ThreadParametersSnapshot { SizeName = "M10", PitchMm = 1.0, NominalDiaMm = 10.0, Starts = 1, LengthMm = 80.0, OffsetMm = 0.0 },
                Target = new ThreadTargetSnapshot { Center = new[] { 0.0, 0.0, 0.0 }, Axis = new[] { 0.0, 0.0, 1.0 }, RadiusCm = 0.5, LengthCm = 2.0, BodyName = "Solid1" }
            }, new[] { 0.0, 0.0, 1.0 }, out integrityStart, out integrityEnd),
                ref pass, ref fail, "Интервал за пределами исходного цилиндра не принимается.");
            ThreadMetadataRecord reverseGroup = new ThreadMetadataRecord {
                SchemaVersion = 1, ThreadId = "reverse-group", ObjectCount = 1,
                Parameters = new ThreadParametersSnapshot { SizeName = "M10", PitchMm = 1.0, NominalDiaMm = 10.0, Starts = 1, LengthMm = 20.0, OffsetMm = 0.0 },
                Target = new ThreadTargetSnapshot { Center = new[] { 10.25, -4.5, 5.0 }, Axis = new[] { 0.0, 0.0, 1.0 }, RadiusCm = 1.0, LengthCm = 6.2, BodyName = "Solid1" }
            };
            double reverseStart, reverseEnd;
            Check("INTEGRITY-OVERLAP-COMMON-AXIS-REVERSED", ThreadIntegrityPolicy.TryGetInterval(original, new[] { 0.0, 0.0, 1.0 }, out integrityStart, out integrityEnd) &&
                ThreadIntegrityPolicy.TryGetInterval(reverseGroup, new[] { 0.0, 0.0, 1.0 }, out reverseStart, out reverseEnd) &&
                ThreadIntegrityPolicy.IntervalsOverlap(integrityStart, integrityEnd, reverseStart, reverseEnd),
                ref pass, ref fail, "Пересечение определяется корректно для групп с противоположным направлением оси.");
            Check("INTEGRITY-OVERLAP-NONFINITE-FAILS-CLOSED", ThreadIntegrityPolicy.IntervalsOverlap(double.NaN, 1.0, 0.5, 1.5),
                ref pass, ref fail, "Некорректные координаты при проверке целостности трактуются как конфликт.");
            Check("NATIVE-COSMETIC-OVERLAP-BLOCKS", NativeThreadOverlapPolicy.ShouldBlock(true, true, 0.0, 2.0, 1.0, 3.0),
                ref pass, ref fail, "Новая физическая резьба блокируется при пересечении со штатной косметической резьбой на том же цилиндре.");
            Check("NATIVE-COSMETIC-SEPARATED-INTERVAL-ALLOWED", !NativeThreadOverlapPolicy.ShouldBlock(true, true, 0.0, 1.0, 1.01, 2.0),
                ref pass, ref fail, "Непересекающиеся осевые интервалы штатной и физической резьбы допустимы.");
            Check("NATIVE-COSMETIC-UNKNOWN-INTERVAL-FAILS-CLOSED", NativeThreadOverlapPolicy.ShouldBlock(true, false, 0.0, 0.0, 0.0, 0.0),
                ref pass, ref fail, "Если штатная косметическая резьба найдена на том же цилиндре, но её интервал неизвестен, построение блокируется.");
            Check("NATIVE-COSMETIC-TAPERED-THREAD-ON-OTHER-CYLINDER-IGNORED",
                NativeThreadOverlapPolicy.CanClassifyTaperedThreadAsUnrelatedToCylinder(true, true) &&
                !NativeThreadOverlapPolicy.ShouldBlock(false, false, 0.0, 0.0, 0.0, 0.0),
                ref pass, ref fail, "Если интервалы конического ThreadFeature недоступны, известный TaperedThreadInfo на конусе не блокирует построение на другой цилиндрической поверхности.");
            Check("NATIVE-COSMETIC-UNKNOWN-THREAD-FAILS-CLOSED",
                !NativeThreadOverlapPolicy.CanClassifyTaperedThreadAsUnrelatedToCylinder(false, true) &&
                NativeThreadOverlapPolicy.ShouldBlock(true, false, 0.0, 0.0, 0.0, 0.0),
                ref pass, ref fail, "Неизвестный тип штатной резьбы не получает безопасное исключение и сохраняет fail-closed на том же цилиндре.");
            // Native ThreadFeature conversion must independently preflight persisted Helivanta
            // physical zones before its transaction can delete the cosmetic source feature.
            double editProposedStart, editProposedEnd, editExistingStart, editExistingEnd;
            bool editProposedIntervalKnown = NativeThreadOverlapPolicy.TryGetInterval(
                new[] { 0.0, 0.0, 0.0 }, new[] { 0.0, 0.0, 1.0 }, 5.0, false, 20.0, 0.0,
                new[] { 0.0, 0.0, 0.0 }, new[] { 0.0, 0.0, 1.0 }, out editProposedStart, out editProposedEnd);
            bool editExistingIntervalKnown = NativeThreadOverlapPolicy.TryGetInterval(
                new[] { 0.0, 0.0, 1.0 }, new[] { 0.0, 0.0, 1.0 }, 5.0, false, 20.0, 0.0,
                new[] { 0.0, 0.0, 1.0 }, new[] { 0.0, 0.0, 1.0 }, out editExistingStart, out editExistingEnd);
            Check("NATIVE-EDIT-EXISTING-HELI-VANTA-OVERLAP-BLOCKS", editProposedIntervalKnown && editExistingIntervalKnown &&
                NativeThreadOverlapPolicy.ShouldBlock(true, true, editProposedStart, editProposedEnd, editExistingStart, editExistingEnd),
                ref pass, ref fail, "Preflight преобразования native ThreadFeature блокирует пересечение с уже сохранённой физической резьбой Helivanta на том же цилиндре до открытия транзакции.");
            Check("NATIVE-EDIT-EXISTING-HELI-VANTA-SEPARATED-ALLOWED", NativeThreadOverlapPolicy.ShouldBlock(true, true, 0.0, 1.0, 1.01, 2.0) == false,
                ref pass, ref fail, "Преобразование native ThreadFeature разрешается, если существующая физическая резьба занимает разнесённый осевой интервал.");
            Check("NATIVE-EDIT-UNKNOWN-INTERVAL-FAILS-CLOSED", NativeThreadOverlapPolicy.ShouldBlock(true, false, 0.0, 0.0, 0.0, 0.0),
                ref pass, ref fail, "Преобразование native ThreadFeature блокируется до мутации, если интервал существующей резьбы на том же цилиндре неизвестен.");
            Check("NATIVE-COSMETIC-DIFFERENT-CYLINDER-IGNORED", !NativeThreadOverlapPolicy.ShouldBlock(false, false, 0.0, 0.0, 0.0, 0.0),
                ref pass, ref fail, "Неизвестный интервал штатной резьбы на другом цилиндре не создаёт ложного конфликта.");
            double nativeStart, nativeEnd;
            Check("NATIVE-COSMETIC-INTERVAL-REVERSED-AXIS", NativeThreadOverlapPolicy.TryGetInterval(
                new[] { 0.0, 0.0, 4.0 }, new[] { 0.0, 0.0, -1.0 }, 5.0, false, 20.0, 5.0,
                new[] { 0.0, 0.0, 0.0 }, new[] { 0.0, 0.0, 1.0 }, out nativeStart, out nativeEnd) &&
                Math.Abs(nativeStart - 3.5) < 1e-9 && Math.Abs(nativeEnd - 1.5) < 1e-9,
                ref pass, ref fail, "Интервал штатной резьбы вычисляется в общей системе координат при реверсированном направлении оси.");
            Check("NATIVE-COSMETIC-INTERVAL-REJECTS-OUT-OF-BOUNDS", !NativeThreadOverlapPolicy.TryGetInterval(
                new[] { 0.0, 0.0, 0.0 }, new[] { 0.0, 0.0, 1.0 }, 1.0, false, 20.0, 0.0,
                new[] { 0.0, 0.0, 0.0 }, new[] { 0.0, 0.0, 1.0 }, out nativeStart, out nativeEnd),
                ref pass, ref fail, "Интервал штатной косметической резьбы, выходящий за границы исходного цилиндра, не принимается.");

            // Regression: the size label must come from the active standard, not a stale
            // selected item from the previous template during thread editing.
            Check("EDIT-SIZE-NAME-CURRENT-STANDARD", ThreadSizeNamePolicy.Build(
                ThreadStandard.Tr, ThreadStandards.Sizes(ThreadStandard.Tr), 45.0, 3.0) == "Tr 45 x 3",
                ref pass, ref fail, "После смены ISO M45 на Tr45×3 имя строится по стандарту Tr, а не остаётся M45×3.");
            Check("EDIT-SIZE-NAME-CUSTOM-PITCH-KEEPS-PREFIX", ThreadSizeNamePolicy.Build(
                ThreadStandard.Tr, ThreadStandards.Sizes(ThreadStandard.Tr), 45.0, 2.5) == "Tr 45 x 2.5",
                ref pass, ref fail, "Пользовательский шаг сохраняет префикс активного стандарта.");
            Check("EDIT-SIZE-NAME-RD-KEEPS-PREFIX", ThreadSizeNamePolicy.Build(
                ThreadStandard.Rd, ThreadStandards.Sizes(ThreadStandard.Rd), 45.0, 3.0) == "Rd 45 x 3",
                ref pass, ref fail, "Имя пользовательского размера Rd не наследует префикс прежнего стандарта.");
            Check("FOLDER-NAME-RIGHT-HAND-LABEL", ThreadFolderNamePolicy.DirectionLabel(true) == "Правая (R)",
                ref pass, ref fail, "Правая резьба явно обозначается в имени папки как R.");
            Check("FOLDER-NAME-LEFT-HAND-LABEL", ThreadFolderNamePolicy.DirectionLabel(false) == "Левая (L)",
                ref pass, ref fail, "Левая резьба явно обозначается в имени папки как L.");
            Check("FOLDER-NAME-BUILDER-REFLECTS-EDITED-SIZE-STARTS-AND-ISO-TEMPLATE",
                ThreadFolderNamePolicy.BuildThreadFolderName("M45 x 2", 3, true, ThreadStandard.ISO, false) ==
                "Резьба — ISO · M45 x 2 · 3 захода · Правая (R)",
                ref pass, ref fail, "Имя папки показывает шаблон ISO, новый размер и число заходов.");
            Check("FOLDER-NAME-BSW-TEMPLATE-EXPLICIT",
                ThreadFolderNamePolicy.BuildThreadFolderName("1/2-12", 1, true, ThreadStandard.BSW, false) ==
                "Резьба — BSW · 1/2-12 · 1 заход · Правая (R)",
                ref pass, ref fail, "Дюймовой размер BSW явно отличим от ANSI/UN по имени папки.");
            Check("FOLDER-NAME-ANSI-TEMPLATE-EXPLICIT",
                ThreadFolderNamePolicy.BuildThreadFolderName("1/2-13", 1, true, ThreadStandard.ANSI, false) ==
                "Резьба — ANSI/UN · 1/2-13 · 1 заход · Правая (R)",
                ref pass, ref fail, "Дюймовой размер ANSI/UN явно маркируется названием шаблона.");
            Check("FOLDER-NAME-TR-TEMPLATE-EXPLICIT-WITHOUT-DOUBLE-PREFIX",
                ThreadFolderNamePolicy.BuildThreadFolderName("Tr 45 x 3", 1, true, ThreadStandard.Tr, false) ==
                "Резьба — Tr · 45 x 3 · 1 заход · Правая (R)",
                ref pass, ref fail, "Tr обозначается по шаблону без повторения префикса в размере.");
            Check("FOLDER-NAME-S-DIN513-TEMPLATE-EXPLICIT",
                ThreadFolderNamePolicy.BuildThreadFolderName("S 45 x 2.5", 1, true, ThreadStandard.S, false) ==
                "Резьба — S (DIN 513) · 45 x 2.5 · 1 заход · Правая (R) · Прямой профиль",
                ref pass, ref fail, "Упорная резьба явно связана с шаблоном DIN 513.");
            Check("FOLDER-NAME-RD-DIN405-TEMPLATE-EXPLICIT",
                ThreadFolderNamePolicy.BuildThreadFolderName("Rd 20 x 3", 1, true, ThreadStandard.Rd, false) ==
                "Резьба — Rd (DIN 405) · 20 x 3 · 1 заход · Правая (R)",
                ref pass, ref fail, "Круглая резьба явно связана с шаблоном DIN 405.");
            Check("FOLDER-NAME-RUNOUT-EXPLICIT-TEMPLATE",
                ThreadFolderNamePolicy.BuildRunoutFolderName("1/2-12", 1, ThreadStandard.BSW) ==
                "Сбег — BSW · 1/2-12 · 1 заход",
                ref pass, ref fail, "Папка сбега также показывает семейство шаблона и правильно склоняет один заход.");
            Check("FOLDER-NAME-STANDARD-LABELS-COVER-ALL-TEMPLATES",
                ThreadFolderNamePolicy.StandardLabel(ThreadStandard.ISO) == "ISO" &&
                ThreadFolderNamePolicy.StandardLabel(ThreadStandard.BSW) == "BSW" &&
                ThreadFolderNamePolicy.StandardLabel(ThreadStandard.ANSI) == "ANSI/UN" &&
                ThreadFolderNamePolicy.StandardLabel(ThreadStandard.Tr) == "Tr" &&
                ThreadFolderNamePolicy.StandardLabel(ThreadStandard.S) == "S (DIN 513)" &&
                ThreadFolderNamePolicy.StandardLabel(ThreadStandard.Rd) == "Rd (DIN 405)",
                ref pass, ref fail, "Все шесть семейств имеют устойчивые и однозначные подписи.");
            Check("UNDO-BOUNDARY-DOES-NOT-CLEAR-WITH-NO-OPEN-DOCUMENTS",
                !UndoHistoryBoundaryPolicy.ShouldClearAllTransactions(0, false),
                ref pass, ref fail, "Без открытого документа очистка глобальной истории не запускается.");
            Check("UNDO-BOUNDARY-CLEARS-ONLY-WITH-ONE-OPEN-DOCUMENT",
                UndoHistoryBoundaryPolicy.ShouldClearAllTransactions(1, false),
                ref pass, ref fail, "Граница при открытии устанавливается только при ровно одном открытом документе.");
            Check("UNDO-BOUNDARY-PRESERVES-HISTORY-WITH-TWO-OPEN-DOCUMENTS",
                !UndoHistoryBoundaryPolicy.ShouldClearAllTransactions(2, false),
                ref pass, ref fail, "При нескольких открытых документах глобальные Undo/Redo сохраняются.");
            Check("UNDO-BOUNDARY-PRESERVES-HISTORY-WITH-MANY-OPEN-DOCUMENTS",
                !UndoHistoryBoundaryPolicy.ShouldClearAllTransactions(5, false),
                ref pass, ref fail, "Защитная политика не запускает глобальный сброс при любом количестве больше одного.");
            Check("UNDO-BOUNDARY-PRESERVES-HISTORY-AFTER-MULTI-DOCUMENT-OPEN-SEQUENCE",
                !UndoHistoryBoundaryPolicy.ShouldClearAllTransactions(1, true),
                ref pass, ref fail, "Если во время связанной последовательности открытия наблюдалось несколько документов, поздний счётчик 1 не разрешает глобальный сброс.");
            Check("UNDO-BOUNDARY-RECOGNIZES-UNIDENTIFIED-TRANSACTION-SENTINEL",
                !UndoHistoryBoundaryPolicy.IsIdentifiedTransactionInProgress("Unidentified transaction"),
                ref pass, ref fail, "Постоянный sentinel Inventor не блокирует безопасную проверку границы Undo.");
            Check("UNDO-BOUNDARY-SENTINEL-CHECK-IS-CASE-INSENSITIVE",
                !UndoHistoryBoundaryPolicy.IsIdentifiedTransactionInProgress("unidentified transaction"),
                ref pass, ref fail, "Регистр имени sentinel не меняет распознавание.");
            Check("UNDO-BOUNDARY-BLOCKS-NAMED-CURRENT-TRANSACTION",
                UndoHistoryBoundaryPolicy.IsIdentifiedTransactionInProgress("Создание резьбы"),
                ref pass, ref fail, "Любая именованная текущая транзакция блокирует очистку истории.");
            Check("UNDO-BOUNDARY-FAILS-CLOSED-ON-UNKNOWN-TRANSACTION-NAME",
                UndoHistoryBoundaryPolicy.IsIdentifiedTransactionInProgress(null) &&
                UndoHistoryBoundaryPolicy.IsIdentifiedTransactionInProgress(" "),
                ref pass, ref fail, "Пустое или неизвестное имя считается активным состоянием и не разрешает сброс.");
            Check("PREVIEW-OVERLAY-BURN-THROUGH",
                PreviewGraphicsPolicy.BurnThroughModel,
                ref pass, ref fail, "Затенённый фантом и контуры рисуются поверх перекрывающего тела без изменения тела.");
            Check("PREVIEW-NEVER-CHANGES-SOURCE-BODY-VISIBILITY",
                !PreviewGraphicsPolicy.ChangesSourceBodyVisibility,
                ref pass, ref fail, "Переключение предпросмотра не изменяет SurfaceBody.Visible и не добавляет Show/Hide транзакции.");
            Check("PREVIEW-OVERLAY-USES-PRIORITY",
                PreviewGraphicsPolicy.DepthPriority > 0,
                ref pass, ref fail, "Временная графика получает положительный приоритет отображения.");
            Check("PREVIEW-CHAMFER-START-EDGE-FACTOR",
                ThreadPreviewChamferPolicy.IncludesStart(1) &&
                Math.Abs(ThreadPreviewChamferPolicy.DepthFactor(0.0, 2.0, 1, 0.1) - 1.0) < 1e-10 &&
                Math.Abs(ThreadPreviewChamferPolicy.DepthFactor(0.1, 2.0, 1, 0.1)) < 1e-10,
                ref pass, ref fail, "Фантомная фаска в начале максимальна на торце и сходится к цилиндру за заданную длину.");
            Check("PREVIEW-CHAMFER-END-EDGE-FACTOR",
                ThreadPreviewChamferPolicy.IncludesEnd(2) &&
                Math.Abs(ThreadPreviewChamferPolicy.DepthFactor(2.0, 2.0, 2, 0.1) - 1.0) < 1e-10 &&
                Math.Abs(ThreadPreviewChamferPolicy.DepthFactor(1.9, 2.0, 2, 0.1)) < 1e-10,
                ref pass, ref fail, "Фантомная фаска в конце привязана к дальнему торцу цилиндра.");
            Check("PREVIEW-CHAMFER-BOTH-ENDS",
                ThreadPreviewChamferPolicy.IncludesStart(3) && ThreadPreviewChamferPolicy.IncludesEnd(3) &&
                Math.Abs(ThreadPreviewChamferPolicy.DepthFactor(0.0, 2.0, 3, 0.1) - 1.0) < 1e-10 &&
                Math.Abs(ThreadPreviewChamferPolicy.DepthFactor(2.0, 2.0, 3, 0.1) - 1.0) < 1e-10 &&
                Math.Abs(ThreadPreviewChamferPolicy.DepthFactor(1.0, 2.0, 3, 0.1)) < 1e-10,
                ref pass, ref fail, "Обе торцевые фаски показываются раздельно и не влияют на середину цилиндра.");
            Check("PREVIEW-CHAMFER-INVALID-VALUES-FAIL-SOFT",
                Math.Abs(ThreadPreviewChamferPolicy.DepthFactor(0.0, 2.0, 1, double.NaN)) < 1e-10 &&
                ThreadPreviewChamferPolicy.WasVisualDepthCapped(20.0, ThreadPreviewChamferPolicy.ResolveVisualDepthCm(20.0, 1.0, 2.0, 3)),
                ref pass, ref fail, "Некорректная или не помещающаяся фаска не ломает фантом; отображение ограничивается безопасным габаритом.");
            Check("PREVIEW-CHAMFER-DEPTH-TRACKS-SETTING",
                Math.Abs(ThreadPreviewChamferPolicy.ResolveVisualDepthCm(0.1, 2.0, 10.0, 3) - 0.1) < 1e-10 &&
                Math.Abs(ThreadPreviewChamferPolicy.ResolveVisualDepthCm(0.2, 2.0, 10.0, 3) - 0.2) < 1e-10 &&
                Math.Abs(ThreadPreviewChamferPolicy.ResolveVisualDepthCm(0.2, 2.0, 10.0, 3) -
                    ThreadPreviewChamferPolicy.ResolveVisualDepthCm(0.1, 2.0, 10.0, 3)) > 1e-10,
                ref pass, ref fail, "Визуальная глубина фаски меняется вместе с введённым размером, если геометрические пределы её не ограничивают.");
            Check("WALL-MINIMUM-ABSOLUTE-FLOOR",
                Math.Abs(ThreadWallThicknessPolicy.RequiredRemainingWallCm(0.03) - 0.05) < 1e-10,
                ref pass, ref fail, "Для мелкого шага остаточная стенка не может быть меньше абсолютного пола 0,5 мм.");
            Check("WALL-MINIMUM-SCALES-WITH-PITCH",
                Math.Abs(ThreadWallThicknessPolicy.RequiredRemainingWallCm(0.8) - 0.2) < 1e-10,
                ref pass, ref fail, "Для шага 8 мм минимальная остаточная стенка равна четверти шага, то есть 2 мм.");
            Check("WALL-CUT-DEPTH-UNCHANGED-WITHOUT-CHAMFER",
                Math.Abs(ThreadWallThicknessPolicy.EffectiveCutDepthCm(0.69, false, 0.1) - 0.69) < 1e-10,
                ref pass, ref fail, "Без фаски запас глубины равен глубине профиля.");
            Check("WALL-CUT-DEPTH-USES-MAX-LOCAL-CUT",
                Math.Abs(ThreadWallThicknessPolicy.EffectiveCutDepthCm(0.69, true, 0.1) - 0.69) < 1e-10,
                ref pass, ref fail, "Корневая канавка и фаска — отдельные вычитаемые объёмы; локальная радиальная глубина объединения равна максимуму, а не сумме.");
            Check("WALL-CUT-DEPTH-RESERVES-LARGER-CHAMFER",
                Math.Abs(ThreadWallThicknessPolicy.EffectiveCutDepthCm(0.69, true, 0.75) - 0.75) < 1e-10,
                ref pass, ref fail, "Если фаска глубже корня, резервируется её собственная локальная глубина.");
            double finePitchRemaining, finePitchRequired;
            Groove s52x1Groove = ThreadStandards.ComputeGroove(
                ThreadStandards.Spec(ThreadStandard.S), true, 0.1, 0.0, 0.1, 10.0);
            double s52x1EffectiveCut = s52x1Groove == null ? double.NaN :
                ThreadWallThicknessPolicy.EffectiveCutDepthCm(s52x1Groove.Depth, true, 0.1);
            Check("WALL-S52X1-WITH-1MM-CHAMFER-DOES-NOT-DOUBLE-COUNT",
                s52x1Groove != null && ThreadWallThicknessPolicy.HasSafeRemainingWall(0.35, 0.0,
                    s52x1EffectiveCut, 0.1, out finePitchRemaining, out finePitchRequired) &&
                    Math.Abs(s52x1EffectiveCut - 0.1) < 1e-8 &&
                    Math.Abs(finePitchRemaining - 0.25) < 1e-8 &&
                    Math.Abs(finePitchRequired - 0.05) < 1e-10,
                ref pass, ref fail, "Для фактической геометрии профиля S52×1 стенка 3,5 мм с фаской 1 мм учитывает максимум корня и фаски; остаток 2,5 мм безопасен по политике.");
            Check("CHAMFER-PREFLIGHT-ACCEPTS-S52X1-ONE-MM",
                ThreadWallThicknessPolicy.ValidateChamferFit(true, 2.6, 10.0, 3, 0.1, false, false) == null,
                ref pass, ref fail, "Фаска 1 мм на длинном цилиндре Ø52 проходит проверку размера; остаточная стенка оценивается отдельной политикой.");
            Check("CHAMFER-PREFLIGHT-REPORTS-SIZE-NOT-WALL",
                (ThreadWallThicknessPolicy.ValidateChamferFit(true, 0.1, 10.0, 1, 0.1, false, false) ?? "").IndexOf("радиуса", StringComparison.OrdinalIgnoreCase) >= 0 &&
                (ThreadWallThicknessPolicy.ValidateChamferFit(true, 2.6, 0.15, 3, 0.1, false, false) ?? "").IndexOf("две фаски", StringComparison.OrdinalIgnoreCase) >= 0,
                ref pass, ref fail, "Слишком большая фаска получает конкретную причину отказа до измерения стенки.");
            Check("CHAMFER-PREFLIGHT-REPORTS-SHOULDER-CONFLICT",
                (ThreadWallThicknessPolicy.ValidateChamferFit(true, 2.6, 10.0, 1, 0.1, true, false) ?? "").IndexOf("вогнутом", StringComparison.OrdinalIgnoreCase) >= 0 &&
                ThreadWallThicknessPolicy.ValidateChamferFit(true, 2.6, 10.0, 1, 0.1, false, false) == null,
                ref pass, ref fail, "Конфликт фаски с плечом сообщается отдельно от толщины стенки.");
            Check("WALL-CUT-DEPTH-FAILS-CLOSED-ON-INVALID-CHAMFER",
                double.IsNaN(ThreadWallThicknessPolicy.EffectiveCutDepthCm(0.69, true, 0.0)) &&
                double.IsNaN(ThreadWallThicknessPolicy.EffectiveCutDepthCm(double.NaN, false, 0.0)),
                ref pass, ref fail, "Некорректная глубина профиля/включённой фаски не разрешает построение.");

            double wallRemaining, wallRequired;
            Check("WALL-POLICY-SAFE-RESIDUAL",
                ThreadWallThicknessPolicy.HasSafeRemainingWall(0.8, 0.0, 0.55, 0.8,
                    out wallRemaining, out wallRequired) &&
                Math.Abs(wallRemaining - 0.25) < 1e-10 && Math.Abs(wallRequired - 0.2) < 1e-10,
                ref pass, ref fail, "Построение разрешено, когда после корня резьбы остаётся достаточная стенка.");
            Check("WALL-POLICY-BLOCKS-THIN-RESIDUAL",
                !ThreadWallThicknessPolicy.HasSafeRemainingWall(0.7, 0.0, 0.55, 0.8,
                    out wallRemaining, out wallRequired) && Math.Abs(wallRemaining - 0.15) < 1e-10,
                ref pass, ref fail, "Построение блокируется, если остаточная стенка меньше четверти шага.");

            Check("WALL-EXTERNAL-ADDED-RADIUS-INCREASES-RESIDUAL",
                Math.Abs(ThreadWallThicknessPolicy.RadiusAdjustmentCm(true, 2.60, 2.62) - 0.02) < 1e-10 &&
                ThreadWallThicknessPolicy.HasSafeRemainingWall(0.8,
                    ThreadWallThicknessPolicy.RadiusAdjustmentCm(true, 2.60, 2.62), 0.6, 0.8,
                    out wallRemaining, out wallRequired),
                ref pass, ref fail, "Увеличение наружного радиуса добавляет припуск, учтённый в остаточной стенке.");
            Check("WALL-EXTERNAL-REMOVED-RADIUS-REDUCES-RESIDUAL",
                Math.Abs(ThreadWallThicknessPolicy.RadiusAdjustmentCm(true, 2.62, 2.60) + 0.02) < 1e-10 &&
                !ThreadWallThicknessPolicy.HasSafeRemainingWall(0.8,
                    ThreadWallThicknessPolicy.RadiusAdjustmentCm(true, 2.62, 2.60), 0.6, 0.8,
                    out wallRemaining, out wallRequired),
                ref pass, ref fail, "Приведение завышенного наружного диаметра к расчётному уменьшает остаточную стенку.");
            Check("WALL-INTERNAL-REDUCED-BORE-ADDS-WALL",
                Math.Abs(ThreadWallThicknessPolicy.RadiusAdjustmentCm(false, 1.0, 0.98) - 0.02) < 1e-10 &&
                ThreadWallThicknessPolicy.HasSafeRemainingWall(0.8,
                    ThreadWallThicknessPolicy.RadiusAdjustmentCm(false, 1.0, 0.98), 0.6, 0.8,
                    out wallRemaining, out wallRequired),
                ref pass, ref fail, "Уменьшение исходного отверстия добавляет материал и учитывается при проверке внутренней резьбы.");
            Check("WALL-INTERNAL-ENLARGED-BORE-REMOVES-WALL",
                Math.Abs(ThreadWallThicknessPolicy.RadiusAdjustmentCm(false, 0.98, 1.0) + 0.02) < 1e-10 &&
                !ThreadWallThicknessPolicy.HasSafeRemainingWall(0.8,
                    ThreadWallThicknessPolicy.RadiusAdjustmentCm(false, 0.98, 1.0), 0.6, 0.8,
                    out wallRemaining, out wallRequired),
                ref pass, ref fail, "Увеличение исходного отверстия уменьшает остаточную стенку и может блокировать построение.");
            Check("WALL-POLICY-FAILS-CLOSED-ON-NONFINITE",
                !ThreadWallThicknessPolicy.HasSafeRemainingWall(double.NaN, 0.0, 0.3, 0.8,
                    out wallRemaining, out wallRequired) && double.IsNaN(wallRemaining),
                ref pass, ref fail, "Отсутствующее или некорректное измерение стенки блокирует построение.");
            ThreadTargetSnapshot sourceCylinder = new ThreadTargetSnapshot
            {
                Center = new[] { 0.0, 0.0, 0.0 },
                Axis = new[] { 0.0, 0.0, 1.0 },
                RadiusCm = 0.5,
                LengthCm = 2.0,
                IsExternal = true,
                BodyName = "Solid1"
            };
            ThreadTargetSnapshot sameBodyAxialSegment = CloneTarget(sourceCylinder);
            sameBodyAxialSegment.Center = new[] { 0.0, 0.0, 2.0 };
            Check("TARGET-ISOLATION-SAME-BODY-AXIAL-SEGMENTS",
                ThreadTargetIsolationPolicy.SameCylinder(sourceCylinder, sameBodyAxialSegment) &&
                !ThreadEditSafetyPolicy.IntervalsOverlap(0.0, 1.0, 1.1, 2.0),
                ref pass, ref fail, "Разнесённые осевые интервалы одного цилиндра распознаются как один источник, но не как перекрытие.");

            ThreadTargetSnapshot coincidentOtherBody = CloneTarget(sourceCylinder);
            coincidentOtherBody.BodyName = "Solid2";
            Check("TARGET-ISOLATION-SEPARATE-BODIES",
                !ThreadTargetIsolationPolicy.SameCylinder(sourceCylinder, coincidentOtherBody),
                ref pass, ref fail, "Геометрически совпадающие цилиндры в разных телах многотельной детали изолированы.");

            ThreadTargetSnapshot radialNeighbor = CloneTarget(sourceCylinder);
            radialNeighbor.Center = new[] { 0.02, 0.0, 0.0 };
            Check("TARGET-ISOLATION-RADIAL-NEIGHBOR",
                !ThreadTargetIsolationPolicy.SameCylinder(sourceCylinder, radialNeighbor),
                ref pass, ref fail, "Параллельный цилиндр со смещённой осью не смешивается с исходной поверхностью.");

            ThreadTargetSnapshot differentRadius = CloneTarget(sourceCylinder);
            differentRadius.RadiusCm = 0.6;
            Check("TARGET-ISOLATION-RADIUS-MISMATCH",
                !ThreadTargetIsolationPolicy.SameCylinder(sourceCylinder, differentRadius),
                ref pass, ref fail, "Цилиндры с различными радиусами не считаются одним источником.");

            ThreadTargetSnapshot reversedAxis = CloneTarget(sourceCylinder);
            reversedAxis.Center = new[] { 0.0, 0.0, 1.0 };
            reversedAxis.Axis = new[] { 0.0, 0.0, -1.0 };
            Check("TARGET-ISOLATION-REVERSED-AXIS",
                ThreadTargetIsolationPolicy.SameCylinder(sourceCylinder, reversedAxis),
                ref pass, ref fail, "Разворот направления оси не ломает идентификацию того же цилиндра.");

            ThreadTargetSnapshot caseVariantBody = CloneTarget(sourceCylinder);
            caseVariantBody.BodyName = "solid1";
            Check("TARGET-ISOLATION-BODY-NAME-CASE-INSENSITIVE",
                ThreadTargetIsolationPolicy.SameCylinder(sourceCylinder, caseVariantBody),
                ref pass, ref fail, "Имя одного тела сравнивается без учёта регистра.");

            Check("TARGET-ISOLATION-OVERLAPPING-THREAD-RANGES",
                ThreadTargetIsolationPolicy.SameCylinder(sourceCylinder, sameBodyAxialSegment) &&
                ThreadEditSafetyPolicy.IntervalsOverlap(0.0, 1.0, 0.8, 1.5),
                ref pass, ref fail, "Перекрывающиеся интервалы на одном цилиндре остаются конфликтом.");

            ThreadTargetSnapshot invalidTarget = CloneTarget(sourceCylinder);
            invalidTarget.Axis = null;
            Check("TARGET-ISOLATION-TRANSIENT-MISSING-BODY-NAME",
                ThreadTargetIsolationPolicy.SameCylinderGeometry(
                    "Solid1", null, 0.5, 0.5,
                    sourceCylinder.Center, sourceCylinder.Axis,
                    sourceCylinder.Center, sourceCylinder.Axis, requireBodyNames: false),
                ref pass, ref fail, "Для временного выбора сохраняется прежнее поведение, если имя тела недоступно.");

            Check("TARGET-ISOLATION-INVALID-METADATA-FAILS-CLOSED",
                !ThreadTargetIsolationPolicy.SameCylinder(sourceCylinder, invalidTarget),
                ref pass, ref fail, "Повреждённые геометрические снимки не разрешают небезопасное совпадение.");
            Check("FOLDER-NAME-UNKNOWN-TEMPLATE-DOES-NOT-MISLABEL-ISO",
                ThreadFolderNamePolicy.StandardLabel((ThreadStandard)999) == "Неизвестный шаблон",
                ref pass, ref fail, "Некорректное значение стандарта не маскируется подписью ISO.");
            Check("FOLDER-NAME-S-STRAIGHT-PROFILE", ThreadFolderNamePolicy.AppendThreadOrientation(
                "Резьба — S 45 x 2.5 · 1 заход", true, ThreadStandard.S, false) ==
                "Резьба — S 45 x 2.5 · 1 заход · Правая (R) · Прямой профиль",
                ref pass, ref fail, "Для S в имени папки показано правое направление и прямой профиль.");
            Check("FOLDER-NAME-S-MIRRORED-PROFILE", ThreadFolderNamePolicy.AppendThreadOrientation(
                "Резьба — S 45 x 2.5 · 1 заход", false, ThreadStandard.S, true) ==
                "Резьба — S 45 x 2.5 · 1 заход · Левая (L) · Зеркальный профиль",
                ref pass, ref fail, "Для S в имени папки показаны левое направление и зеркальный профиль.");
            Check("FOLDER-NAME-NON-S-NO-PROFILE-LABEL", ThreadFolderNamePolicy.AppendThreadOrientation(
                "Резьба — Tr 45 x 3 · 1 заход", true, ThreadStandard.Tr, true) ==
                "Резьба — Tr 45 x 3 · 1 заход · Правая (R)",
                ref pass, ref fail, "Метка прямого/зеркального профиля не добавляется к стандартам, отличным от S.");

            Check("EDIT-CLEANUP-INCLUDES-RUNOUT-FOLDERS",
                ThreadBrowserFolderPolicy.IsManagedThreadFolder("Сбег — Tr 45 x 3 · 1 заход") &&
                ThreadBrowserFolderPolicy.IsManagedThreadFolder("Резьба — Tr 45 x 3 · 1 заход") &&
                !ThreadBrowserFolderPolicy.IsManagedThreadFolder("Эскизы"),
                ref pass, ref fail, "Очистка рассматривает пустые папки резьбы и сбега, не затрагивая чужие папки.");

            // Undo/Redo must be tied to the actual transaction kind and exact edited ThreadId.
            const string buildTxPrefix = "Helivanta: построение резьбы";
            const string editTxPrefix = "Helivanta: редактирование резьбы";
            string parsedThreadId;
            Check("UNDO-CLASSIFY-BUILD-TRANSACTION",
                ThreadEditSafetyPolicy.ClassifyTransaction(buildTxPrefix, buildTxPrefix, editTxPrefix, out parsedThreadId) == HelivantaTransactionKind.Build &&
                parsedThreadId == null,
                ref pass, ref fail, "Транзакция обычного построения классифицируется отдельно от редактирования.");
            Check("UNDO-CLASSIFY-EDIT-TRANSACTION-ID",
                ThreadEditSafetyPolicy.ClassifyTransaction(editTxPrefix + " thread-A", buildTxPrefix, editTxPrefix, out parsedThreadId) == HelivantaTransactionKind.Edit &&
                parsedThreadId == "thread-A",
                ref pass, ref fail, "Транзакция редактирования содержит ID изменённой группы.");
            Check("UNDO-REJECT-AMBIGUOUS-EDIT-TRANSACTION",
                ThreadEditSafetyPolicy.ClassifyTransaction(editTxPrefix, buildTxPrefix, editTxPrefix, out parsedThreadId) == HelivantaTransactionKind.Other &&
                parsedThreadId == null,
                ref pass, ref fail, "Транзакция редактирования без ThreadId игнорируется как неоднозначная.");
            Check("UNDO-MATCHES-CURRENT-THREAD",
                ThreadEditSafetyPolicy.IsEditTransactionForThread(editTxPrefix + " thread-A", buildTxPrefix, editTxPrefix, "thread-A"),
                ref pass, ref fail, "Событие Undo/Redo относится к открытому ThreadId только при точном совпадении.");
            Check("UNDO-IGNORES-OTHER-THREAD",
                !ThreadEditSafetyPolicy.IsEditTransactionForThread(editTxPrefix + " thread-B", buildTxPrefix, editTxPrefix, "thread-A"),
                ref pass, ref fail, "Undo/Redo другой резьбы не выдаётся за изменение текущей группы.");
            Check("EDIT-NOMINAL-DIAMETER-PRESERVED-ON-STANDARD-SWITCH",
                ThreadEditSafetyPolicy.IsNominalDiameterPreserved(45.0, 45.0),
                ref pass, ref fail, "При смене M45 на Tr45 номинальный диаметр остаётся Ø45 мм.");
            Check("EDIT-NOMINAL-DIAMETER-REJECTS-M200",
                !ThreadEditSafetyPolicy.IsNominalDiameterPreserved(45.0, 200.0),
                ref pass, ref fail, "Редактирование существующей Ø45 резьбы не может заменить её на Ø200 и изменить базовый цилиндр.");
            Check("EDIT-NOMINAL-DIAMETER-REJECTS-INVALID",
                !ThreadEditSafetyPolicy.IsNominalDiameterPreserved(45.0, double.NaN) &&
                !ThreadEditSafetyPolicy.IsNominalDiameterPreserved(45.0, 0.0),
                ref pass, ref fail, "Некорректный или неположительный диаметр отклоняется до открытия транзакции.");

            Check("STANDARD-IGNORE-TRANSIENT-INDEX-CHANGED",
                !ThreadStandardSelectionPolicy.ShouldApplyChange(false, false, 4, 6),
                ref pass, ref fail, "Промежуточный SelectedIndexChanged не запускает перестроение каталога до фиксации выбора.");
            Check("STANDARD-APPLY-COMMITTED-S",
                ThreadStandardSelectionPolicy.ShouldApplyChange(true, false, (int)ThreadStandard.S, 6),
                ref pass, ref fail, "Подтверждённый выбор стандарта S применяется после закрытия выпадающего списка.");
            Check("STANDARD-IGNORE-PROGRAMMATIC-CHANGE",
                !ThreadStandardSelectionPolicy.ShouldApplyChange(true, true, (int)ThreadStandard.S, 6),
                ref pass, ref fail, "Программная загрузка параметров не запускает повторное пользовательское переключение.");
            Check("STANDARD-RESTORE-LAST-COMMITTED-AFTER-EMPTY",
                ThreadStandardSelectionPolicy.ResolveStableIndex(-1, (int)ThreadStandard.S, 6) == (int)ThreadStandard.S,
                ref pass, ref fail, "Пустое промежуточное значение ComboBox восстанавливается к последнему подтверждённому стандарту S.");
            Check("STANDARD-COMMITTED-S-SURVIVES-EMPTY-CLOSED-FIELD",
                ThreadStandardSelectionPolicy.ResolveAfterDropdownClose(true, (int)ThreadStandard.S, -1, (int)ThreadStandard.Tr, 6) == (int)ThreadStandard.S,
                ref pass, ref fail, "Подтверждённый стандарт S сохраняется, даже если нативное поле после закрытия временно сообщает SelectedIndex=-1.");
            Check("STANDARD-STABLE-CLOSED-SELECTION-WINS",
                ThreadStandardSelectionPolicy.ResolveAfterDropdownClose(false, -1, (int)ThreadStandard.S, (int)ThreadStandard.Tr, 6) == (int)ThreadStandard.S,
                ref pass, ref fail, "Устойчивый выбор S применяется и при запоздавшем уведомлении фиксации.");
            Check("STANDARD-CANCEL-RESTORES-LAST-COMMITTED",
                ThreadStandardSelectionPolicy.ResolveAfterDropdownClose(false, (int)ThreadStandard.S, -1, (int)ThreadStandard.Tr, 6) == (int)ThreadStandard.Tr,
                ref pass, ref fail, "Неподтверждённый промежуточный S не применяется после отмены раскрытого списка.");
            Check("STANDARD-COMMIT-USES-VALID-CURRENT-INDEX",
                ThreadStandardSelectionPolicy.ResolveCommittedIndex((int)ThreadStandard.S, (int)ThreadStandard.Tr, (int)ThreadStandard.ISO, 6) == (int)ThreadStandard.S,
                ref pass, ref fail, "Подтверждённый индекс S сразу становится источником состояния стандарта.");
            Check("STANDARD-COMMIT-USES-CAPTURED-INDEX-AFTER-NATIVE-CLEAR",
                ThreadStandardSelectionPolicy.ResolveCommittedIndex(-1, (int)ThreadStandard.S, (int)ThreadStandard.ISO, 6) == (int)ThreadStandard.S,
                ref pass, ref fail, "Если поле ComboBox уже пусто, подтверждённый кандидат S сохраняется для построения.");
            Check("STANDARD-COMMIT-PREFERS-NEW-CANDIDATE-OVER-STALE-CURRENT",
                ThreadStandardSelectionPolicy.ResolveCommittedIndex((int)ThreadStandard.Tr, (int)ThreadStandard.S, (int)ThreadStandard.Tr, 6) == (int)ThreadStandard.S,
                ref pass, ref fail, "Позднее уведомление со старым индексом Tr не отменяет уже выбранный S.");
            Check("STANDARD-COMMIT-FALLS-BACK-ONLY-WITHOUT-CANDIDATE",
                ThreadStandardSelectionPolicy.ResolveCommittedIndex(-1, -1, (int)ThreadStandard.Tr, 6) == (int)ThreadStandard.Tr,
                ref pass, ref fail, "Предыдущий стандарт сохраняется только если нет нового действительного выбора.");
            Check("STANDARD-CLOSED-FIELD-USES-COMMITTED-LABEL",
                ThreadStandardSelectionPolicy.ResolveFieldDisplayText("S", "", false) == "S" &&
                ThreadStandardSelectionPolicy.ResolveFieldDisplayText("S", "Tr", false) == "S" &&
                ThreadStandardSelectionPolicy.ResolveFieldDisplayText("S", "S", true) == "S",
                ref pass, ref fail, "Закрытое поле показывает подтверждённый стандарт даже при пустом/устаревшем native Text.");

            Check("TECHNOLOGY-STABLE-INDEX-RESOLUTION",
                ThreadTechnologySelectionPolicy.ResolveStableIndex(-1, 3, 5) == 3 &&
                ThreadTechnologySelectionPolicy.ResolveStableIndex(2, 3, 5) == 2 &&
                ThreadTechnologySelectionPolicy.ResolveStableIndex(-1, 8, 5) == 0,
                ref pass, ref fail, "Технология корректно использует стабильный индекс при пустом или недопустимом native SelectedIndex.");

            Check("TECHNOLOGY-COMMIT-PREFERS-NEW-FDM-CANDIDATE",
                ThreadTechnologySelectionPolicy.ResolveCommittedIndex(0, 3, 0, 5) == 3,
                ref pass, ref fail, "При первом выборе FDM запоздавший индекс Металл не отменяет выбор пользователя.");
            Check("TECHNOLOGY-COMMIT-SURVIVES-NATIVE-CLEAR",
                ThreadTechnologySelectionPolicy.ResolveCommittedIndex(-1, 3, 0, 5) == 3,
                ref pass, ref fail, "Подтверждённый FDM сохраняется, даже если ComboBox очищает SelectedIndex при закрытии списка.");
            Check("TECHNOLOGY-CLOSED-FIELD-RETAINS-COMMITTED-FDM",
                ThreadTechnologySelectionPolicy.ResolveAfterDropdownClose(true, 3, -1, 0, 5) == 3,
                ref pass, ref fail, "После закрытия списка остаётся подтверждённая технология FDM.");
            Check("TECHNOLOGY-CANCEL-RESTORES-PREVIOUS-CHOICE",
                ThreadTechnologySelectionPolicy.ResolveAfterDropdownClose(false, 3, 0, 0, 5) == 0,
                ref pass, ref fail, "Без подтверждения выбора отмена списка возвращает прежнюю технологию.");
            Check("TECHNOLOGY-REOPEN-IGNORES-STALE-NATIVE-INDEX",
                ThreadTechnologySelectionPolicy.ResolveAfterDropdownClose(false, -1, 0, 3, 5) == 3,
                ref pass, ref fail, "При повторном запуске формы устаревший native индекс Metal не отменяет подтверждённый FDM.");
            Check("TECHNOLOGY-CLOSED-FIELD-USES-COMMITTED-LABEL",
                ThreadTechnologySelectionPolicy.ResolveFieldDisplayText("FDM-печать (0,3)", "Металл (0)", false) == "FDM-печать (0,3)" &&
                ThreadTechnologySelectionPolicy.ResolveFieldDisplayText("FDM-печать (0,3)", "Металл (0)", true) == "Металл (0)",
                ref pass, ref fail, "Закрытое поле показывает сохранённую технологию, но во время раскрытия не заменяет native текст.");
            decimal fdmClearance, slsClearance, ignoredClearance;
            Check("TECHNOLOGY-PRESET-CLEARANCE-MAPPING",
                ThreadTechnologySelectionPolicy.TryGetPresetClearance(3, out fdmClearance) && fdmClearance == 0.3m &&
                ThreadTechnologySelectionPolicy.TryGetPresetClearance(2, out slsClearance) && slsClearance == 0.15m &&
                ThreadTechnologySelectionPolicy.FindPresetIndex(0.30, 0.0006) == 3 &&
                ThreadTechnologySelectionPolicy.FindPresetIndex(0.22, 0.0006) == 4 &&
                ThreadTechnologySelectionPolicy.IsPresetIndex(3) && !ThreadTechnologySelectionPolicy.IsPresetIndex(4) &&
                !ThreadTechnologySelectionPolicy.TryGetPresetClearance(4, out ignoredClearance),
                ref pass, ref fail, "FDM задаёт 0,30 мм, SLS — 0,15 мм, а «Другое» сохраняет ручной зазор.");

            Check("CHAMFER-COMMIT-PREFERS-BOTH-ENDS-CANDIDATE",
                ThreadChamferSelectionPolicy.ResolveCommittedIndex(0, 2, 0, 3) == 2,
                ref pass, ref fail, "Подтверждённый выбор «С обоих краёв» имеет приоритет над старым индексом «В начале».");
            Check("CHAMFER-COMMIT-SURVIVES-NATIVE-CLEAR",
                ThreadChamferSelectionPolicy.ResolveCommittedIndex(-1, 2, 0, 3) == 2,
                ref pass, ref fail, "Выбор «С обоих краёв» сохраняется, даже если нативный ComboBox очищает SelectedIndex.");
            Check("CHAMFER-CLOSED-FIELD-PRESERVES-BOTH-ENDS",
                ThreadChamferSelectionPolicy.ResolveAfterDropdownClose(true, 2, -1, 0, 3) == 2,
                ref pass, ref fail, "После закрытия списка остаётся подтверждённое расположение фасок с обоих краёв.");
            Check("CHAMFER-LATE-OLD-INDEX-DOES-NOT-ROLL-BACK",
                ThreadChamferSelectionPolicy.ResolveAfterDropdownClose(true, 2, 0, 2, 3) == 2,
                ref pass, ref fail, "Запоздалое уведомление со старым индексом не отменяет подтверждённый выбор обоих краёв.");
            Check("CHAMFER-CANCEL-RESTORES-LAST-COMMITTED",
                ThreadChamferSelectionPolicy.ResolveAfterDropdownClose(false, 2, -1, 0, 3) == 0,
                ref pass, ref fail, "Закрытие без подтверждения возвращает предыдущее расположение фаски.");
            Check("CHAMFER-STABLE-CLOSED-SELECTION-WINS",
                ThreadChamferSelectionPolicy.ResolveAfterDropdownClose(false, -1, 2, 0, 3) == 2,
                ref pass, ref fail, "Устойчивый новый выбор расположения принимается даже при запоздавшем уведомлении фиксации.");
            Check("CHAMFER-CLOSED-FIELD-USES-COMMITTED-LABEL",
                ThreadChamferSelectionPolicy.ResolveFieldDisplayText("С обоих краёв", "В начале", false) == "С обоих краёв" &&
                ThreadChamferSelectionPolicy.ResolveFieldDisplayText("С обоих краёв", "В начале", true) == "В начале",
                ref pass, ref fail, "Закрытое поле показывает подтверждённый вариант, а открытый список сохраняет нативное управление.");
            Check("CHAMFER-MODE-USES-COMMITTED-INDEX",
                ThreadChamferSelectionPolicy.ResolveChamferMode(true, 0, 2, 3) == 3 &&
                ThreadChamferSelectionPolicy.ResolveChamferMode(false, 2, 2, 3) == 0,
                ref pass, ref fail, "При построении подтверждённый индекс обоих краёв сильнее устаревшего индекса начала; выключено = 0.");

            Check("EDIT-ROLLBACK-VERIFIED-ONLY-WHEN-COMPLETE",
                ThreadEditSafetyPolicy.IsRollbackVerified(true, true, true, 12, 12),
                ref pass, ref fail, "Откат подтверждается только при успешном Abort, совпадении записи и полном составе группы.");
            Check("EDIT-ROLLBACK-REJECTS-ABORT-FAILURE",
                !ThreadEditSafetyPolicy.IsRollbackVerified(false, true, true, 12, 12),
                ref pass, ref fail, "Ошибка Abort не позволяет объявить восстановление подтверждённым.");
            Check("EDIT-ROLLBACK-REJECTS-RECORD-MISMATCH",
                !ThreadEditSafetyPolicy.IsRollbackVerified(true, true, false, 12, 12),
                ref pass, ref fail, "Откат отклоняется как неподтверждённый, если параметры/снимок исходной группы изменились.");
            Check("EDIT-ROLLBACK-REJECTS-INCOMPLETE-GROUP",
                !ThreadEditSafetyPolicy.IsRollbackVerified(true, true, true, 12, 11) &&
                !ThreadEditSafetyPolicy.IsRollbackVerified(true, false, false, 12, 0),
                ref pass, ref fail, "Неполная или отсутствующая исходная группа не считается восстановленной.");

            int[] deleteOrder;
            bool hasDeleteOrder = ThreadEditSafetyPolicy.TryBuildDeletionOrder(
                new[] { ThreadEditMemberKind.WorkFeature, ThreadEditMemberKind.Sketch, ThreadEditMemberKind.Feature,
                        ThreadEditMemberKind.WorkFeature, ThreadEditMemberKind.Sketch, ThreadEditMemberKind.Feature },
                out deleteOrder);
            Check("EDIT-DELETE-PLAN-FEATURES-FIRST-REVERSE", hasDeleteOrder &&
                deleteOrder.SequenceEqual(new[] { 5, 2, 4, 1, 3, 0 }),
                ref pass, ref fail, "План удаления: фичи в обратном порядке создания, затем эскизы, затем рабочие объекты.");
            Check("EDIT-DELETE-PLAN-REJECT-UNSUPPORTED", !ThreadEditSafetyPolicy.TryBuildDeletionOrder(
                new[] { ThreadEditMemberKind.Feature, ThreadEditMemberKind.Unsupported }, out _),
                ref pass, ref fail, "Неизвестный тип в группе отклоняется до первого удаления.");


            // Build155: pure preflight contract for the isolated packaging-thread prototype.
            Check("PACKAGING-ONE-START-LEAD-EQUALS-PITCH",
                PackagingThreadGeometryPolicy.TryResolve(28, 2.7, 1, 0.025, 0.0, 2.0, false, out var pack1, out _) &&
                Math.Abs(pack1.LeadMm - 2.7) < 1e-12,
                ref pass, ref fail, "Для однозаходной резьбы lead равен pitch.");
            Check("PACKAGING-TWO-START-LEAD-TWICE-PITCH",
                PackagingThreadGeometryPolicy.TryResolve(28, 2.7, 2, 0.025, 0.0, 2.0, false, out var pack2, out _) &&
                Math.Abs(pack2.LeadMm - 5.4) < 1e-12,
                ref pass, ref fail, "Для двух заходов осевое перемещение за оборот равно двум шагам.");
            Check("PACKAGING-THREE-START-LEAD-THREE-PITCH",
                PackagingThreadGeometryPolicy.TryResolve(28, 1.5, 3, 0.025, 0.0, 2.0, false, out var pack3, out _) &&
                Math.Abs(pack3.LeadMm - 4.5) < 1e-12,
                ref pass, ref fail, "Для трёх заходов lead равен трём pitch.");
            Check("PACKAGING-HEIGHT-SCALES-WITH-DIAMETER",
                PackagingThreadGeometryPolicy.TryResolve(20, 2.7, 1, 0.02, 0.0, 1.0, false, out var packSmall, out _) &&
                PackagingThreadGeometryPolicy.TryResolve(40, 2.7, 1, 0.02, 0.0, 1.0, false, out var packLarge, out _) &&
                Math.Abs(packLarge.HeightMm / packSmall.HeightMm - 2.0) < 1e-12,
                ref pass, ref fail, "Высота пропорциональна диаметру внутри абсолютных безопасных пределов.");
            Check("PACKAGING-HEIGHT-LOWER-BOUND",
                PackagingThreadGeometryPolicy.TryResolve(10, 0.5, 1, 0.005, 0.0, 1.0, false, out var packMin, out _) &&
                Math.Abs(packMin.HeightMm - PackagingThreadGeometryPolicy.MinHeightMm) < 1e-12,
                ref pass, ref fail, "Абсолютная минимальная высота не даёт получить слишком тонкий профиль.");
            Check("PACKAGING-HEIGHT-UPPER-BOUND-INCLUDES-PITCH-SAFETY",
                PackagingThreadGeometryPolicy.TryResolve(100, 2.0, 1, 0.06, 0.0, 1.0, false, out var packMax, out _) &&
                Math.Abs(packMax.HeightMm - (2.0 * PackagingThreadGeometryPolicy.MaxProfileDepthPitchRatio / (1.0 + PackagingThreadGeometryPolicy.DefaultEmbedRatio))) < 1e-12 &&
                packMax.HeightMm < PackagingThreadGeometryPolicy.MaxHeightMm &&
                packMax.HeightMm + packMax.EmbedMm <= 2.0 * PackagingThreadGeometryPolicy.MaxProfileDepthPitchRatio + 1e-9,
                ref pass, ref fail, "Профиль ограничен безопасной глубиной относительно шага и абсолютным максимумом.");
            var packD22 = new PackagingThreadGeometryPolicy.ResolvedParameters();
            var packD31 = new PackagingThreadGeometryPolicy.ResolvedParameters();
            var packD52 = new PackagingThreadGeometryPolicy.ResolvedParameters();
            bool diametersResolved =
                PackagingThreadGeometryPolicy.TryResolve(22, 2.7, 3, 0.025, 0.0, 1.0, false, out packD22, out _) &&
                PackagingThreadGeometryPolicy.TryResolve(31, 2.7, 3, 0.025, 0.0, 1.0, false, out packD31, out _) &&
                PackagingThreadGeometryPolicy.TryResolve(52, 2.7, 3, 0.025, 0.0, 1.0, false, out packD52, out _);
            double packW22 = diametersResolved ? PackagingThreadGeometryPolicy.ResolveProfileBaseWidthMm(2.7, packD22.HeightMm, packD22.EmbedMm) : 0;
            double packW31 = diametersResolved ? PackagingThreadGeometryPolicy.ResolveProfileBaseWidthMm(2.7, packD31.HeightMm, packD31.EmbedMm) : 0;
            double packW52 = diametersResolved ? PackagingThreadGeometryPolicy.ResolveProfileBaseWidthMm(2.7, packD52.HeightMm, packD52.EmbedMm) : 0;
            Check("PACKAGING-DIAMETER-22-31-52-PROFILE-ENVELOPE",
                diametersResolved && packW22 <= 2.7 * PackagingThreadGeometryPolicy.MaxProfileBaseWidthPitchRatio + 1e-12 &&
                packW31 > packW22 && packW52 >= packW31 &&
                packW52 <= 2.7 * PackagingThreadGeometryPolicy.MaxProfileBaseWidthPitchRatio + 1e-12 &&
                (packD52.HeightMm + packD52.EmbedMm) <= 2.7 * PackagingThreadGeometryPolicy.MaxProfileDepthPitchRatio + 1e-9,
                ref pass, ref fail, "На D22/D31/D52 с P=2,7 мм сечение расширяет основания по мере роста глубины и остаётся в пределах шага.");
            Check("PACKAGING-CLEARANCE-INDEPENDENT",
                PackagingThreadGeometryPolicy.TryResolve(28, 2.7, 1, 0.025, 0.0, 1.0, false, out var packNom, out _) &&
                PackagingThreadGeometryPolicy.TryResolve(28, 2.7, 1, 0.025, 0.2, 1.0, false, out var packPrint, out _) &&
                Math.Abs(packNom.HeightMm - packPrint.HeightMm) < 1e-12 &&
                Math.Abs(packPrint.ClearanceMm - 0.2) < 1e-12,
                ref pass, ref fail, "Зазор печати сохраняется отдельно и не меняет номинальную высоту.");
            Check("PACKAGING-AUTO-DETECT-CYLINDRICAL-FACE-TYPE",
                PackagingThreadGeometryPolicy.IsInternalFromFaceParamReversed(false) &&
                !PackagingThreadGeometryPolicy.IsInternalFromFaceParamReversed(true),
                ref pass, ref fail, "Ориентация цилиндрической грани Inventor определяет внутреннюю поверхность отверстия (IsParamReversed=false) и наружную поверхность вала (true).");
            Check("PACKAGING-INTERNAL-AND-EXTERNAL-SAME-NOMINAL-PROFILE",
                PackagingThreadGeometryPolicy.TryResolve(28, 2.7, 1, 0.025, 0.0, 1.0, true, out var packInternal, out _) &&
                PackagingThreadGeometryPolicy.TryResolve(28, 2.7, 1, 0.025, 0.0, 1.0, false, out var packExternal, out _) &&
                Math.Abs(packInternal.HeightMm - packExternal.HeightMm) < 1e-12,
                ref pass, ref fail, "Направление выступа выбирается ролью внутренней/наружной геометрии, а номинальная высота не меняется.");
            Check("PACKAGING-INTERNAL-RIB-PROJECTS-INTO-BORE-AND-JOINS-WALL",
                PackagingThreadGeometryPolicy.TryResolveProfileRadiiMm(14.0, 0.7, 0.14, true, out double innerRoot, out double innerCrest, out _) &&
                innerRoot > 14.0 && innerCrest < 14.0 && innerRoot > innerCrest &&
                PackagingThreadGeometryPolicy.TryResolveProfileRadiiMm(14.0, 0.7, 0.14, false, out double outerRoot, out double outerCrest, out _) &&
                outerRoot < 14.0 && outerCrest > 14.0 && outerRoot < outerCrest,
                ref pass, ref fail, "Для внутреннего валика корень радиально пересекает стенку, а вершина выступает в отверстие; наружный профиль остаётся наружным.");
            Check("PACKAGING-INTERNAL-PROFILE-REJECTS-INVALID-RADII",
                !PackagingThreadGeometryPolicy.TryResolveProfileRadiiMm(0.05, 0.2, 0.1, true, out _, out _, out _) &&
                !PackagingThreadGeometryPolicy.TryResolveProfileRadiiMm(14.0, 20.0, 0.1, true, out _, out _, out _),
                ref pass, ref fail, "Внутренний валик отклоняется при отрицательном радиусе или неверном взаимном расположении вершин.");
            Check("PACKAGING-RUNOUT-PLAN-BOTH-ENDS-PRESERVES-CORE",
                PackagingThreadRunoutPolicy.TryResolve(10.0, 2.7, 8.1, 0.775, 0.155, 1.674, false, true, true, out var bothRunouts, out _) &&
                bothRunouts.StartLengthMm > 0.0 && bothRunouts.EndLengthMm > 0.0 &&
                Math.Abs(bothRunouts.TotalLengthMm - bothRunouts.StartLengthMm - bothRunouts.CoreLengthMm - bothRunouts.EndLengthMm) < 1e-9 &&
                bothRunouts.CoreLengthMm >= 8.1 * PackagingThreadRunoutPolicy.MinimumCoreLeadFraction - 1e-9 &&
                bothRunouts.StartSectionCount >= PackagingThreadRunoutPolicy.MinimumSectionCount &&
                bothRunouts.EndSectionCount <= PackagingThreadRunoutPolicy.MaximumSectionCount,
                ref pass, ref fail, "Два сбега сохраняют заданную длину на каждом конце и оставляют минимум четверти оборота основного Coil.");
            Check("PACKAGING-RUNOUT-PLAN-INDEPENDENT-END-TOGGLES",
                PackagingThreadRunoutPolicy.TryResolve(10.0, 2.7, 8.1, 0.775, 0.155, 1.674, false, true, false, out var startOnly, out _) &&
                startOnly.StartLengthMm > 0.0 && startOnly.EndLengthMm == 0.0 && startOnly.EndSectionCount == 0 &&
                PackagingThreadRunoutPolicy.TryResolve(10.0, 2.7, 8.1, 0.775, 0.155, 1.674, false, false, true, out var endOnly, out _) &&
                endOnly.StartLengthMm == 0.0 && endOnly.EndLengthMm > 0.0 && endOnly.StartSectionCount == 0,
                ref pass, ref fail, "Начальный и конечный сбеги включаются независимо из UI.");
            Check("PACKAGING-RUNOUT-EXTERNAL-ONE-TWELFTH-TURN",
                PackagingThreadRunoutPolicy.TryResolve(10.0, 2.7, 8.1, 0.775, 0.155, 1.674, false, true, true, out var externalRunouts, out _) &&
                Math.Abs(externalRunouts.StartLengthMm - 8.1 / 12.0) < 1e-9 &&
                Math.Abs(externalRunouts.EndLengthMm - 8.1 / 12.0) < 1e-9 &&
                Math.Abs(externalRunouts.CoreLengthMm - (10.0 - 2.0 * 8.1 / 12.0)) < 1e-9 &&
                Math.Abs(externalRunouts.TargetTurnFraction - 1.0 / 12.0) < 1e-12 &&
                !externalRunouts.IsInternalThread,
                ref pass, ref fail, "Оба сбега наружной многозаходной резьбы равны 1/12 полного оборота по ходу L=P×N.");
            Check("PACKAGING-RUNOUT-INTERNAL-ONE-SIXTH-TURN",
                PackagingThreadRunoutPolicy.TryResolve(10.0, 2.7, 8.1, 0.775, 0.155, 1.674, true, true, true, out var internalRunouts, out _) &&
                Math.Abs(internalRunouts.StartLengthMm - 8.1 / 6.0) < 1e-9 &&
                Math.Abs(internalRunouts.EndLengthMm - 8.1 / 6.0) < 1e-9 &&
                Math.Abs(internalRunouts.CoreLengthMm - (10.0 - 2.0 * 8.1 / 6.0)) < 1e-9 &&
                Math.Abs(internalRunouts.TargetTurnFraction - 1.0 / 6.0) < 1e-12 &&
                internalRunouts.IsInternalThread,
                ref pass, ref fail, "Оба сбега внутреннего положительного валика равны 1/6 полного оборота по ходу L=P×N.");
            Check("PACKAGING-RUNOUT-SHORT-THREAD-SCALES-BOTH-RUNOUTS",
                PackagingThreadRunoutPolicy.TryResolve(4.05, 2.7, 8.1, 1.125, 0.225, 1.674, true, true, true, out var shortenedRunouts, out _) &&
                Math.Abs(shortenedRunouts.StartLengthMm - 1.0125) < 1e-9 &&
                Math.Abs(shortenedRunouts.EndLengthMm - 1.0125) < 1e-9 &&
                Math.Abs(shortenedRunouts.CoreLengthMm - 2.025) < 1e-9 &&
                shortenedRunouts.EffectiveTurnFraction < shortenedRunouts.TargetTurnFraction &&
                shortenedRunouts.StartSectionCount >= PackagingThreadRunoutPolicy.MinimumSectionCount &&
                shortenedRunouts.EndSectionCount >= PackagingThreadRunoutPolicy.MinimumSectionCount,
                ref pass, ref fail, "Для короткой внутренней резьбы оба сбега равномерно укорачиваются, сохраняя минимальный рабочий участок.");
            Check("PACKAGING-RUNOUT-BELOW-MINIMUM-CORE-REJECTED",
                !PackagingThreadRunoutPolicy.TryResolve(2.0, 2.7, 8.1, 1.125, 0.225, 1.674, true, true, true, out _, out _),
                ref pass, ref fail, "Длина меньше минимального рабочего участка по-прежнему отклоняется явно.");
            Check("PACKAGING-RUNOUT-SMOOTHSTEP-ENDPOINTS-AND-MONOTONICITY",
                Math.Abs(PackagingThreadRunoutPolicy.SmoothStep(0.0)) < 1e-12 &&
                Math.Abs(PackagingThreadRunoutPolicy.SmoothStep(1.0) - 1.0) < 1e-12 &&
                PackagingThreadRunoutPolicy.GetCrestFactor(0.0, true) == PackagingThreadRunoutPolicy.TerminalCrestFactor &&
                Math.Abs(PackagingThreadRunoutPolicy.GetCrestFactor(1.0, true) - 1.0) < 1e-12 &&
                Math.Abs(PackagingThreadRunoutPolicy.GetCrestFactor(0.0, false) - 1.0) < 1e-12 &&
                Math.Abs(PackagingThreadRunoutPolicy.GetCrestFactor(1.0, false) - PackagingThreadRunoutPolicy.TerminalCrestFactor) < 1e-12 &&
                PackagingThreadRunoutPolicy.GetCrestFactor(0.25, true) < PackagingThreadRunoutPolicy.GetCrestFactor(0.75, true),
                ref pass, ref fail, "Сбег использует smoothstep с нулевым наклоном на обоих концах и монотонно меняет высоту.");
            Check("PACKAGING-RUNOUT-ROOT-OVERLAP-AND-SMOOTH-FADE",
                Math.Abs(PackagingThreadRunoutPolicy.GetRootFactor(0.0, true, 0.05) - 0.30) < 1e-12 &&
                Math.Abs(PackagingThreadRunoutPolicy.GetRootFactor(1.0, true, 0.05) - 1.0) < 1e-12 &&
                Math.Abs(PackagingThreadRunoutPolicy.GetRootFactor(0.0, false, 0.05) - 1.0) < 1e-12 &&
                Math.Abs(PackagingThreadRunoutPolicy.GetRootFactor(1.0, false, 0.05) - 0.30) < 1e-12 &&
                Math.Abs(PackagingThreadRunoutPolicy.GetRootFactor(0.5, true, 0.155) - 0.55) < 1e-12 &&
                PackagingThreadRunoutPolicy.GetRootFactor(0.25, true, 0.155) < PackagingThreadRunoutPolicy.GetRootFactor(0.75, true, 0.155) &&
                PackagingThreadRunoutPolicy.GetRootFactor(0.25, false, 0.155) > PackagingThreadRunoutPolicy.GetRootFactor(0.75, false, 0.155),
                ref pass, ref fail, "Корень сохраняет ограниченное проникновение и затухает по smoothstep с нулевым наклоном на обоих концах.");
            Check("PACKAGING-VENT-SLOT-DEFAULTS-ARE-EXTERNAL-4-INTERNAL-8",
                PackagingThreadVentSlotPolicy.GetDefaultCount(false) == 4 &&
                PackagingThreadVentSlotPolicy.GetDefaultCount(true) == 8 &&
                Math.Abs(PackagingThreadVentSlotPolicy.GetDefaultWidthDegrees(false) - 14.0) < 1e-12 &&
                Math.Abs(PackagingThreadVentSlotPolicy.GetDefaultWidthDegrees(true) - 14.0) < 1e-12,
                ref pass, ref fail, "Both external and internal default widths are 14 degrees; the 56-degree PCO1881 drawing reference remains a separately selectable value, not the modelling default.");
            Check("PACKAGING-VENT-SLOT-CUTTER-START-AND-END-OVERRUN",
                Math.Abs(PackagingThreadVentSlotPolicy.GetStartOverrunMm(2.025) - 2.275) < 1e-12 &&
                Math.Abs(PackagingThreadVentSlotPolicy.GetAxialOverrunMm(0.4) - 1.0) < 1e-12 &&
                Math.Abs(PackagingThreadVentSlotPolicy.GetAxialOverrunMm(8.1) - 8.1) < 1e-12 &&
                Math.Abs(PackagingThreadVentSlotPolicy.GetEndOverrunMm(8.1, 40.0) - 8.1) < 1e-12 &&
                Math.Abs(PackagingThreadVentSlotPolicy.GetEndOverrunMm(8.1, 2.0) - 2.25) < 1e-12 &&
                Math.Abs(PackagingThreadVentSlotPolicy.GetEndOverrunMm(8.1, 0.0) - 0.25) < 1e-12,
                ref pass, ref fail, "Start extends 0.25 mm before the selected edge; end prefers one full lead but is capped to only 0.25 mm past the opposite cylindrical-face boundary.");
            Check("PACKAGING-VENT-SLOT-OUTER-PLAN-FOUR-EVENLY-SPACED",
                PackagingThreadVentSlotPolicy.TryResolve(true, false, 4, 56.0, out var ventOuter, out _) &&
                ventOuter.Enabled && ventOuter.SlotCount == 4 && Math.Abs(ventOuter.SpacingDegrees - 90.0) < 1e-12 &&
                Math.Abs(ventOuter.GetStartAngleDegrees(0) - 28.0) < 1e-12 &&
                Math.Abs(ventOuter.GetStartAngleDegrees(1) - 118.0) < 1e-12 &&
                Math.Abs(ventOuter.GetStartAngleDegrees(3) - 298.0) < 1e-12,
                ref pass, ref fail, "Внешние пропилы PCO1881 распределяются через 90 градусов; полный сектор 56 градусов (28 градусов на сторону).");
            Check("PACKAGING-VENT-SLOT-INNER-PLAN-EIGHT-EVENLY-SPACED",
                PackagingThreadVentSlotPolicy.TryResolve(true, true, 8, 28.0, out var ventInner, out _) &&
                ventInner.Enabled && ventInner.SlotCount == 8 && Math.Abs(ventInner.SpacingDegrees - 45.0) < 1e-12 &&
                Math.Abs(ventInner.GetStartAngleDegrees(0) - 14.0) < 1e-12 &&
                Math.Abs(ventInner.GetStartAngleDegrees(7) - 329.0) < 1e-12,
                ref pass, ref fail, "Восемь внутренних прорезей по 28 градусов — изменяемая гипотеза; распределение через 45 градусов не является требованием чертежа горловины.");
            Check("PACKAGING-VENT-SLOT-DISABLED-PRESERVES-NO-SLOTS",
                PackagingThreadVentSlotPolicy.TryResolve(false, true, 0, double.NaN, out var noVentSlots, out _) &&
                !noVentSlots.Enabled && noVentSlots.SlotCount == 0,
                ref pass, ref fail, "При выключенном чекбоксе политика не создаёт пропилов и не валидирует неиспользуемые поля.");
            Check("PACKAGING-VENT-SLOT-REJECTS-OVERLAPPING-WIDTH",
                !PackagingThreadVentSlotPolicy.TryResolve(true, false, 8, 45.0, out _, out _) &&
                !PackagingThreadVentSlotPolicy.TryResolve(true, false, 4, 0.0, out _, out _) &&
                !PackagingThreadVentSlotPolicy.TryResolve(true, false, 21, 10.0, out _, out _),
                ref pass, ref fail, "Ширина должна быть положительной и меньше углового интервала, число прорезей ограничено 1–20.");
            Check("PACKAGING-VENT-FRAGMENT-REMOVE-SHORT-END-SEGMENT",
                PackagingThreadVentFragmentPolicy.TryResolve(204.444444444, false, 4, 14.0, 3, 8.1, 1.674, out var shortVentFragment, out _) &&
                shortVentFragment.ShouldTrim && Math.Abs(shortVentFragment.GapAngleDegrees - 76.0) < 1e-9 &&
                shortVentFragment.FractionOfGap < PackagingThreadVentFragmentPolicy.FragmentThresholdFraction &&
                Math.Abs(shortVentFragment.AxialTravelMm - 8.1 * shortVentFragment.FragmentAngleDegrees / 360.0) < 1e-9 &&
                shortVentFragment.SweepWidthDegrees > shortVentFragment.FragmentAngleDegrees,
                ref pass, ref fail, "Короткий терминальный фрагмент меньше 1/4 свободного сегмента разрешает очистку; для выбора граней используется локальный осевой/угловой диапазон.");
            Check("PACKAGING-VENT-FRAGMENT-START-USES-NEAREST-BOUNDARY",
                PackagingThreadVentFragmentPolicy.TryResolve(120.0, true, 4, 14.0, 3, 8.1, 1.674, out var startTwoVentFragment, out _) &&
                startTwoVentFragment.ShouldTrim && Math.Abs(startTwoVentFragment.FragmentAngleDegrees - 23.0) < 1e-9 &&
                Math.Abs(startTwoVentFragment.SlotBoundaryDegrees - 97.0) < 1e-9 &&
                Math.Abs(startTwoVentFragment.SweepWidthDegrees - 23.04) < 1e-9,
                ref pass, ref fail, "В начале выбирается ближайшая граница 97°, а не граница 173° за 53°; короткий фрагмент корректно определяется.");
            Check("PACKAGING-VENT-FRAGMENT-START-BORDERLINE-23-DEG-TRIMS-WITHIN-TOLERANCE",
                PackagingThreadVentFragmentPolicy.TryResolve(240.0, true, 4, 14.0, 3, 8.1, 1.674, out var twentyThreeDegreeVentFragment, out _) &&
                twentyThreeDegreeVentFragment.ShouldTrim && Math.Abs(twentyThreeDegreeVentFragment.FractionOfGap - (23.0 / 76.0)) < 1e-9 &&
                Math.Abs(twentyThreeDegreeVentFragment.FractionOfSector - (23.0 / 90.0)) < 1e-9 &&
                Math.Abs(twentyThreeDegreeVentFragment.EffectiveThresholdDegrees - 23.5) < 1e-9,
                ref pass, ref fail, "23° is 25.556% of the 90° repeated sector; it is treated as a borderline quarter-sector tail within the documented 1° angular tolerance.");
            Check("PACKAGING-VENT-FRAGMENT-FACE-WINDOW-IS-HANDEDNESS-AND-ENDPOINT-AWARE",
                PackagingThreadVentFragmentPolicy.UseForwardFacePhaseWindow(true, 1.0) &&
                !PackagingThreadVentFragmentPolicy.UseForwardFacePhaseWindow(false, 1.0) &&
                !PackagingThreadVentFragmentPolicy.UseForwardFacePhaseWindow(true, -1.0) &&
                PackagingThreadVentFragmentPolicy.UseForwardFacePhaseWindow(false, -1.0) &&
                PackagingThreadVentFragmentPolicy.GetFacePhaseCorrectionSign(true, 1.0) == -1.0 &&
                PackagingThreadVentFragmentPolicy.GetFacePhaseCorrectionSign(false, 1.0) == 1.0 &&
                PackagingThreadVentFragmentPolicy.GetFacePhaseCorrectionSign(true, -1.0) == -1.0 &&
                PackagingThreadVentFragmentPolicy.GetFacePhaseCorrectionSign(false, -1.0) == 1.0,
                ref pass, ref fail, "Face search uses paired correction-sign/window orientations for RH/LH at both endpoints; the previous single-sign inversion missed all tails.");
            Check("PACKAGING-VENT-FRAGMENT-PHASE-CORRECTS-RH-START-USING-INVENTOR-FACE-SIGN",
                Math.Abs(PackagingThreadVentFragmentPolicy.CorrectAngleToEndpoint(75.555555556, 0.1, 0.0, 8.1, -1.0) - 120.0) < 1e-6,
                ref pass, ref fail, "Для правой резьбы азимут PointOnFace на 1 мм от начала корректируется обратным знаком направления профиля.");
            Check("PACKAGING-VENT-FRAGMENT-PHASE-CORRECTS-LH-END-USING-INVENTOR-FACE-SIGN",
                Math.Abs(PackagingThreadVentFragmentPolicy.CorrectAngleToEndpoint(160.0, 0.44, 0.54, 8.1, 1.0) - 204.444444444) < 1e-6,
                ref pass, ref fail, "Для левой резьбы азимут PointOnFace за 1 мм до конца корректируется обратным знаком направления профиля.");

            Check("PACKAGING-VENT-FRAGMENT-LONG-REMAINDER-PRESERVED",
                PackagingThreadVentFragmentPolicy.TryResolve(324.444444444, false, 4, 14.0, 3, 8.1, 1.674, out var longVentFragment, out _) &&
                !longVentFragment.ShouldTrim && longVentFragment.FragmentAngleDegrees > longVentFragment.EffectiveThresholdDegrees,
                ref pass, ref fail, "Фрагмент дальше эффективного четвертного порога сохраняется.");
            Check("PACKAGING-VENT-FRAGMENT-ALREADY-IN-SLOT-DOES-NOT-ADD-CUT",
                PackagingThreadVentFragmentPolicy.TryResolve(84.0, true, 4, 14.0, 3, 8.1, 1.674, out var endpointInsideSlot, out _) &&
                !endpointInsideSlot.ShouldTrim,
                ref pass, ref fail, "Если конец уже находится внутри ширины существующего пропила, дополнительный вырез не добавляется.");
            Check("PACKAGING-VENT-FRAGMENT-SUPPRESSES-CUT-THAT-CAN-HIT-NEIGHBOUR-START",
                PackagingThreadVentFragmentPolicy.TryResolve(6.0, false, 1, 10.0, 12, 1.0, 0.9, out var unsafeVentFragment, out _) &&
                !unsafeVentFragment.ShouldTrim && unsafeVentFragment.Reason.IndexOf("соседний заход", StringComparison.OrdinalIgnoreCase) >= 0,
                ref pass, ref fail, "Защитная политика не делает локальный концевой вырез, если его угол и footprint профиля могут повредить соседний заход.");

            Check("PACKAGING-THIN-WALL-REJECT",
                !PackagingThreadGeometryPolicy.TryResolve(28, 2.7, 1, 0.025, 0.0, 0.4, true, out _, out _),
                ref pass, ref fail, "Предварительная политика закрывается при стенке тоньше 0,6 мм.");
            Check("PACKAGING-INVALID-STARTS-REJECT",
                !PackagingThreadGeometryPolicy.TryResolve(28, 2.7, 0, 0.025, 0.0, 1.0, false, out _, out _) &&
                !PackagingThreadGeometryPolicy.TryResolve(28, 2.7, 13, 0.025, 0.0, 1.0, false, out _, out _),
                ref pass, ref fail, "Ноль и больше 12 заходов отклоняются.");
            Check("PACKAGING-INVALID-PITCH-REJECT",
                !PackagingThreadGeometryPolicy.TryResolve(28, 0.1, 1, 0.025, 0.0, 1.0, false, out _, out _) &&
                !PackagingThreadGeometryPolicy.TryResolve(28, 13.0, 1, 0.025, 0.0, 1.0, false, out _, out _),
                ref pass, ref fail, "Шаг вне документированного диапазона отклоняется.");
            Check("PACKAGING-INVALID-RATIO-REJECT",
                !PackagingThreadGeometryPolicy.TryResolve(28, 1.0, 1, 0.001, 0.0, 1.0, false, out _, out _) &&
                !PackagingThreadGeometryPolicy.TryResolve(28, 1.0, 1, 0.1, 0.0, 1.0, false, out _, out _),
                ref pass, ref fail, "Отношение высоты вне безопасного диапазона отклоняется.");
            Check("PACKAGING-INVALID-CLEARANCE-REJECT",
                !PackagingThreadGeometryPolicy.TryResolve(28, 1.0, 1, 0.025, -0.1, 1.0, false, out _, out _) &&
                !PackagingThreadGeometryPolicy.TryResolve(28, 1.0, 1, 0.025, 0.6, 1.0, false, out _, out _),
                ref pass, ref fail, "Отрицательный и чрезмерный зазор печати отклоняются.");
            Check("PACKAGING-TURNS-USE-LEAD",
                PackagingThreadGeometryPolicy.TryGetTurns(10.0, 5.4, out double packTurns) &&
                Math.Abs(packTurns - (10.0 / 5.4)) < 1e-12,
                ref pass, ref fail, "Число оборотов рассчитывается по lead, а не по pitch.");
            Check("PACKAGING-TURNS-INVALID-REJECT",
                !PackagingThreadGeometryPolicy.TryGetTurns(0.0, 2.0, out _) &&
                !PackagingThreadGeometryPolicy.TryGetTurns(10.0, 0.0, out _),
                ref pass, ref fail, "Нулевая длина и нулевой lead отклоняются.");
            Check("PACKAGING-START-PHASES-EVENLY-SPACED",
                Math.Abs(PackagingThreadGeometryPolicy.GetStartPhaseDegrees(0, 3) - 0.0) < 1e-12 &&
                Math.Abs(PackagingThreadGeometryPolicy.GetStartPhaseDegrees(1, 3) - 120.0) < 1e-12 &&
                Math.Abs(PackagingThreadGeometryPolicy.GetStartPhaseDegrees(2, 3) - 240.0) < 1e-12,
                ref pass, ref fail, "Начальные фазы заходов распределяются равномерно по окружности.");
            double[] packRadial0 = PackagingThreadPhaseMath.RotateAroundAxis(new[] { 1.0, 0.0, 0.0 }, new[] { 0.0, 0.0, 1.0 }, 0.0);
            double[] packRadial1 = PackagingThreadPhaseMath.RotateAroundAxis(new[] { 1.0, 0.0, 0.0 }, new[] { 0.0, 0.0, 1.0 }, 2.0 * Math.PI / 3.0);
            double[] packRadial2 = PackagingThreadPhaseMath.RotateAroundAxis(new[] { 1.0, 0.0, 0.0 }, new[] { 0.0, 0.0, 1.0 }, 4.0 * Math.PI / 3.0);
            double phaseDot01 = packRadial0[0] * packRadial1[0] + packRadial0[1] * packRadial1[1] + packRadial0[2] * packRadial1[2];
            double phaseDot12 = packRadial1[0] * packRadial2[0] + packRadial1[1] * packRadial2[1] + packRadial1[2] * packRadial2[2];
            double phaseDot20 = packRadial2[0] * packRadial0[0] + packRadial2[1] * packRadial0[1] + packRadial2[2] * packRadial0[2];
            Check("PACKAGING-START-PHASE-VECTORS-ROTATE-AROUND-AXIS",
                Math.Abs(phaseDot01 + 0.5) < 1e-12 && Math.Abs(phaseDot12 + 0.5) < 1e-12 && Math.Abs(phaseDot20 + 0.5) < 1e-12 &&
                Math.Abs(Math.Sqrt(packRadial0[0] * packRadial0[0] + packRadial0[1] * packRadial0[1] + packRadial0[2] * packRadial0[2]) - 1.0) < 1e-12 &&
                Math.Abs(Math.Sqrt(packRadial1[0] * packRadial1[0] + packRadial1[1] * packRadial1[1] + packRadial1[2] * packRadial1[2]) - 1.0) < 1e-12 &&
                Math.Abs(Math.Sqrt(packRadial2[0] * packRadial2[0] + packRadial2[1] * packRadial2[1] + packRadial2[2] * packRadial2[2]) - 1.0) < 1e-12,
                ref pass, ref fail, "Для трёх заходов радиальные направления повернуты на 0/120/240° без изменения длины вектора.");
            Check("PACKAGING-RH-LH-CLOCKWISE-MAPPING-INDEPENDENT-OF-EDGE",
                !PackagingThreadPhaseMath.ResolveClockwiseRotation(true) &&
                PackagingThreadPhaseMath.ResolveClockwiseRotation(false),
                ref pass, ref fail, "Based on the Inventor result, RH maps to ClockwiseRotation=false and LH to true; selected end changes axial build direction only.");
            Check("PACKAGING-RH-HIGH-END-AND-LH-LOW-END-DO-NOT-COLLAPSE-TO-SAME-CLOCKWISE-FLAG",
                PackagingThreadPhaseMath.ResolveClockwiseRotation(true) !=
                PackagingThreadPhaseMath.ResolveClockwiseRotation(false),
                ref pass, ref fail, "RH and LH requests that previously both produced ClockwiseRotation=false now differ.");
            string packNameA = PackagingThreadFeatureNamePolicy.CreateSafeUniqueName(1, 3, 0.0, Guid.Parse("11111111-1111-1111-1111-111111111111"));
            string packNameB = PackagingThreadFeatureNamePolicy.CreateSafeUniqueName(1, 3, 0.0, Guid.Parse("22222222-2222-2222-2222-222222222222"));
            Check("PACKAGING-FEATURE-NAMES-ARE-SAFE-AND-UNIQUE",
                packNameA != packNameB && packNameA.StartsWith("HVPkg_", StringComparison.Ordinal) &&
                packNameA.IndexOf('/') < 0 && packNameA.IndexOf('\\') < 0 && packNameA.IndexOf('°') < 0 &&
                packNameA.IndexOf('—') < 0 && packNameA.IndexOf(' ') < 0,
                ref pass, ref fail, "Feature labels use conservative ASCII and differ for separate builds, preventing opposite-end name collisions.");

            Console.WriteLine("Helivanta — Metadata, Preview, Wall Thickness Safety, Sequential Native Inventor Thread Conversion, Nominal Diameter, Custom Pitch, Folder Selection, Technology Selection, Standard Selection, Chamfer Location Selection, Naming, Undo/Redo and Thread Edit Recovery Safety Test");
            Console.WriteLine("PASS: " + pass + "   FAIL: " + fail);
            Console.WriteLine(fail == 0 ? "RESULT: PASS" : "RESULT: FAIL");
            return fail == 0 ? 0 : 2;
        }

        private static ThreadMetadataRecord CloneRecord(ThreadMetadataRecord record)
        {
            return JsonSerializer.Deserialize<ThreadMetadataRecord>(JsonSerializer.Serialize(record));
        }

        private static ThreadTargetSnapshot CloneTarget(ThreadTargetSnapshot target)
        {
            return new ThreadTargetSnapshot
            {
                Center = target.Center == null ? null : (double[])target.Center.Clone(),
                Axis = target.Axis == null ? null : (double[])target.Axis.Clone(),
                RadiusCm = target.RadiusCm,
                LengthCm = target.LengthCm,
                IsExternal = target.IsExternal,
                BodyName = target.BodyName,
                StartIsShoulder = target.StartIsShoulder,
                EndIsShoulder = target.EndIsShoulder
            };
        }

        private static bool ThrowsInvalidOperation(Action action)
        {
            try { action(); }
            catch (InvalidOperationException) { return true; }
            catch { return false; }
            return false;
        }

        private static void Check(string id, bool condition, ref int pass, ref int fail, string description)
        {
            if (condition)
            {
                pass++;
                Console.WriteLine("[PASS] " + id + " — " + description);
            }
            else
            {
                fail++;
                Console.WriteLine("[FAIL] " + id + " — " + description);
            }
        }
    }
}
