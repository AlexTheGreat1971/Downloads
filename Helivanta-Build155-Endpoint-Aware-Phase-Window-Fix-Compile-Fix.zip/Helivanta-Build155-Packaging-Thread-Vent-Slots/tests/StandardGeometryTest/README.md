﻿# Helivanta — Standard Geometry Test

Developer-only regression test for the **production `src/ThreadStandards.cs`** implementation.

The project links the real production source file rather than copying it. This is intentional: a future change to standard formulas immediately changes the test subject.

## Run

```bat
run-standard-geometry-test.bat
```

Reports are written to the repository `test-results\` directory:

- `standard-geometry-test-report.txt`
- `standard-geometry-test-report.json`

Return code `0` = all tests passed. Return code `2` = one or more tests failed.

## What is covered

- ISO / ANSI 60° profile constants and depths.
- BSW 55° depth and Whitworth radius.
- Tr 30° profile, H1, crest flat, and ac table.
- S DIN 513 asymmetry 3°/30°, H1 and ac.
- Rd DIN 405 external/internal depths and basic minor-diameter relationships.
- Size-table sanity and duplicate detection.
- Regression checkpoints for M10×1.5, BSW 1/2-12, Tr20×4, S20×4 and Rd20×1/8.
- **Explicit clearance rule:** user clearance `c` must be split as `c/2 + c/2`. For `0.30 mm`, each mating surface is shifted `0.15 mm` and the total radial gap is `0.30 mm`.
- Basic groove validity for every size in every standard table.
- Production `ThreadStandards.MinorOffset()` is checked against the standard internal basic depth, preventing Rd from silently using `0.50P` instead of `0.45P`.
