$ErrorActionPreference = 'Stop'
$root = Split-Path -Parent (Split-Path -Parent $PSScriptRoot)
$project = Join-Path $PSScriptRoot 'StandardGeometryTest.csproj'
$out = Join-Path $root 'test-results'
New-Item -ItemType Directory -Force -Path $out | Out-Null

dotnet run --project $project -c Release -- --out $out @args
if ($LASTEXITCODE -ne 0) { throw 'Standard Geometry Test failed.' }
Write-Host "Standard Geometry Test passed. Reports: $out"
