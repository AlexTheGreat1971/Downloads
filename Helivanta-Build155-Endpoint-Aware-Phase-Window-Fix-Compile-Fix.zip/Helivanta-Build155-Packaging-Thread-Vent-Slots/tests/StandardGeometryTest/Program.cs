﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Text;
using System.Text.Json;

namespace ThreadPro.StandardGeometryTest
{
    internal enum TestStatus { Pass, Fail, Skip }

    internal sealed class TestResult
    {
        public string Id;
        public string Category;
        public TestStatus Status;
        public string Message;
        public double? Expected;
        public double? Actual;
        public double? Error;
        public string Unit;

        public static TestResult Pass(string id, string category, string message, double? expected = null, double? actual = null, double? error = null, string unit = "")
        {
            return new TestResult { Id = id, Category = category, Status = TestStatus.Pass, Message = message, Expected = expected, Actual = actual, Error = error, Unit = unit };
        }

        public static TestResult Fail(string id, string category, string message, double? expected = null, double? actual = null, double? error = null, string unit = "")
        {
            return new TestResult { Id = id, Category = category, Status = TestStatus.Fail, Message = message, Expected = expected, Actual = actual, Error = error, Unit = unit };
        }

        public static TestResult Skip(string id, string category, string message)
        {
            return new TestResult { Id = id, Category = category, Status = TestStatus.Skip, Message = message };
        }
    }

    internal sealed class TestReport
    {
        public string Version = "1.4.43";
        public DateTime Utc = DateTime.UtcNow;
        public int Pass;
        public int Fail;
        public int Skip;
        public List<TestResult> Results = new List<TestResult>();
    }

    internal static class Program
    {
        private const double Tol = 1e-9;
        private const double MmTol = 1e-6;
        private const double ClearanceTol = 1e-9;

        private static readonly CultureInfo Inv = CultureInfo.InvariantCulture;

        private static int Main(string[] args)
        {
            bool quiet = args.Any(a => string.Equals(a, "--quiet", StringComparison.OrdinalIgnoreCase));
            string outDir = GetOutputDirectory(args);
            Directory.CreateDirectory(outDir);

            var report = RunAllTests();
            string textPath = Path.Combine(outDir, "standard-geometry-test-report.txt");
            string jsonPath = Path.Combine(outDir, "standard-geometry-test-report.json");
            File.WriteAllText(textPath, RenderText(report), new UTF8Encoding(false));
            File.WriteAllText(jsonPath, JsonSerializer.Serialize(report, new JsonSerializerOptions { WriteIndented = true }), new UTF8Encoding(false));

            if (!quiet)
            {
                Console.OutputEncoding = Encoding.UTF8;
                Console.WriteLine(RenderConsole(report));
                Console.WriteLine();
                Console.WriteLine("TXT:  " + textPath);
                Console.WriteLine("JSON: " + jsonPath);
            }

            return report.Fail == 0 ? 0 : 2;
        }

        private static string GetOutputDirectory(string[] args)
        {
            for (int i = 0; i < args.Length - 1; i++)
            {
                if (string.Equals(args[i], "--out", StringComparison.OrdinalIgnoreCase))
                    return Path.GetFullPath(args[i + 1]);
            }
            return Path.Combine(AppContext.BaseDirectory, "test-results");
        }

        private static TestReport RunAllTests()
        {
            var report = new TestReport();
            AddTolerancePolicyTests(report);
            AddProfileTests(report);
            AddCatalogueTests(report);
            AddIndependentReferenceTests(report);
            AddCheckpointTests(report);
            AddClearanceTests(report);
            AddAllSizeGeometryTests(report);
            Recount(report);
            return report;
        }

        private static void AddTolerancePolicyTests(TestReport report)
        {
            const string cat = "Классы допуска";
            string normalized;
            bool ok = ThreadTolerancePolicy.TryNormalize(ThreadStandard.ISO, false, "6H", out normalized);
            AssertTrue(report, "TOL-ISO-6H-INTERNAL", cat, ok && normalized == "6H", "6H принимается для внутренней ISO-резьбы с сохранением регистра");
            ok = ThreadTolerancePolicy.TryNormalize(ThreadStandard.ISO, true, "6G", out normalized);
            AssertTrue(report, "TOL-ISO-6G-EXTERNAL-REJECT", cat, !ok, "6G не принимается вместо заявленного внешнего класса 6g");
            ok = ThreadTolerancePolicy.TryNormalize(ThreadStandard.ISO, true, "6g", out normalized);
            AssertTrue(report, "TOL-ISO-6G-EXTERNAL", cat, ok && normalized == "6g", "6g нормализуется для наружной ISO-резьбы");
            ok = ThreadTolerancePolicy.TryNormalize(ThreadStandard.BSW, true, "6g", out normalized);
            AssertTrue(report, "TOL-NON-ISO-REJECT", cat, !ok, "Класс ISO не применяется к не-ISO стандарту");
            ok = ThreadTolerancePolicy.TryNormalize(ThreadStandard.ISO, false, "6g", out normalized);
            AssertTrue(report, "TOL-INTERNAL-6G-REJECT", cat, !ok, "Наружный класс 6g не принимается для внутренней резьбы");
            ok = ThreadTolerancePolicy.TryNormalize(ThreadStandard.ISO, true, " ", out normalized);
            AssertTrue(report, "TOL-EMPTY-LEGACY", cat, ok && normalized == string.Empty, "Пустой класс сохраняет режим без указанного допуска");
        }

        private static void AddProfileTests(TestReport report)
        {
            const string cat = "Профили";
            double h60 = Math.Sqrt(3.0) / 2.0;
            double h55 = 0.960491;

            var iso = ThreadStandards.Spec(ThreadStandard.ISO);
            AssertNear(report, "PROFILE-ISO-ANGLE", cat, 60.0, iso.AngleDeg, Tol, "ISO угол 60°");
            AssertNear(report, "PROFILE-ISO-DEPTH-EXT", cat, 17.0 / 24.0 * h60, iso.DepthExt, Tol, "ISO внешняя глубина / P");
            AssertNear(report, "PROFILE-ISO-DEPTH-INT", cat, 5.0 / 8.0 * h60, iso.DepthInt, Tol, "ISO внутренняя глубина / P");

            var ansi = ThreadStandards.Spec(ThreadStandard.ANSI);
            AssertNear(report, "PROFILE-ANSI-ANGLE", cat, 60.0, ansi.AngleDeg, Tol, "ANSI/UN угол 60°");
            AssertNear(report, "PROFILE-ANSI-DEPTH-EXT", cat, 17.0 / 24.0 * h60, ansi.DepthExt, Tol, "ANSI внешняя глубина / P");
            AssertNear(report, "PROFILE-ANSI-DEPTH-INT", cat, 5.0 / 8.0 * h60, ansi.DepthInt, Tol, "ANSI внутренняя глубина / P");

            var bsw = ThreadStandards.Spec(ThreadStandard.BSW);
            AssertNear(report, "PROFILE-BSW-ANGLE", cat, 55.0, bsw.AngleDeg, Tol, "BSW угол 55°");
            AssertNear(report, "PROFILE-BSW-DEPTH", cat, 2.0 / 3.0 * h55, bsw.DepthExt, Tol, "BSW глубина / P");
            AssertNear(report, "PROFILE-BSW-RADIUS", cat, 0.137329, bsw.RadCrestExt, Tol, "BSW радиус / P");
            AssertNear(report, "PROFILE-BSW-RADIUS-ROOT", cat, 0.137329, bsw.RadRootExt, Tol, "BSW радиус впадины / P");

            var tr = ThreadStandards.Spec(ThreadStandard.Tr);
            AssertNear(report, "PROFILE-TR-ANGLE", cat, 30.0, tr.AngleDeg, Tol, "Tr угол профиля");
            AssertNear(report, "PROFILE-TR-H1", cat, 0.5, tr.H1, Tol, "Tr H1 / P");
            AssertNear(report, "PROFILE-TR-FLAT", cat, 0.36603, tr.Flat, Tol, "Tr плоскость вершины / P");

            var s = ThreadStandards.Spec(ThreadStandard.S);
            AssertNear(report, "PROFILE-S-ASYM-L", cat, 30.0, s.AngL, Tol, "S рабочая грань 30°");
            AssertNear(report, "PROFILE-S-ASYM-R", cat, 3.0, s.AngR, Tol, "S обратная грань 3°");
            AssertNear(report, "PROFILE-S-H1", cat, 0.75, s.H1, Tol, "S H1 / P");
            AssertNear(report, "PROFILE-S-AC", cat, 0.117767, s.AcFrac, Tol, "S ac / P");

            var rd = ThreadStandards.Spec(ThreadStandard.Rd);
            AssertNear(report, "PROFILE-RD-ANGLE", cat, 30.0, rd.AngleDeg, Tol, "Rd угол");
            AssertNear(report, "PROFILE-RD-DEPTH-EXT", cat, 0.5, rd.DepthExt, Tol, "Rd внешняя глубина / P");
            AssertNear(report, "PROFILE-RD-DEPTH-INT", cat, 0.45, rd.DepthInt, Tol, "Rd внутренняя глубина / P");
            AssertNear(report, "PROFILE-RD-AC", cat, 0.05, rd.AcFrac, Tol, "Rd ac / P");

            AssertNear(report, "AC-TR-1.5", cat, 0.15, ThreadStandards.Ac(tr, 1.5, 1.0), Tol, "Tr ac для P≤1,5");
            AssertNear(report, "AC-TR-4", cat, 0.25, ThreadStandards.Ac(tr, 4.0, 1.0), Tol, "Tr ac для 1,5<P≤5");
            AssertNear(report, "AC-TR-6", cat, 0.5, ThreadStandards.Ac(tr, 6.0, 1.0), Tol, "Tr ac для 5<P≤12");
            AssertNear(report, "AC-TR-12.1", cat, 1.0, ThreadStandards.Ac(tr, 12.1, 1.0), Tol, "Tr ac для P>12");
        }

        private static void AddCatalogueTests(TestReport report)
        {
            const string cat = "Таблицы размеров";
            foreach (ThreadStandard standard in Enum.GetValues(typeof(ThreadStandard)))
            {
                List<ThreadSize> sizes = ThreadStandards.Sizes(standard);
                if (sizes == null || sizes.Count == 0)
                {
                    report.Results.Add(TestResult.Fail("CAT-" + standard, cat, "Таблица размеров пуста."));
                    continue;
                }

                bool duplicate = sizes.GroupBy(x => x.Name, StringComparer.Ordinal).Any(g => g.Count() > 1);
                if (duplicate)
                    report.Results.Add(TestResult.Fail("CAT-DUP-" + standard, cat, "Обнаружены дубликаты типоразмеров."));
                else
                    report.Results.Add(TestResult.Pass("CAT-DUP-" + standard, cat, "Дубликаты не обнаружены: " + sizes.Count + " размеров."));

                int invalid = sizes.Count(x => x.DiameterMm <= 0 || x.PitchMm <= 0);
                if (invalid != 0)
                    report.Results.Add(TestResult.Fail("CAT-POS-" + standard, cat, "Есть типоразмеры с неположительным диаметром/шагом: " + invalid));
                else
                    report.Results.Add(TestResult.Pass("CAT-POS-" + standard, cat, "Все диаметры и шаги положительны."));
            }

            List<ThreadSize> sSizes = ThreadStandards.Sizes(ThreadStandard.S);
            AssertInt(report, "CAT-S-COUNT", cat, 62, sSizes.Count, "DIN 513 S: ожидается 62 базовых размера.");
            AssertExists(report, "CAT-ISO-M10X15", cat, ThreadStandard.ISO, x => Near(x.DiameterMm, 10.0) && Near(x.PitchMm, 1.5), "M10×1,5");
            AssertExists(report, "CAT-BSW-HALF-12", cat, ThreadStandard.BSW, x => Near(x.DiameterMm, 12.7) && Near(x.PitchMm, 25.4 / 12.0), "1/2-12 BSW");
            AssertExists(report, "CAT-ANSI-HALF-UNC13", cat, ThreadStandard.ANSI, x => Near(x.DiameterMm, 12.7) && Near(x.PitchMm, 25.4 / 13.0), "1/2-13 UNC");
            AssertExists(report, "CAT-TR20X4", cat, ThreadStandard.Tr, x => Near(x.DiameterMm, 20.0) && Near(x.PitchMm, 4.0), "Tr20×4");
            AssertExists(report, "CAT-S20X4", cat, ThreadStandard.S, x => Near(x.DiameterMm, 20.0) && Near(x.PitchMm, 4.0), "S20×4");
            AssertExists(report, "CAT-RD20", cat, ThreadStandard.Rd, x => Near(x.DiameterMm, 20.0) && Near(x.PitchMm, 25.4 / 8.0), "Rd20×1/8\"");
        }

        private static void AddIndependentReferenceTests(TestReport report)
        {
            const string cat = "Независимый эталон";

            // These values intentionally do NOT come from ThreadStandards.Spec().
            // They are independent basic-profile references used to detect accidental
            // self-consistency of the production table.
            const double H60 = 0.8660254037844386;
            const double H55 = 0.960491;

            AssertNear(report, "REF-ISO-EXT-M10", cat,
                17.0 / 24.0 * H60 * 1.5,
                Depth(ThreadStandards.Spec(ThreadStandard.ISO), true, 1.5), MmTol,
                "ISO 60° external basic depth = 17H/24", "мм");
            AssertNear(report, "REF-ISO-INT-M10", cat,
                5.0 / 8.0 * H60 * 1.5,
                Depth(ThreadStandards.Spec(ThreadStandard.ISO), false, 1.5), MmTol,
                "ISO 60° internal basic depth = 5H/8", "мм");

            AssertNear(report, "REF-BSW-EXT-HALF12", cat,
                2.0 / 3.0 * H55 * (25.4 / 12.0),
                Depth(ThreadStandards.Spec(ThreadStandard.BSW), true, 25.4 / 12.0), MmTol,
                "Whitworth 55° external depth = 2H/3", "мм");

            AssertNear(report, "REF-TR-EXT-20X4", cat,
                0.5 * 4.0 + 0.25,
                Depth(ThreadStandards.Spec(ThreadStandard.Tr), true, 4.0), MmTol,
                "Tr20×4 external depth = H1 + ac = 0.5P + 0.25", "мм");
            AssertNear(report, "REF-TR-INT-20X4", cat,
                0.5 * 4.0 + 0.25,
                Depth(ThreadStandards.Spec(ThreadStandard.Tr), false, 4.0), MmTol,
                "Tr20×4 internal depth = H1 + ac", "мм");

            AssertNear(report, "REF-S-EXT-20X4", cat,
                (0.75 + 0.117767) * 4.0,
                Depth(ThreadStandards.Spec(ThreadStandard.S), true, 4.0), MmTol,
                "S20×4 external depth = 0.75P + ac", "мм");
            AssertNear(report, "REF-S-INT-20X4", cat,
                0.75 * 4.0,
                Depth(ThreadStandards.Spec(ThreadStandard.S), false, 4.0), MmTol,
                "S20×4 internal depth = 0.75P", "мм");

            AssertNear(report, "REF-RD-EXT-20", cat,
                0.50 * (25.4 / 8.0),
                Depth(ThreadStandards.Spec(ThreadStandard.Rd), true, 25.4 / 8.0), MmTol,
                "Rd external depth = 0.50P", "мм");
            AssertNear(report, "REF-RD-INT-20", cat,
                0.45 * (25.4 / 8.0),
                Depth(ThreadStandards.Spec(ThreadStandard.Rd), false, 25.4 / 8.0), MmTol,
                "Rd internal depth = 0.45P", "мм");

            var bsw = ThreadStandards.Spec(ThreadStandard.BSW);
            AssertNear(report, "REF-BSW-RADIUS", cat,
                0.137329 * (25.4 / 12.0), bsw.RadCrestExt * (25.4 / 12.0), MmTol,
                "Whitworth radius = 0.137329P", "мм");

            // Mating clearance is deliberately tested as a physical pair property,
            // independent of ISO tolerance-position concepts.
            foreach (ThreadStandard standard in Enum.GetValues(typeof(ThreadStandard)))
            {
                double p = RepresentativePitch(standard);
                double c = Math.Min(0.20, 0.10 * p);
                var spec = ThreadStandards.Spec(standard);
                Groove ext = ThreadStandards.ComputeGroove(spec, true, p, c, p, 1.0);
                Groove inner = ThreadStandards.ComputeGroove(spec, false, p, c, p, 1.0);
                AssertNear(report, "REF-PAIR-CLEARANCE-" + standard, cat, c,
                    ext.CapDepth + inner.CapDepth, ClearanceTol,
                    standard + ": physical pair radial clearance = c", "мм");
            }
        }

        private static void AddCheckpointTests(TestReport report)
        {
            const string cat = "Контрольные расчёты";
            var iso = ThreadStandards.Spec(ThreadStandard.ISO);
            double pIso = 1.5;
            AssertNear(report, "CHK-ISO-M10-D0-EXT", cat, 17.0 / 24.0 * Math.Sqrt(3.0) / 2.0 * pIso, Depth(iso, true, pIso), MmTol, "ISO M10×1,5 внешняя глубина", "мм");
            AssertNear(report, "CHK-ISO-M10-D0-INT", cat, 5.0 / 8.0 * Math.Sqrt(3.0) / 2.0 * pIso, Depth(iso, false, pIso), MmTol, "ISO M10×1,5 внутренняя глубина", "мм");

            var bsw = ThreadStandards.Spec(ThreadStandard.BSW);
            double pBsw = 25.4 / 12.0;
            AssertNear(report, "CHK-BSW-HALF12-DEPTH", cat, 2.0 / 3.0 * 0.960491 * pBsw, Depth(bsw, true, pBsw), MmTol, "BSW 1/2-12 базовая глубина", "мм");
            AssertNear(report, "CHK-BSW-HALF12-RADIUS", cat, 0.137329 * pBsw, bsw.RadCrestExt * pBsw, MmTol, "BSW 1/2-12 радиус", "мм");

            var tr = ThreadStandards.Spec(ThreadStandard.Tr);
            double pTr = 4.0;
            AssertNear(report, "CHK-TR20X4-DEPTH-EXT", cat, 0.5 * pTr + 0.25, Depth(tr, true, pTr), MmTol, "Tr20×4 внешняя глубина", "мм");
            AssertNear(report, "CHK-TR20X4-D3", cat, 15.5, 20.0 - 2.0 * Depth(tr, true, pTr), MmTol, "Tr20×4 наружный малый диаметр", "мм");
            AssertNear(report, "CHK-TR20X4-D1", cat, 16.0, 20.0 - 2.0 * ThreadStandards.MinorOffset(tr, pTr, 1.0), MmTol, "Tr20×4 внутренний малый диаметр", "мм");

            var s = ThreadStandards.Spec(ThreadStandard.S);
            double pS = 4.0;
            AssertNear(report, "CHK-S20X4-DEPTH-EXT", cat, 0.75 * pS + 0.117767 * pS, Depth(s, true, pS), MmTol, "S20×4 внешняя глубина", "мм");
            AssertNear(report, "CHK-S20X4-D3", cat, 20.0 - 2.0 * (0.75 * pS + 0.117767 * pS), 13.057864, 2e-5, "S20×4 наружный малый диаметр", "мм");
            AssertNear(report, "CHK-S20X4-D1", cat, 20.0 - 2.0 * 0.75 * pS, 14.0, MmTol, "S20×4 внутренний малый диаметр", "мм");

            var rd = ThreadStandards.Spec(ThreadStandard.Rd);
            double pRd = 25.4 / 8.0;
            AssertNear(report, "CHK-RD20-EXT", cat, 0.5 * pRd, Depth(rd, true, pRd), MmTol, "Rd20×1/8 внешняя глубина", "мм");
            AssertNear(report, "CHK-RD20-INT", cat, 0.45 * pRd, Depth(rd, false, pRd), MmTol, "Rd20×1/8 внутренняя глубина", "мм");
            AssertNear(report, "CHK-RD20-D3", cat, 20.0 - 1.0 * pRd, 16.825, MmTol, "Rd20×1/8 наружный малый диаметр", "мм");
            AssertNear(report, "CHK-RD20-D1", cat, 20.0 - 0.9 * pRd, 17.1425, MmTol, "Rd20×1/8 внутренний малый диаметр", "мм");

            // This explicitly guards the production method used by ThreadBuilder for the nominal internal radius.
            foreach (ThreadStandard standard in Enum.GetValues(typeof(ThreadStandard)))
            {
                var spec = ThreadStandards.Spec(standard);
                double p = RepresentativePitch(standard);
                double expected = spec.Trap ? spec.DepthInt * p : spec.DepthInt * p;
                double actual = ThreadStandards.MinorOffset(spec, p, 1.0);
                AssertNear(report, "CHK-MINOR-OFFSET-" + standard, cat, expected, actual, MmTol, standard + " MinorOffset() соответствует внутренней базовой глубине", "мм");
            }
        }

        private static void AddClearanceTests(TestReport report)
        {
            const string cat = "Зазор";
            const double c = 0.30;
            var cases = new[]
            {
                new { Std = ThreadStandard.ISO, P = 1.5, Name = "ISO M10×1,5" },
                new { Std = ThreadStandard.ANSI, P = 25.4 / 13.0, Name = "ANSI 1/2-13" },
                new { Std = ThreadStandard.BSW, P = 25.4 / 12.0, Name = "BSW 1/2-12" },
                new { Std = ThreadStandard.Tr, P = 4.0, Name = "Tr20×4" },
                new { Std = ThreadStandard.S, P = 4.0, Name = "S20×4" },
                new { Std = ThreadStandard.Rd, P = 25.4 / 8.0, Name = "Rd20×1/8" }
            };

            foreach (var item in cases)
            {
                var spec = ThreadStandards.Spec(item.Std);
                Groove ext = ThreadStandards.ComputeGroove(spec, true, item.P, c, item.P, 1.0);
                Groove inner = ThreadStandards.ComputeGroove(spec, false, item.P, c, item.P, 1.0);
                double half = c / 2.0;

                AssertNear(report, "CLR-EXT-CAP-" + item.Std, cat, half, ext.CapDepth, ClearanceTol, item.Name + ": внешнее смещение = c/2", "мм");
                AssertNear(report, "CLR-EXT-RING-" + item.Std, cat, half, ext.RingDepth, ClearanceTol, item.Name + ": внешнее кольцевое смещение = c/2", "мм");
                AssertNear(report, "CLR-INT-CAP-" + item.Std, cat, half, inner.CapDepth, ClearanceTol, item.Name + ": внутреннее смещение = c/2", "мм");
                AssertNear(report, "CLR-INT-RING-" + item.Std, cat, half, inner.RingDepth, ClearanceTol, item.Name + ": внутреннее кольцевое смещение = c/2", "мм");
                AssertNear(report, "CLR-TOTAL-" + item.Std, cat, c, ext.CapDepth + inner.CapDepth, ClearanceTol, item.Name + ": суммарный радиальный зазор = c", "мм");

                double expectedExtBasic = ExpectedBasicDepth(spec, true, item.P, 1.0);
                double expectedIntBasic = ExpectedBasicDepth(spec, false, item.P, 1.0);
                AssertNear(report, "CLR-EXT-BASIC-" + item.Std, cat, expectedExtBasic, ext.Depth - ext.CapDepth, MmTol, item.Name + ": внешняя база не искажается зазором", "мм");
                AssertNear(report, "CLR-INT-BASIC-" + item.Std, cat, expectedIntBasic, inner.Depth, MmTol, item.Name + ": внутренняя базовая глубина не искажается зазором", "мм");
            }

            // Regression guard for the exact user scenario.
            var iso = ThreadStandards.Spec(ThreadStandard.ISO);
            Groove e03 = ThreadStandards.ComputeGroove(iso, true, 1.5, 0.30, 1.5, 1.0);
            Groove i03 = ThreadStandards.ComputeGroove(iso, false, 1.5, 0.30, 1.5, 1.0);
            AssertNear(report, "CLR-REGRESSION-M10-0.30", cat, 0.30, e03.CapDepth + i03.CapDepth, ClearanceTol, "M10×1,5 при Зазор=0,30 должен давать 0,30 мм", "мм");
        }

        private static void AddAllSizeGeometryTests(TestReport report)
        {
            const string cat = "Все типоразмеры";
            foreach (ThreadStandard standard in Enum.GetValues(typeof(ThreadStandard)))
            {
                int checkedCount = 0;
                int skippedClearance = 0;
                foreach (ThreadSize size in ThreadStandards.Sizes(standard))
                {
                    var spec = ThreadStandards.Spec(standard);
                    try
                    {
                        Groove ext = ThreadStandards.ComputeGroove(spec, true, size.PitchMm, 0.0, size.PitchMm, 1.0);
                        Groove inner = ThreadStandards.ComputeGroove(spec, false, size.PitchMm, 0.0, size.PitchMm, 1.0);
                        if (!IsValidGroove(ext) || !IsValidGroove(inner))
                        {
                            report.Results.Add(TestResult.Fail("SIZE-BASIC-" + standard + "-" + size.Name, cat, size.Name + ": базовая канавка геометрически недопустима."));
                            continue;
                        }
                        checkedCount++;

                        // Use a scaled probe clearance for tiny pitches; for ordinary sizes this reaches the product value 0.30 mm.
                        double probe = Math.Min(0.30, 0.20 * size.PitchMm);
                        try
                        {
                            Groove e = ThreadStandards.ComputeGroove(spec, true, size.PitchMm, probe, size.PitchMm, 1.0);
                            Groove i = ThreadStandards.ComputeGroove(spec, false, size.PitchMm, probe, size.PitchMm, 1.0);
                            if (!IsValidGroove(e) || !IsValidGroove(i))
                            {
                                report.Results.Add(TestResult.Fail("SIZE-CLR-" + standard + "-" + size.Name, cat, size.Name + ": зазорный профиль некорректен при c=" + F(probe) + " мм."));
                                continue;
                            }
                            double err = Math.Abs((e.CapDepth + i.CapDepth) - probe);
                            if (err > ClearanceTol)
                            {
                                report.Results.Add(TestResult.Fail("SIZE-CLR-" + standard + "-" + size.Name, cat, size.Name + ": c/2+c/2 не даёт заданный зазор.", probe, e.CapDepth + i.CapDepth, err, "мм"));
                            }
                        }
                        catch (InvalidOperationException)
                        {
                            skippedClearance++;
                        }
                    }
                    catch (Exception ex)
                    {
                        report.Results.Add(TestResult.Fail("SIZE-EXC-" + standard + "-" + size.Name, cat, size.Name + ": исключение " + ex.Message));
                    }
                }

                report.Results.Add(TestResult.Pass("SIZE-SUMMARY-" + standard, cat,
                    standard + ": проверено базовых профилей = " + checkedCount + ", пропущено слишком больших зазоров = " + skippedClearance + "."));
            }
        }

        private static bool IsValidGroove(Groove g)
        {
            return g != null && g.TopWidth > 0.0 && g.BottomWidth > 0.0 && g.Depth > 0.0 &&
                   g.X1R > g.X1L && g.ExtWidth > 0.0;
        }

        private static double ExpectedBasicDepth(ThreadProfileSpec s, bool external, double pitch, double mmPerUnit)
        {
            double depth = (external ? s.DepthExt : s.DepthInt) * pitch;
            if (s.Trap)
            {
                bool addAc = external ? s.AddAcToExternalDepth : s.AddAcToInternalDepth;
                if (addAc) depth += ThreadStandards.Ac(s, pitch, mmPerUnit);
            }
            return depth;
        }

        private static double Depth(ThreadProfileSpec s, bool external, double pitch)
        {
            return ExpectedBasicDepth(s, external, pitch, 1.0);
        }

        private static double RepresentativePitch(ThreadStandard standard)
        {
            switch (standard)
            {
                case ThreadStandard.BSW: return 25.4 / 12.0;
                case ThreadStandard.ANSI: return 25.4 / 13.0;
                case ThreadStandard.Tr: return 4.0;
                case ThreadStandard.S: return 4.0;
                case ThreadStandard.Rd: return 25.4 / 8.0;
                default: return 1.5;
            }
        }

        private static void AssertExists(TestReport report, string id, string category, ThreadStandard standard, Func<ThreadSize, bool> predicate, string label)
        {
            bool found = ThreadStandards.Sizes(standard).Any(predicate);
            report.Results.Add(found
                ? TestResult.Pass(id, category, "Найден контрольный размер: " + label + ".")
                : TestResult.Fail(id, category, "Не найден контрольный размер: " + label + "."));
        }

        private static void AssertInt(TestReport report, string id, string category, int expected, int actual, string message)
        {
            report.Results.Add(expected == actual
                ? TestResult.Pass(id, category, message, expected, actual, expected - actual)
                : TestResult.Fail(id, category, message, expected, actual, Math.Abs(expected - actual)));
        }

        private static void AssertTrue(TestReport report, string id, string category, bool condition, string message)
        {
            report.Results.Add(condition ? TestResult.Pass(id, category, message) : TestResult.Fail(id, category, message));
        }

        private static void AssertNear(TestReport report, string id, string category, double expected, double actual, double tolerance, string message, string unit = "")
        {
            double err = Math.Abs(actual - expected);
            report.Results.Add(err <= tolerance
                ? TestResult.Pass(id, category, message + " (допуск ±" + F(tolerance) + (unit.Length == 0 ? "" : " " + unit) + ").", expected, actual, err, unit)
                : TestResult.Fail(id, category, message + " (ПРЕВЫШЕН допуск ±" + F(tolerance) + (unit.Length == 0 ? "" : " " + unit) + ").", expected, actual, err, unit));
        }

        private static bool Near(double a, double b) { return Math.Abs(a - b) <= 1e-9; }
        private static string F(double v) { return v.ToString("0.##########", Inv); }

        private static void Recount(TestReport report)
        {
            report.Pass = report.Results.Count(x => x.Status == TestStatus.Pass);
            report.Fail = report.Results.Count(x => x.Status == TestStatus.Fail);
            report.Skip = report.Results.Count(x => x.Status == TestStatus.Skip);
        }

        private static string RenderConsole(TestReport report)
        {
            var sb = new StringBuilder();
            sb.AppendLine("Helivanta — Standard Geometry Test 1.4.43");
            sb.AppendLine("=================================================");
            sb.AppendLine("PASS: " + report.Pass + "   FAIL: " + report.Fail + "   SKIP: " + report.Skip);
            sb.AppendLine();
            foreach (IGrouping<string, TestResult> group in report.Results.GroupBy(x => x.Category))
            {
                sb.AppendLine("[" + group.Key + "]");
                foreach (TestResult r in group)
                    sb.AppendLine("  " + StatusText(r.Status) + " " + r.Id + " — " + r.Message +
                        (r.Expected.HasValue ? " | exp=" + F(r.Expected.Value) : "") +
                        (r.Actual.HasValue ? " | act=" + F(r.Actual.Value) : "") +
                        (r.Error.HasValue ? " | err=" + F(r.Error.Value) : "") +
                        (string.IsNullOrEmpty(r.Unit) ? "" : " " + r.Unit));
                sb.AppendLine();
            }
            sb.AppendLine(report.Fail == 0 ? "RESULT: PASS" : "RESULT: FAIL");
            return sb.ToString();
        }

        private static string RenderText(TestReport report) { return RenderConsole(report); }

        private static string StatusText(TestStatus status)
        {
            switch (status)
            {
                case TestStatus.Pass: return "[PASS]";
                case TestStatus.Fail: return "[FAIL]";
                default: return "[SKIP]";
            }
        }
    }
}
