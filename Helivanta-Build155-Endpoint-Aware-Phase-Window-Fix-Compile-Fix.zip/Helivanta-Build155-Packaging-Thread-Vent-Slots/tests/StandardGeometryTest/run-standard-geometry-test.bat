@echo off
cd /d "%~dp0..\.."
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0run-standard-geometry-test.ps1" %*
if errorlevel 1 pause
