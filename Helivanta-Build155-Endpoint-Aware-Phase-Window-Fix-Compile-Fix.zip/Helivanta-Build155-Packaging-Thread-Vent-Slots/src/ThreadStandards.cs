﻿using System;
using System.Collections.Generic;
using System.Globalization;

namespace ThreadPro
{
    public enum ThreadStandard { ISO = 0, BSW = 1, ANSI = 2, Tr = 3, S = 4, Rd = 5 }

    public sealed class ThreadSize
    {
        public string Name;
        public double DiameterMm;
        public double PitchMm;
        public override string ToString() { return Name; }
    }

    /// <summary>Basic profile description (fractions of pitch P).</summary>
    public sealed class ThreadProfileSpec
    {
        public double AngleDeg;       // included flank angle
        public double AngL, AngR;     // flank angles from the radial direction (deg); 0 = AngleDeg / 2 (symmetric)
        public bool Trap;             // trapezoidal family (Tr, S, Rd): depth = H1 + ac, nut crest at d - 2*H1
        public double Flat;           // crest flat (fraction of P), trapezoidal family
        public double H1;             // flank engagement height (fraction of P), trapezoidal family
        public int AcMode;            // crest clearance ac: 0 none, 1 table of Tr threads, 2 AcFrac * P
        public double AcFrac;
        public bool UseAllowance;     // legacy ISO/ANSI g-position helper; NOT applied to explicit user clearance
        public bool AddAcToExternalDepth; // standard-specific crest clearance added to external groove depth
        public bool AddAcToInternalDepth; // standard-specific crest clearance added to internal groove depth
        public double CrestFlatExt;   // flat on the crest of an external thread
        public double CrestFlatInt;   // flat on the crest of an internal thread (at minor dia)
        public double DepthExt;       // thread depth, external
        public double DepthInt;       // thread depth, internal
        // requested fillet radii (fractions of P); they are clamped to what fits on the flats
        public double RadCrestExt, RadCrestInt, RadRootExt, RadRootInt;
    }

    /// <summary>Cross-section of the groove (cutting tool). Unit-agnostic (mm or cm).</summary>
    public sealed class Groove
    {
        public double TopWidth;     // groove width at the crest radius
        public double BottomWidth;  // groove width at the root
        public double Depth;        // radial depth incl. clearance
        public double Ext;          // extension of the tool outside the crest radius
        public double ExtWidth;     // width at the extended outer edge
        public double CrestRemain;  // width of the remaining crest flat
        public double X0L, X0R;     // flank positions at the crest level (axial, relative to the groove centre)
        public double X1L, X1R;     // flank positions at the root level
        public double CapDepth;     // depth of the (offset) crest below the nominal crest radius; 0 without clearance
        public double RingDepth;    // >0: the crest zone is turned down/out by this depth with a ring cut (clearance > 0)
    }

    public static class ThreadStandards
    {
        /// <summary>Gap (fraction of P) kept between the tools of neighbouring turns.</summary>
        public const double GapFrac = 0.004;

        private const double H60 = 0.8660254037844386;   // H = P*sqrt(3)/2
        private const double H55 = 0.960491;             // Whitworth H = 0.960491 P

        public static string Title(ThreadStandard s)
        {
            switch (s)
            {
                case ThreadStandard.ISO: return "ISO (метрическая, 60°)";
                case ThreadStandard.BSW: return "BSW (Витворта, 55°)";
                case ThreadStandard.Tr: return "Tr — трапецеидальная (ISO 2901–2904, 30°)";
                case ThreadStandard.S: return "S — упорная (DIN 513, 3°/30°)";
                case ThreadStandard.Rd: return "Rd — круглая (DIN 405, 30°)";
                default: return "ANSI (UN/UNC/UNF, 60°)";
            }
        }

        public static ThreadProfileSpec Spec(ThreadStandard s)
        {
            switch (s)
            {
                case ThreadStandard.BSW:
                    // Rounded crest/root of BSW approximated by flats of P/6, depth 2H/3 = 0.640327 P
                    return new ThreadProfileSpec
                    {
                        AngleDeg = 55.0,
                        CrestFlatExt = 1.0 / 6.0, CrestFlatInt = 1.0 / 6.0,
                        DepthExt = 2.0 / 3.0 * H55, DepthInt = 2.0 / 3.0 * H55,
                        // Whitworth radius: r = 0.137329 P (BS 84 / Whitworth basic form).
                        RadCrestExt = 0.137329, RadCrestInt = 0.137329, RadRootExt = 0.137329, RadRootInt = 0.137329,
                        UseAllowance = true
                    };
                case ThreadStandard.Tr:
                    // ISO 2904: 30 deg, crest flat 0.366 P, H1 = 0.5 P, clearance ac from the table
                    return new ThreadProfileSpec
                    {
                        AngleDeg = 30.0, Trap = true, Flat = 0.36603, H1 = 0.5, AcMode = 1,
                        AddAcToExternalDepth = true, AddAcToInternalDepth = true,
                        CrestFlatExt = 0.36603, CrestFlatInt = 0.36603, DepthExt = 0.5, DepthInt = 0.5
                    };
                case ThreadStandard.S:
                    // DIN 513 buttress: load flank 3 deg, back flank 30 deg, H1 = 0.75 P, ac = 0.117767 P, flat 0.26384 P
                    return new ThreadProfileSpec
                    {
                        AngleDeg = 33.0, AngL = 30.0, AngR = 3.0, Trap = true, Flat = 0.26384, H1 = 0.75,
                        AcMode = 2, AcFrac = 0.117767, AddAcToExternalDepth = true, AddAcToInternalDepth = false,
                        CrestFlatExt = 0.26384, CrestFlatInt = 0.26384, DepthExt = 0.75, DepthInt = 0.75
                    };
                case ThreadStandard.Rd:
                    // DIN 405 round thread: 30 deg flanks joined by arcs, H1 = 0.5 P, ac = 0.05 P
                    return new ThreadProfileSpec
                    {
                        AngleDeg = 30.0, Trap = true, Flat = 0.36603, H1 = 0.5, AcMode = 2, AcFrac = 0.05,
                        // DIN 405 basic diameters: external minor d3 = d - 1.0P; internal minor D1 = D - 0.9P.
                        // The 0.05P ac value is a profile parameter, not an automatic depth addition.
                        AddAcToExternalDepth = false, AddAcToInternalDepth = false,
                        CrestFlatExt = 0.36603, CrestFlatInt = 0.36603, DepthExt = 0.5, DepthInt = 0.45
                    };
                default:
                    // ISO 68-1 / ASME B1.1 basic profile: ext. crest P/8, depth 17H/24; int. crest P/4, depth 5H/8
                    return new ThreadProfileSpec
                    {
                        AngleDeg = 60.0,
                        CrestFlatExt = 1.0 / 8.0, CrestFlatInt = 1.0 / 4.0,
                        DepthExt = 17.0 / 24.0 * H60, DepthInt = 5.0 / 8.0 * H60,
                        // root: ext H/6, int H/8 (ISO 68-1); crest rounded as far as the flat allows
                        RadCrestExt = H60 / 6.0, RadCrestInt = H60 / 6.0, RadRootExt = H60 / 6.0, RadRootInt = H60 / 8.0,
                        UseAllowance = true
                    };
            }
        }

        /// <summary>Crest clearance ac (same unit as pitch) of the trapezoidal family.</summary>
        public static double Ac(ThreadProfileSpec s, double pitch, double mmPerUnit = 1.0)
        {
            if (s.AcMode == 1)   // ISO 2904 / DIN 103
            {
                double p = pitch * mmPerUnit, ac;
                if (p <= 1.5 + 1e-9) ac = 0.15;
                else if (p <= 5.0 + 1e-9) ac = 0.25;
                else if (p <= 12.0 + 1e-9) ac = 0.5;
                else ac = 1.0;
                return ac / mmPerUnit;
            }
            if (s.AcMode == 2) return s.AcFrac * pitch;
            return 0.0;
        }

        /// <summary>Radial distance from the nominal major radius to the crest of the internal thread (minor radius = d/2 - this).</summary>
        public static double MinorOffset(ThreadProfileSpec s, double pitch, double mmPerUnit = 1.0)
        {
            // Internal minor-radius position is defined by the standard basic internal
            // depth.  For Tr and S it equals H1; for Rd it is 0.45P (not H1 = 0.50P).
            // Keep this tied to DepthInt so ThreadBuilder uses the same standard-specific
            // value that ComputeGroove uses for the internal profile.
            return s.DepthInt * pitch;
        }

        private static double BasicDepth(ThreadProfileSpec s, bool external, double pitch, double mmPerUnit)
        {
            if (!s.Trap) return (external ? s.DepthExt : s.DepthInt) * pitch;

            double depth = (external ? s.DepthExt : s.DepthInt) * pitch;
            bool addAc = external ? s.AddAcToExternalDepth : s.AddAcToInternalDepth;
            if (addAc) depth += Ac(s, pitch, mmPerUnit);
            return depth;
        }

        /// <summary>Requested fillet radii of crest corners and root corners (same unit as pitch).</summary>
        public static void Radii(ThreadStandard std, ThreadProfileSpec s, bool external, double pitch, double mmPerUnit,
                                 out double rCrest, out double rRoot)
        {
            switch (std)
            {
                case ThreadStandard.Tr:      // ISO 2904: R1 max = 0.5 ac, R2 max = ac
                    rCrest = 0.5 * Ac(s, pitch, mmPerUnit);
                    rRoot = Ac(s, pitch, mmPerUnit);
                    break;
                case ThreadStandard.S:       // DIN 513: root radius 0.12427 P
                    rCrest = 0.05 * pitch;
                    rRoot = 0.12427 * pitch;
                    break;
                case ThreadStandard.Rd:      // DIN 405: R1 = 0.23851 P, R2 = 0.25597 P (clamped to the tangent arcs)
                    rCrest = 0.23851 * pitch;
                    rRoot = 0.25597 * pitch;
                    break;
                default:
                    rCrest = (external ? s.RadCrestExt : s.RadCrestInt) * pitch;
                    rRoot = (external ? s.RadRootExt : s.RadRootInt) * pitch;
                    break;
            }
        }

        private static Groove MakeGroove(double wTop, double depth, double cap, double ringDepth, double pitch,
                                         double tanL, double tanR, double crest)
        {
            double below = depth - cap;                    // flank length below the crest level
            double x0l = -wTop / 2.0, x0r = wTop / 2.0;
            double x1l = x0l + below * tanL, x1r = x0r - below * tanR;
            return new Groove
            {
                TopWidth = wTop, BottomWidth = x1r - x1l, Depth = depth, Ext = 0.1 * pitch,
                ExtWidth = pitch * (1.0 - 2.0 * GapFrac), CrestRemain = crest, CapDepth = cap, RingDepth = ringDepth,
                X0L = x0l, X0R = x0r, X1L = x1l, X1R = x1r
            };
        }

        /// <summary>
        /// Groove (cut) cross-section, depths measured from the cylinder radius R into the material
        /// (external: toward the axis, internal: away from the axis). Unit-agnostic; mmPerUnit is needed
        /// only for the standard-specific crest clearance ac. The user-entered clearance is
        /// a geometric TOTAL radial gap between mating thread surfaces. Therefore, when clearance > 0,
        /// each mating profile is offset by exactly clearance/2; no hidden ISO/ANSI allowance is added.
        ///
        /// clearance = 0 : basic/design profile.
        /// clearance > 0 : mating bolt/nut pair with c/2 offset per side.
        /// </summary>
        public static Groove ComputeGroove(ThreadProfileSpec s, bool external, double pitch, double clearance, double lead, double mmPerUnit = 1.0)
        {
            double tanL = Math.Tan((s.AngL > 0 ? s.AngL : s.AngleDeg / 2.0) * Math.PI / 180.0);
            double tanR = Math.Tan((s.AngR > 0 ? s.AngR : s.AngleDeg / 2.0) * Math.PI / 180.0);
            double tsum = tanL + tanR;
            double crest = (external ? s.CrestFlatExt : s.CrestFlatInt) * pitch;
            double minB = 0.02 * pitch;
            double wTop = pitch - crest;                    // groove width at the crest level (crest flat is kept)

            if (clearance <= 1e-9)
            {
                double depth = BasicDepth(s, external, pitch, mmPerUnit);
                double wB = wTop - depth * tsum;
                if (wB < minB) depth = (wTop - minB) / tsum;
                return MakeGroove(wTop, depth, 0.0, 0.0, pitch, tanL, tanR, crest);
            }

            double hB = BasicDepth(s, external, pitch, mmPerUnit);
            double shift, dRoot, below;
            if (external)
            {
                // IMPORTANT: "Зазор" is the total radial geometric clearance.
                // 0.30 mm therefore means 0.15 mm offset on the bolt profile and
                // 0.15 mm offset on the nut profile. ISO 965 g/G deviations are
                // tolerance-position data and are not silently mixed into this field.
                shift = clearance / 2.0;
                dRoot = hB + shift;
                below = hB;
            }
            else
            {
                shift = clearance / 2.0;                    // crest and flanks move out, root stays at the standard basic position
                dRoot = hB;
                if (hB - shift < 0.05 * pitch)
                    throw new InvalidOperationException("Зазор слишком большой для этого шага.");
                below = hB - shift;
            }
            if (wTop - below * tsum < minB)
                throw new InvalidOperationException("Зазор слишком большой для этого шага.");

            return MakeGroove(wTop, dRoot, shift, shift, pitch, tanL, tanR, crest);
        }

        // ---------------- size tables ----------------
        // ISO 261: nominal diameter : pitches (coarse first, then fine)
        private const string IsoData =
            "1:0.25,0.2;1.1:0.25,0.2;1.2:0.25,0.2;1.4:0.3,0.2;1.6:0.35,0.2;1.8:0.35,0.2;2:0.4,0.25;2.2:0.45,0.25;" +
            "2.5:0.45,0.35;3:0.5,0.35;3.5:0.6,0.35;4:0.7,0.5;4.5:0.75,0.5;5:0.8,0.5;5.5:0.5;6:1,0.75;7:1,0.75;" +
            "8:1.25,1,0.75;9:1.25,1,0.75;10:1.5,1.25,1,0.75;11:1.5,1,0.75;12:1.75,1.5,1.25,1;14:2,1.5,1.25,1;" +
            "15:1.5,1;16:2,1.5,1;17:1.5,1;18:2.5,2,1.5,1;20:2.5,2,1.5,1;22:2.5,2,1.5,1;24:3,2,1.5,1;25:2,1.5,1;" +
            "26:1.5;27:3,2,1.5,1;28:2,1.5,1;30:3.5,3,2,1.5,1;32:2,1.5;33:3.5,3,2,1.5;35:1.5;36:4,3,2,1.5;38:1.5;" +
            "39:4,3,2,1.5;40:3,2,1.5;42:4.5,4,3,2,1.5;45:4.5,4,3,2,1.5;48:5,4,3,2,1.5;50:3,2,1.5;52:5,4,3,2,1.5;" +
            "55:4,3,2,1.5;56:5.5,4,3,2,1.5;58:4,3,2,1.5;60:5.5,4,3,2,1.5;62:4,3,2,1.5;64:6,4,3,2,1.5;65:4,3,2,1.5;" +
            "68:6,4,3,2,1.5;70:6,4,3,2,1.5;72:6,4,3,2,1.5;75:4,3,2,1.5;76:6,4,3,2,1.5;80:6,4,3,2,1.5;85:6,4,3,2;" +
            "90:6,4,3,2;95:6,4,3,2;100:6,4,3,2;105:6,4,3,2;110:6,4,3,2;115:6,4,3,2;120:6,4,3,2;125:6,4,3,2;" +
            "130:6,4,3,2;140:6,4,3;150:6,4,3;160:6,4,3;170:6,4,3;180:6,4,3;190:6,4,3;200:6,4,3;220:6,4,3;" +
            "240:6,4,3;260:6,4,3;280:6,4,3;300:6,4,3";

        // DIN 103 (Tr): standard single-start base pitches, coarse series.
        // Multi-start is handled separately by the Starts parameter; lead values such as 8 mm are not stored as pitch.
        private const string TrCoarseData =
            "9:2;10:2;11:3;12:3;14:3;16:4;18:4;20:4;22:5;24:5;26:5;28:5;30:6;32:6;34:6;36:6;38:7;40:7;" +
            "42:7;44:7;46:8;48:8;50:8;52:8;55:9;60:9;65:10;70:10;75:10;80:10;85:12;90:12;95:12;" +
            "100:12;105:12;110:12;115:14;120:14;125:14;130:14;135:14;140:14;145:14;150:16;155:16;" +
            "160:16;165:16;170:16;175:16;180:18;185:18;190:18;195:18;200:18;210:20;220:20;230:20;" +
            "240:22;250:22;260:22;270:24;280:24;290:24;300:24";

        // DIN 103 fine series (base pitch values).
        private const string TrFineData =
            "8:1.5;9:1.5;10:1.5;11:2;12:2;14:2;16:2;18:2;20:2;22:3;24:3;26:3;28:3;30:3;" +
            "32:3;34:3;36:3;38:3;40:3;42:3;44:3;46:3;48:3;50:3;52:3;55:3;60:3;65:4;70:4;" +
            "75:4;80:4;85:4;90:4;95:4;100:4;105:4;110:4;115:6;120:6;125:6;130:6;135:6;" +
            "140:6;145:6;150:6;155:6;160:6;165:6;170:6;175:8;180:8;185:8;190:8;195:8;" +
            "200:8;210:8;220:8;230:8;240:8;250:12;260:12;270:12;280:12;290:12;300:12";

        // DIN 513 S, coarse: the standard's 62-size list (S10x2 to S300x24).
        private const string SData =
            "10:2;12:3;14:3;16:4;18:4;20:4;22:5;24:5;26:5;28:5;30:6;32:6;34:6;36:6;38:7;40:7;42:7;44:7;" +
            "46:8;48:8;50:8;52:8;55:9;60:9;65:10;70:10;75:10;80:10;85:12;90:12;95:12;100:12;105:12;110:12;" +
            "115:14;120:14;125:14;130:14;135:14;140:14;145:14;150:16;155:16;160:16;165:16;170:16;175:16;" +
            "180:18;185:18;190:18;195:18;200:18;210:20;220:20;230:20;240:22;250:22;260:22;270:24;280:24;290:24;300:24";

        // DIN 405 (Rd): nominal diameter : threads per inch
        private const string RdData =
            "8:10;9:10;10:10;11:10;12:10;14:8;16:8;18:8;20:8;22:8;24:8;26:8;28:8;30:8;32:6;34:6;36:6;38:6;40:6;42:6;" +
            "44:6;46:6;48:6;50:6;52:6;55:6;58:6;60:6;62:6;65:6;68:6;70:6;72:6;75:6;78:6;80:6;85:6;90:6;95:6;100:6;" +
            "105:6;110:6;115:6;120:4;130:4;140:4;150:4;160:4;170:4;180:4;190:4;200:4";

        // BS 84 (BSW): nominal diameter in inches : TPI
        private const string BswData =
            "1/16:60;3/32:48;1/8:40;5/32:32;3/16:24;7/32:24;1/4:20;5/16:18;3/8:16;7/16:14;1/2:12;9/16:12;5/8:11;" +
            "11/16:11;3/4:10;7/8:9;1:8;1 1/8:7;1 1/4:7;1 3/8:6;1 1/2:6;1 5/8:5;1 3/4:5;1 7/8:4.5;2:4.5;2 1/4:4;" +
            "2 1/2:4;2 3/4:3.5;3:3.5;3 1/4:3.25;3 1/2:3.25;3 3/4:3;4:3;4 1/2:2.875;5:2.75;5 1/2:2.625;6:2.5";

        // ASME B1.1: UNC / UNF / UNEF
        private const string UnData =
            "#0:UNF80;#1:UNC64,UNF72;#2:UNC56,UNF64;#3:UNC48,UNF56;#4:UNC40,UNF48;#5:UNC40,UNF44;#6:UNC32,UNF40;" +
            "#8:UNC32,UNF36;#10:UNC24,UNF32;#12:UNC24,UNF28,UNEF32;1/4:UNC20,UNF28,UNEF32;5/16:UNC18,UNF24,UNEF32;" +
            "3/8:UNC16,UNF24,UNEF32;7/16:UNC14,UNF20,UNEF28;1/2:UNC13,UNF20,UNEF28;9/16:UNC12,UNF18,UNEF24;" +
            "5/8:UNC11,UNF18,UNEF24;11/16:UNEF24;3/4:UNC10,UNF16,UNEF20;13/16:UNEF20;7/8:UNC9,UNF14,UNEF20;" +
            "15/16:UNEF20;1:UNC8,UNF12,UNEF20;1 1/16:UNEF18;1 1/8:UNC7,UNF12,UNEF18;1 3/16:UNEF18;" +
            "1 1/4:UNC7,UNF12,UNEF18;1 5/16:UNEF18;1 3/8:UNC6,UNF12,UNEF18;1 7/16:UNEF18;1 1/2:UNC6,UNF12,UNEF18;" +
            "1 9/16:UNEF18;1 5/8:UNEF18;1 11/16:UNEF18;1 3/4:UNC5;2:UNC4.5;2 1/4:UNC4.5;2 1/2:UNC4;2 3/4:UNC4;" +
            "3:UNC4;3 1/4:UNC4;3 1/2:UNC4;3 3/4:UNC4;4:UNC4";

        // constant-pitch UN series: TPI, smallest and largest diameter (inches)
        private static readonly double[][] UnConst =
        {
            new[] { 4.0, 2.5, 6.0 }, new[] { 6.0, 1.375, 6.0 }, new[] { 8.0, 1.0, 6.0 }, new[] { 12.0, 0.5625, 6.0 },
            new[] { 16.0, 0.75, 6.0 }, new[] { 20.0, 0.25, 1.6875 }, new[] { 28.0, 0.25, 1.375 }, new[] { 32.0, 0.25, 1.25 }
        };

        /// <summary>"1 3/8", "5/16", "#10" -> inches.</summary>
        private static double ParseInch(string label)
        {
            var ci = CultureInfo.InvariantCulture;
            label = label.Trim();
            if (label.StartsWith("#")) return 0.060 + 0.013 * double.Parse(label.Substring(1), ci);
            double total = 0.0;
            foreach (string part in label.Split(' '))
            {
                if (part.Contains("/"))
                {
                    string[] f = part.Split('/');
                    total += double.Parse(f[0], ci) / double.Parse(f[1], ci);
                }
                else total += double.Parse(part, ci);
            }
            return total;
        }

        private static string InchLabel(double inch)
        {
            int whole = (int)Math.Floor(inch + 1e-9);
            int n64 = (int)Math.Round((inch - whole) * 64.0);
            if (n64 == 64) { whole++; n64 = 0; }
            string frac = "";
            if (n64 > 0)
            {
                int num = n64, den = 64;
                while (num % 2 == 0) { num /= 2; den /= 2; }
                frac = num + "/" + den;
            }
            if (whole == 0) return frac;
            return frac.Length == 0 ? whole.ToString() : whole + " " + frac;
        }

        public static List<ThreadSize> Sizes(ThreadStandard s)
        {
            var list = new List<ThreadSize>();
            var ci = CultureInfo.InvariantCulture;
            if (s == ThreadStandard.ISO)
            {
                foreach (string item in IsoData.Split(new[] { ';' }, StringSplitOptions.RemoveEmptyEntries))
                {
                    string[] kv = item.Split(':');
                    double d = double.Parse(kv[0], ci);
                    foreach (string ps in kv[1].Split(','))
                    {
                        double pch = double.Parse(ps, ci);
                        list.Add(new ThreadSize
                        {
                            Name = "M" + d.ToString(ci) + " x " + pch.ToString(ci),
                            DiameterMm = d, PitchMm = pch
                        });
                    }
                }
            }
            else if (s == ThreadStandard.BSW)
            {
                foreach (string item in BswData.Split(new[] { ';' }, StringSplitOptions.RemoveEmptyEntries))
                {
                    string[] kv = item.Split(':');
                    double d = ParseInch(kv[0]), tpi = double.Parse(kv[1], ci);
                    list.Add(new ThreadSize
                    {
                        Name = kv[0] + "\" BSW - " + tpi.ToString(ci) + " TPI",
                        DiameterMm = d * 25.4, PitchMm = 25.4 / tpi
                    });
                }
            }
            else if (s == ThreadStandard.Tr || s == ThreadStandard.S)
            {
                string prefix = s == ThreadStandard.Tr ? "Tr " : "S ";
                string[] tables = s == ThreadStandard.Tr
                    ? new[] { TrCoarseData, TrFineData }
                    : new[] { SData };
                var seen = new HashSet<string>(StringComparer.Ordinal);
                foreach (string data in tables)
                foreach (string item in data.Split(new[] { ';' }, StringSplitOptions.RemoveEmptyEntries))
                {
                    string[] kv = item.Split(':');
                    double d = double.Parse(kv[0], ci);
                    foreach (string ps in kv[1].Split(','))
                    {
                        double pch = double.Parse(ps, ci);
                        string key = d.ToString("0.###", ci) + "|" + pch.ToString("0.###", ci);
                        if (!seen.Add(key)) continue;
                        list.Add(new ThreadSize { Name = prefix + d.ToString(ci) + " x " + pch.ToString(ci), DiameterMm = d, PitchMm = pch });
                    }
                }
            }
            else if (s == ThreadStandard.Rd)
            {
                foreach (string item in RdData.Split(new[] { ';' }, StringSplitOptions.RemoveEmptyEntries))
                {
                    string[] kv = item.Split(':');
                    double d = double.Parse(kv[0], ci), tpi = double.Parse(kv[1], ci);
                    list.Add(new ThreadSize
                    {
                        Name = "Rd " + d.ToString(ci) + " x 1/" + tpi.ToString(ci) + "\"",
                        DiameterMm = d, PitchMm = 25.4 / tpi
                    });
                }
            }
            else
            {
                var have = new List<double[]>();   // inch, tpi
                foreach (string item in UnData.Split(new[] { ';' }, StringSplitOptions.RemoveEmptyEntries))
                {
                    string[] kv = item.Split(':');
                    double d = ParseInch(kv[0]);
                    foreach (string tok in kv[1].Split(','))
                    {
                        int k = 0;
                        while (k < tok.Length && char.IsLetter(tok[k])) k++;
                        string series = tok.Substring(0, k);
                        double tpi = double.Parse(tok.Substring(k), ci);
                        have.Add(new[] { d, tpi });
                        list.Add(new ThreadSize
                        {
                            Name = kv[0] + "-" + tpi.ToString(ci) + " " + series,
                            DiameterMm = d * 25.4, PitchMm = 25.4 / tpi
                        });
                    }
                }
                foreach (double[] cs in UnConst)
                {
                    double tpi = cs[0];
                    for (double d = cs[1]; d <= cs[2] + 1e-9; d += (d < 2.0 - 1e-9 ? 0.0625 : (d < 4.0 - 1e-9 ? 0.125 : 0.25)))
                    {
                        bool dup = false;
                        foreach (double[] h in have)
                            if (Math.Abs(h[0] - d) < 1e-4 && Math.Abs(h[1] - tpi) < 1e-9) { dup = true; break; }
                        if (dup) continue;
                        list.Add(new ThreadSize
                        {
                            Name = InchLabel(d) + "-" + tpi.ToString(ci) + " UN",
                            DiameterMm = d * 25.4, PitchMm = 25.4 / tpi
                        });
                    }
                }
            }
            list.Sort((x, y) =>
            {
                int c = x.DiameterMm.CompareTo(y.DiameterMm);
                return c != 0 ? c : y.PitchMm.CompareTo(x.PitchMm);   // coarse first
            });
            return list;
        }
    }
}
