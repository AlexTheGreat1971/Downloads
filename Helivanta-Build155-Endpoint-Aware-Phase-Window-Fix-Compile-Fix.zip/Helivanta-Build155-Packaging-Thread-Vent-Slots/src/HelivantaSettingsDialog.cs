﻿﻿using System;
using System.Drawing;
using System.Windows.Forms;

namespace ThreadPro
{
    internal sealed class HelivantaSettingsDialog : Form
    {
        private readonly HelivantaSettingsData data;
        private FlowLayoutPanel theme, accent, language;
        private Button[] themeOptions;
        private RadioButton[] accentOptions, languageOptions;
        private ComboBox standard, technology;
        private NumericUpDown opacity, lineScale;
        private CheckBox autoPreview, rememberPreview, external, rightHand, tooltips;
        private Button apply, cancel, defaults;
        private Label title;
        private string _selectedTheme = "Dark";
        private bool _suppressThemeEvents;

        internal HelivantaSettingsDialog(IWin32Window owner)
        {
            // Current is loaded from settings.json at add-in startup and updated only after a
            // verified Save(). Re-reading the file on every dialog construction can overwrite
            // the valid in-session choice during an unrelated file refresh; use the live source.
            data = new HelivantaSettingsData();
            var d = HelivantaUserSettings.Current;
            data.Theme = d.Theme; data.Accent = d.Accent; data.Language = d.Language;
            _selectedTheme = string.Equals(data.Theme, "Light", StringComparison.OrdinalIgnoreCase) ? "Light" : "Dark";
            data.PreviewOpacity = d.PreviewOpacity; data.PreviewLineScale = d.PreviewLineScale;
            data.AutoPreview = d.AutoPreview; data.RememberPreview = d.RememberPreview;
            data.DefaultStandard = d.DefaultStandard; data.DefaultTechnology = d.DefaultTechnology;
            data.DefaultExternal = d.DefaultExternal; data.DefaultRightHand = d.DefaultRightHand; data.Tooltips = d.Tooltips;
            Text = L("Настройки Helivanta", "Helivanta Settings");
            StartPosition = FormStartPosition.CenterParent; FormBorderStyle = FormBorderStyle.FixedDialog;
            MaximizeBox = false; MinimizeBox = false; ShowInTaskbar = false; AutoScaleMode = AutoScaleMode.Dpi;
            Font = new Font("Segoe UI", 9f); ClientSize = new Size(560, 640);
            Build();
            // Re-assert the persisted choice after all RadioButtons and CheckedChanged handlers exist.
            // WinForms Appearance.Button radio groups can otherwise leave visual selection and the
            // backing field out of sync while the panel is populated.
            SelectThemeOption(_selectedTheme, applyPalette: false);
            ApplyPalette();
        }

        protected override void OnShown(EventArgs e)
        {
            base.OnShown(e);
            // The constructor has already loaded the persisted preference. Reapply that explicit
            // value after native handles are created, but do not read the file a second time here:
            // a stale/delayed filesystem view must not override the just-loaded session state.
            SelectThemeOption(_selectedTheme, applyPalette: true);
        }

        private bool En => data.Language == "en";
        private string L(string ru, string en) => En ? en : ru;
        private Label LabelFor(string text) => new Label { Text = text, AutoSize = true, Anchor = AnchorStyles.Left, Margin = new Padding(3, 7, 3, 3) };

        private ComboBox Choice(string[] items, int selected)
        {
            var c = new ComboBox { DropDownStyle = ComboBoxStyle.DropDownList, Dock = DockStyle.Fill, IntegralHeight = false };
            c.Items.AddRange(items); c.SelectedIndex = Math.Max(0, Math.Min(selected, items.Length - 1)); return c;
        }

        private FlowLayoutPanel ThemeTiles(out Button[] buttons)
        {
            var panel = new FlowLayoutPanel { Dock = DockStyle.Fill, AutoSize = true, WrapContents = false, FlowDirection = FlowDirection.LeftToRight, Margin = Padding.Empty, Padding = Padding.Empty };
            buttons = new Button[2];
            string[] captions = { L("◐ Тёмная", "◐ Dark"), L("☼ Светлая", "☼ Light") };
            string[] values = { "Dark", "Light" };
            for (int i = 0; i < buttons.Length; i++)
            {
                int index = i;
                var button = new Button
                {
                    Text = captions[i], Tag = values[i], Width = 116, Height = 34,
                    TextAlign = ContentAlignment.MiddleCenter, FlatStyle = FlatStyle.Flat,
                    TabStop = true, Margin = new Padding(0, 1, 5, 1),
                    Font = new Font("Segoe UI Semibold", 8.5f, FontStyle.Bold),
                    BackColor = Color.FromArgb(33, 44, 58), ForeColor = Color.White,
                    UseVisualStyleBackColor = false
                };
                button.FlatAppearance.BorderSize = 1;
                button.Click += (sender, args) => SelectThemeOption(values[index], applyPalette: true);
                buttons[i] = button;
                panel.Controls.Add(button);
            }
            return panel;
        }

        private FlowLayoutPanel Tiles(string[] captions, int selected, int[] widths, Color[] captionColors, out RadioButton[] buttons)
        {
            var panel = new FlowLayoutPanel { Dock = DockStyle.Fill, AutoSize = true, WrapContents = false, FlowDirection = FlowDirection.LeftToRight, Margin = Padding.Empty, Padding = Padding.Empty };
            buttons = new RadioButton[captions.Length];
            for (int i = 0; i < captions.Length; i++)
            {
                int index = i;
                var button = new RadioButton
                {
                    Appearance = Appearance.Button, AutoSize = false, Width = widths[i], Height = 34,
                    Text = captions[i], TextAlign = ContentAlignment.MiddleCenter, Checked = i == selected,
                    FlatStyle = FlatStyle.Flat, TabStop = true, Margin = new Padding(0, 1, 5, 1),
                    Font = new Font("Segoe UI Semibold", 8.5f, FontStyle.Bold),
                    ForeColor = captionColors != null && i < captionColors.Length ? captionColors[i] : Color.White,
                    BackColor = Color.FromArgb(33, 44, 58)
                };
                button.FlatAppearance.BorderSize = 1;
                button.CheckedChanged += (sender, args) =>
                {
                    if (button.Checked && !_suppressThemeEvents) ApplyPalette();
                };
                buttons[i] = button; panel.Controls.Add(button);
            }
            return panel;
        }

        private void Build()
        {
            var root = new TableLayoutPanel { Dock = DockStyle.Fill, Padding = new Padding(14, 12, 14, 52), ColumnCount = 2, RowCount = 13 };
            root.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 42));
            root.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 58));
            for (int i = 0; i < 12; i++) root.RowStyles.Add(new RowStyle(SizeType.AutoSize));
            root.RowStyles.Add(new RowStyle(SizeType.Percent, 100)); Controls.Add(root);

            title = new Label { Text = L("Внешний вид и поведение", "Appearance and behavior"), AutoSize = true, Font = new Font("Segoe UI Semibold", 13f, FontStyle.Bold), Margin = new Padding(0, 0, 0, 8) };
            root.Controls.Add(title, 0, 0); root.SetColumnSpan(title, 2);

            // Theme is intentionally represented by ordinary Buttons, not RadioButtons.
            // WinForms can re-evaluate RadioButton groups during handle creation and reparenting;
            // that visual state must never be able to overwrite the persisted theme preference.
            theme = ThemeTiles(out themeOptions);
            AddRow(root, 1, L("Цветовая тема", "Color theme"), theme);
            accent = Tiles(new[] { L("■ Янтарный", "■ Amber"), L("■ Голубой", "■ Blue"), L("■ Серый", "■ Gray") }, data.Accent == "Blue" ? 1 : data.Accent == "Gray" ? 2 : 0, new[] { 92, 86, 78 }, new[] { Color.FromArgb(191, 123, 24), Color.FromArgb(39, 140, 212), Color.FromArgb(112, 126, 140) }, out accentOptions);
            AddRow(root, 2, L("Цвет акцента", "Accent color"), accent);
            language = Tiles(new[] { "RU  Русский", "EN  English" }, data.Language == "en" ? 1 : 0, new[] { 104, 104 }, null, out languageOptions);
            AddRow(root, 3, L("Язык интерфейса", "Interface language"), language);

            AddRow(root, 4, L("Стандарт по умолчанию", "Default standard"), standard = Choice(new[] { "ISO", "ANSI/UN", "BSW", "Tr", "S", "Rd" }, Array.IndexOf(new[] { "ISO", "ANSI/UN", "BSW", "Tr", "S", "Rd" }, data.DefaultStandard)));
            AddRow(root, 5, L("Технология по умолчанию", "Default technology"), technology = Choice(new[] { L("Металл", "Metal"), L("Смола", "Resin"), "SLS", "FDM" }, data.DefaultTechnology == "Resin" ? 1 : data.DefaultTechnology == "SLS" ? 2 : data.DefaultTechnology == "FDM" ? 3 : 0));
            AddRow(root, 6, L("Прозрачность фантома (%)", "Preview opacity (%)"), opacity = new NumericUpDown { Minimum = 0, Maximum = 100, Value = Math.Max(0, Math.Min(100, data.PreviewOpacity)), Dock = DockStyle.Fill });
            AddRow(root, 7, L("Толщина линий (%)", "Line thickness (%)"), lineScale = new NumericUpDown { Minimum = 50, Maximum = 200, Value = Math.Max(50, Math.Min(200, data.PreviewLineScale)), Dock = DockStyle.Fill });

            autoPreview = new CheckBox { Text = L("Автоматически обновлять предпросмотр", "Update preview automatically"), Checked = data.AutoPreview, AutoSize = true }; root.Controls.Add(autoPreview, 0, 8); root.SetColumnSpan(autoPreview, 2);
            rememberPreview = new CheckBox { Text = L("Запоминать параметры предпросмотра", "Remember preview settings"), Checked = data.RememberPreview, AutoSize = true }; root.Controls.Add(rememberPreview, 0, 9); root.SetColumnSpan(rememberPreview, 2);
            external = new CheckBox { Text = L("Наружная резьба по умолчанию", "External thread by default"), Checked = data.DefaultExternal, AutoSize = true }; root.Controls.Add(external, 0, 10); root.SetColumnSpan(external, 2);
            rightHand = new CheckBox { Text = L("Правая резьба по умолчанию", "Right-hand thread by default"), Checked = data.DefaultRightHand, AutoSize = true }; root.Controls.Add(rightHand, 0, 11); root.SetColumnSpan(rightHand, 2);
            tooltips = new CheckBox { Text = L("Показывать подсказки", "Show tooltips"), Checked = data.Tooltips, AutoSize = true }; root.Controls.Add(tooltips, 0, 12); root.SetColumnSpan(tooltips, 2);

            var footer = new FlowLayoutPanel { Dock = DockStyle.Bottom, Height = 44, FlowDirection = FlowDirection.RightToLeft, Padding = new Padding(0, 5, 12, 0), WrapContents = false };
            Controls.Add(footer); footer.BringToFront();
            apply = new Button { Text = L("Применить", "Apply"), Width = 100 };
            cancel = new Button { Text = L("Отмена", "Cancel"), Width = 90, DialogResult = DialogResult.Cancel };
            defaults = new Button { Text = L("По умолчанию", "Defaults"), Width = 105 };
            defaults.Click += (sender, args) =>
            {
                SelectThemeOption("Dark", applyPalette: false);
                accentOptions[0].Checked = true; languageOptions[0].Checked = true;
                standard.SelectedIndex = 0; technology.SelectedIndex = 0; opacity.Value = 80; lineScale.Value = 100;
                autoPreview.Checked = true; rememberPreview.Checked = true; external.Checked = true; rightHand.Checked = true; tooltips.Checked = true;
                ApplyPalette();
            };
            apply.Click += (sender, args) =>
            {
                SaveValues();
                DialogResult = DialogResult.OK;
                Close();
            };
            footer.Controls.Add(apply); footer.Controls.Add(cancel); footer.Controls.Add(defaults); AcceptButton = apply; CancelButton = cancel;
            languageOptions[0].CheckedChanged += (sender, args) => { if (languageOptions[0].Checked) data.Language = "ru"; };
            languageOptions[1].CheckedChanged += (sender, args) => { if (languageOptions[1].Checked) data.Language = "en"; };
        }

        private void SelectThemeOption(string themeName, bool applyPalette = true)
        {
            _selectedTheme = string.Equals(themeName, "Light", StringComparison.OrdinalIgnoreCase) ? "Light" : "Dark";
            if (applyPalette) ApplyPalette();
            else if (themeOptions != null) StyleThemeTiles(themeOptions, _selectedTheme == "Light" ? 1 : 0,
                BackColor, Color.FromArgb(33, 44, 58), ForeColor,
                SelectedAccentColor());
        }

        private void AddRow(TableLayoutPanel panel, int row, string label, Control control)
        {
            panel.Controls.Add(LabelFor(label), 0, row); panel.Controls.Add(control, 1, row);
        }

        private int SelectedIndex(RadioButton[] buttons)
        {
            if (buttons == null) return 0;
            for (int i = 0; i < buttons.Length; i++) if (buttons[i].Checked) return i;
            return 0;
        }

        private void SaveValues()
        {
            // Save the explicit selection set by the theme-tile handlers, not a transient
            // native Checked value that can change during handle creation/layout. Synchronize
            // the button state right before persisting, while suppressing its event callbacks.
            _selectedTheme = string.Equals(_selectedTheme, "Light", StringComparison.OrdinalIgnoreCase) ? "Light" : "Dark";
            data.Theme = _selectedTheme;
            data.Accent = SelectedIndex(accentOptions) == 1 ? "Blue" : SelectedIndex(accentOptions) == 2 ? "Gray" : "Amber";
            data.Language = SelectedIndex(languageOptions) == 1 ? "en" : "ru";
            data.DefaultStandard = standard.SelectedItem?.ToString() ?? "ISO";
            data.DefaultTechnology = technology.SelectedIndex == 1 ? "Resin" : technology.SelectedIndex == 2 ? "SLS" : technology.SelectedIndex == 3 ? "FDM" : "Metal";
            data.PreviewOpacity = (int)opacity.Value; data.PreviewLineScale = (int)lineScale.Value;
            data.AutoPreview = autoPreview.Checked; data.RememberPreview = rememberPreview.Checked;
            data.DefaultExternal = external.Checked; data.DefaultRightHand = rightHand.Checked; data.Tooltips = tooltips.Checked;
            HelivantaUserSettings.Save(data);
            _selectedTheme = string.Equals(HelivantaUserSettings.Current.Theme, "Light", StringComparison.OrdinalIgnoreCase) ? "Light" : "Dark";
            if (!string.Equals(data.Theme, _selectedTheme, StringComparison.Ordinal))
                throw new InvalidOperationException("The saved Helivanta theme does not match the selected theme.");
            ApplyPalette();
        }

        private void ApplyPalette()
        {
            bool light = string.Equals(_selectedTheme, "Light", StringComparison.OrdinalIgnoreCase);
            Color surface = light ? Color.FromArgb(239, 242, 245) : Color.FromArgb(37, 48, 63);
            Color field = light ? Color.White : Color.FromArgb(33, 44, 58);
            Color fore = light ? Color.FromArgb(35, 45, 55) : Color.FromArgb(235, 241, 247);
            int ai = SelectedIndex(accentOptions);
            Color ac = ai == 1 ? Color.FromArgb(39, 140, 212) : ai == 2 ? Color.FromArgb(112, 126, 140) : Color.FromArgb(191, 123, 24);
            BackColor = surface; ForeColor = fore; ApplyRecursive(this, surface, field, fore, ac);
            StyleThemeTiles(themeOptions, light ? 1 : 0, surface, field, fore, ac);
            StyleTiles(accentOptions, SelectedIndex(accentOptions), surface, field, fore, ac, new[] { Color.FromArgb(191, 123, 24), Color.FromArgb(39, 140, 212), Color.FromArgb(112, 126, 140) });
            StyleTiles(languageOptions, SelectedIndex(languageOptions), surface, field, fore, ac, null);
        }

        private void StyleThemeTiles(Button[] buttons, int selected, Color surface, Color field, Color fore, Color accentColor)
        {
            if (buttons == null) return;
            for (int i = 0; i < buttons.Length; i++)
            {
                buttons[i].FlatStyle = FlatStyle.Flat;
                buttons[i].UseVisualStyleBackColor = false;
                buttons[i].BackColor = i == selected ? accentColor : field;
                buttons[i].ForeColor = i == selected ? Color.White : fore;
                buttons[i].FlatAppearance.BorderColor = i == selected ? ControlPaint.Light(accentColor, .25f) : lightBorder(surface);
                buttons[i].FlatAppearance.BorderSize = i == selected ? 2 : 1;
            }
        }

        private Color SelectedAccentColor()
        {
            int ai = SelectedIndex(accentOptions);
            return ai == 1 ? Color.FromArgb(39, 140, 212) : ai == 2 ? Color.FromArgb(112, 126, 140) : Color.FromArgb(191, 123, 24);
        }

        private void StyleTiles(RadioButton[] buttons, int selected, Color surface, Color field, Color fore, Color accentColor, Color[] swatches)
        {
            if (buttons == null) return;
            for (int i = 0; i < buttons.Length; i++)
            {
                buttons[i].BackColor = i == selected ? accentColor : field;
                buttons[i].ForeColor = i == selected ? Color.White : (swatches != null && i < swatches.Length ? swatches[i] : fore);
                buttons[i].FlatAppearance.BorderColor = i == selected ? ControlPaint.Light(accentColor, .25f) : (lightBorder(surface));
                buttons[i].FlatAppearance.BorderSize = i == selected ? 2 : 1;
            }
        }

        private Color lightBorder(Color surface) => surface.R > 100 ? Color.FromArgb(174, 184, 194) : Color.FromArgb(78, 98, 118);

        private void ApplyRecursive(Control control, Color surface, Color field, Color fore, Color accentColor)
        {
            if (control is Form || control is TableLayoutPanel || control is FlowLayoutPanel) { control.BackColor = surface; control.ForeColor = fore; }
            if (control is Label || control is CheckBox) { control.ForeColor = fore; control.BackColor = Color.Transparent; }
            if (control is ComboBox || control is NumericUpDown) { control.BackColor = field; control.ForeColor = fore; }
            if (control is Button b && !(control is RadioButton)) { b.BackColor = accentColor; b.ForeColor = Color.White; b.FlatStyle = FlatStyle.Flat; b.FlatAppearance.BorderColor = ControlPaint.Light(accentColor, .25f); }
            foreach (Control child in control.Controls) ApplyRecursive(child, surface, field, fore, accentColor);
        }
    }
}
