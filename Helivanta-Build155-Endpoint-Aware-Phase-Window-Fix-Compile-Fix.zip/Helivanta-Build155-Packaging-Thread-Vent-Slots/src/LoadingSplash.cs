﻿using System;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Reflection;
using System.Windows.Forms;

namespace ThreadPro
{
    /// <summary>
    /// Lightweight startup feedback shown before ThreadDialog starts its expensive layout
    /// and Inventor selection initialization. Kept intentionally static: painting it must
    /// finish quickly even on low-performance workstations.
    /// </summary>
    internal sealed class LoadingSplash : Form
    {
        private static readonly Color Surface = Color.FromArgb(37, 48, 63);
        private static readonly Color TextColor = Color.FromArgb(235, 241, 247);
        private static readonly Color Accent = Color.FromArgb(72, 173, 235);
        private static readonly Color BorderColor = Color.FromArgb(78, 98, 118);
        private PictureBox _logo;
        private Label _statusLabel;
        public LoadingSplash(IntPtr referenceWindowHandle)
        {
            AutoScaleMode = AutoScaleMode.Dpi;
            Load += (sender, args) => HelivantaLocalization.Apply(this);
            Text = "Helivanta";
            FormBorderStyle = FormBorderStyle.FixedDialog;
            // Position explicitly on the right side of the monitor hosting Inventor rather than
            // relying on CenterParent or allowing an owner activation pass to place it on the left.
            StartPosition = FormStartPosition.Manual;
            ShowInTaskbar = false;
            ShowIcon = false;
            ControlBox = false;
            MinimizeBox = false;
            MaximizeBox = false;
            TopMost = false;
            ClientSize = new Size(420, 250);
            MinimumSize = MaximumSize = Size;
            Rectangle workArea;
            try
            {
                workArea = referenceWindowHandle != IntPtr.Zero
                    ? Screen.FromHandle(referenceWindowHandle).WorkingArea
                    : (Screen.PrimaryScreen != null ? Screen.PrimaryScreen.WorkingArea : SystemInformation.WorkingArea);
            }
            catch
            {
                workArea = SystemInformation.WorkingArea;
            }
            // Align the startup splash to the same right-hand area as the main dialog.
            // This prevents the launch sequence from appearing to jump from left/center to right.
            int margin = 18;
            int x = Math.Max(workArea.Left + 8, workArea.Right - Width - margin);
            int y = workArea.Top + Math.Min(20, Math.Max(8, (workArea.Height - Height) / 5));
            y = Math.Max(workArea.Top + 8, Math.Min(y, workArea.Bottom - Height - 8));
            Location = new Point(x, y);
            BackColor = Surface;
            ForeColor = TextColor;
            Font = new Font("Segoe UI", 10f, FontStyle.Regular, GraphicsUnit.Point);
            DoubleBuffered = true;
            SetStyle(ControlStyles.OptimizedDoubleBuffer | ControlStyles.AllPaintingInWmPaint | ControlStyles.ResizeRedraw, true);

            var frame = new SplashHatchPanel
            {
                Dock = DockStyle.Fill,
                BackColor = Surface,
                Padding = new Padding(1),
                Margin = Padding.Empty
            };
            frame.Paint += (s, e) =>
            {
                using (var pen = new Pen(BorderColor))
                    e.Graphics.DrawRectangle(pen, 0, 0, Math.Max(0, frame.Width - 1), Math.Max(0, frame.Height - 1));
            };
            Controls.Add(frame);

            var layout = new TableLayoutPanel
            {
                Dock = DockStyle.Fill,
                ColumnCount = 1,
                RowCount = 3,
                BackColor = Color.Transparent,
                // Keep the splash window fixed at 420x250, but give the approved square logo
                // the largest height that leaves full, independent rows for version and status.
                // Small vertical padding avoids wasting space; the logo remains proportionally scaled.
                Padding = new Padding(10, 2, 10, 2),
                Margin = Padding.Empty
            };
            layout.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100f));
            layout.RowStyles.Add(new RowStyle(SizeType.Percent, 74f));
            layout.RowStyles.Add(new RowStyle(SizeType.Percent, 11f));
            layout.RowStyles.Add(new RowStyle(SizeType.Percent, 15f));
            frame.Controls.Add(layout);

            _logo = new PictureBox
            {
                Name = "pluginLogo",
                // The artwork is square. Keep its native proportions and use nearly all
                // available splash height rather than stretching it or clipping the tagline.
                Size = new Size(180, 180),
                SizeMode = PictureBoxSizeMode.Zoom,
                BackColor = Color.Transparent,
                Anchor = AnchorStyles.None,
                Margin = Padding.Empty,
                Image = LoadLogo()
            };
            layout.Controls.Add(_logo, 0, 0);

            var version = new Label
            {
                Text = "Версия " + GetDisplayVersionText(),
                Dock = DockStyle.Fill,
                TextAlign = ContentAlignment.MiddleCenter,
                ForeColor = Color.FromArgb(176, 189, 202),
                BackColor = Color.Transparent,
                Font = new Font("Segoe UI", 9.5f, FontStyle.Regular, GraphicsUnit.Point),
                Margin = Padding.Empty
            };
            layout.Controls.Add(version, 0, 1);

            var status = new Label
            {
                Text = "Загрузка...",
                Dock = DockStyle.Fill,
                TextAlign = ContentAlignment.MiddleCenter,
                ForeColor = Accent,
                BackColor = Color.Transparent,
                Font = new Font("Segoe UI Semibold", 13f, FontStyle.Bold, GraphicsUnit.Point),
                Margin = Padding.Empty
            };
            layout.Controls.Add(status, 0, 2);
            _statusLabel = status;
        }


        internal void SetStatus(string text)
        {
            try { if (_statusLabel != null && !_statusLabel.IsDisposed) _statusLabel.Text = HelivantaLocalization.Translate(text ?? string.Empty); } catch { }
        }

        private static string GetDisplayVersionText()
        {
            try
            {
                Assembly assembly = Assembly.GetExecutingAssembly();
                Version version = assembly.GetName().Version;
                string text = version != null ? version.ToString(3) : "2.0.0";
                AssemblyInformationalVersionAttribute informational =
                    (AssemblyInformationalVersionAttribute)Attribute.GetCustomAttribute(
                        assembly, typeof(AssemblyInformationalVersionAttribute));
                string value = informational == null ? null : informational.InformationalVersion;
                if (!string.IsNullOrWhiteSpace(value))
                {
                    int marker = value.IndexOf("-preview.", StringComparison.OrdinalIgnoreCase);
                    if (marker >= 0)
                    {
                        string suffix = value.Substring(marker + 9).Split('+')[0];
                        int number;
                        if (int.TryParse(suffix, out number)) text += " Preview " + number;
                    }
                }
                return text;
            }
            catch
            {
                return "2.0.0 Preview 14";
            }
        }

        public void EnsureRightPosition(IntPtr referenceWindowHandle)
        {
            try
            {
                if (!IsHandleCreated) return;
                if (NativeWindowPositioning.MoveToRight(Handle, referenceWindowHandle, 18, 8)) return;

                Rectangle workArea = referenceWindowHandle != IntPtr.Zero
                    ? Screen.FromHandle(referenceWindowHandle).WorkingArea
                    : (Screen.PrimaryScreen != null ? Screen.PrimaryScreen.WorkingArea : SystemInformation.WorkingArea);
                int x = Math.Max(workArea.Left + 8, workArea.Right - Width - 18);
                int y = workArea.Top + Math.Min(20, Math.Max(8, (workArea.Height - Height) / 5));
                y = Math.Max(workArea.Top + 8, Math.Min(y, workArea.Bottom - Height - 8));
                Location = new Point(x, y);
            }
            catch { }
        }

        private static Image LoadLogo()
        {
            try
            {
                Assembly assembly = Assembly.GetExecutingAssembly();
                using (var stream = assembly.GetManifestResourceStream("Helivanta-Logo.png"))
                {
                    if (stream != null)
                    {
                        using (var source = Image.FromStream(stream))
                            return new Bitmap(source);
                    }
                }

                foreach (string name in assembly.GetManifestResourceNames())
                {
                    if (!name.EndsWith("Helivanta-Logo.png", StringComparison.OrdinalIgnoreCase)) continue;
                    using (var stream = assembly.GetManifestResourceStream(name))
                    using (var source = Image.FromStream(stream))
                        return new Bitmap(source);
                }
            }
            catch { }
            return new Bitmap(1, 1);
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing && _logo != null && _logo.Image != null)
            {
                try { _logo.Image.Dispose(); } catch { }
                _logo.Image = null;
            }
            base.Dispose(disposing);
        }

        /// <summary>Full-surface version of the section-header diagonal hatch for the startup splash.</summary>
        private sealed class SplashHatchPanel : Panel
        {
            public SplashHatchPanel()
            {
                SetStyle(ControlStyles.UserPaint | ControlStyles.AllPaintingInWmPaint |
                         ControlStyles.OptimizedDoubleBuffer | ControlStyles.ResizeRedraw |
                         ControlStyles.SupportsTransparentBackColor, true);
                DoubleBuffered = true;
            }

            protected override void OnPaintBackground(PaintEventArgs e)
            {
                e.Graphics.Clear(BackColor);
                if (SystemInformation.HighContrast || ClientSize.Width <= 0 || ClientSize.Height <= 0) return;

                Color hatch = Color.FromArgb(
                    Math.Min(255, BackColor.R + 8),
                    Math.Min(255, BackColor.G + 9),
                    Math.Min(255, BackColor.B + 10));
                int spacing = Math.Max(7, (int)Math.Round(8.0 * Math.Max(96, DeviceDpi) / 96.0));
                using (var pen = new Pen(hatch, 1f))
                {
                    pen.StartCap = LineCap.Flat;
                    pen.EndCap = LineCap.Flat;
                    // Match SectionHeaderPanel exactly: lines follow x + y = constant.
                    // This gives the same bottom-left to top-right visual orientation as section headers.
                    for (int c = 0; c <= ClientSize.Width + ClientSize.Height; c += spacing)
                    {
                        var points = new System.Collections.Generic.List<PointF>(4);
                        AddHatchIntersection(points, new PointF(0, c));
                        AddHatchIntersection(points, new PointF(c, 0));
                        AddHatchIntersection(points, new PointF(ClientSize.Width - 1, c - (ClientSize.Width - 1)));
                        AddHatchIntersection(points, new PointF(c - (ClientSize.Height - 1), ClientSize.Height - 1));
                        if (points.Count >= 2) e.Graphics.DrawLine(pen, points[0], points[1]);
                    }
                }
            }

            private void AddHatchIntersection(System.Collections.Generic.List<PointF> points, PointF point)
            {
                if (point.X < 0 || point.Y < 0 || point.X >= ClientSize.Width || point.Y >= ClientSize.Height) return;
                foreach (PointF existing in points)
                    if (Math.Abs(existing.X - point.X) < 0.01f && Math.Abs(existing.Y - point.Y) < 0.01f) return;
                points.Add(point);
            }

        }
    }
}
