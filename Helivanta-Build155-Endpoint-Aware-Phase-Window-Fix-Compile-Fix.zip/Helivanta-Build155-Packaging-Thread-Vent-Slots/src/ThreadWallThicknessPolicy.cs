﻿using System;
using System.Collections.Generic;

namespace ThreadPro
{
    /// <summary>
    /// Conservative, unit-explicit screening policy for the material left below a thread root.
    /// Distances are centimetres unless a member name says otherwise.
    /// This is a build-safety floor, not a structural-strength certification.
    /// </summary>
    internal static class ThreadWallThicknessPolicy
    {
        public const double AbsoluteMinimumRemainingWallMm = 0.5;
        public const double PitchFractionMinimumRemainingWall = 0.25;
        private const double CmPerMm = 0.1;
        private const double NumericToleranceCm = 1e-7;

        public static double RequiredRemainingWallCm(double pitchCm)
        {
            if (!IsFinite(pitchCm) || pitchCm <= 0.0) return double.NaN;
            return Math.Max(AbsoluteMinimumRemainingWallMm * CmPerMm,
                pitchCm * PitchFractionMinimumRemainingWall);
        }

        /// <summary>
        /// Converts the nominal-radius adjustment into a wall-thickness adjustment.
        /// An increased outside radius or a reduced bore radius adds wall; the opposite removes it.
        /// </summary>
        public static double RadiusAdjustmentCm(bool externalSurface, double measuredRadiusCm, double calculatedRadiusCm)
        {
            return externalSurface
                ? calculatedRadiusCm - measuredRadiusCm
                : measuredRadiusCm - calculatedRadiusCm;
        }

        /// <summary>
        /// A ray from an external face through a solid shaft may hit the opposite external face,
        /// returning a full diameter rather than the radial stock depth. Cap that case at the
        /// selected outside radius. For a hollow wall the first opposing hit is the near inner
        /// wall and the measured chord is smaller than the radius, so its actual wall thickness
        /// is preserved. Internal-bore rays travel outward and already measure the wall directly.
        /// Distances are centimetres; invalid readings fail closed.
        /// </summary>
        public static double EffectiveRadialWallThicknessCm(bool externalSurface,
            double measuredRayLengthCm, double selectedRadiusCm)
        {
            if (!IsFinite(measuredRayLengthCm) || measuredRayLengthCm <= 0.0 ||
                !IsFinite(selectedRadiusCm) || selectedRadiusCm <= 0.0)
                return double.NaN;
            return externalSurface ? Math.Min(measuredRayLengthCm, selectedRadiusCm) : measuredRayLengthCm;
        }

        /// <summary>
        /// Resolves wall thickness from a radial ray that starts a known offset inside an external
        /// cylindrical stock face and travels inward. The nearest forward boundary is either the
        /// inner face of a hollow wall or the opposite outside face of a solid shaft. Adding the
        /// probe offset restores the face-to-boundary distance; clamping to the selected radius
        /// prevents a through-diameter hit from masquerading as radial wall thickness.
        /// Distances are centimetres. Invalid or missing measurements fail closed.
        /// </summary>
        public static bool TryGetExternalRadialWallThicknessCm(IEnumerable<double> rayHitDistancesCm,
            double probeOffsetCm, double selectedRadiusCm, out double wallThicknessCm)
        {
            wallThicknessCm = double.NaN;
            if (rayHitDistancesCm == null || !IsFinite(probeOffsetCm) || probeOffsetCm <= 0.0 ||
                !IsFinite(selectedRadiusCm) || selectedRadiusCm <= 0.0)
                return false;

            double nearestHitCm = double.PositiveInfinity;
            bool hasHit = false;
            foreach (double distance in rayHitDistancesCm)
            {
                if (!IsFinite(distance) || distance < -1e-7) return false;
                double forwardDistance = Math.Max(0.0, distance);
                if (forwardDistance < nearestHitCm) nearestHitCm = forwardDistance;
                hasHit = true;
            }
            if (!hasHit || !IsFinite(nearestHitCm)) return false;

            double faceToBoundaryCm = nearestHitCm + probeOffsetCm;
            wallThicknessCm = EffectiveRadialWallThicknessCm(true, faceToBoundaryCm, selectedRadiusCm);
            return IsFinite(wallThicknessCm) && wallThicknessCm > 0.0;
        }

        /// <summary>
        /// Converts ray intersections into the first interval when the ray starts outside a body.
        /// Sorts/coalesces duplicate edge/face hits to distinguish a thin wall from repeat hits.
        /// Distances are centimetres.
        /// </summary>
        public static bool TryGetFirstDistinctIntersectionIntervalCm(IEnumerable<double> intersectionDistancesCm,
            out double intervalCm)
        {
            intervalCm = double.NaN;
            if (intersectionDistancesCm == null) return false;
            var distances = new List<double>();
            foreach (double distance in intersectionDistancesCm)
            {
                if (!IsFinite(distance) || distance < -1e-7) return false;
                distances.Add(Math.Max(0.0, distance));
            }
            if (distances.Count < 2) return false;
            distances.Sort();
            const double duplicateHitToleranceCm = 1e-6;
            double first = distances[0];
            for (int i = 1; i < distances.Count; i++)
            {
                double delta = distances[i] - first;
                if (delta > duplicateHitToleranceCm)
                {
                    intervalCm = delta;
                    return IsFinite(intervalCm) && intervalCm > 0.0;
                }
                first = Math.Min(first, distances[i]);
            }
            return false;
        }

        /// <summary>
        /// Validates known chamfer fit constraints before the wall-thickness estimate is reported.
        /// Returns a user-facing reason when a requested chamfer is geometrically incompatible,
        /// so the UI does not misdiagnose a chamfer-size problem as a thin-wall problem.
        /// Distances are centimetres. This mirrors the deterministic checks in ThreadBuilder.
        /// </summary>
        public static string ValidateChamferFit(bool externalSurface, double effectiveRadiusCm,
            double surfaceLengthCm, int chamferMode, double chamferDepthCm,
            bool startIsShoulder, bool endIsShoulder)
        {
            if (chamferMode == 0) return null;
            if (chamferMode < 0 || chamferMode > 3)
                return "Построение запрещено: неизвестный режим фаски. Модель не изменена.";
            if (!IsFinite(chamferDepthCm) || chamferDepthCm <= 0.0)
                return "Построение запрещено: размер включённой фаски должен быть больше нуля. Модель не изменена.";
            if (!IsFinite(surfaceLengthCm) || surfaceLengthCm <= 0.0)
                return "Построение запрещено: невозможно проверить фаску — длина цилиндрической поверхности неизвестна. Модель не изменена.";
            if (externalSurface && (!IsFinite(effectiveRadiusCm) || effectiveRadiusCm <= 0.0 || chamferDepthCm >= effectiveRadiusCm))
                return "Построение запрещено: фаска " + (chamferDepthCm * 10.0).ToString("0.###", System.Globalization.CultureInfo.InvariantCulture) +
                    " мм не меньше радиуса цилиндра. Уменьшите размер фаски. Модель не изменена.";
            if (chamferDepthCm >= surfaceLengthCm)
                return "Построение запрещено: фаска " + (chamferDepthCm * 10.0).ToString("0.###", System.Globalization.CultureInfo.InvariantCulture) +
                    " мм достигает или превышает длину цилиндрической поверхности. Уменьшите фаску. Модель не изменена.";

            bool includesStart = chamferMode == 1 || chamferMode == 3;
            bool includesEnd = chamferMode == 2 || chamferMode == 3;
            if (chamferMode == 3 && 2.0 * chamferDepthCm >= surfaceLengthCm - 1e-9)
                return "Построение запрещено: две фаски по " + (chamferDepthCm * 10.0).ToString("0.###", System.Globalization.CultureInfo.InvariantCulture) +
                    " мм не помещаются на выбранной поверхности. Их суммарная длина должна быть меньше длины цилиндра. Модель не изменена.";
            if (includesStart && startIsShoulder)
                return "Построение запрещено: фаску в начале нельзя построить на вогнутом/упорном ребре — это может повредить соседнюю поверхность. Измените положение фаски. Модель не изменена.";
            if (includesEnd && endIsShoulder)
                return "Построение запрещено: фаску в конце нельзя построить на вогнутом/упорном ребре — это может повредить соседнюю поверхность. Измените положение фаски. Модель не изменена.";
            return null;
        }

        /// <summary>
        /// Reserves the maximum local radial removal relative to the original cylindrical stock.
        /// The thread groove and end chamfer are two subtractive cuts; along one radial ray, the
        /// removed volume is their union, not the sum of their radial depths. The larger local
        /// depth is used for this conservative screen. Invalid dimensions fail closed as NaN.
        /// This is not an exact B-Rep intersection analysis.
        /// </summary>
        public static double EffectiveCutDepthCm(double grooveDepthCm, bool chamferEnabled, double chamferDepthCm)
        {
            if (!IsFinite(grooveDepthCm) || grooveDepthCm <= 0.0 ||
                !IsFinite(chamferDepthCm) || chamferDepthCm < 0.0 || (chamferEnabled && chamferDepthCm <= 0.0))
                return double.NaN;
            double localMaximum = Math.Max(grooveDepthCm, chamferEnabled ? chamferDepthCm : 0.0);
            return IsFinite(localMaximum) && localMaximum > 0.0 ? localMaximum : double.NaN;
        }

        /// <summary>
        /// Returns true only when sampled material thickness minus the radial thread cut leaves
        /// at least the conservative residual-wall floor. Invalid measurements fail closed.
        /// </summary>
        public static bool HasSafeRemainingWall(double measuredWallCm, double radiusAdjustmentCm,
            double grooveDepthCm, double pitchCm, out double remainingWallCm, out double requiredWallCm)
        {
            remainingWallCm = double.NaN;
            requiredWallCm = RequiredRemainingWallCm(pitchCm);
            if (!IsFinite(measuredWallCm) || measuredWallCm <= 0.0 ||
                !IsFinite(radiusAdjustmentCm) || !IsFinite(grooveDepthCm) || grooveDepthCm < 0.0 ||
                !IsFinite(requiredWallCm) || requiredWallCm <= 0.0)
                return false;

            remainingWallCm = measuredWallCm + radiusAdjustmentCm - grooveDepthCm;
            if (!IsFinite(remainingWallCm)) return false;
            return remainingWallCm + NumericToleranceCm >= requiredWallCm;
        }

        private static bool IsFinite(double value)
        {
            return !double.IsNaN(value) && !double.IsInfinity(value);
        }
    }
}
