﻿namespace ThreadPro
{
    /// <summary>
    /// Pure state model for converting multiple native Inventor ThreadFeatures in sequence.
    /// A next feature can replace the active plan only after the previous conversion succeeded
    /// and the user explicitly requested the next selection.
    /// </summary>
    internal enum NativeThreadConversionSequenceState
    {
        NotInConversionMode,
        ReadyToConvertCurrent,
        RequestNextSelection,
        AwaitingNextSelection,
        InvalidState
    }

    internal static class NativeThreadConversionSequencePolicy
    {
        internal static NativeThreadConversionSequenceState Resolve(
            bool conversionMode, bool conversionCompleted, bool awaitingNextSelection)
        {
            if (!conversionMode)
                return NativeThreadConversionSequenceState.NotInConversionMode;

            if (awaitingNextSelection)
                return conversionCompleted
                    ? NativeThreadConversionSequenceState.AwaitingNextSelection
                    : NativeThreadConversionSequenceState.InvalidState;

            return conversionCompleted
                ? NativeThreadConversionSequenceState.RequestNextSelection
                : NativeThreadConversionSequenceState.ReadyToConvertCurrent;
        }

        internal static bool CanAcceptNextFeature(
            bool conversionMode, bool conversionCompleted, bool awaitingNextSelection)
        {
            return Resolve(conversionMode, conversionCompleted, awaitingNextSelection) ==
                   NativeThreadConversionSequenceState.AwaitingNextSelection;
        }
    }
}
