﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;
using Inventor;

namespace ThreadPro
{
    /// <summary>Geometry found from the picked circular edge (all lengths in cm - Inventor API units).</summary>
    public sealed class ThreadTarget
    {
        public double[] Center;   // centre of the picked edge, lies on the axis
        public double[] U;        // unit vector along the axis, pointing into the cylindrical face
        public double RadiusCm;
        public double LengthCm;   // length of the face measured from the picked edge
        public bool IsExternal;
        public bool IsConical;
        public bool NativeDirectionReversed;
        public Edge SelectedEdge;
        public Face SelectedFace;
        public SurfaceBody Body;       // solid body that owns the picked surface (multi-body parts)
        public string BodyName;
        /// <summary>Original part document captured at selection time. Prevents building in another active document.</summary>
        public PartDocument SourceDocument;
        public string SourceDocumentInternalName;
        public bool StartIsShoulder;   // the picked edge lies at a shoulder (concave edge): the tool must not enter it
        public bool EndIsShoulder;     // the far edge lies at a shoulder
        public List<Edge> StartEdges = new List<Edge>();   // circular edges at the picked end
        public List<Edge> EndEdges = new List<Edge>();     // circular edges at the far end
    }

    public sealed class ThreadParams
    {
        public ThreadStandard Standard;
        public string SizeName;
        public double PitchMm;
        public int Starts;
        public double ClearanceMm;
        public bool External;
        public bool Round;            // fillets on crests and roots
        public bool Smooth;           // enable helical run-out of a partial thread
        // Retained only to read old metadata; Build/BuildAll force it false so all new/edited threads use smooth run-out.
        public bool SimplifiedRunout; // Legacy metadata field only; simplified run-out is no longer supported.
        public double RunSteps;       // length of the run-out in pitches
        public bool Mirror;           // buttress thread: load flank on the other side
        public bool SortThreadsIntoFolders = true; // group each logical thread into an Inventor browser folder
        public double NominalDiaMm;   // nominal (major) diameter of the thread
        public bool FullLength;
        public double LengthMm;
        public double OffsetMm;
        public bool RunOut;       // let the thread run out through the far end
        public bool RightHand;
        public int ChamferMode;      // 0 none, 1 start, 2 end, 3 both
        public double ChamferMm;
        // Thread tolerance designation, e.g. 6H / 6g. Empty preserves legacy behavior.
        public string ToleranceClass = string.Empty;
        // Tapered-thread definition. TaperRatio is radial diameter change per axial length
        // expressed as a ratio (e.g. 1.0 / 16.0); zero means a parallel thread.
        public bool Tapered;
        public TaperGeometryModeKind TaperGeometryMode = TaperGeometryModeKind.StrictStandard;
        public string TaperStandard = string.Empty;
        public string TaperDesignation = string.Empty; // exact key accepted by ThreadTableQuery
        public string TaperDisplayDesignation = string.Empty; // human-readable name returned by Inventor, for browser/UI labels
        public double TaperRatio;
        public double TaperReferenceDiameterMm;
        public double TaperReferenceLengthMm;
        public double TaperStartDiameterMm;
        public double TaperEndDiameterMm;
        // Native TaperedThreadInfo.ThreadHeight converted to mm; used for physical groove geometry.
        public double TaperThreadDepthMm;
        // UI must explicitly confirm any standard-driven change to the source body's geometry.
        // This is a one-operation runtime gate and is not persisted in thread metadata.
        public bool TaperGeometryChangeConfirmed;
    }

    public static class ThreadBuilder
    {
        internal const string TransactionPrefix = "Helivanta: построение резьбы";
        internal const string EditTransactionPrefix = "Helivanta: редактирование резьбы";
        internal static bool LastMetadataAttachSucceeded;

        /// <summary>Non-fatal problem of the last Build call (e.g. folder could not be created).</summary>
        public static string LastWarning;

        /// <summary>Per-stage timing information for the most recent smooth run-out Loft build.</summary>
        public static string LastRunoutPerformance;

        /// <summary>Diagnostic text for the most recent failed BuildAll call.</summary>
        public static string LastError;

        /// <summary>Concise, actionable text for the user after a failed build; never contains a stack trace.</summary>
        public static string LastUserError;

        /// <summary>Summary of persistent edit metadata written for the most recent BuildAll operation.</summary>
        public static string LastMetadataStatus;

        private static string LastBrowserFolderPerformance;

        /// <summary>Clears folder-timing diagnostics before a replacement build.</summary>
        internal static void ResetBrowserFolderPerformance()
        {
            LastBrowserFolderPerformance = null;
        }

        private sealed class ReferenceComparer<T> : IEqualityComparer<T> where T : class
        {
            public bool Equals(T x, T y) { return object.ReferenceEquals(x, y); }
            public int GetHashCode(T obj) { return obj == null ? 0 : RuntimeHelpers.GetHashCode(obj); }
        }

        /// <summary>Returns true only when the newest committed Inventor transaction belongs to Helivanta.</summary>
        public static bool CanUndoLastBuild(Inventor.Application app)
        {
            if (app == null) return false;
            try
            {
                TransactionsEnumerator committed = app.TransactionManager.CommittedTransactions;
                if (committed == null || committed.Count <= 0) return false;
                Transaction last = null;
                foreach (Transaction candidate in committed)
                    last = candidate;

                return last != null && !string.IsNullOrEmpty(last.DisplayName) &&
                       (last.DisplayName.StartsWith(TransactionPrefix, StringComparison.Ordinal) ||
                        last.DisplayName.StartsWith(EditTransactionPrefix, StringComparison.Ordinal));
            }
            catch
            {
                return false;
            }
        }

        /// <summary>Returns true only when the newest committed transaction is an edit of an existing Helivanta thread.</summary>
        internal static bool CanUndoLastEdit(Inventor.Application app, string threadId)
        {
            if (app == null) return false;
            try
            {
                TransactionsEnumerator committed = app.TransactionManager.CommittedTransactions;
                if (committed == null || committed.Count <= 0) return false;
                Transaction last = null;
                foreach (Transaction candidate in committed) last = candidate;
                return last != null && !string.IsNullOrEmpty(last.DisplayName) &&
                    !string.IsNullOrWhiteSpace(threadId) &&
                    last.DisplayName.StartsWith(EditTransactionPrefix + " " + threadId, StringComparison.Ordinal);
            }
            catch { return false; }
        }

        /// <summary>Undoes exactly the last Helivanta build/edit transaction and never an unrelated Inventor action.</summary>
        public static void UndoLastBuild(Inventor.Application app)
        {
            if (!CanUndoLastBuild(app))
                throw new InvalidOperationException("Последним действием была не операция Helivanta — отменять нечего.");

            try
            {
                app.TransactionManager.UndoTransaction();
            }
            catch (Exception ex)
            {
                throw new InvalidOperationException("Не удалось отменить последнее построение: " + ex.Message, ex);
            }
        }

        private static string StdName(ThreadStandard s)
        {
            switch (s)
            {
                case ThreadStandard.ISO: return "ISO";
                case ThreadStandard.BSW: return "BSW";
                case ThreadStandard.Tr: return "Tr";
                case ThreadStandard.S: return "S";
                case ThreadStandard.Rd: return "Rd";
                default: return "ANSI";
            }
        }

        // ---------- small vector helpers ----------
        private static double Dot(double[] a, double[] b) { return a[0] * b[0] + a[1] * b[1] + a[2] * b[2]; }
        private static double[] Sub(double[] a, double[] b) { return new[] { a[0] - b[0], a[1] - b[1], a[2] - b[2] }; }
        private static double[] Cross(double[] a, double[] b)
        {
            return new[] { a[1] * b[2] - a[2] * b[1], a[2] * b[0] - a[0] * b[2], a[0] * b[1] - a[1] * b[0] };
        }
        private static double[] Norm(double[] a)
        {
            double l = Math.Sqrt(Dot(a, a));
            return new[] { a[0] / l, a[1] / l, a[2] / l };
        }

        private static double[] CenterOf(Edge e)
        {
            switch (e.GeometryType)
            {
                case CurveTypeEnum.kCircleCurve:
                    {
                        Circle c = (Circle)e.Geometry;
                        return new[] { c.Center.X, c.Center.Y, c.Center.Z };
                    }
                case CurveTypeEnum.kCircularArcCurve:
                    {
                        Arc3d a = (Arc3d)e.Geometry;
                        return new[] { a.Center.X, a.Center.Y, a.Center.Z };
                    }
                default:
                    return null;
            }
        }

        // concave edge (shoulder / bottom): the neighbouring face looks along the direction into the cylinder
        private static bool IsShoulderEdge(Edge e, double[] dirIntoCyl, double cylRadius, bool external)
        {
            foreach (Face f in e.Faces)
            {
                if (f.SurfaceType == SurfaceTypeEnum.kPlaneSurface)
                {
                    Plane pl = (Plane)f.Geometry;
                    double[] nrm = { pl.Normal.X, pl.Normal.Y, pl.Normal.Z };
                    double sgn = f.IsParamReversed ? -1.0 : 1.0;   // outward normal of the face
                    return Dot(nrm, dirIntoCyl) * sgn > 0.5;
                }
                if (f.SurfaceType == SurfaceTypeEnum.kTorusSurface)
                {
                    Torus tor = (Torus)f.Geometry;   // fillet: concave if its centre circle is outside (shaft) / inside (hole)
                    return external ? tor.MajorRadius > cylRadius + 1e-4 : tor.MajorRadius < cylRadius - 1e-4;
                }
            }
            return false;
        }

        // ---------- analysis of the picked edge ----------
        public static ThreadTarget Analyze(Inventor.Application app, Edge edge)
        {
            Face cylFace = null;
            Face coneFace = null;
            foreach (Face f in edge.Faces)
            {
                if (f.SurfaceType == SurfaceTypeEnum.kCylinderSurface) { cylFace = f; break; }
                if (f.SurfaceType == SurfaceTypeEnum.kConeSurface) coneFace = f;
            }
            bool isConical = cylFace == null && coneFace != null;
            Face selectedFace = cylFace ?? coneFace;
            if (selectedFace == null)
                throw new InvalidOperationException("К выбранному круговому ребру должна примыкать цилиндрическая или коническая грань.");

            double[] c1 = CenterOf(edge);
            if (c1 == null)
                throw new InvalidOperationException("Выберите круговое ребро.");
            double[] axis;
            double radiusAtStart;
            if (isConical)
            {
                Cone cone = (Cone)coneFace.Geometry;
                axis = Norm(new[] { cone.AxisVector.X, cone.AxisVector.Y, cone.AxisVector.Z });
                double[] basePoint = { cone.BasePoint.X, cone.BasePoint.Y, cone.BasePoint.Z };
                double[] fromBase = Sub(c1, basePoint);
                double axialToBase = Dot(fromBase, axis);
                double[] radial = { fromBase[0] - axis[0] * axialToBase, fromBase[1] - axis[1] * axialToBase, fromBase[2] - axis[2] * axialToBase };
                radiusAtStart = Math.Sqrt(Dot(radial, radial));
                if (!double.IsFinite(radiusAtStart) || radiusAtStart <= 1e-6)
                    throw new InvalidOperationException("Не удалось определить радиус выбранного торца конуса.");
            }
            else
            {
                Cylinder cyl = (Cylinder)cylFace.Geometry;
                axis = Norm(new[] { cyl.AxisVector.X, cyl.AxisVector.Y, cyl.AxisVector.Z });
                double[] basePoint = { cyl.BasePoint.X, cyl.BasePoint.Y, cyl.BasePoint.Z };
                double[] fromBase = Sub(c1, basePoint);
                double axial = Dot(fromBase, axis);
                double[] radial = { fromBase[0] - axis[0] * axial, fromBase[1] - axis[1] * axial, fromBase[2] - axis[2] * axial };
                double axisOffset = Math.Sqrt(Dot(radial, radial));
                double axisTol = Math.Max(1e-5, cyl.Radius * 1e-5);
                if (axisOffset > axisTol)
                    throw new InvalidOperationException("Выбранное круговое ребро не лежит на оси цилиндрической поверхности.");
                radiusAtStart = cyl.Radius;
            }

            // far end of the face along the axis
            double signed = 0.0;
            foreach (Edge e in selectedFace.Edges)
            {
                double[] c = CenterOf(e);
                if (c == null) continue;
                double d = Dot(Sub(c, c1), axis);
                if (Math.Abs(d) > Math.Abs(signed)) signed = d;
            }
            if (Math.Abs(signed) < 1e-6)
            {
                // fallback: vertices of the face projected on the axis
                foreach (Vertex v in selectedFace.Vertices)
                {
                    double[] pv = { v.Point.X, v.Point.Y, v.Point.Z };
                    double d = Dot(Sub(pv, c1), axis);
                    if (Math.Abs(d) > Math.Abs(signed)) signed = d;
                }
            }
            if (Math.Abs(signed) < 1e-6)
                throw new InvalidOperationException("Не удалось определить осевую длину выбранной грани.");

            double sgn = signed >= 0 ? 1.0 : -1.0;
            var startEdges = new List<Edge>();
            var endEdges = new List<Edge>();
            foreach (Edge e in selectedFace.Edges)
            {
                double[] c = CenterOf(e);
                if (c == null) continue;
                double d = Dot(Sub(c, c1), axis);
                if (Math.Abs(d) < 1e-4) startEdges.Add(e);
                else if (Math.Abs(d - signed) < 1e-4) endEdges.Add(e);
            }
            bool isExt = selectedFace.IsParamReversed;
            PartDocument sourceDoc = null;
            string sourceDocInternalName = null;
            try
            {
                sourceDoc = app.ActiveDocument as PartDocument;
                if (sourceDoc != null) sourceDocInternalName = sourceDoc.InternalName;
            }
            catch { }
            double[] uDir = { axis[0] * sgn, axis[1] * sgn, axis[2] * sgn };
            double[] uBack = { -uDir[0], -uDir[1], -uDir[2] };
            bool startSh = !isConical && IsShoulderEdge(edge, uDir, radiusAtStart, isExt);
            bool endSh = !isConical && endEdges.Count > 0 && IsShoulderEdge(endEdges[0], uBack, radiusAtStart, isExt);
            SurfaceBody ownerBody = null;
            string ownerName = null;
            try { ownerBody = selectedFace.SurfaceBody; ownerName = ownerBody.Name; } catch { }
            return new ThreadTarget
            {
                Body = ownerBody,
                BodyName = ownerName,
                SourceDocument = sourceDoc,
                SourceDocumentInternalName = sourceDocInternalName,
                StartIsShoulder = startSh,
                EndIsShoulder = endSh,
                StartEdges = startEdges,
                EndEdges = endEdges,
                SelectedEdge = edge,
                SelectedFace = selectedFace,
                IsConical = isConical,
                NativeDirectionReversed = signed < 0.0,
                Center = c1,
                U = new[] { axis[0] * sgn, axis[1] * sgn, axis[2] * sgn },
                RadiusCm = radiusAtStart,
                LengthCm = Math.Abs(signed),
                // for cylinders Inventor reports IsParamReversed = true on a shaft (convex) and false on a hole
                IsExternal = selectedFace.IsParamReversed
            };
        }

        private static void AttachNativeTaperedMetadata(ThreadParams parameters, ThreadTarget target, string threadIdOverride)
        {
            LastMetadataAttachSucceeded = false;
            LastMetadataStatus = null;
            ThreadFeature feature = NativeTaperedThreadBuilder.LastCreatedFeature;
            List<object> objects = NativeTaperedThreadBuilder.LastCreatedObjects;
            if (feature == null || objects == null || objects.Count < 4)
            {
                LastMetadataStatus = "Нативная коническая группа неполна: не найдены все объекты подготовки поверхности и ThreadFeature.";
                throw new InvalidOperationException(LastMetadataStatus + " Построение будет отменено, чтобы не оставить непригодную для редактирования геометрию.");
            }
            string threadId, error;
            if (ThreadMetadataStore.TryAttach(objects, parameters, target, out threadId, out error, threadIdOverride))
            {
                LastMetadataAttachSucceeded = true;
                LastMetadataStatus = "Метаданные конической группы сохранены (ID " + threadId + "; объектов " + objects.Count + ").";
            }
            else
            {
                LastMetadataAttachSucceeded = false;
                LastMetadataStatus = "Не удалось сохранить метаданные конической группы: " + error;
                throw new InvalidOperationException(LastMetadataStatus + " Транзакция будет отменена, чтобы не оставить неуправляемый конус.");
            }
        }

        // ---------- profile path with fillets (2D, coordinates: a = axial, D = depth) ----------
        private sealed class Piece { public bool Arc; public double[] P0, Pm, P1; }

        private static double Dist2(double[] a, double[] b)
        {
            return Math.Sqrt((b[0] - a[0]) * (b[0] - a[0]) + (b[1] - a[1]) * (b[1] - a[1]));
        }

        private static double[] Unit2(double[] a, double[] b)
        {
            double l = Dist2(a, b);
            return new[] { (b[0] - a[0]) / l, (b[1] - a[1]) / l };
        }

        /// <summary>Closed polygon -> lines and arcs. radius[k] is the requested fillet radius at vertex k
        /// (clamped so that the tangent lengths fit on the adjacent edges).</summary>
        private static List<Piece> RoundedPath(List<double[]> v, double[] radius)
        {
            int n = v.Count;
            double[] r = (double[])radius.Clone();
            double[] f = new double[n];        // tangent length per unit radius
            double[] sh = new double[n];       // sin(phi/2)
            for (int k = 0; k < n; k++)
            {
                double[] e1 = Unit2(v[k], v[(k + n - 1) % n]);
                double[] e2 = Unit2(v[k], v[(k + 1) % n]);
                double c = Math.Max(-1.0, Math.Min(1.0, e1[0] * e2[0] + e1[1] * e2[1]));
                double phi = Math.Acos(c);
                f[k] = 1.0 / Math.Tan(phi / 2.0);
                sh[k] = Math.Sin(phi / 2.0);
            }
            for (int iter = 0; iter < 8; iter++)
                for (int k = 0; k < n; k++)
                {
                    int m = (k + 1) % n;
                    double L = Dist2(v[k], v[m]);
                    double ta = r[k] * f[k], tb = r[m] * f[m];
                    if (ta + tb > L * (1.0 + 1e-9))
                    {
                        double sc = L / (ta + tb);
                        r[k] *= sc; r[m] *= sc;
                    }
                }

            var pieces = new List<Piece>();
            const double minLen = 2e-3;   // cm: shorter lines are dropped (pieces are chained anyway)
            Action<double[], double[]> addLine = (a, b) =>
            {
                if (Dist2(a, b) > minLen) pieces.Add(new Piece { Arc = false, P0 = a, P1 = b });
            };

            double[] cur = null, start = null;
            for (int k = 0; k < n; k++)
            {
                double[] V = v[k];
                if (r[k] > 1e-9)
                {
                    double[] e1 = Unit2(V, v[(k + n - 1) % n]);
                    double[] e2 = Unit2(V, v[(k + 1) % n]);
                    double t = r[k] * f[k];
                    double[] t1 = { V[0] + e1[0] * t, V[1] + e1[1] * t };
                    double[] t2 = { V[0] + e2[0] * t, V[1] + e2[1] * t };
                    double bx = e1[0] + e2[0], by = e1[1] + e2[1];
                    double bl = Math.Sqrt(bx * bx + by * by);
                    bx /= bl; by /= bl;
                    double dc = r[k] / sh[k];
                    double[] ctr = { V[0] + bx * dc, V[1] + by * dc };
                    double[] mid = { ctr[0] - bx * r[k], ctr[1] - by * r[k] };
                    if (cur == null) { start = t1; cur = t1; }
                    addLine(cur, t1);
                    pieces.Add(new Piece { Arc = true, P0 = t1, Pm = mid, P1 = t2 });
                    cur = t2;
                }
                else
                {
                    if (cur == null) { start = V; cur = V; }
                    else addLine(cur, V);
                    cur = V;
                }
            }
            addLine(cur, start);

            // two arcs of the same circle that meet at one point (flat fully consumed) -> one arc through the joint
            for (int i = 0; i + 1 < pieces.Count; i++)
            {
                Piece pa = pieces[i], pb = pieces[i + 1];
                if (pa.Arc && pb.Arc && Dist2(pa.P1, pb.P0) < 1e-6)
                {
                    pieces[i] = new Piece { Arc = true, P0 = pa.P0, Pm = pa.P1, P1 = pb.P1 };
                    pieces.RemoveAt(i + 1);
                    i--;
                }
            }
            return pieces;
        }

        // Resolve the body after earlier modeling operations.  Edge references can become stale,
        // but the body name remains stable inside a PartDocument.
        private static SurfaceBody OwnedBody(PartComponentDefinition def, ThreadTarget t)
        {
            try
            {
                if (!string.IsNullOrEmpty(t.BodyName))
                    foreach (SurfaceBody sb in def.SurfaceBodies)
                        if (sb.Name == t.BodyName) return sb;
            }
            catch { }

            try { return t.Body; } catch { return null; }
        }

        // Circular edges of coaxial cylinders of the given radius at the given axial position (cm).
        // Search only the body that owns the selected surface; otherwise a multi-body part can
        // accidentally contribute a coincident edge from another solid.
        private static void FindCircularEdges(PartComponentDefinition def, ThreadTarget t, double radius, double axialPos, List<Edge> result)
        {
            double[] u = t.U;
            SurfaceBody owner = OwnedBody(def, t);
            if (owner == null) return;
            IEnumerable<SurfaceBody> bodies = new[] { owner };

            foreach (SurfaceBody sb in bodies)
                foreach (Face f in sb.Faces)
                {
                    if (f.SurfaceType != SurfaceTypeEnum.kCylinderSurface) continue;
                    Cylinder cyl = (Cylinder)f.Geometry;
                    if (Math.Abs(cyl.Radius - radius) > 1e-4) continue;
                    foreach (Edge e in f.Edges)
                    {
                        double[] c = CenterOf(e);
                        if (c == null) continue;
                        double[] d = Sub(c, t.Center);
                        double z = Dot(d, u);
                        double[] perp = { d[0] - u[0] * z, d[1] - u[1] * z, d[2] - u[2] * z };
                        if (Math.Sqrt(Dot(perp, perp)) > 1e-4) continue;   // not on the axis
                        if (Math.Abs(z - axialPos) < 1e-4) result.Add(e);
                    }
                }
        }

        // ---------- Inventor 2027 browser-folder support ----------
        // Inventor 2027 supports creating a PartFeatureFolder with the BrowserNodes
        // option. Prefer this single batch operation: BrowserFolder.Add rebuilds/reorders
        // the tree for every node and was measured at 20.6 seconds for 42 run-out nodes.
        // The final folder position is restored with BrowserPane.Reorder. If the batch
        // API rejects the collection, a measured per-node fallback remains available.
        private static BrowserPane GetPartModelBrowser(PartDocument doc)
        {
            if (doc == null) return null;
            try
            {
                BrowserPane active = doc.BrowserPanes.ActivePane;
                if (active != null && active.TreeBrowser) return active;
            }
            catch { }

            // The C# Inventor 2027 interop used by this project does not expose
            // BrowserPanes.Item(...). Fall back to enumerating the collection.
            try
            {
                foreach (BrowserPane pane in doc.BrowserPanes)
                {
                    if (pane != null && pane.TreeBrowser) return pane;
                }
            }
            catch { }

            return null;
        }

        private static BrowserNode LastTopLevelNodeBeforeEop(BrowserPane pane)
        {
            if (pane == null || pane.TopNode == null) return null;
            BrowserNode last = null;
            try
            {
                foreach (BrowserNode node in pane.TopNode.BrowserNodes)
                {
                    object native = null;
                    try { native = node.NativeObject; } catch { }
                    if (native is EndOfFeatures) break;
                    last = node;
                }
            }
            catch { }
            return last;
        }

        private static string UniqueThreadFolderName(BrowserNode topNode, string baseName)
        {
            if (topNode == null) return baseName;
            try
            {
                bool exists = false;
                int max = 1;
                string prefix = baseName + " #";
                foreach (BrowserFolder folder in topNode.BrowserFolders)
                {
                    string n = folder.Name ?? string.Empty;
                    if (string.Equals(n, baseName, StringComparison.OrdinalIgnoreCase))
                        exists = true;
                    else if (n.StartsWith(prefix, StringComparison.OrdinalIgnoreCase))
                    {
                        int k;
                        if (int.TryParse(n.Substring(prefix.Length), out k))
                            max = Math.Max(max, k);
                    }
                }
                return exists ? baseName + " #" + (max + 1).ToString() : baseName;
            }
            catch
            {
                return baseName;
            }
        }

        private static ObjectCollection CollectCreatedTopLevelBrowserNodes(Inventor.Application app, PartDocument doc, BrowserPane pane,
            IList<object> created, out long snapshotMs, out long fallbackLookupMs)
        {
            snapshotMs = 0;
            fallbackLookupMs = 0;
            if (app == null || doc == null || pane == null || created == null || created.Count == 0) return null;

            // Resolve the created Inventor objects to top-level BrowserNodes before creating the folder.
            // New features created inside the same transaction may not yet be represented in the
            // cached tree (most often noticed in tapered edit/rebuild). Update the model and browser
            // view before asking GetBrowserNodeFromObject; do not loosen the requirement that every
            // top-level feature must be grouped before the transaction can commit.
            try { doc.Update(); } catch { }
            try { pane.Update(); } catch { }
            // Inventor 2027 accepts an ObjectCollection of nodes in AddBrowserFolderWithOptions, allowing
            // the folder and its contents to be grouped in one native operation instead of 40+ folder.Add calls.
            var snapshotTimer = Stopwatch.StartNew();
            BrowserNode topNode = pane.TopNode;
            var nativeObjectNodes = new List<KeyValuePair<object, BrowserNode>>();
            var browserOrder = new List<BrowserNode>();
            try
            {
                foreach (BrowserNode node in topNode.BrowserNodes)
                {
                    if (node == null) continue;
                    browserOrder.Add(node);
                    object native = null;
                    try { native = node.NativeObject; } catch { }
                    if (native != null && !nativeObjectNodes.Any(entry => SameBrowserComObject(entry.Key, native)))
                        nativeObjectNodes.Add(new KeyValuePair<object, BrowserNode>(native, node));
                }
            }
            catch { }
            snapshotTimer.Stop();
            snapshotMs = snapshotTimer.ElapsedMilliseconds;

            // Match BrowserNode.NativeObject to the originally-created RCW by COM identity first;
            // Inventor may expose two managed wrappers for the same native object. Fall back to
            // GetBrowserNodeFromObject only if the browser snapshot cannot resolve that identity.
            var resolved = new List<BrowserNode>();
            for (int i = 0; i < created.Count; i++)
            {
                object obj = created[i];
                if (obj == null) continue;
                BrowserNode node = null;
                for (int nativeIndex = 0; nativeIndex < nativeObjectNodes.Count; nativeIndex++)
                {
                    if (SameBrowserComObject(nativeObjectNodes[nativeIndex].Key, obj))
                    {
                        node = nativeObjectNodes[nativeIndex].Value;
                        break;
                    }
                }
                if (node == null)
                {
                    var lookupTimer = Stopwatch.StartNew();
                    try { node = pane.GetBrowserNodeFromObject(obj); }
                    catch { node = null; }
                    lookupTimer.Stop();
                    fallbackLookupMs += lookupTimer.ElapsedMilliseconds;
                    if (node == null) continue;

                    // A helper object nested below its owning feature is captured with that owner.
                    // Only a genuinely top-level BrowserNode can be independently moved.
                    try
                    {
                        object parentObject = node.Parent;
                        BrowserNode parent = parentObject as BrowserNode;
                        if (parent != null && !SameBrowserComObject(parent, topNode)) continue;
                    }
                    catch { continue; }
                }

                if (node != null && !resolved.Any(existing => SameBrowserComObject(existing, node)))
                    resolved.Add(node);
            }

            // Preserve existing browser order while comparing COM identity, not wrapper identity.
            // Any nodes absent from the snapshot stay at the end in the order discovered above.
            var remaining = new List<BrowserNode>(resolved);
            var ordered = new List<BrowserNode>();
            foreach (BrowserNode browserNode in browserOrder)
            {
                int match = remaining.FindIndex(candidate => SameBrowserComObject(candidate, browserNode));
                if (match >= 0)
                {
                    ordered.Add(remaining[match]);
                    remaining.RemoveAt(match);
                }
            }
            ordered.AddRange(remaining);

            ObjectCollection result = app.TransientObjects.CreateObjectCollection();
            foreach (BrowserNode node in ordered) result.Add(node);
            return result;
        }

        internal static bool SameBrowserComObject(object first, object second)
        {
            if (object.ReferenceEquals(first, second)) return true;
            if (first == null || second == null) return false;
            try { if (first.Equals(second)) return true; } catch { }
            try { if (object.Equals(first, second)) return true; } catch { }

            // Some Inventor BrowserNode properties hand back different managed wrappers for one
            // native COM object. Compare canonical IUnknown identity as a final fallback. Balance
            // both AddRef operations from GetIUnknownForObject even when the second lookup fails.
            IntPtr firstIdentity = IntPtr.Zero;
            IntPtr secondIdentity = IntPtr.Zero;
            try
            {
                firstIdentity = Marshal.GetIUnknownForObject(first);
                secondIdentity = Marshal.GetIUnknownForObject(second);
                return firstIdentity == secondIdentity;
            }
            catch { }
            finally
            {
                if (secondIdentity != IntPtr.Zero) Marshal.Release(secondIdentity);
                if (firstIdentity != IntPtr.Zero) Marshal.Release(firstIdentity);
            }
            return false;
        }

        // Inventor 2027 part-feature folders can expose more than one BrowserNode for the
        // same NativeObject: GetBrowserNodeFromObject returns only the first match, which may
        // be the normal feature-history node rather than the displayed node inside a folder.
        // Therefore folder ownership during tapered edit is resolved from the rendered tree walk,
        // correlating each node's NativeObject and its actual tree path. Do not infer membership
        // solely from GetBrowserNodeFromObject(...).Parent.
        private sealed class BrowserTreeOccurrence
        {
            internal BrowserNode Node;
            internal object NativeObject;
            internal List<BrowserNode> Ancestors;
            internal string Path;
        }

        private const int FolderRepairMaxTreeDepth = 16;
        private const int FolderRepairMaxTreeNodes = 5000;

        private static void CollectBrowserTreeOccurrences(BrowserNode parent, string path,
            List<BrowserNode> ancestors, int depth, List<BrowserTreeOccurrence> occurrences,
            ref int visited, ref bool truncated)
        {
            if (parent == null) return;
            if (depth > FolderRepairMaxTreeDepth || visited >= FolderRepairMaxTreeNodes)
            {
                truncated = true;
                return;
            }

            try
            {
                int index = 0;
                foreach (BrowserNode child in parent.BrowserNodes)
                {
                    if (child == null) continue;
                    index++;
                    if (visited >= FolderRepairMaxTreeNodes)
                    {
                        truncated = true;
                        return;
                    }
                    visited++;

                    object native = null;
                    try { native = child.NativeObject; } catch { }
                    occurrences.Add(new BrowserTreeOccurrence
                    {
                        Node = child,
                        NativeObject = native,
                        Ancestors = new List<BrowserNode>(ancestors),
                        Path = path + "/" + index.ToString()
                    });

                    if (depth < FolderRepairMaxTreeDepth)
                    {
                        var childAncestors = new List<BrowserNode>(ancestors) { child };
                        CollectBrowserTreeOccurrences(child, path + "/" + index.ToString(),
                            childAncestors, depth + 1, occurrences, ref visited, ref truncated);
                        if (truncated) return;
                    }
                }
            }
            catch
            {
                // A branch that cannot be enumerated makes the tree snapshot incomplete. The
                // caller will fail closed if an existing folder was partially identified.
                truncated = true;
            }
        }

        private static List<BrowserTreeOccurrence> SnapshotBrowserTree(BrowserNode topNode, out bool truncated)
        {
            var occurrences = new List<BrowserTreeOccurrence>();
            truncated = false;
            if (topNode == null)
            {
                truncated = true;
                return occurrences;
            }

            int visited = 0;
            CollectBrowserTreeOccurrences(topNode, "TopNode", new List<BrowserNode> { topNode },
                0, occurrences, ref visited, ref truncated);
            return occurrences;
        }

        private static string GetBrowserNodeNativeName(BrowserNode node)
        {
            if (node == null) return string.Empty;
            try
            {
                object native = node.NativeObject;
                if (native == null) return string.Empty;
                dynamic dynamicNative = native;
                object name = dynamicNative.Name;
                return Convert.ToString(name) ?? string.Empty;
            }
            catch { return string.Empty; }
        }

        private static string GetBrowserNodeNativeNameFromObject(object nativeObject)
        {
            if (nativeObject == null) return string.Empty;
            try
            {
                dynamic dynamicObject = nativeObject;
                object name = dynamicObject.Name;
                return Convert.ToString(name) ?? string.Empty;
            }
            catch { return string.Empty; }
        }

        private static bool IsHelivantaThreadFolder(BrowserFolder folder)
        {
            if (folder == null) return false;
            try
            {
                return folder.PartFeatureFolder &&
                    (folder.Name ?? string.Empty).StartsWith("Резьба — ", StringComparison.OrdinalIgnoreCase);
            }
            catch { return false; }
        }

        private static List<BrowserFolder> GetRootHelivantaThreadFolders(BrowserNode topNode,
            out bool enumerationComplete, out string enumerationError)
        {
            var folders = new List<BrowserFolder>();
            enumerationComplete = topNode != null;
            enumerationError = null;
            if (topNode == null)
            {
                enumerationComplete = false;
                enumerationError = "TopNode is null";
                return folders;
            }
            try
            {
                foreach (BrowserFolder folder in topNode.BrowserFolders)
                {
                    if (!IsHelivantaThreadFolder(folder)) continue;
                    if (!folders.Any(existing => SameBrowserComObject(existing, folder)))
                        folders.Add(folder);
                }
            }
            catch (Exception ex)
            {
                enumerationComplete = false;
                enumerationError = ex.GetType().Name + ": " + ex.Message;
            }
            return folders;
        }

        private static string DescribeRootThreadFolderInventory(BrowserNode topNode)
        {
            if (topNode == null) return "<TopNode unavailable>";
            var descriptions = new List<string>();
            try
            {
                foreach (BrowserFolder folder in topNode.BrowserFolders)
                {
                    if (folder == null) continue;
                    string name = "<name unavailable>";
                    string partFeatureFolder = "<unavailable>";
                    try { name = folder.Name ?? string.Empty; } catch { }
                    try { partFeatureFolder = folder.PartFeatureFolder.ToString(); } catch { }
                    BrowserNode folderNode = null;
                    try { folderNode = folder.BrowserNode; } catch { }
                    descriptions.Add("name=\"" + name + "\"; PartFeatureFolder=" + partFeatureFolder +
                        "; folderNodeNativeName=\"" + GetBrowserNodeNativeName(folderNode) + "\"");
                }
            }
            catch (Exception ex)
            {
                descriptions.Add("enumerationError=" + ex.GetType().Name + ": " + ex.Message);
            }
            return descriptions.Count == 0 ? "<no BrowserFolders returned>" : string.Join(" | ", descriptions);
        }

        private static bool BrowserNodeRepresentsFolder(BrowserNode treeNode, BrowserFolder folder)
        {
            if (treeNode == null || folder == null) return false;
            BrowserNode folderNode = null;
            try { folderNode = folder.BrowserNode; } catch { }
            if (folderNode != null && SameBrowserComObject(treeNode, folderNode)) return true;

            object treeNative = null;
            object folderNative = null;
            try { treeNative = treeNode.NativeObject; } catch { }
            try { if (folderNode != null) folderNative = folderNode.NativeObject; } catch { }
            if (treeNative != null && folderNative != null && SameBrowserComObject(treeNative, folderNative))
                return true;

            // Inventor's folder display node can be a different BrowserNode wrapper than the
            // object exposed by BrowserFolder.BrowserNode. The root-level label is a final
            // disambiguator, but only against a real PartFeatureFolder returned by TopNode.
            string folderName = string.Empty;
            try { folderName = folder.Name ?? string.Empty; } catch { }
            return !string.IsNullOrWhiteSpace(folderName) &&
                folderName.StartsWith("Резьба — ", StringComparison.OrdinalIgnoreCase) &&
                string.Equals(GetBrowserNodeNativeName(treeNode), folderName, StringComparison.OrdinalIgnoreCase);
        }

        private static List<BrowserFolder> GetThreadFolderOwners(BrowserTreeOccurrence occurrence,
            IList<BrowserFolder> threadFolders)
        {
            var owners = new List<BrowserFolder>();
            if (occurrence == null || occurrence.Ancestors == null || occurrence.Ancestors.Count < 2 ||
                threadFolders == null) return owners;

            // Ancestors[0] is TopNode; Ancestors[1] is the visible root branch. Search all
            // ancestors as a defensive allowance for browser implementations that wrap folders.
            for (int ancestorIndex = 1; ancestorIndex < occurrence.Ancestors.Count; ancestorIndex++)
            {
                BrowserNode ancestor = occurrence.Ancestors[ancestorIndex];
                foreach (BrowserFolder folder in threadFolders)
                {
                    if (!BrowserNodeRepresentsFolder(ancestor, folder)) continue;
                    if (!owners.Any(existing => SameBrowserComObject(existing, folder)))
                        owners.Add(folder);
                }
            }
            return owners;
        }

        private static List<BrowserTreeOccurrence> FindTreeOccurrencesForObject(
            IList<BrowserTreeOccurrence> occurrences, object nativeObject)
        {
            var matches = new List<BrowserTreeOccurrence>();
            if (occurrences == null || nativeObject == null) return matches;
            foreach (BrowserTreeOccurrence occurrence in occurrences)
            {
                if (occurrence != null && occurrence.NativeObject != null &&
                    SameBrowserComObject(occurrence.NativeObject, nativeObject))
                    matches.Add(occurrence);
            }
            return matches;
        }

        private static bool OccurrenceIsInsideFolder(BrowserTreeOccurrence occurrence, BrowserFolder folder)
        {
            List<BrowserFolder> owners = GetThreadFolderOwners(occurrence, new List<BrowserFolder> { folder });
            return owners.Any(owner => SameBrowserComObject(owner, folder));
        }

        // During tapered edit, Inventor may already display the replacement operations in the
        // surviving PartFeatureFolder. GetBrowserNodeFromObject can return the first logical
        // feature-history node instead of that folder's display occurrence, so Parent-based
        // ownership checks are not reliable here. Walk the actual tree and match NativeObject
        // identity. If the full replacement is already under the preserved folder, reuse it
        // without re-grouping or another Update/Refresh. If only some operations are present,
        // move only nodes proven to be direct TopNode children; ambiguous states abort.
        private static bool TryRepairSharedExistingTaperedFolder(Inventor.Application app, PartDocument doc,
            BrowserPane pane, IList<object> created, out BrowserFolder sharedFolder, out string detail,
            out bool repairMustAbortOnFailure)
        {
            sharedFolder = null;
            detail = null;
            repairMustAbortOnFailure = false;
            if (app == null || doc == null || pane == null || pane.TopNode == null || created == null) return false;

            var createdPartFeatures = created.Where(item => item is PartFeature).ToList();
            if (createdPartFeatures.Count == 0)
            {
                detail = "в списке новых объектов нет PartFeature";
                return false;
            }

            BrowserNode topNode = pane.TopNode;
            bool folderEnumerationComplete;
            string folderEnumerationError;
            List<BrowserFolder> threadFolders = GetRootHelivantaThreadFolders(topNode,
                out folderEnumerationComplete, out folderEnumerationError);
            if (!folderEnumerationComplete)
            {
                detail = "не удалось полностью перечислить BrowserFolders TopNode: " +
                    (folderEnumerationError ?? "ошибка не определена") + "; видимые папки=" +
                    DescribeRootThreadFolderInventory(topNode);
                repairMustAbortOnFailure = true;
                BrowserTreeDiagnostics.WriteEvent("ThreadBuilder", "tapered-folder-reuse-folder-enumeration-failed", detail);
                return false;
            }
            if (threadFolders.Count == 0)
            {
                detail = "в TopNode нет существующей папки PartFeatureFolder с именем Helivanta «Резьба — …»; BrowserFolders=" +
                    DescribeRootThreadFolderInventory(topNode);
                BrowserTreeDiagnostics.WriteEvent("ThreadBuilder", "tapered-folder-reuse-no-root-folder", detail);
                return false;
            }

            bool truncated;
            List<BrowserTreeOccurrence> occurrences = SnapshotBrowserTree(topNode, out truncated);
            if (truncated)
            {
                detail = "полный обход дерева обрезан или одна из ветвей недоступна; принадлежность существующей папке не доказана";
                repairMustAbortOnFailure = true;
                return false;
            }

            BrowserFolder candidate = null;
            int partFeaturesInFolder = 0;
            int topLevelPartFeatures = 0;
            string unresolvedPartFeature = null;
            var topLevelNodesToMove = new List<BrowserNode>();
            var partFeatureTrace = new List<string>();
            for (int i = 0; i < createdPartFeatures.Count; i++)
            {
                object partFeature = createdPartFeatures[i];
                string featureName = GetBrowserNodeNativeNameFromObject(partFeature);
                List<BrowserTreeOccurrence> matches = FindTreeOccurrencesForObject(occurrences, partFeature);
                if (matches.Count == 0)
                {
                    if (unresolvedPartFeature == null)
                        unresolvedPartFeature = "в полном обходе дерева нет BrowserNode.NativeObject для PartFeature " +
                            (i + 1) + "/" + createdPartFeatures.Count + " (" + featureName + ")";
                    partFeatureTrace.Add("PF[" + (i + 1) + "] name=\"" + featureName + "\"; occurrences=0");
                    continue;
                }

                var owners = new List<BrowserFolder>();
                foreach (BrowserTreeOccurrence occurrence in matches)
                {
                    foreach (BrowserFolder owner in GetThreadFolderOwners(occurrence, threadFolders))
                    {
                        if (!owners.Any(existing => SameBrowserComObject(existing, owner))) owners.Add(owner);
                    }
                }
                partFeatureTrace.Add("PF[" + (i + 1) + "] name=\"" + featureName + "\"; paths=" +
                    string.Join(",", matches.Select(match => match.Path)) + "; ownerCount=" + owners.Count +
                    (owners.Count == 0 ? string.Empty : "; ownerNames=" + string.Join(",", owners.Select(owner => owner.Name))));

                if (owners.Count > 1)
                {
                    detail = "одна новая PartFeature визуально присутствует в нескольких папках резьбы; " +
                        "feature=" + featureName + "; paths=" + string.Join(",", matches.Select(match => match.Path));
                    repairMustAbortOnFailure = true;
                    BrowserTreeDiagnostics.WriteEvent("ThreadBuilder", "tapered-folder-reuse-ambiguous-owner",
                        detail + "; BrowserFolders=" + DescribeRootThreadFolderInventory(topNode));
                    return false;
                }

                if (owners.Count == 1)
                {
                    if (candidate == null) candidate = owners[0];
                    else if (!SameBrowserComObject(candidate, owners[0]))
                    {
                        detail = "новые PartFeature отображаются в разных папках резьбы; feature=" + featureName +
                            "; owner=" + owners[0].Name + "; candidate=" + candidate.Name;
                        repairMustAbortOnFailure = true;
                        BrowserTreeDiagnostics.WriteEvent("ThreadBuilder", "tapered-folder-reuse-multiple-owners",
                            detail + "; BrowserFolders=" + DescribeRootThreadFolderInventory(topNode));
                        return false;
                    }
                    partFeaturesInFolder++;
                    continue;
                }

                // No occurrence is inside a thread folder. Only an actual direct child of
                // TopNode is independently movable. A nested or ambiguous node is remembered;
                // continue the scan so a later feature can still reveal the shared folder.
                BrowserTreeOccurrence topLevel = matches.FirstOrDefault(match =>
                    match.Ancestors != null && match.Ancestors.Count == 1);
                if (topLevel == null)
                {
                    if (unresolvedPartFeature == null)
                        unresolvedPartFeature = "PartFeature " + (i + 1) + "/" + createdPartFeatures.Count +
                            " (" + featureName + ") не найдена внутри общей папки и не является непосредственным ребёнком TopNode";
                    continue;
                }
                topLevelPartFeatures++;
                if (!topLevelNodesToMove.Any(existing => SameBrowserComObject(existing, topLevel.Node)))
                    topLevelNodesToMove.Add(topLevel.Node);
            }

            if (candidate == null || partFeaturesInFolder == 0)
            {
                detail = "полный обход дерева не обнаружил новые PartFeature внутри существующей папки резьбы; " +
                    "PartFeature=" + createdPartFeatures.Count + "; unresolved=" +
                    (unresolvedPartFeature ?? "нет") + "; BrowserFolders=" + DescribeRootThreadFolderInventory(topNode);
                BrowserTreeDiagnostics.WriteEvent("ThreadBuilder", "tapered-folder-reuse-no-candidate",
                    detail + "; trace=" + string.Join(" || ", partFeatureTrace));
                return false;
            }

            repairMustAbortOnFailure = true;
            if (unresolvedPartFeature != null)
            {
                detail = "общая папка «" + candidate.Name + "» найдена, но владение одной или нескольких PartFeature не определено: " +
                    unresolvedPartFeature + "; trace=" + string.Join(" || ", partFeatureTrace);
                BrowserTreeDiagnostics.WriteEvent("ThreadBuilder", "tapered-folder-reuse-unresolved-feature",
                    detail + "; BrowserFolders=" + DescribeRootThreadFolderInventory(topNode));
                return false;
            }

            string candidateName = string.Empty;
            try { candidateName = candidate.Name ?? string.Empty; } catch { }
            if (!IsHelivantaThreadFolder(candidate) || string.IsNullOrWhiteSpace(candidateName))
            {
                detail = "найденный владелец не является корневой папкой резьбы Helivanta";
                return false;
            }

            // Determine membership from the occurrence tree, not from the first node returned
            // by GetBrowserNodeFromObject. Any visible object not already in this folder may be
            // moved only if it has a confirmed direct TopNode occurrence.
            int visibleCreatedObjects = 0;
            int visibleObjectsAlreadyInFolder = 0;
            int invisibleCreatedObjects = 0;
            for (int i = 0; i < created.Count; i++)
            {
                object createdObject = created[i];
                List<BrowserTreeOccurrence> matches = FindTreeOccurrencesForObject(occurrences, createdObject);
                if (matches.Count == 0)
                {
                    invisibleCreatedObjects++;
                    continue;
                }
                visibleCreatedObjects++;
                if (matches.Any(match => OccurrenceIsInsideFolder(match, candidate)))
                {
                    visibleObjectsAlreadyInFolder++;
                    continue;
                }

                BrowserTreeOccurrence topLevel = matches.FirstOrDefault(match =>
                    match.Ancestors != null && match.Ancestors.Count == 1);
                if (topLevel == null)
                {
                    detail = "видимый объект новой группы «" + GetBrowserNodeNativeName(matches[0].Node) +
                        "» не находится в сохраняемой папке и не является непосредственным ребёнком TopNode; path=" +
                        matches[0].Path + "; BrowserFolders=" + DescribeRootThreadFolderInventory(topNode);
                    BrowserTreeDiagnostics.WriteEvent("ThreadBuilder", "tapered-folder-reuse-unmapped-visible-object", detail);
                    return false;
                }
                if (!topLevelNodesToMove.Any(existing => SameBrowserComObject(existing, topLevel.Node)))
                    topLevelNodesToMove.Add(topLevel.Node);
            }

            int movedNodes = 0;
            // Folder.Add can reorder/rebuild the tree. Use the already captured direct TopNode
            // occurrences in reverse order. Successful API return is the move result; avoid a
            // second Parent/Update-based membership test that is known to select another node.
            for (int i = topLevelNodesToMove.Count - 1; i >= 0; i--)
            {
                BrowserNode node = topLevelNodesToMove[i];
                try
                {
                    candidate.Add(node);
                    movedNodes++;
                }
                catch (Exception addEx)
                {
                    detail = "перенос в существующую папку оборвался после " + movedNodes + " узлов: " + addEx.Message;
                    repairMustAbortOnFailure = true;
                    BrowserTreeDiagnostics.WriteSnapshot("ThreadBuilder", "tapered-folder-tree-repair-add-failed",
                        doc, pane, created, "folder=" + candidateName + "; moved=" + movedNodes + "; exception=" + addEx);
                    return false;
                }
            }

            sharedFolder = candidate;
            detail = "сохранена существующая папка «" + candidateName + "»: PartFeature в ней=" +
                partFeaturesInFolder + "/" + createdPartFeatures.Count + ", PartFeature на TopNode=" +
                topLevelPartFeatures + ", видимых объектов группы=" + visibleCreatedObjects +
                ", уже в папке=" + visibleObjectsAlreadyInFolder + ", без BrowserNode=" +
                invisibleCreatedObjects + ", перенесено корневых узлов=" + movedNodes +
                "; владельцы определены обходом дерева, без повторного Update/Refresh и без повторной группировки.";
            BrowserTreeDiagnostics.WriteEvent("ThreadBuilder", "tapered-folder-tree-reuse",
                "folder=" + candidateName + "; partFeatures=" + partFeaturesInFolder + "/" + createdPartFeatures.Count +
                "; visibleObjects=" + visibleCreatedObjects + "; inFolder=" + visibleObjectsAlreadyInFolder +
                "; invisible=" + invisibleCreatedObjects + "; movedTopLevelNodes=" + movedNodes +
                "; BrowserFolders=" + DescribeRootThreadFolderInventory(topNode) +
                "; partFeatureTrace=" + string.Join(" || ", partFeatureTrace));
            return true;
        }

        private static BrowserFolder FindBrowserFolderByName(BrowserNode topNode, string name)
        {
            if (topNode == null || string.IsNullOrWhiteSpace(name)) return null;
            try
            {
                foreach (BrowserFolder candidate in topNode.BrowserFolders)
                    if (candidate != null && string.Equals(candidate.Name, name, StringComparison.OrdinalIgnoreCase))
                        return candidate;
            }
            catch { }
            return null;
        }

        private static BrowserNode CreateNamedBrowserFolder(Inventor.Application app, PartDocument doc, BrowserPane pane,
                                                            BrowserNode anchorBeforeFolder, IList<object> created,
                                                            string baseName, bool collapseAfterCreate,
                                                            bool exposeHistoryForMapping = false)
        {
            if (doc == null || pane == null || created == null || created.Count == 0) return null;
            var totalTimer = Stopwatch.StartNew();
            long topNodeMs = 0, uniqueNameMs = 0, createAndGroupMs = 0, setEopMs = 0;
            long snapshotMs = 0, fallbackLookupMs = 0, fallbackAddMs = 0, folderNodeMs = 0, reorderMs = 0;
            int addedCount = 0;
            string groupingMode = "batch BrowserNodes";
            string fallbackReason = "";
            string editFolderReuseFailure = null;
            bool abortOnPartialGrouping = false;
            string name = baseName;
            BrowserNode topNode = null;
            try
            {
                var topNodeTimer = Stopwatch.StartNew();
                topNode = pane.TopNode;
                topNodeTimer.Stop();
                topNodeMs = topNodeTimer.ElapsedMilliseconds;

                var uniqueNameTimer = Stopwatch.StartNew();
                name = UniqueThreadFolderName(topNode, baseName);
                uniqueNameTimer.Stop();
                uniqueNameMs = uniqueNameTimer.ElapsedMilliseconds;

                // During tapered replacement, ThreadEditService deliberately moves End-of-Part
                // before the old group. Inventor can leave newly-created feature BrowserNodes out
                // of the cached tree until the full feature history is exposed. Reveal the history
                // inside the same transaction before mapping/grouping; ThreadEditService restores
                // the user's original marker after the replacement group is complete.
                if (exposeHistoryForMapping)
                {
                    try { doc.ComponentDefinition.SetEndOfPartToTopOrBottom(false); }
                    catch (Exception eopEx)
                    {
                        throw new InvalidOperationException("Не удалось временно открыть историю построений для группировки новой конической резьбы: " + eopEx.Message, eopEx);
                    }
                    bool updateOk = doc.Update2(true);
                    if (!updateOk)
                        throw new InvalidOperationException("Inventor не смог перестроить открытую историю перед группировкой конической резьбы.");
                    try { pane.Refresh(); } catch { }
                    try { pane.Update(); } catch { }
                }

                if (exposeHistoryForMapping)
                {
                    BrowserFolder inheritedFolder;
                    string reuseDetail;
                    bool repairMustAbortOnFailure;
                    if (TryRepairSharedExistingTaperedFolder(app, doc, pane, created, out inheritedFolder,
                        out reuseDetail, out repairMustAbortOnFailure))
                    {
                        BrowserNode inheritedNode = null;
                        try { inheritedNode = inheritedFolder.BrowserNode; } catch { }
                        if (inheritedNode != null)
                        {
                            totalTimer.Stop();
                            LastBrowserFolderPerformance = (string.IsNullOrWhiteSpace(LastBrowserFolderPerformance) ? "" : LastBrowserFolderPerformance + "\n") +
                                string.Format("Папка «{0}»: {1}; группировка не повторялась, чтобы сохранить наследованную membership при редактировании. Всего {2} мс.",
                                    inheritedFolder.Name, reuseDetail, totalTimer.ElapsedMilliseconds);
                            return inheritedNode;
                        }
                        repairMustAbortOnFailure = true;
                        reuseDetail = "существующая папка обнаружена, но её BrowserNode недоступен после восстановления";
                    }
                    if (repairMustAbortOnFailure)
                    {
                        editFolderReuseFailure = reuseDetail;
                        throw new InvalidOperationException(
                            "Восстановление существующей папки конической резьбы не завершено; переход к новой папке запрещён, чтобы не сохранить разорванную группу. " +
                            (string.IsNullOrWhiteSpace(reuseDetail) ? "Причина не определена." : reuseDetail));
                    }
                    else if (!string.IsNullOrWhiteSpace(reuseDetail))
                    {
                        editFolderReuseFailure = reuseDetail;
                        LastBrowserFolderPerformance = (string.IsNullOrWhiteSpace(LastBrowserFolderPerformance) ? "" : LastBrowserFolderPerformance + "\n") +
                            "Переиспользование папки при редактировании не подтверждено: " + reuseDetail + ".";
                    }
                }

                ObjectCollection browserNodes = CollectCreatedTopLevelBrowserNodes(app, doc, pane, created,
                    out snapshotMs, out fallbackLookupMs);
                int resolvedCount = browserNodes != null ? browserNodes.Count : 0;
                if (resolvedCount == 0)
                {
                    string detail = string.Format("Не удалось сопоставить созданные операции с узлами дерева для папки «{0}»: объектов {1}, верхнеуровневых узлов дерева {2}, раскрытие истории при редактировании {3}{4}.",
                        name, created.Count, pane.TopNode == null ? 0 : pane.TopNode.BrowserNodes.Count, exposeHistoryForMapping,
                        string.IsNullOrWhiteSpace(editFolderReuseFailure) ? string.Empty : "; переиспользование старой папки: " + editFolderReuseFailure);
                    LastWarning = string.IsNullOrWhiteSpace(LastWarning) ? detail : LastWarning + "\n" + detail;
                    BrowserTreeDiagnostics.WriteSnapshot("ThreadBuilder", "folder-node-mapping-empty", doc, pane, created, detail);
                    return null;
                }

                BrowserFolder folder = null;
                var groupTimer = Stopwatch.StartNew();
                try
                {
                    NameValueMap opts = app.TransientObjects.CreateNameValueMap();
                    opts.Add("PartFeatureFolder", true);
                    opts.Add("BrowserNodes", browserNodes);
                    folder = pane.AddBrowserFolderWithOptions(name, opts);
                    if (folder == null) throw new InvalidOperationException("Inventor не вернул BrowserFolder для массовой группировки.");
                    addedCount = resolvedCount;
                    groupTimer.Stop();
                    createAndGroupMs = groupTimer.ElapsedMilliseconds;
                }
                catch (Exception bulkEx)
                {
                    groupTimer.Stop();
                    createAndGroupMs = groupTimer.ElapsedMilliseconds;
                    // Compatibility fallback: a single bulk call can fail when this Inventor build
                    // cannot reorder the supplied nodes as a group. Retain the established per-node path.
                    groupingMode = "резервный folder.Add";
                    fallbackReason = bulkEx.Message;
                    folder = FindBrowserFolderByName(topNode, name);
                    if (folder == null)
                    {
                        var emptyFolderTimer = Stopwatch.StartNew();
                        NameValueMap emptyOptions = app.TransientObjects.CreateNameValueMap();
                        emptyOptions.Add("PartFeatureFolder", true);
                        folder = pane.AddBrowserFolderWithOptions(name, emptyOptions);
                        emptyFolderTimer.Stop();
                        createAndGroupMs += emptyFolderTimer.ElapsedMilliseconds;
                    }
                    if (folder == null) throw new InvalidOperationException("Inventor не вернул BrowserFolder после резервной попытки.");

                    var fallbackTimer = Stopwatch.StartNew();
                    // Inventor COM ObjectCollection indexing is 1-based.
                    for (int i = browserNodes.Count; i >= 1; i--)
                    {
                        BrowserNode node = null;
                        try { node = browserNodes[i] as BrowserNode; } catch { }
                        if (node == null) continue;
                        try
                        {
                            folder.Add(node);
                            addedCount++;
                        }
                        catch
                        {
                            // A partially successful bulk operation can have moved some nodes already.
                            // Those nodes are already inside this folder and need no additional move.
                            try
                            {
                                BrowserNode folderBrowserNode = folder.BrowserNode;
                                BrowserNode parent = node.Parent as BrowserNode;
                                if (folderBrowserNode != null && SameBrowserComObject(parent, folderBrowserNode))
                                    addedCount++;
                            }
                            catch { }
                        }
                    }
                    fallbackTimer.Stop();
                    fallbackAddMs = fallbackTimer.ElapsedMilliseconds;
                    if (addedCount != resolvedCount)
                    {
                        abortOnPartialGrouping = true;
                        string incompleteGrouping = string.Format(
                            "Резервная группировка папки «{0}» неполна: подтверждено {1} из {2} узлов. Продолжение запрещено.",
                            name, addedCount, resolvedCount);
                        throw new InvalidOperationException(incompleteGrouping + " Исходная ошибка массовой группировки: " + fallbackReason);
                    }
                }

                if (groupingMode != "batch BrowserNodes" && !string.IsNullOrWhiteSpace(fallbackReason))
                {
                    string fallbackNote = "Для папки «" + name + "» использован резервный способ группировки: " + fallbackReason;
                    LastWarning = string.IsNullOrWhiteSpace(LastWarning) ? fallbackNote : LastWarning + "\n" + fallbackNote;
                }

                var eopTimer = Stopwatch.StartNew();
                try { folder.SetEndOfPart(false); } catch { }
                eopTimer.Stop();
                setEopMs += eopTimer.ElapsedMilliseconds;

                var folderNodeTimer = Stopwatch.StartNew();
                BrowserNode folderNode = folder.BrowserNode;
                folderNodeTimer.Stop();
                folderNodeMs = folderNodeTimer.ElapsedMilliseconds;
                if (folderNode == null)
                {
                    totalTimer.Stop();
                    LastBrowserFolderPerformance = (string.IsNullOrWhiteSpace(LastBrowserFolderPerformance) ? "" : LastBrowserFolderPerformance + "\n") +
                        string.Format("Папка «{0}»: BrowserNode отсутствует после {1} мс.", name, totalTimer.ElapsedMilliseconds);
                    return null;
                }

                var reorderTimer = Stopwatch.StartNew();
                if (anchorBeforeFolder != null)
                {
                    try { pane.Reorder(anchorBeforeFolder, false, folderNode); }
                    catch
                    {
                        try { folder.SetEndOfPart(false); } catch { }
                    }
                }
                else
                {
                    try { folder.SetEndOfPart(false); } catch { }
                }
                reorderTimer.Stop();
                reorderMs = reorderTimer.ElapsedMilliseconds;

                if (collapseAfterCreate)
                {
                    try { folderNode.Expanded = false; } catch { }
                }

                // Do not call doc.Update2(true) and then reject this folder based on a second
                // GetBrowserNodeFromObject/ancestor lookup. In the user's Build97 retest this
                // post-check failed after AddBrowserFolderWithOptions had returned a folder,
                // rolling back an ordinary tapered build. Keep success tied to the native
                // folder-creation/grouping API result and pre-grouping resolved BrowserNodes.
                // Actual folder membership must still be verified manually in Inventor 2027.

                totalTimer.Stop();
                string folderTiming = string.Format(
                    "Папка «{0}»: объектов {1}, узлов сгруппировано {2}; TopNode {3} мс, поиск имени {4} мс, снимок дерева {5} мс, резервный поиск узлов {6} мс, создание + группировка {7} мс ({8}), резервные folder.Add {9} мс, BrowserNode папки {10} мс, SetEndOfPart {11} мс, Reorder {12} мс, всего {13} мс.",
                    name, created.Count, addedCount, topNodeMs, uniqueNameMs, snapshotMs,
                    fallbackLookupMs, createAndGroupMs, groupingMode, fallbackAddMs, folderNodeMs,
                    setEopMs, reorderMs, totalTimer.ElapsedMilliseconds);
                LastBrowserFolderPerformance = string.IsNullOrWhiteSpace(LastBrowserFolderPerformance)
                    ? folderTiming
                    : LastBrowserFolderPerformance + "\n" + folderTiming;
                return folderNode;
            }
            catch (Exception ex)
            {
                totalTimer.Stop();
                string diagnosticStage;
                if (ex.Message.IndexOf("Восстановление существующей папки конической резьбы не завершено", StringComparison.OrdinalIgnoreCase) >= 0)
                    diagnosticStage = "tapered-folder-repair-rejected";
                else if (ex.Message.IndexOf("Резервная группировка папки", StringComparison.OrdinalIgnoreCase) >= 0)
                    diagnosticStage = "folder-fallback-incomplete";
                else
                    diagnosticStage = "folder-grouping-exception";
                BrowserTreeDiagnostics.WriteSnapshot("ThreadBuilder", diagnosticStage, doc, pane,
                    created, "folder=" + name + "; groupingMode=" + groupingMode + "; added=" + addedCount + "; exception=" + ex);
                LastBrowserFolderPerformance = (string.IsNullOrWhiteSpace(LastBrowserFolderPerformance) ? "" : LastBrowserFolderPerformance + "\n") +
                    string.Format("Папка «{0}»: ошибка после {1} мс — {2}", name, totalTimer.ElapsedMilliseconds, ex.Message);
                LastWarning = string.IsNullOrEmpty(LastWarning)
                    ? "Не удалось сгруппировать элементы резьбы в папку: " + ex.Message
                    : LastWarning + "\nНе удалось сгруппировать элементы резьбы в папку: " + ex.Message;
                if (abortOnPartialGrouping) throw;
                return null;
            }
        }

        private static BrowserNode CreateNativeTaperedThreadBrowserFolder(Inventor.Application app, PartDocument doc,
            BrowserPane pane, BrowserNode anchorBeforeBuild, ThreadParams p, bool exposeHistoryForMapping)
        {
            List<object> created = NativeTaperedThreadBuilder.LastCreatedObjects;
            if (created == null || created.Count == 0)
                throw new InvalidOperationException("Не найдены объекты подготовки конуса и физической конической резьбы для группировки.");

            // A tapered thread always keeps its implementation features together, independent
            // of the optional sorting preference used for ordinary cylindrical thread folders.
            string folderName = ThreadFolderNamePolicy.BuildTaperedThreadFolderName(
                p.TaperStandard, p.TaperDisplayDesignation, p.TaperDesignation, p.Starts, p.RightHand);
            BrowserNode folderNode = CreateNamedBrowserFolder(app, doc, pane, anchorBeforeBuild, created, folderName, false,
                exposeHistoryForMapping);
            if (folderNode == null)
            {
                string detail = string.IsNullOrWhiteSpace(LastWarning) ? "Inventor не вернул узел папки." : LastWarning;
                throw new InvalidOperationException("Не удалось сгруппировать все объекты конической резьбы в папку «" + folderName + "». Построение будет отменено. " + detail);
            }
            return folderNode;
        }

        private static BrowserNode CreateThreadBrowserFolder(Inventor.Application app, PartDocument doc, BrowserPane pane,
                                                           BrowserNode anchorBeforeBuild, IList<object> created, ThreadParams p, int sequence)
        {
            // Include the template family explicitly: BSW and ANSI sizes are often numeric/fractional
            // labels without a recognizable prefix, so size alone is ambiguous in the browser tree.
            string folderName = ThreadFolderNamePolicy.BuildThreadFolderName(
                p.SizeName, p.Starts, p.RightHand, p.Standard, p.Mirror);
            return CreateNamedBrowserFolder(app, doc, pane, anchorBeforeBuild, created, folderName, false);
        }

        public static string GetUserFacingError(Exception ex)
        {
            // COM failures may be wrapped by feature/body helpers, so inspect the complete chain.
            Exception current = ex;
            bool hasComFailure = false;
            while (current != null)
            {
                if (current is COMException) { hasComFailure = true; break; }
                current = current.InnerException;
            }

            if (hasComFailure)
            {
                return "Inventor не смог выполнить одну из геометрических операций. Частая причина — " +
                    "соседняя фаска или скругление, нехватка места у плеча либо конфликт параметров.\n\n" +
                    "Попробуйте по очереди: отключите «Фаски»; если ошибка остаётся — отключите «Выход инструмента за деталь»; " +
                    "снимите «Скруглять» или уменьшите длину фаски/сбега. " +
                    "После каждого изменения повторите построение. Подробная причина сохранена в журнале диагностики.";
            }

            if (ex is InvalidOperationException || ex is ArgumentException)
                return ex.Message;

            return "Inventor не смог завершить построение для выбранной геометрии. Проверьте фаски и скругления рядом с выбранным ребром, " +
                "попробуйте отключить «Фаски» и «Выход инструмента за деталь», затем повторите построение. " +
                "Подробная причина сохранена в журнале диагностики.";
        }

        /// <summary>Several edges (one diameter) in one undo step.</summary>
        public static int BuildAll(Inventor.Application app, IList<ThreadTarget> targets, ThreadParams p)
        {
            if (p != null) p.SimplifiedRunout = false; // migration guard for older snapshots/callers
            LastError = null;
            LastUserError = null;
            LastWarning = null;
            LastRunoutPerformance = null;
            LastMetadataStatus = null;
            LastBrowserFolderPerformance = null;
            if (targets == null || targets.Count == 0)
                throw new InvalidOperationException("Не выбрано ни одного ребра.");
            if (p == null) throw new ArgumentNullException("p");

            // Preflight every target before opening the shared transaction. A thin-wall failure
            // on a later selected edge must not start partial modelling work for earlier edges.
            foreach (ThreadTarget target in targets)
            {
                if (p.Tapered)
                {
                    if (targets.Count != 1) throw new InvalidOperationException("Автоматическую коническую резьбу строят по одному выбранному ребру за операцию.");
                    NativeTaperedThreadBuilder.ValidateWallThicknessOrThrow(app, target, p);
                }
                else
                {
                    if (target != null && target.IsConical) throw new InvalidOperationException("Выбрана коническая грань. Включите «Коническая резьба» или выберите цилиндрическую грань.");
                    ValidateTargetWallThicknessOrThrow(app, target, p);
                }
            }

            TransactionLifecycleDiagnostics.Write("ThreadBuilder.BuildAll", "StartTransaction.before", app,
                app.ActiveDocument as Inventor._Document, null, false, "targets=" + targets.Count);
            Transaction tr = app.TransactionManager.StartTransaction(
                app.ActiveDocument,
                TransactionPrefix);
            TransactionLifecycleDiagnostics.Write("ThreadBuilder.BuildAll", "StartTransaction.after", app,
                app.ActiveDocument as Inventor._Document, tr, false, "targets=" + targets.Count);
            int total = 0;
            string warn = null;
            try
            {
                foreach (ThreadTarget t in targets)
                {
                    total += BuildAfterWallThicknessValidation(app, t, p, false);
                    if (LastWarning != null) warn = (warn == null ? "" : warn + "\n") + LastWarning;
                }
                var commitTimer = Stopwatch.StartNew();
                TransactionLifecycleDiagnostics.Write("ThreadBuilder.BuildAll", "Transaction.End.before", app,
                    app.ActiveDocument as Inventor._Document, tr, false, "targets=" + targets.Count + "; total=" + total);
                tr.End();
                TransactionLifecycleDiagnostics.Write("ThreadBuilder.BuildAll", "Transaction.End.after", app,
                    app.ActiveDocument as Inventor._Document, tr, false, "targets=" + targets.Count + "; total=" + total);
                commitTimer.Stop();
                if (!string.IsNullOrWhiteSpace(LastRunoutPerformance))
                    LastRunoutPerformance += "\nФиксация транзакции/обновление документа: " + commitTimer.ElapsedMilliseconds + " мс.";
            }
            catch (Exception ex)
            {
                TransactionLifecycleDiagnostics.Write("ThreadBuilder.BuildAll", "exception-before-Abort", app,
                    app.ActiveDocument as Inventor._Document, tr, false, ex.ToString());
                LastError = ex.ToString();
                if (string.IsNullOrWhiteSpace(LastUserError))
                    LastUserError = GetUserFacingError(ex);
                try
                {
                    tr.Abort();
                    TransactionLifecycleDiagnostics.Write("ThreadBuilder.BuildAll", "Transaction.Abort.after", app,
                        app.ActiveDocument as Inventor._Document, tr, false, "result=success");
                }
                catch (Exception abortEx)
                {
                    TransactionLifecycleDiagnostics.Write("ThreadBuilder.BuildAll", "Transaction.Abort.failed", app,
                        app.ActiveDocument as Inventor._Document, tr, false, abortEx.ToString());
                }
                throw;
            }
            LastWarning = warn;
            return total;
        }

        // ---------- thread creation ----------
        internal static void ValidateTargetWallThicknessOrThrow(Inventor.Application app, ThreadTarget target, ThreadParams parameters)
        {
            ThreadWallThicknessGuard.ValidateOrThrow(app, target, parameters);
        }

        /// <summary>Public build entry point. The wall-thickness check completes before this call opens a transaction.</summary>
        public static int Build(Inventor.Application app, ThreadTarget t, ThreadParams p, bool ownTransaction = true,
                                string threadIdOverride = null)
        {
            if (p == null) throw new ArgumentNullException("p");
            p.SimplifiedRunout = false; // Legacy callers cannot re-enable the removed run-out mode.
            if (p.Tapered)
            {
                NativeTaperedThreadBuilder.ValidateWallThicknessOrThrow(app, t, p);
            }
            else ValidateTargetWallThicknessOrThrow(app, t, p);
            return BuildAfterWallThicknessValidation(app, t, p, ownTransaction, threadIdOverride);
        }

        /// <summary>
        /// Runs the existing geometric build after a caller has completed wall-thickness preflight.
        /// Multi-target and native-thread workflows use this only after their own preflight completed.
        /// </summary>
        internal static int BuildAfterWallThicknessValidation(Inventor.Application app, ThreadTarget t, ThreadParams p,
                                bool ownTransaction = true, string threadIdOverride = null)
        {
            if (ownTransaction)
            {
                LastMetadataStatus = null;
                LastMetadataAttachSucceeded = false;
            }
            PartDocument doc = app.ActiveDocument as PartDocument;
            if (doc == null)
                throw new InvalidOperationException("Активный документ должен быть деталью (.ipt).");
            if (t == null)
                throw new ArgumentNullException("t");
            string activeDocumentInternalName = null;
            try { activeDocumentInternalName = doc.InternalName; } catch { }
            if (!string.IsNullOrEmpty(t.SourceDocumentInternalName) &&
                !string.Equals(t.SourceDocumentInternalName, activeDocumentInternalName, StringComparison.OrdinalIgnoreCase))
                throw new InvalidOperationException("Выбранные рёбра принадлежат другому документу. Вернитесь к исходной детали и повторите выбор.");
            if (string.IsNullOrEmpty(t.SourceDocumentInternalName) && t.SourceDocument != null &&
                !object.ReferenceEquals(t.SourceDocument, doc))
                throw new InvalidOperationException("Выбранные рёбра принадлежат другому документу. Вернитесь к исходной детали и повторите выбор.");

            PartComponentDefinition def = doc.ComponentDefinition;
            TransientGeometry tg = app.TransientGeometry;

            BrowserPane browserPane = GetPartModelBrowser(doc);
            BrowserNode browserAnchor = LastTopLevelNodeBeforeEop(browserPane);

            if (p == null)
                throw new ArgumentNullException("p");

            if (p.Tapered)
            {
                NativeTaperedThreadBuilder.ValidateSourceTarget(t, p);
                if (ownTransaction)
                {
                    Transaction nativeTransaction = app.TransactionManager.StartTransaction(app.ActiveDocument, TransactionPrefix + " — подготовка конуса и коническая резьба");
                    try
                    {
                        int nativeCreatedCount = NativeTaperedThreadBuilder.Build(app, t, p);
                        CreateNativeTaperedThreadBrowserFolder(app, doc, browserPane, browserAnchor, p,
                            exposeHistoryForMapping: threadIdOverride != null);
                        AttachNativeTaperedMetadata(p, t, threadIdOverride);
                        nativeTransaction.End();
                        return nativeCreatedCount;
                    }
                    catch { try { nativeTransaction.Abort(); } catch { } throw; }
                }
                int nativeCreated = NativeTaperedThreadBuilder.Build(app, t, p);
                CreateNativeTaperedThreadBrowserFolder(app, doc, browserPane, browserAnchor, p,
                    exposeHistoryForMapping: threadIdOverride != null);
                AttachNativeTaperedMetadata(p, t, threadIdOverride);
                return nativeCreated;
            }
            if (t.IsConical)
                throw new InvalidOperationException("Выбрана коническая поверхность. Включите «Коническая резьба» для нативного построения или выберите цилиндр.");

            if (p.Starts < 1 || p.Starts > 12)
                throw new InvalidOperationException("Число заходов должно быть от 1 до 12.");
            if (p.PitchMm <= 0.0 || p.NominalDiaMm <= 0.0)
                throw new InvalidOperationException("Диаметр и шаг должны быть больше нуля.");

            double pitch = p.PitchMm / 10.0;
            double clr = p.ClearanceMm / 10.0;
            int n = p.Starts;
            double lead = pitch * n;
            double R0 = t.RadiusCm;   // radius of the existing surface

            // Inventor's CoilFeatures API supports a real taper angle (radians).
            // TaperRatio is defined here as diameter change / axial length, so the
            // radial slope is half that value. Do not silently guess a standard ratio.
            double coilTaperAngle = 0.0;
            if (p.Tapered)
            {
                if (double.IsNaN(p.TaperRatio) || double.IsInfinity(p.TaperRatio) || p.TaperRatio <= 0.0 || p.TaperRatio >= 1.0)
                    throw new InvalidOperationException("Для конической резьбы задайте корректное отношение конусности: изменение диаметра / осевая длина (например, 1/16 = 0,0625). " +
                        "Конический режим не должен подбирать стандарт или конусность автоматически.");
                coilTaperAngle = Math.Atan(p.TaperRatio / 2.0);
            }

            ThreadProfileSpec spec = ThreadStandards.Spec(p.Standard);
            // The thread is always built from the calculated diameter: major dia (external) / minor dia (internal).
            // The existing cylinder / hole is brought to this diameter first.
            double R = p.External ? p.NominalDiaMm / 20.0 : p.NominalDiaMm / 20.0 - ThreadStandards.MinorOffset(spec, pitch, 10.0);
            if (R <= 0.02)
                throw new InvalidOperationException("Слишком малый диаметр резьбы.");
            bool adjust = Math.Abs(R - R0) > 5e-4;   // > 0.005 mm
            Groove g = ThreadStandards.ComputeGroove(spec, p.External, pitch, clr, lead, 10.0);   // lengths here are cm
            if (p.External && R - g.Depth <= 0.02)
                throw new InvalidOperationException("Диаметр цилиндра слишком мал для выбранного шага и зазора.");
            if (!p.External && R - g.Ext <= 0.01)
                throw new InvalidOperationException("Диаметр отверстия слишком мал для выбранного шага.");

            double offset = p.OffsetMm / 10.0;
            double length = p.FullLength ? t.LengthCm - offset : p.LengthMm / 10.0;
            if (offset < 0.0 || offset >= t.LengthCm - 1e-9)
                throw new InvalidOperationException("Отступ от ребра должен быть меньше длины цилиндрической поверхности.");
            if (length <= 0.0)
                throw new InvalidOperationException("Длина резьбы должна быть больше нуля.");
            if (!p.FullLength && offset + length > t.LengthCm + 1e-6)
                throw new InvalidOperationException("Длина резьбы вместе с отступом выходит за пределы цилиндрической поверхности.");

            double pre = g.ExtWidth / 2.0 * 1.05 + 1e-4;   // profile starts completely outside the part
            double xwHalf0 = g.ExtWidth / 2.0;
            // at a shoulder the tool must not enter the neighbouring body: the groove stops half a profile before it
            bool startSh = t.StartIsShoulder && offset <= 1e-6;
            bool endSh = t.EndIsShoulder && p.FullLength;
            // Smooth run-out is valid at the far termination of the requested thread,
            // including a shoulder. At a shoulder the actual helical taper must finish
            // one profile half-width before the shoulder so that the profile itself does
            // not intrude into the neighbouring face. At a free end it reaches the
            // requested thread end as before. FullLength must never disable a requested
            // smooth run-out.
            // A full-length thread terminating at an open/free cylinder end must retain
            // a full-depth final turn so a mating bolt can start/engage correctly.
            // Use the smooth end run-out only for a shoulder termination, or for an
            // explicitly limited thread whose end is inside the cylinder.
            bool smoothEnd = p.Smooth && (!p.FullLength || endSh);
            bool smoothStart = p.Smooth && offset > 1e-6 && !startSh;

            // Safety cap: leave at least 10% of the requested axial thread interval as
            // full-depth core when one or both end run-outs are present. This cap only
            // controls the actual run-out and the matching main-Coil endpoints; pitch,
            // lead, nominal diameters and thread-profile computations remain unchanged.
            // The actual axial length/turn count is reported in LastRunoutPerformance,
            // so visual fade alone should not be used to infer the mathematical length.
            double runLen = Math.Min(p.RunSteps * pitch, 0.45 * length);
            double threadStart = offset;
            double threadEnd = offset + length;
            double smoothEndZ = endSh ? threadEnd - xwHalf0 * 1.02 : threadEnd;
            if (smoothStart || smoothEnd)
            {
                if (smoothEndZ <= threadStart + 0.5 * pitch)
                    throw new InvalidOperationException("Недостаточно места для плавного сбега перед торцом/плечом цилиндрической поверхности.");
                if (runLen > 0.45 * Math.Max(1e-6, smoothEndZ - threadStart))
                    runLen = 0.45 * Math.Max(1e-6, smoothEndZ - threadStart);

                if (smoothStart && smoothEnd && runLen > 1e-6 &&
                    runLen * 2.0 >= smoothEndZ - threadStart - 1e-6)
                    throw new InvalidOperationException("Длина сбега слишком велика: между сбегами должна оставаться основная зона резьбы.");
            }

            double post = p.RunOut ? pre : 0.0;
            if (endSh) post = -xwHalf0 * 1.02;
            else if (p.RunOut && !smoothEnd) post = pre;

            double mainStartBase = smoothStart ? threadStart + runLen : (startSh ? threadStart + xwHalf0 * 1.02 : threadStart - pre);
            double mainEnd = smoothEnd ? smoothEndZ - runLen : threadEnd + post;
            double ringA0 = startSh ? offset : offset - pre;         // start of the ring cuts
            double endZ = mainEnd;
            if (endZ - mainStartBase < 0.5 * pitch)
                throw new InvalidOperationException("Слишком короткая длина резьбы для выбранного шага.");

            double[] u = t.U;
            double[] helper = Math.Abs(u[0]) < 0.9 ? new[] { 1.0, 0.0, 0.0 } : new[] { 0.0, 1.0, 0.0 };
            double[] r = Norm(Cross(u, Cross(helper, u)));   // radial direction, perpendicular to u

            // groove cross-section in (a = along u, b = radial distance from axis)
            // Tool cross-section in (a, D): D = depth into the material measured from the radius R.
            // Tool width is a whole pitch minus a small gap (neighbouring turns must not touch);
            // along the crest level the tool edge lies on the crest cylinder, so crest corners can be rounded.
            double sgnR = p.External ? -1.0 : 1.0;   // groove goes toward the axis for external threads
            Func<double, double> rad = d => R + sgnR * d;
            double xw = g.ExtWidth / 2.0;
            double dc = g.CapDepth, dr = g.Depth, dtop = g.CapDepth - g.Ext;
            double rc = 0.0, rr = 0.0;
            if (p.Round) ThreadStandards.Radii(p.Standard, spec, p.External, pitch, 10.0, out rc, out rr);
            double sm = p.Mirror ? -1.0 : 1.0;   // mirror the profile along the axis (buttress: load flank side)
            var poly = new List<double[]>
            {
                new[] { sm * -xw, dtop }, new[] { sm * xw, dtop }, new[] { sm * xw, dc }, new[] { sm * g.X0R, dc },
                new[] { sm * g.X1R, dr }, new[] { sm * g.X1L, dr }, new[] { sm * g.X0L, dc }, new[] { sm * -xw, dc }
            };
            double[] polyR = { 0.0, 0.0, 0.0, rc, rr, rr, rc, 0.0 };
            List<Piece> pieces = RoundedPath(poly, polyR);

            LastWarning = null;
            if (adjust)
            {
                // For an external thread, increasing the target radius adds material to the shaft.
                // For an internal thread, decreasing the target radius adds material into the bore.
                // Keep this warning independent of run-out mode: it describes the stock diameter,
                // not the Loft shape. Reporting both measured and target diameters makes the cause clear.
                bool addsMaterial = p.External ? (R > R0) : (R < R0);
                double deltaMm = Math.Abs(R - R0) * 20.0;
                if (addsMaterial && deltaMm >= 0.05)
                {
                    if (p.External)
                    {
                        LastWarning = string.Format(
                            "Подготовка наружной резьбы: исходный диаметр поверхности Ø{0:0.###} мм будет увеличен добавлением материала кольцом до Ø{1:0.###} мм (изменение диаметра {2:0.###} мм). Проверьте, что такое изменение геометрии детали допустимо.",
                            R0 * 20.0, R * 20.0, deltaMm);
                    }
                    else
                    {
                        LastWarning = string.Format(
                            "Подготовка внутренней резьбы Ø{0:0.###} × {1:0.###} мм: исходное отверстие Ø{2:0.###} мм будет предварительно заполнено материалом кольцом до малого диаметра внутреннего профиля Ø{3:0.###} мм (изменение диаметра {4:0.###} мм). Затем винтовой профиль сформирует резьбу до номинального Ø{0:0.###} мм. Номинальный диаметр в параметрах не меняется. Проверьте, что добавление материала допустимо.",
                            p.NominalDiaMm, p.PitchMm, R0 * 20.0, R * 20.0, deltaMm);
                    }
                }
            }
            var created = new List<object>();   // all top-level objects of this logical thread, in creation order
            var runoutCreated = new List<object>(); // only technical objects belonging to the smooth run-out

            // Multi-body parts: a cut / join feature affects only the "default" solid body unless the bodies are set
            // explicitly - otherwise the feature of another body is created "without result".
            ObjectCollection Bodies()
            {
                SurfaceBody b = OwnedBody(def, t);
                if (b == null) return null;
                ObjectCollection oc = app.TransientObjects.CreateObjectCollection();
                oc.Add(b);
                return oc;
            }

            void Affect(object feature)
            {
                if (feature == null) return;
                ObjectCollection bc = Bodies();
                if (bc == null)
                    throw new InvalidOperationException("Не удалось определить твёрдое тело выбранной цилиндрической поверхности.");

                try
                {
                    // Autodesk.Inventor.Sdk exposes SetAffectedBodies on the concrete
                    // COM feature interfaces, but the generated C# interop types do
                    // not allow an implicit conversion to PartFeature. Call the
                    // method on the concrete feature type instead of relying on a
                    // CLR inheritance relationship that is not represented by the SDK.
                    switch (feature)
                    {
                        case RevolveFeature revolve:
                            revolve.SetAffectedBodies(bc);
                            break;
                        case ChamferFeature chamfer:
                            chamfer.SetAffectedBodies(bc);
                            break;
                        case CoilFeature coil:
                            coil.SetAffectedBodies(bc);
                            break;
                        case SweepFeature sweep:
                            sweep.SetAffectedBodies(bc);
                            break;
                        case LoftFeature loft:
                            loft.SetAffectedBodies(bc);
                            break;
                        default:
                            throw new InvalidOperationException(
                                "Неподдерживаемый тип операции для привязки к твёрдому телу: " +
                                feature.GetType().FullName);
                    }
                }
                catch (Exception aex)
                {
                    if (aex is InvalidOperationException &&
                        aex.Message.StartsWith("Неподдерживаемый тип операции", StringComparison.Ordinal))
                        throw;

                    throw new InvalidOperationException(
                        "Не удалось привязать операцию к телу выбранной цилиндрической поверхности: " + aex.Message, aex);
                }
            }

            // revolved ring (rectangle rLow..rHigh, axial aStart..aEnd measured from the picked edge along the axis)
            RevolveFeature Ring(string featName, double aStart, double aEnd, double rLow, double rHigh, PartFeatureOperationEnum op)
            {
                double span = aEnd - aStart;
                double[] o0 =
                {
                    t.Center[0] + u[0] * aStart, t.Center[1] + u[1] * aStart, t.Center[2] + u[2] * aStart
                };
                WorkPlane wp0 = def.WorkPlanes.AddFixed(
                    tg.CreatePoint(o0[0], o0[1], o0[2]),
                    tg.CreateUnitVector(r[0], r[1], r[2]),
                    tg.CreateUnitVector(u[0], u[1], u[2]), false);
                wp0.Visible = false;
                created.Add(wp0);

                PlanarSketch sk0 = def.Sketches.Add(wp0);
                try { sk0.Name = "Эскиз: " + featName; } catch { }
                created.Add(sk0);
                Func<double, double, Point2d> S0 = (a, b) =>
                    sk0.ModelToSketchSpace(tg.CreatePoint(
                        o0[0] + u[0] * a + r[0] * b,
                        o0[1] + u[1] * a + r[1] * b,
                        o0[2] + u[2] * a + r[2] * b));

                SketchLine ax0 = sk0.SketchLines.AddByTwoPoints(S0(0, 0), S0(span, 0));
                ax0.Construction = true;
                SketchLine q1 = sk0.SketchLines.AddByTwoPoints(S0(0, rLow), S0(span, rLow));
                SketchLine q2 = sk0.SketchLines.AddByTwoPoints(q1.EndSketchPoint, S0(span, rHigh));
                SketchLine q3 = sk0.SketchLines.AddByTwoPoints(q2.EndSketchPoint, S0(0, rHigh));
                sk0.SketchLines.AddByTwoPoints(q3.EndSketchPoint, q1.StartSketchPoint);

                Profile pr0 = sk0.Profiles.AddForSolid();
                RevolveFeature rv = def.Features.RevolveFeatures.AddFull(pr0, ax0, op);
                Affect(rv);
                try { rv.Name = featName; } catch { }
                created.Add(rv);
                sk0.Visible = false;
                return rv;
            }

            TransactionLifecycleDiagnostics.Write("ThreadBuilder.Build", "enter", app,
                app.ActiveDocument as Inventor._Document, null, false,
                "ownTransaction=" + ownTransaction + "; threadIdOverride=" + (threadIdOverride ?? string.Empty));
            Transaction tr = null;
            if (ownTransaction)
            {
                TransactionLifecycleDiagnostics.Write("ThreadBuilder.Build", "StartTransaction.before", app,
                    app.ActiveDocument as Inventor._Document, null, false,
                    "threadIdOverride=" + (threadIdOverride ?? string.Empty));
                tr = app.TransactionManager.StartTransaction(app.ActiveDocument, TransactionPrefix);
                TransactionLifecycleDiagnostics.Write("ThreadBuilder.Build", "StartTransaction.after", app,
                    app.ActiveDocument as Inventor._Document, tr, false,
                    "threadIdOverride=" + (threadIdOverride ?? string.Empty));
            }
            try
            {
                // Coarse phase timing helps locate delays outside the run-out Loft itself.
                // In recent tests Loft setup/Add accounted for only a small part of total time.
                var preMainFeatureTimer = Stopwatch.StartNew();
                if (adjust)
                {
                    bool remove = p.External ? (R < R0) : (R > R0);
                    double ov = Math.Min(0.1 * pitch, 0.5 * Math.Min(R0, R));
                    if (remove)
                    {
                        // material has to be removed: cut a ring between the new and the old surface
                        double rLow = p.External ? R : R0 - ov;
                        double rHigh = p.External ? R0 + ov : R;
                        Ring("Резьба: приведение диаметра", ringA0, offset + length, rLow, rHigh,
                             PartFeatureOperationEnum.kCutOperation);
                    }
                    else
                    {
                        // material has to be added (e.g. a hole drawn at the nominal diameter): join a ring
                        double rLow = p.External ? R0 - ov : R;
                        double rHigh = p.External ? R : R0 + ov;
                        Ring("Резьба: приведение диаметра", offset, offset + length, rLow, rHigh,
                             PartFeatureOperationEnum.kJoinOperation);
                    }
                }

                if (p.ChamferMode != 0)
                {
                    // the surface was modified: find the circular edges again
                    // always found by geometry: edge objects of earlier selections may be stale after other features
                    var startEdges = new List<Edge>();
                    var endEdges = new List<Edge>();
                    double searchR = adjust ? R : R0;
                    FindCircularEdges(def, t, searchR, 0.0, startEdges);
                    FindCircularEdges(def, t, searchR, t.LengthCm, endEdges);
                    if ((p.ChamferMode == 1 || p.ChamferMode == 3) && startEdges.Count == 0)
                        throw new InvalidOperationException("Не найдено ребро в начале резьбы для фаски.");
                    double cd = p.ChamferMm / 10.0;
                    if (cd <= 0.0) throw new InvalidOperationException("Размер фаски должен быть больше нуля.");
                    if (p.External && cd >= R) throw new InvalidOperationException("Фаска больше радиуса цилиндра.");
                    if (cd >= t.LengthCm) throw new InvalidOperationException("Фаска больше длины поверхности.");
                    if ((p.ChamferMode == 3) && 2.0 * cd >= t.LengthCm - 1e-9)
                        throw new InvalidOperationException("Две фаски такой длины не помещаются на выбранной поверхности: их суммарная длина должна быть меньше длины цилиндра.");
                    if ((p.ChamferMode == 1 || p.ChamferMode == 3) && t.StartIsShoulder)
                        throw new InvalidOperationException("Фаску в начале нельзя построить на вогнутом/упорном ребре: это может повредить соседнюю поверхность.");
                    if ((p.ChamferMode == 2 || p.ChamferMode == 3) && t.EndIsShoulder)
                        throw new InvalidOperationException("Фаску в конце нельзя построить на вогнутом/упорном ребре: это может повредить соседнюю поверхность.");

                    EdgeCollection ec = app.TransientObjects.CreateEdgeCollection();
                    if (p.ChamferMode == 1 || p.ChamferMode == 3)
                        foreach (Edge e in startEdges) ec.Add(e);
                    if (p.ChamferMode == 2 || p.ChamferMode == 3)
                    {
                        if (endEdges.Count == 0)
                            throw new InvalidOperationException("Не найдено дальнее круговое ребро для фаски.");
                        foreach (Edge e in endEdges) ec.Add(e);
                    }
                    ChamferFeature cf;
                    try
                    {
                        cf = def.Features.ChamferFeatures.AddUsingDistance(ec, cd);
                    }
                    catch (COMException)
                    {
                        LastUserError = "Inventor не смог создать фаску на выбранном ребре. Возможно, рядом уже есть сопряжённая фаска/скругление " +
                            "или соседняя геометрия не оставляет места для новой фаски.\n\n" +
                            "Что попробовать:\n" +
                            "1. Снимите флажок «Фаски» и повторите построение.\n" +
                            "2. Если фаска нужна — уменьшите её длину или попробуйте построить резьбу с другого края.\n" +
                            "3. Если после отключения фасок останется другая ошибка, снимите «Скруглять»; затем при необходимости отключите «Выход инструмента за деталь» " +
                            "или уменьшите длину сбега.\n\n" +
                            "Подробная ошибка сохранена в журнале диагностики.";
                        throw;
                    }
                    Affect(cf);
                    try { cf.Name = "Фаска резьбы"; } catch { }
                    created.Add(cf);
                }

                if (g.RingDepth > 0.0)
                {
                    // Clearance: lower (external) / raise (internal) the crest zone evenly with a ring cut,
                    // so the tooth tip is a clean cylinder instead of a thin ridge.
                    double rA = rad(-g.Ext), rB = rad(g.RingDepth);
                    Ring("Резьба: проточка вершин (зазор)", ringA0, offset + length,
                         Math.Min(rA, rB), Math.Max(rA, rB), PartFeatureOperationEnum.kCutOperation);
                }

                preMainFeatureTimer.Stop();
                long preMainFeatureMs = preMainFeatureTimer.ElapsedMilliseconds;
                long mainSketchProfileMs = 0;
                long mainCoilAddMs = 0;
                var mainCoilStageTimer = Stopwatch.StartNew();

                for (int i = 0; i < n; i++)
                {
                    var profileBuildTimer = Stopwatch.StartNew();
                    // starts are shifted by one pitch along the axis; all end on the same plane
                    double aStart = startSh ? offset + xwHalf0 * 1.02 + i * pitch
                                            : mainStartBase - (n - 1 - i) * pitch;
                    double height = endZ - aStart;
                    double revs = height / lead;

                    double[] o =
                    {
                        t.Center[0] + u[0] * aStart,
                        t.Center[1] + u[1] * aStart,
                        t.Center[2] + u[2] * aStart
                    };

                    WorkPlane wp = def.WorkPlanes.AddFixed(
                        tg.CreatePoint(o[0], o[1], o[2]),
                        tg.CreateUnitVector(r[0], r[1], r[2]),
                        tg.CreateUnitVector(u[0], u[1], u[2]), false);
                    wp.Visible = false;
                    created.Add(wp);

                    PlanarSketch sk = def.Sketches.Add(wp);
                    string title = "Резьба " + StdName(p.Standard) + " " + p.SizeName + " заход " + (i + 1) + "/" + n;
                    created.Add(sk);
                    try { sk.Name = "Эскиз: " + title; } catch { }

                    Func<double, double, Point2d> S = (a, b) =>
                        sk.ModelToSketchSpace(tg.CreatePoint(
                            o[0] + u[0] * a + r[0] * b,
                            o[1] + u[1] * a + r[1] * b,
                            o[2] + u[2] * a + r[2] * b));

                    SketchLine axisLine = sk.SketchLines.AddByTwoPoints(S(0, 0), S(height, 0));
                    axisLine.Construction = true;

                    object prevEnd = null, firstStart = null;
                    for (int k = 0; k < pieces.Count; k++)
                    {
                        Piece pc = pieces[k];
                        Point2d pStart = S(pc.P0[0], rad(pc.P0[1]));
                        Point2d pEnd = S(pc.P1[0], rad(pc.P1[1]));
                        object startObj = (k == 0) ? (object)pStart : prevEnd;
                        object endObj = (k == pieces.Count - 1 && firstStart != null) ? firstStart : (object)pEnd;
                        if (pc.Arc)
                        {
                            SketchArc arc = sk.SketchArcs.AddByThreePoints(startObj, S(pc.Pm[0], rad(pc.Pm[1])), endObj);
                            // Inventor arcs run counter-clockwise: start and end may come back swapped -> pick by position
                            SketchPoint sa = arc.StartSketchPoint, sb = arc.EndSketchPoint;
                            bool aIsEnd = sa.Geometry.DistanceTo(pEnd) < sb.Geometry.DistanceTo(pEnd);
                            if (k == 0) firstStart = aIsEnd ? (object)sb : (object)sa;
                            prevEnd = aIsEnd ? (object)sa : (object)sb;
                        }
                        else
                        {
                            SketchLine ln = sk.SketchLines.AddByTwoPoints(startObj, endObj);
                            if (k == 0) firstStart = ln.StartSketchPoint;
                            prevEnd = ln.EndSketchPoint;
                        }
                    }

                    Profile prof = sk.Profiles.AddForSolid();
                    profileBuildTimer.Stop();
                    mainSketchProfileMs += profileBuildTimer.ElapsedMilliseconds;

                    var mainCoilAddTimer = Stopwatch.StartNew();
                    CoilFeature coil = def.Features.CoilFeatures.AddByPitchAndRevolution(
                        prof, axisLine, lead, revs,
                        PartFeatureOperationEnum.kCutOperation,
                        false, !p.RightHand, coilTaperAngle);   // Inventor ClockwiseRotation is inverted vs. thread handedness; taper angle is radians
                    mainCoilAddTimer.Stop();
                    mainCoilAddMs += mainCoilAddTimer.ElapsedMilliseconds;
                    Affect(coil);
                    try { coil.Name = title; } catch { }
                    created.Add(coil);

                    sk.Visible = false;
                }
                mainCoilStageTimer.Stop();
                long mainCoilStageMs = mainCoilStageTimer.ElapsedMilliseconds;
                long mainCoilOtherMs = Math.Max(0L, mainCoilStageMs - mainSketchProfileMs - mainCoilAddMs);

                // Smooth run-out v4: one LoftFeature through many radial/axial sections.
                // A Loft is used instead of Sweep because Inventor 2027 rejected all prior
                // guide-rail Sweep variants even when added as a separate body (E_FAIL at Add).
                // The section profiles use identical topology and rotate with the thread phase;
                // only groove depth changes from nearly shallow to full depth (or vice versa).
                // Shared helpers used by the experimental Loft and the robust segmented fallback.
                double ScaleRunoutDepth(double d, double factor)
                {
                    factor = Math.Max(0.025, Math.Min(1.0, factor));
                    return g.CapDepth + (d - g.CapDepth) * factor;
                }

                void DeleteTemporaryObjects(List<object> items)
                {
                    if (items == null) return;
                    for (int di = items.Count - 1; di >= 0; di--)
                    {
                        object obj = items[di];
                        if (obj == null) continue;
                        try { ((dynamic)obj).Delete(); } catch { }
                    }
                }

                void AddLoftRunout(string featureName, double zFrom, double zTo, double phaseOrigin, bool shallowerAtEnd, bool protectShoulderTermination)
                {
                    var runoutTimer = Stopwatch.StartNew();
                    // Smooth run-out is the only supported mode. At shoulder terminations use a
                    // conservative contour/void margin to avoid residual material near the face.
                    bool conservativeShoulderProfile = protectShoulderTermination;
                    bool conservativeProfile = conservativeShoulderProfile;
                    double height = zTo - zFrom;
                    if (height <= 1e-5) return;

                    double delta = Math.Max(0.0, g.Depth - dtop);
                    if (delta <= 1e-6) return;
                    // Extend the anchor into free space (outside external stock / inside internal bore).
                    // Smooth mode uses the normal AA margin; the local shoulder safeguard uses a
                    // larger void-side margin to avoid residual material near the terminal shoulder.
                    // At full depth the first Loft section is unchanged.
                    double voidSideOverhangMultiplier = conservativeProfile ? 3.00 : 1.50;
                    double runoutAnchorDepth = Math.Min(dtop, -Math.Max(g.Ext * voidSideOverhangMultiplier, 1e-4));
                    double runoutOverhang = Math.Max(1e-4, -runoutAnchorDepth); // cm
                    double chordRadius = Math.Max(1e-4, R + runoutOverhang);
                    double targetSagitta = runoutOverhang * 0.90;
                    double cosHalf = 1.0 - targetSagitta / chordRadius;
                    cosHalf = Math.Max(-1.0, Math.Min(1.0, cosHalf));
                    double maxSectionAngle = 2.0 * Math.Acos(cosHalf);
                    int sectionsPerTurn = maxSectionAngle > 1e-6
                        ? (int)Math.Ceiling(2.0 * Math.PI / maxSectionAngle)
                        : 64;
                    sectionsPerTurn = Math.Max(10, Math.Min(64, sectionsPerTurn));
                    double runoutTurns = height / Math.Max(lead, 1e-6);
                    int sectionCount = Math.Max(5, Math.Min(257,
                        (int)Math.Ceiling(runoutTurns * sectionsPerTurn) + 1));
                    double phaseSign = p.RightHand ? 1.0 : -1.0;
                    var temp = new List<object>();
                    string loftStage = "подготовка";
                    // Keep identical vertex topology in every Loft profile; changing edge count
                    // section-to-section makes Inventor's face correspondence unstable. To reduce
                    // BRep complexity, use a coarser but still bounded rounding tessellation, then
                    // gradually flatten rounded corners only after the first three near-full-depth
                    // profiles. The separate chord list lets us simplify the shape without changing
                    // topology. API units are cm: 0.004 cm is 0.04 mm.
                    double loftArcSagittaCm = conservativeProfile ? 0.008 : 0.004; // 0.08 mm conservative / 0.04 mm smooth
                    var loftProfileCoords = new List<double[]>();
                    var loftProfileChordCoords = new List<double[]>();
                    var profilePrepTimer = Stopwatch.StartNew();
                    foreach (Piece piece in pieces)
                    {
                        if (loftProfileCoords.Count == 0)
                        {
                            loftProfileCoords.Add((double[])piece.P0.Clone());
                            loftProfileChordCoords.Add((double[])piece.P0.Clone());
                        }

                        if (!piece.Arc)
                        {
                            if (Dist2(loftProfileCoords[loftProfileCoords.Count - 1], piece.P1) > 1e-9)
                            {
                                loftProfileCoords.Add((double[])piece.P1.Clone());
                                loftProfileChordCoords.Add((double[])piece.P1.Clone());
                            }
                            continue;
                        }

                        double[] a = piece.P0, m = piece.Pm, b = piece.P1;
                        double det = 2.0 * (a[0] * (m[1] - b[1]) + m[0] * (b[1] - a[1]) + b[0] * (a[1] - m[1]));
                        if (Math.Abs(det) > 1e-12)
                        {
                            double aa = a[0] * a[0] + a[1] * a[1];
                            double mm = m[0] * m[0] + m[1] * m[1];
                            double bb = b[0] * b[0] + b[1] * b[1];
                            double cx = (aa * (m[1] - b[1]) + mm * (b[1] - a[1]) + bb * (a[1] - m[1])) / det;
                            double cy = (aa * (b[0] - m[0]) + mm * (a[0] - b[0]) + bb * (m[0] - a[0])) / det;
                            double radius = Math.Sqrt((a[0] - cx) * (a[0] - cx) + (a[1] - cy) * (a[1] - cy));
                            double a0 = Math.Atan2(a[1] - cy, a[0] - cx);
                            double am = Math.Atan2(m[1] - cy, m[0] - cx);
                            double a1 = Math.Atan2(b[1] - cy, b[0] - cx);
                            Func<double, double> posAngle = value =>
                            {
                                value %= 2.0 * Math.PI;
                                return value < 0.0 ? value + 2.0 * Math.PI : value;
                            };
                            double ccw = posAngle(a1 - a0);
                            double toMid = posAngle(am - a0);
                            double sweepAngle = toMid <= ccw + 1e-8 ? ccw : ccw - 2.0 * Math.PI;
                            double maxArcCos = 1.0 - loftArcSagittaCm / Math.Max(radius, 1e-9);
                            maxArcCos = Math.Max(-1.0, Math.Min(1.0, maxArcCos));
                            double maxArcStep = 2.0 * Math.Acos(maxArcCos);
                            int arcSegments = maxArcStep > 1e-6
                                ? (int)Math.Ceiling(Math.Abs(sweepAngle) / maxArcStep)
                                : 6;
                            arcSegments = Math.Max(2, Math.Min(conservativeProfile ? 2 : 4, arcSegments));
                            for (int sample = 1; sample <= arcSegments; sample++)
                            {
                                if (sample == arcSegments)
                                {
                                    loftProfileCoords.Add((double[])b.Clone());
                                    loftProfileChordCoords.Add((double[])b.Clone());
                                    continue;
                                }
                                double ang = a0 + sweepAngle * sample / arcSegments;
                                double arcT = sample / (double)arcSegments;
                                loftProfileCoords.Add(new[] { cx + radius * Math.Cos(ang), cy + radius * Math.Sin(ang) });
                                loftProfileChordCoords.Add(new[] {
                                    a[0] + (b[0] - a[0]) * arcT,
                                    a[1] + (b[1] - a[1]) * arcT
                                });
                            }
                        }
                        else
                        {
                            // Degenerate arc fallback: quadratic Bezier forced through Pm at t=0.5.
                            double qx = 2.0 * m[0] - 0.5 * (a[0] + b[0]);
                            double qy = 2.0 * m[1] - 0.5 * (a[1] + b[1]);
                            int degenerateArcSegments = conservativeProfile ? 2 : 3;
                            for (int sample = 1; sample <= degenerateArcSegments; sample++)
                            {
                                if (sample == degenerateArcSegments)
                                {
                                    loftProfileCoords.Add((double[])b.Clone());
                                    loftProfileChordCoords.Add((double[])b.Clone());
                                    continue;
                                }
                                double tArc = sample / (double)degenerateArcSegments, omt = 1.0 - tArc;
                                loftProfileCoords.Add(new[] {
                                    omt * omt * a[0] + 2.0 * omt * tArc * qx + tArc * tArc * b[0],
                                    omt * omt * a[1] + 2.0 * omt * tArc * qy + tArc * tArc * b[1]
                                });
                                loftProfileChordCoords.Add(new[] {
                                    a[0] + (b[0] - a[0]) * tArc,
                                    a[1] + (b[1] - a[1]) * tArc
                                });
                            }
                        }
                    }
                    if (loftProfileCoords.Count > 1 && Dist2(loftProfileCoords[0], loftProfileCoords[loftProfileCoords.Count - 1]) < 1e-7)
                    {
                        loftProfileCoords.RemoveAt(loftProfileCoords.Count - 1);
                        loftProfileChordCoords.RemoveAt(loftProfileChordCoords.Count - 1);
                    }
                    profilePrepTimer.Stop();
                    long profilePrepMs = profilePrepTimer.ElapsedMilliseconds;
                    if (loftProfileCoords.Count < 3 || loftProfileChordCoords.Count != loftProfileCoords.Count)
                        throw new InvalidOperationException("Недостаточно точек профиля для Loft сбега.");

                    long sectionBuildMs = 0;
                    long loftAddMs = 0;
                    try
                    {
                        ObjectCollection sections = app.TransientObjects.CreateObjectCollection();
                        double qx = u[1] * r[2] - u[2] * r[1];
                        double qy = u[2] * r[0] - u[0] * r[2];
                        double qz = u[0] * r[1] - u[1] * r[0];

                        var sectionsTimer = Stopwatch.StartNew();
                        for (int sectionIndex = 0; sectionIndex < sectionCount; sectionIndex++)
                        {
                            double tSection = sectionIndex / (double)(sectionCount - 1);
                            double stationZ = zFrom + height * tSection;
                            // Smoothstep has zero slope at both ends: the full-depth section
                            // matches the main Coil tangentially, and the shallow terminal
                            // section approaches the cylinder without a visible end lip.
                            // Keep a tiny non-zero factor because an exactly collapsed section
                            // has zero area and Inventor cannot use it as a solid Loft profile.
                            double eased = tSection * tSection * (3.0 - 2.0 * tSection);
                            double terminalDepthFactor = conservativeShoulderProfile ? 0.001 : 0.005;
                            double depthFactor = shallowerAtEnd
                                ? 1.0 - (1.0 - terminalDepthFactor) * eased
                                : terminalDepthFactor + (1.0 - terminalDepthFactor) * eased;

                            double phase = phaseSign * 2.0 * Math.PI * ((stationZ - phaseOrigin) / lead);
                            double cp = Math.Cos(phase), sp = Math.Sin(phase);
                            double[] radial = Norm(new[]
                            {
                                r[0] * cp + qx * sp,
                                r[1] * cp + qy * sp,
                                r[2] * cp + qz * sp
                            });

                            Point axisPoint = tg.CreatePoint(
                                t.Center[0] + u[0] * stationZ,
                                t.Center[1] + u[1] * stationZ,
                                t.Center[2] + u[2] * stationZ);

                            loftStage = "создание сечения Loft " + (sectionIndex + 1) + "/" + sectionCount;
                            WorkPlane wp = def.WorkPlanes.AddFixed(
                                axisPoint,
                                tg.CreateUnitVector(radial[0], radial[1], radial[2]),
                                tg.CreateUnitVector(u[0], u[1], u[2]),
                                false);
                            wp.Visible = false;
                            try { wp.Name = "Плоскость сечения сбега " + (sectionIndex + 1) + ": " + featureName; } catch { }
                            temp.Add(wp);

                            PlanarSketch sk = def.Sketches.Add(wp);
                            try { sk.Name = "Сечение сбега " + (sectionIndex + 1) + "/" + sectionCount + ": " + featureName; } catch { }
                            temp.Add(sk);

                            Func<double, double, Point2d> SLoft = (a, d) =>
                            {
                                // Contract towards the void-side anchor so the cutting overhang
                                // survives while depth fades out. The sketch plane has X=radial,
                                // Y=axis and is based at the cylinder axis at stationZ; consequently
                                // local coordinates are (radial distance, axial offset).
                                // Direct 2D points avoid a 3D Point + ModelToSketchSpace COM round-trip
                                // for every vertex in every section (hundreds of calls per Loft).
                                double runoutDepth = runoutAnchorDepth + (d - runoutAnchorDepth) * depthFactor;
                                double rd = R + sgnR * runoutDepth;
                                return tg.CreatePoint2d(rd, a);
                            };

                            // Preserve the rounded profile for the first three sections where it
                            // meets the full-size Coil; then smoothly blend the arc samples toward
                            // their straight chords. Vertex count/order remain identical for Loft.
                            double roundingBlend = 1.0;
                            if (sectionIndex > 2)
                            {
                                double simplifyT = (sectionIndex - 2.0) / Math.Max(1.0, sectionCount - 3.0);
                                simplifyT = Math.Max(0.0, Math.Min(1.0, simplifyT));
                                simplifyT = simplifyT * simplifyT * (3.0 - 2.0 * simplifyT);
                                roundingBlend = 1.0 - (conservativeProfile ? 1.0 : 0.80) * simplifyT;
                                // Smooth mode retains 20% rounding at the terminal section unless
                                // the shoulder-protection profile must transition fully to its chords.
                            }
                            var sectionVertices = new List<Point2d>(loftProfileCoords.Count);
                            for (int profileIndex = 0; profileIndex < loftProfileCoords.Count; profileIndex++)
                            {
                                double[] curved = loftProfileCoords[profileIndex];
                                double[] chord = loftProfileChordCoords[profileIndex];
                                double axial = chord[0] + (curved[0] - chord[0]) * roundingBlend;
                                double depth = chord[1] + (curved[1] - chord[1]) * roundingBlend;
                                sectionVertices.Add(SLoft(axial, depth));
                            }

                            object prevEnd = null, firstStart = null;
                            for (int vertexIndex = 0; vertexIndex < sectionVertices.Count; vertexIndex++)
                            {
                                object startObj = vertexIndex == 0 ? (object)sectionVertices[vertexIndex] : prevEnd;
                                object endObj = vertexIndex == sectionVertices.Count - 1
                                    ? firstStart
                                    : (object)sectionVertices[vertexIndex + 1];
                                SketchLine line = sk.SketchLines.AddByTwoPoints(startObj, endObj);
                                if (vertexIndex == 0) firstStart = line.StartSketchPoint;
                                prevEnd = line.EndSketchPoint;
                            }

                            Profile profile = sk.Profiles.AddForSolid();
                            sections.Add(profile);
                        }
                        sectionsTimer.Stop();
                        sectionBuildMs = sectionsTimer.ElapsedMilliseconds;

                        loftStage = "добавление LoftFeature (непрерывный сбег, сечений: " + sectionCount + ")";
                        var loftTimer = Stopwatch.StartNew();
                        LoftDefinition loftDefinition = def.Features.LoftFeatures.CreateLoftDefinition(
                            sections,
                            PartFeatureOperationEnum.kCutOperation);
                        LoftFeature loftFeature = def.Features.LoftFeatures.Add(loftDefinition);
                        loftTimer.Stop();
                        loftAddMs = loftTimer.ElapsedMilliseconds;
                        temp.Add(loftFeature);
                        Affect(loftFeature);
                        try { loftFeature.Name = featureName; } catch { }

                        runoutTimer.Stop();
                        double runoutSteps = height / Math.Max(pitch, 1e-6);
                        string timing = string.Format(
                            "Сбег Loft ({0}): длина {1:0.##} мм; {2:0.##} шага, {3:0.##} об.; {4} сеч., {5} вершин; подготовка профиля {6} мс, создание WorkPlane/Sketch/Profile {7} мс, Loft.Add {8} мс, всего этапа {9} мс.",
                            conservativeShoulderProfile ? "плавный, защита плеча" : "плавный", height * 10.0, runoutSteps, runoutTurns,
                            sectionCount, loftProfileCoords.Count, profilePrepMs, sectionBuildMs, loftAddMs, runoutTimer.ElapsedMilliseconds);
                        LastRunoutPerformance = string.IsNullOrWhiteSpace(LastRunoutPerformance)
                            ? timing
                            : LastRunoutPerformance + "\n" + timing;

                        foreach (object obj in temp)
                        {
                            created.Add(obj);
                            runoutCreated.Add(obj);
                        }
                    }
                    catch (Exception ex)
                    {
                        DeleteTemporaryObjects(temp);
                        throw new InvalidOperationException(
                            "Loft сбега не принят Inventor. Этап: " + loftStage + ". Причина: " + ex.Message, ex);
                    }
                }

                void AddSegmentedRunoutCoil(string featureName, double zFrom, double zTo, double phaseOrigin, bool shallowerAtEnd)
                {
                    double height = zTo - zFrom;
                    if (height <= 1e-5) return;

                    int segments = Math.Max(6, Math.Min(16, (int)Math.Ceiling((height / Math.Max(pitch, 1e-6)) * 8.0)));
                    for (int segNo = 0; segNo < segments; segNo++)
                    {
                        double za = zFrom + height * segNo / segments;
                        double zb = zFrom + height * (segNo + 1) / segments;
                        double segHeight = zb - za;
                        if (segHeight <= 1e-6) continue;

                        double q = (segNo + 0.5) / segments;
                        double factor = shallowerAtEnd ? (1.0 - q) : q;
                        factor = Math.Max(0.025, Math.Min(1.0, factor));

                        double phaseSign = p.RightHand ? 1.0 : -1.0;
                        double phase = phaseSign * 2.0 * Math.PI * ((za - phaseOrigin) / lead);
                        double qx = u[1] * r[2] - u[2] * r[1];
                        double qy = u[2] * r[0] - u[0] * r[2];
                        double qz = u[0] * r[1] - u[1] * r[0];
                        double cp = Math.Cos(phase), sp = Math.Sin(phase);
                        double[] rr =
                        {
                            r[0] * cp + qx * sp,
                            r[1] * cp + qy * sp,
                            r[2] * cp + qz * sp
                        };
                        double[] o =
                        {
                            t.Center[0] + u[0] * za,
                            t.Center[1] + u[1] * za,
                            t.Center[2] + u[2] * za
                        };

                        string segTitle = featureName + " · " + (segNo + 1) + "/" + segments;
                        WorkPlane wp = def.WorkPlanes.AddFixed(
                            tg.CreatePoint(o[0], o[1], o[2]),
                            tg.CreateUnitVector(rr[0], rr[1], rr[2]),
                            tg.CreateUnitVector(u[0], u[1], u[2]), false);
                        wp.Visible = false;
                        created.Add(wp);
                        runoutCreated.Add(wp);

                        PlanarSketch sk = def.Sketches.Add(wp);
                        try { sk.Name = "Эскиз: " + segTitle; } catch { }
                        created.Add(sk);
                        runoutCreated.Add(sk);

                        Func<double, double, Point2d> SRun = (a, d) =>
                        {
                            double rd = R + sgnR * ScaleRunoutDepth(d, factor);
                            return sk.ModelToSketchSpace(tg.CreatePoint(
                                o[0] + u[0] * a + rr[0] * rd,
                                o[1] + u[1] * a + rr[1] * rd,
                                o[2] + u[2] * a + rr[2] * rd));
                        };

                        object prevEnd = null, firstStart = null;
                        for (int k = 0; k < pieces.Count; k++)
                        {
                            Piece pc = pieces[k];
                            Point2d p0 = SRun(pc.P0[0], pc.P0[1]);
                            Point2d p1 = SRun(pc.P1[0], pc.P1[1]);
                            object startObj = (k == 0) ? (object)p0 : prevEnd;
                            object endObj = (k == pieces.Count - 1 && firstStart != null) ? firstStart : (object)p1;
                            if (pc.Arc)
                            {
                                SketchArc arc = sk.SketchArcs.AddByThreePoints(startObj, SRun(pc.Pm[0], pc.Pm[1]), endObj);
                                SketchPoint sa = arc.StartSketchPoint, sb = arc.EndSketchPoint;
                                bool aIsEnd = sa.Geometry.DistanceTo(p1) < sb.Geometry.DistanceTo(p1);
                                if (k == 0) firstStart = aIsEnd ? (object)sb : (object)sa;
                                prevEnd = aIsEnd ? (object)sa : (object)sb;
                            }
                            else
                            {
                                SketchLine ln = sk.SketchLines.AddByTwoPoints(startObj, endObj);
                                if (k == 0) firstStart = ln.StartSketchPoint;
                                prevEnd = ln.EndSketchPoint;
                            }
                        }

                        SketchLine axisLine = sk.SketchLines.AddByTwoPoints(
                            sk.ModelToSketchSpace(tg.CreatePoint(o[0], o[1], o[2])),
                            sk.ModelToSketchSpace(tg.CreatePoint(o[0] + u[0] * segHeight, o[1] + u[1] * segHeight, o[2] + u[2] * segHeight)));
                        axisLine.Construction = true;

                        Profile prof = sk.Profiles.AddForSolid();
                        double revs = segHeight / lead;
                        CoilFeature coil = def.Features.CoilFeatures.AddByPitchAndRevolution(
                            prof, axisLine, lead, revs,
                            PartFeatureOperationEnum.kCutOperation,
                            false, !p.RightHand, coilTaperAngle);
                        Affect(coil);
                        try { coil.Name = segTitle; } catch { }
                        created.Add(coil);
                        runoutCreated.Add(coil);
                        sk.Visible = false;
                    }
                }

                void AddRunout(string featureName, double zFrom, double zTo, double phaseOrigin, bool shallowerAtEnd)
                {
                    try
                    {
                        AddLoftRunout(
                            featureName, zFrom, zTo, phaseOrigin, shallowerAtEnd,
                            shallowerAtEnd && endSh);
                    }
                    catch (Exception loftEx)
                    {
                        // Keep the existing segmented fallback as a safety net in either mode.
                        // A failed experimental Loft must never make thread creation impossible.
                        string modeName = "Плавный сбег (резервный сегментный Coil при отказе Loft)";
                        string msg = modeName + ": Loft не принят Inventor, использован резервный сегментный режим. " + loftEx.Message;
                        LastWarning = string.IsNullOrEmpty(LastWarning) ? msg : LastWarning + "\n" + msg;
                        AddSegmentedRunoutCoil(featureName, zFrom, zTo, phaseOrigin, shallowerAtEnd);
                    }
                }

                if ((smoothEnd || smoothStart) && runLen > 1e-4)
                {
                    for (int i = 0; i < n; i++)
                    {
                        double phaseOrigin = startSh
                            ? offset + xwHalf0 * 1.02 + i * pitch
                            : mainStartBase - (n - 1 - i) * pitch;

                        if (smoothEnd)
                        {
                            double zB = smoothEndZ;
                            double zA = zB - runLen;
                            AddRunout("Резьба: плавный сбег в конце " + (i + 1) + "/" + n, zA, zB, phaseOrigin, true);
                        }

                        if (smoothStart)
                        {
                            double zA = threadStart;
                            double zB = zA + runLen;
                            AddRunout("Резьба: плавный сбег в начале " + (i + 1) + "/" + n, zA, zB, phaseOrigin, false);
                        }
                    }
                }

                // Keep the proven segmented run-out geometry, but hide its technical
                // WorkPlane/Sketch/Coil explosion in a dedicated browser folder. The run-out
                // folder is created even when general thread sorting is disabled, because these
                // are implementation details rather than user-level thread operations.
                var browserFolderTimer = Stopwatch.StartNew();
                BrowserNode afterMainFolder = browserAnchor;
                long folderPrepareMs = 0;
                if (p.SortThreadsIntoFolders)
                {
                    var folderPrepareTimer = Stopwatch.StartNew();
                    var mainCreated = new List<object>();
                    var runoutSet = new HashSet<object>(runoutCreated, new ReferenceComparer<object>());
                    for (int ci = 0; ci < created.Count; ci++)
                    {
                        object obj = created[ci];
                        if (!runoutSet.Contains(obj)) mainCreated.Add(obj);
                    }
                    folderPrepareTimer.Stop();
                    folderPrepareMs = folderPrepareTimer.ElapsedMilliseconds;

                    afterMainFolder = CreateThreadBrowserFolder(app, doc, browserPane, browserAnchor, mainCreated, p, n) ?? browserAnchor;
                }

                if (runoutCreated.Count > 0)
                {
                    string runoutName = ThreadFolderNamePolicy.BuildRunoutFolderName(p.SizeName, p.Starts, p.Standard);
                    CreateNamedBrowserFolder(app, doc, browserPane, afterMainFolder, runoutCreated, runoutName, true);
                }
                browserFolderTimer.Stop();

                string coreTiming = string.Format(
                    "Основная резьба: фаски/проточки/подготовка {0} мс; WorkPlane/Sketch/Profile {1} мс; Coil.Add {2} мс; прочее этапа {3} мс; всего этапа {4} мс. Подготовка группировки {5} мс; папки дерева {6} мс.",
                    preMainFeatureMs, mainSketchProfileMs, mainCoilAddMs, mainCoilOtherMs,
                    mainCoilStageMs, folderPrepareMs, browserFolderTimer.ElapsedMilliseconds);
                LastRunoutPerformance = string.IsNullOrWhiteSpace(LastRunoutPerformance)
                    ? coreTiming
                    : LastRunoutPerformance + "\n" + coreTiming;
                if (!string.IsNullOrWhiteSpace(LastBrowserFolderPerformance))
                    LastRunoutPerformance += "\n" + LastBrowserFolderPerformance;

                // Store a persistent, versioned record for the entire logical thread group.
                // The metadata is attached after geometry succeeds and remains inside the same
                // Inventor transaction, so Undo/Abort keeps geometry and tags consistent.
                // A tagging failure is non-fatal for ordinary modelling: the geometry remains
                // usable, but this build is deliberately not offered for editing later.
                string metadataThreadId;
                string metadataError;
                if (ThreadMetadataStore.TryAttach(created, p, t, out metadataThreadId, out metadataError, threadIdOverride))
                {
                    LastMetadataAttachSucceeded = true;
                    string summary = "ID " + metadataThreadId + "; объектов " + created.Count;
                    LastMetadataStatus = string.IsNullOrWhiteSpace(LastMetadataStatus)
                        ? summary
                        : LastMetadataStatus + " | " + summary;
                }
                else
                {
                    LastMetadataAttachSucceeded = false;
                    string metadataWarning = "Не удалось сохранить данные редактирования этой резьбы; геометрия построена, но автоматическое редактирование для неё будет недоступно. Причина: " + metadataError;
                    LastWarning = string.IsNullOrWhiteSpace(LastWarning)
                        ? metadataWarning
                        : LastWarning + "\n" + metadataWarning;
                    LastMetadataStatus = string.IsNullOrWhiteSpace(LastMetadataStatus)
                        ? "Метаданные не записаны: " + metadataError
                        : LastMetadataStatus + " | метаданные не записаны: " + metadataError;
                }

                if (tr != null)
                {
                    TransactionLifecycleDiagnostics.Write("ThreadBuilder.Build", "Transaction.End.before", app,
                        app.ActiveDocument as Inventor._Document, tr, false,
                        "threadIdOverride=" + (threadIdOverride ?? string.Empty));
                    tr.End();
                    TransactionLifecycleDiagnostics.Write("ThreadBuilder.Build", "Transaction.End.after", app,
                        app.ActiveDocument as Inventor._Document, tr, false,
                        "threadIdOverride=" + (threadIdOverride ?? string.Empty));
                }
                TransactionLifecycleDiagnostics.Write("ThreadBuilder.Build", "success", app,
                    app.ActiveDocument as Inventor._Document, tr, false,
                    "ownTransaction=" + ownTransaction + "; threadIdOverride=" + (threadIdOverride ?? string.Empty) +
                    "; createdCount=" + created.Count);
            }
            catch (Exception ex)
            {
                TransactionLifecycleDiagnostics.Write("ThreadBuilder.Build", "exception-before-Abort", app,
                    app.ActiveDocument as Inventor._Document, tr, true,
                    "ownTransaction=" + ownTransaction + "; threadIdOverride=" + (threadIdOverride ?? string.Empty) +
                    "; exception=" + ex);
                if (tr != null)
                {
                    try
                    {
                        tr.Abort();
                        TransactionLifecycleDiagnostics.Write("ThreadBuilder.Build", "Transaction.Abort.after", app,
                            app.ActiveDocument as Inventor._Document, tr, false, "result=success");
                    }
                    catch (Exception abortEx)
                    {
                        TransactionLifecycleDiagnostics.Write("ThreadBuilder.Build", "Transaction.Abort.failed", app,
                            app.ActiveDocument as Inventor._Document, tr, false, abortEx.ToString());
                        throw; // Preserve Fix37's behavior: a failed Abort escapes instead of the original exception.
                    }
                }
                throw;
            }
            return n;
        }
    }
}
