using System;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Windows.Forms;

namespace ThreadPro
{
    internal enum SectionGlyphKind
    {
        Target,
        Actions,
        Thread,
        Dimensions,
        Geometry
    }

    /// <summary>
    /// Decorative technical icons only; section numbering is intentionally absent from the current UI.
    /// The glyphs use distinct silhouettes (crosshair, sliders, thread teeth, dimension arrows,
    /// isometric block) and paint transparently so the header hatch continues behind the symbol.
    /// </summary>
    internal sealed class SectionGlyph : Control
    {
        private readonly SectionGlyphKind _kind;

        internal SectionGlyph(SectionGlyphKind kind)
        {
            _kind = kind;
            SetStyle(ControlStyles.UserPaint | ControlStyles.AllPaintingInWmPaint |
                     ControlStyles.OptimizedDoubleBuffer | ControlStyles.ResizeRedraw |
                     ControlStyles.SupportsTransparentBackColor, true);
            BackColor = Color.Transparent;
            ForeColor = HelivantaUiTheme.AccentHover;
            Margin = Padding.Empty;
            TabStop = false;
            AccessibleRole = AccessibleRole.Graphic;
            Size = new Size(24, 24);
            Text = string.Empty;
        }

        protected override void OnPaintBackground(PaintEventArgs e)
        {
            // Paint the same hatch phase as the parent header so lines continue beneath the icon.
            if (Parent is SectionHeaderPanel header)
            {
                header.PaintChildBackground(e.Graphics, ClientRectangle, Left, Top);
                return;
            }
            base.OnPaintBackground(e);
        }

        protected override void OnPaint(PaintEventArgs e)
        {
            Graphics g = e.Graphics;
            g.SmoothingMode = SmoothingMode.AntiAlias;
            g.PixelOffsetMode = PixelOffsetMode.HighQuality;
            g.CompositingQuality = CompositingQuality.HighQuality;
            Color color = SystemInformation.HighContrast ? SystemColors.Highlight : HelivantaUiTheme.AccentHover;
            using (var pen = new Pen(color, 1.65f))
            {
                pen.StartCap = LineCap.Flat;
                pen.EndCap = LineCap.Flat;
                pen.LineJoin = LineJoin.Miter;
                float side = Math.Min(ClientSize.Width, ClientSize.Height);
                float scale = side / 24f;
                if (scale <= 0f) return;
                float dx = (ClientSize.Width - 24f * scale) / 2f;
                float dy = (ClientSize.Height - 24f * scale) / 2f;
                GraphicsState state = g.Save();
                try
                {
                    g.TranslateTransform(dx, dy);
                    g.ScaleTransform(scale, scale);
                    switch (_kind)
                    {
                        case SectionGlyphKind.Target:
                            // Selection/focus reticle: four corner brackets and a diamond centre.
                            g.DrawLines(pen, new[] { new PointF(8, 4), new PointF(4, 4), new PointF(4, 8) });
                            g.DrawLines(pen, new[] { new PointF(16, 4), new PointF(20, 4), new PointF(20, 8) });
                            g.DrawLines(pen, new[] { new PointF(4, 16), new PointF(4, 20), new PointF(8, 20) });
                            g.DrawLines(pen, new[] { new PointF(16, 20), new PointF(20, 20), new PointF(20, 16) });
                            g.DrawPolygon(pen, new[] { new PointF(12, 8), new PointF(16, 12), new PointF(12, 16), new PointF(8, 12) });
                            break;
                        case SectionGlyphKind.Actions:
                            // Three control rails with square handles; no round endpoints.
                            g.DrawLine(pen, 3, 6, 21, 6);
                            g.DrawLine(pen, 3, 12, 21, 12);
                            g.DrawLine(pen, 3, 18, 21, 18);
                            g.DrawRectangle(pen, 7, 4, 4, 4);
                            g.DrawRectangle(pen, 14, 10, 4, 4);
                            g.DrawRectangle(pen, 5, 16, 4, 4);
                            break;
                        case SectionGlyphKind.Thread:
                            // Trapezoidal thread crest/root profile, unlike numerals or a rounded badge.
                            g.DrawLine(pen, 3, 18, 21, 18);
                            g.DrawLines(pen, new[] {
                                new PointF(3, 17), new PointF(6, 7), new PointF(9, 7),
                                new PointF(12, 17), new PointF(15, 17), new PointF(18, 7), new PointF(21, 7) });
                            g.DrawLine(pen, 3, 5, 21, 5);
                            break;
                        case SectionGlyphKind.Dimensions:
                            // Horizontal dimension with extension lines and inward-pointing arrowheads.
                            g.DrawLine(pen, 4, 4, 4, 20);
                            g.DrawLine(pen, 20, 4, 20, 20);
                            g.DrawLine(pen, 4, 12, 20, 12);
                            g.DrawLines(pen, new[] { new PointF(8, 9), new PointF(4, 12), new PointF(8, 15) });
                            g.DrawLines(pen, new[] { new PointF(16, 9), new PointF(20, 12), new PointF(16, 15) });
                            break;
                        default:
                            // Isometric solid block: no nested square/round motif that can read as 0/1.
                            g.DrawPolygon(pen, new[] {
                                new PointF(12, 3), new PointF(21, 8), new PointF(21, 17),
                                new PointF(12, 22), new PointF(3, 17), new PointF(3, 8) });
                            g.DrawLine(pen, 12, 3, 12, 12);
                            g.DrawLine(pen, 12, 12, 3, 8);
                            g.DrawLine(pen, 12, 12, 21, 8);
                            g.DrawLine(pen, 12, 12, 12, 22);
                            break;
                    }
                }
                finally { g.Restore(state); }
            }
        }
    }
}
