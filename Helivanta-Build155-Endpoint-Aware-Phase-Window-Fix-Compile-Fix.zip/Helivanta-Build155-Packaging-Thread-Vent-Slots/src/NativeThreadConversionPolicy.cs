﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Text.RegularExpressions;

namespace ThreadPro
{
    /// <summary>
    /// Pure mapping rules that translate a supported native Inventor thread definition to one
    /// of Helivanta's physical thread profiles. This does not edit an Inventor ThreadFeature.
    /// </summary>
    internal static class NativeThreadConversionPolicy
    {
        internal sealed class ProfileDefinition
        {
            internal ThreadStandard Standard;
            internal double DiameterMm;
            internal double PitchMm;
            internal int Starts;
        }

        internal static bool TryResolveProfile(string threadTypeIdentifier, string designation,
                                               string nominalSize, bool metric, double nativePitch,
                                               out ProfileDefinition definition, out string error)
        {
            definition = null;
            error = null;

            ThreadStandard standard;
            if (!TryResolveStandard(threadTypeIdentifier, designation, metric, out standard))
            {
                error = "Профиль штатной резьбы Inventor «" + (threadTypeIdentifier ?? "") +
                    "» не сопоставлен с поддерживаемыми профилями Helivanta (ISO, ANSI/UN, BSW, Tr, S, Rd). Операция Inventor не изменена.";
                return false;
            }

            bool expectsMetric = standard == ThreadStandard.ISO || standard == ThreadStandard.Tr ||
                                 standard == ThreadStandard.S || standard == ThreadStandard.Rd;
            if (metric != expectsMetric)
            {
                error = "Единицы штатной резьбы не соответствуют распознанному профилю Helivanta. Преобразование отклонено без изменения модели.";
                return false;
            }

            if (string.IsNullOrWhiteSpace(designation))
            {
                error = "Inventor не вернул обозначение штатной резьбы. Преобразование невозможно; операция не изменена.";
                return false;
            }

            if (!IsFinite(nativePitch) || nativePitch <= 0.0)
            {
                error = "Inventor вернул недопустимый шаг штатной резьбы. Операция не изменена.";
                return false;
            }

            double diameterMm;
            if (!TryParseNominalDiameter(nominalSize, designation, metric, out diameterMm) ||
                !IsFinite(diameterMm) || diameterMm <= 0.0)
            {
                error = "Не удалось однозначно определить номинальный диаметр из параметров штатной резьбы Inventor. Операция не изменена.";
                return false;
            }

            double pitchMm = metric ? nativePitch : nativePitch * 25.4;
            if (!IsFinite(pitchMm) || pitchMm <= 0.0)
            {
                error = "Шаг штатной резьбы не удалось перевести в миллиметры. Операция не изменена.";
                return false;
            }

            int starts = ResolveStartsFromDesignation(designation, metric, pitchMm);
            definition = new ProfileDefinition
            {
                Standard = standard,
                DiameterMm = diameterMm,
                PitchMm = pitchMm,
                Starts = starts
            };
            return true;
        }

        internal static bool TryResolveStandard(string threadTypeIdentifier, string designation,
                                                bool metric, out ThreadStandard standard)
        {
            string type = (threadTypeIdentifier ?? string.Empty).Trim().ToUpperInvariant();
            string callout = (designation ?? string.Empty).Trim().ToUpperInvariant();

            // Resolve the more specific profiles first: both use trapezoidal-ish or lettered
            // designations, so a generic metric fallback must not swallow them.
            if (ContainsAny(type, "DIN 405", "ROUND THREAD", "ROUNDED THREAD", "ROUND PROFILE") ||
                Regex.IsMatch(callout, @"^RD\s*\d", RegexOptions.IgnoreCase))
            {
                standard = ThreadStandard.Rd;
                return true;
            }
            if (ContainsAny(type, "DIN 513", "BUTTRESS", "SAW-TOOTH", "SAWTOOTH") ||
                Regex.IsMatch(callout, @"^S\s*\d+(?:[.,]\d+)?\s*(?:X|×)", RegexOptions.IgnoreCase))
            {
                standard = ThreadStandard.S;
                return true;
            }
            if (ContainsAny(type, "TRAPEZOID", "ISO 2901", "ISO 2902", "DIN 103") ||
                Regex.IsMatch(callout, @"^TR\s*\d", RegexOptions.IgnoreCase))
            {
                standard = ThreadStandard.Tr;
                return true;
            }
            if (ContainsAny(type, "WHITWORTH", "BSW", "BRITISH STANDARD WHITWORTH") ||
                Regex.IsMatch(callout, @"\bBSW\b", RegexOptions.IgnoreCase))
            {
                standard = ThreadStandard.BSW;
                return true;
            }
            if (ContainsAny(type, "UNIFIED", "ANSI UNIFIED", "UNIFIED SCREW") ||
                Regex.IsMatch(callout, @"\b(?:UNC|UNF|UNEF|UNS)\b", RegexOptions.IgnoreCase))
            {
                standard = ThreadStandard.ANSI;
                return true;
            }
            if (ContainsAny(type, "ANSI METRIC M PROFILE", "ISO METRIC", "METRIC PROFILE", "ISO 68", "ISO") ||
                Regex.IsMatch(callout, @"^M\s*\d", RegexOptions.IgnoreCase))
            {
                standard = ThreadStandard.ISO;
                return true;
            }

            // Do not guess an arbitrary metric sheet to be ISO. Some metric tables use
            // different profiles even though their pitch is expressed in millimetres.
            standard = ThreadStandard.ISO;
            return false;
        }

        internal static bool TryParseNominalDiameter(string nominalSize, string designation,
                                                     bool metric, out double diameterMm)
        {
            diameterMm = 0.0;
            string source = !string.IsNullOrWhiteSpace(nominalSize) ? nominalSize.Trim() : (designation ?? string.Empty).Trim();
            if (string.IsNullOrWhiteSpace(source)) return false;

            if (metric)
            {
                Match match = Regex.Match(source, @"(?<value>\d+(?:[.,]\d+)?)", RegexOptions.CultureInvariant);
                if (!match.Success && !string.IsNullOrWhiteSpace(designation))
                    match = Regex.Match(designation, @"^\s*(?:M|TR|RD|S)?\s*(?<value>\d+(?:[.,]\d+)?)", RegexOptions.IgnoreCase | RegexOptions.CultureInvariant);
                return match.Success && TryParseNumber(match.Groups["value"].Value, out diameterMm) && diameterMm > 0.0;
            }

            Match mixedFraction = Regex.Match(source, @"^\s*(?<whole>\d+)\s+(?<num>\d+)\s*/\s*(?<den>\d+)", RegexOptions.CultureInvariant);
            if (mixedFraction.Success)
            {
                double whole, numerator, denominator;
                if (!TryParseNumber(mixedFraction.Groups["whole"].Value, out whole) ||
                    !TryParseNumber(mixedFraction.Groups["num"].Value, out numerator) ||
                    !TryParseNumber(mixedFraction.Groups["den"].Value, out denominator) || denominator <= 0.0) return false;
                diameterMm = (whole + numerator / denominator) * 25.4;
                return diameterMm > 0.0;
            }

            Match fraction = Regex.Match(source, @"^\s*(?<num>\d+)\s*/\s*(?<den>\d+)", RegexOptions.CultureInvariant);
            if (fraction.Success)
            {
                double numerator, denominator;
                if (!TryParseNumber(fraction.Groups["num"].Value, out numerator) ||
                    !TryParseNumber(fraction.Groups["den"].Value, out denominator) || denominator <= 0.0) return false;
                diameterMm = numerator / denominator * 25.4;
                return diameterMm > 0.0;
            }

            Match numeric = Regex.Match(source, @"(?<value>\d+(?:[.,]\d+)?)", RegexOptions.CultureInvariant);
            double inches;
            if (!numeric.Success || !TryParseNumber(numeric.Groups["value"].Value, out inches) || inches <= 0.0) return false;
            diameterMm = inches * 25.4;
            return true;
        }

        internal static int ResolveStartsFromDesignation(string designation, bool metric, double pitchMm)
        {
            if (string.IsNullOrWhiteSpace(designation) || !IsFinite(pitchMm) || pitchMm <= 0.0) return 1;

            // Multi-start trapezoidal callouts commonly look like Tr30x6(P3): the lead is
            // 6 mm and the pitch is 3 mm, hence two starts. When the (P...) suffix is absent,
            // compare the lead with the actual StandardThreadInfo.Pitch supplied by the caller.
            // Do not interpret the 20 in 1/2-20 unified callouts as lead: imperial designations
            // have no X separator, so they do not enter this branch.
            Match match = Regex.Match(designation,
                @"(?:X|×)\s*(?<lead>\d+(?:[.,]\d+)?)(?:\s*\(\s*P\s*(?<pitch>\d+(?:[.,]\d+)?)\s*\))?",
                RegexOptions.IgnoreCase | RegexOptions.CultureInvariant);
            if (!match.Success) return 1;

            double lead;
            if (!TryParseNumber(match.Groups["lead"].Value, out lead) || lead <= 0.0) return 1;
            double explicitPitch = pitchMm;
            if (match.Groups["pitch"].Success &&
                !TryParseNumber(match.Groups["pitch"].Value, out explicitPitch)) return 1;
            if (explicitPitch <= 0.0) return 1;
            double ratio = lead / explicitPitch;
            int rounded = (int)Math.Round(ratio, MidpointRounding.AwayFromZero);
            if (rounded < 1 || rounded > 12 || Math.Abs(ratio - rounded) > 1e-3) return 1;
            return rounded;
        }

        /// <summary>
        /// Returns the number of real feature-history entries strictly after the selected entry.
        /// The selected feature itself and browser-only nodes are not counted. Returns -1 when
        /// the supplied history indices are invalid, so callers can fail closed.
        /// </summary>
        internal static int ResolveDownstreamOperationCount(int totalFeatureCount, int selectedFeatureIndex)
        {
            if (totalFeatureCount < 1 || selectedFeatureIndex < 0 || selectedFeatureIndex >= totalFeatureCount)
                return -1;
            return totalFeatureCount - selectedFeatureIndex - 1;
        }

        /// <summary>
        /// Converts optional native ThreadFeature length parameters into millimetres without
        /// dereferencing a missing COM Parameter. A missing ThreadDepth is valid only for a
        /// FullDepth operation, where axial length comes from the target cylinder. A missing
        /// ThreadOffset has the native semantic value zero.
        /// </summary>
        internal static bool TryResolveNativeThreadLengths(bool fullDepth,
                                                           bool hasDepthParameter, double depthCm,
                                                           bool hasOffsetParameter, double offsetCm,
                                                           double targetLengthCm,
                                                           out double depthMm, out double offsetMm,
                                                           out double lengthMm, out string error)
        {
            depthMm = 0.0;
            offsetMm = 0.0;
            lengthMm = 0.0;
            error = null;

            if (!IsFinite(targetLengthCm) || targetLengthCm <= 0.0)
            {
                error = "Длина исходной цилиндрической поверхности отсутствует или недопустима.";
                return false;
            }
            if (hasDepthParameter && (!IsFinite(depthCm) || depthCm < 0.0))
            {
                error = "Inventor вернул недопустимую глубину штатной резьбы.";
                return false;
            }
            if (!hasDepthParameter && !fullDepth)
            {
                error = "У ограниченной штатной резьбы отсутствует параметр ThreadDepth.";
                return false;
            }
            if (hasOffsetParameter && (!IsFinite(offsetCm) || offsetCm < 0.0))
            {
                error = "Inventor вернул недопустимое смещение штатной резьбы.";
                return false;
            }

            depthMm = hasDepthParameter ? depthCm * 10.0 : 0.0;
            offsetMm = hasOffsetParameter ? offsetCm * 10.0 : 0.0;
            lengthMm = fullDepth ? Math.Max(0.1, targetLengthCm * 10.0 - offsetMm) : depthMm;
            if (!IsFinite(depthMm) || !IsFinite(offsetMm) || !IsFinite(lengthMm) ||
                offsetMm < 0.0 || lengthMm <= 0.0)
            {
                error = "Длина или смещение штатной резьбы после перевода единиц недопустимы.";
                return false;
            }
            return true;
        }

        /// <summary>
        /// Infers the native thread's starting axial station when Inventor exposes no StartEdge.
        /// With the normal direction the start is the minimum station along the analytic cylinder axis;
        /// a reversed operation starts at the maximum station. Invalid/empty input fails closed.
        /// Values use Inventor database length units (centimetres).
        /// </summary>
        internal static bool ShouldReverseStartToPreferFreeEnd(bool startIsShoulder, bool endIsShoulder)
        {
            // If the native StartEdge sits at a shoulder while the opposite end is free,
            // start the physical Helivanta thread at that free end. If both ends have the
            // same topology (both shoulders or both free), the API's start remains authoritative.
            return startIsShoulder && !endIsShoulder;
        }

        internal static bool TryResolveStartStation(IList<double> axialStations, bool directionReversed,
                                                    out double startStation)
        {
            startStation = 0.0;
            if (axialStations == null || axialStations.Count == 0) return false;

            bool hasValue = false;
            double selected = 0.0;
            for (int i = 0; i < axialStations.Count; i++)
            {
                double value = axialStations[i];
                if (!IsFinite(value)) return false;
                if (!hasValue)
                {
                    selected = value;
                    hasValue = true;
                    continue;
                }
                if (directionReversed ? value > selected : value < selected) selected = value;
            }

            if (!hasValue) return false;
            startStation = selected;
            return true;
        }

        internal static double MillimetersToDatabaseCentimeters(double millimeters)
        {
            if (!IsFinite(millimeters)) throw new ArgumentOutOfRangeException(nameof(millimeters));
            return millimeters / 10.0;
        }

        internal static double DatabaseCentimetersToMillimeters(double centimeters)
        {
            if (!IsFinite(centimeters)) throw new ArgumentOutOfRangeException(nameof(centimeters));
            return centimeters * 10.0;
        }

        internal static bool NearlyEqual(double left, double right, double tolerance = 1e-7)
        {
            return IsFinite(left) && IsFinite(right) && Math.Abs(left - right) <= tolerance;
        }

        private static bool ContainsAny(string source, params string[] tokens)
        {
            foreach (string token in tokens)
                if (source.IndexOf(token, StringComparison.OrdinalIgnoreCase) >= 0) return true;
            return false;
        }

        private static bool TryParseNumber(string text, out double value)
        {
            value = 0.0;
            if (string.IsNullOrWhiteSpace(text)) return false;
            return double.TryParse(text.Replace(',', '.'), NumberStyles.Float, CultureInfo.InvariantCulture, out value) && IsFinite(value);
        }

        private static bool IsFinite(double value)
        {
            return !double.IsNaN(value) && !double.IsInfinity(value);
        }
    }
}
