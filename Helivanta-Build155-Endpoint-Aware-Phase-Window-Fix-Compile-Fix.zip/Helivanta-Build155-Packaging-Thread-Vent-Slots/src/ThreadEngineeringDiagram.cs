﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Globalization;
using System.Linq;
using System.Windows.Forms;

namespace ThreadPro
{
    /// <summary>Display-only snapshot of the current thread selection. It never drives CAD geometry.</summary>
    internal sealed class ThreadEngineeringDiagramState
    {
        public ThreadStandard Standard { get; set; } = ThreadStandard.ISO;
        public bool External { get; set; } = true;
        public bool Mirror { get; set; }
        public bool Tapered { get; set; }
        public bool RoundProfile { get; set; }
        public bool ChamferEnabled { get; set; }
        public string ChamferPosition { get; set; } = string.Empty;
        public double ChamferLengthMm { get; set; }
        // PreviewControlsDialog owns an external legend row; standalone Help diagrams keep theirs embedded.
        public bool ShowLegend { get; set; } = true;
        public bool TaperFreeGeometry { get; set; }
        public string TaperStandard { get; set; } = string.Empty;
        public string TaperDesignation { get; set; } = string.Empty;
        public string SizeName { get; set; } = string.Empty;
        public double DiameterMm { get; set; }
        public double PitchMm { get; set; }
        public double LengthMm { get; set; }
        public double OffsetMm { get; set; }
        public bool FullLength { get; set; }
        // Populated only after a non-transacting Inventor table lookup succeeded.
        // In cone mode these are the actual parameters that the preview/build pipeline resolved.
        public bool TaperResolved { get; set; }
        public double TaperDepthMm { get; set; }
        public double TaperStartDiameterMm { get; set; }
        public double TaperEndDiameterMm { get; set; }
        public double TaperHostLengthMm { get; set; }
        public double TaperRatio { get; set; } = 1.0 / 16.0;

        public string DisplayKey
        {
            get
            {
                return string.Join("|", ((int)Standard).ToString(CultureInfo.InvariantCulture), External ? "E" : "I",
                    Mirror ? "M" : "N", Tapered ? "T" : "C", RoundProfile ? "ROUND" : "SHARP",
                    ChamferEnabled ? "CHAMFER" : "NOCHAMFER", ChamferPosition ?? string.Empty,
                    ChamferLengthMm.ToString("R", CultureInfo.InvariantCulture), ShowLegend ? "LEGEND" : "NOLEGEND",
                    TaperFreeGeometry ? "FREE" : "STRICT",
                    TaperStandard ?? string.Empty, TaperDesignation ?? string.Empty,
                    SizeName ?? string.Empty, DiameterMm.ToString("R", CultureInfo.InvariantCulture),
                    PitchMm.ToString("R", CultureInfo.InvariantCulture), LengthMm.ToString("R", CultureInfo.InvariantCulture),
                    OffsetMm.ToString("R", CultureInfo.InvariantCulture), FullLength ? "FULL" : "FIXED",
                    TaperResolved ? "R" : "U", TaperDepthMm.ToString("R", CultureInfo.InvariantCulture),
                    TaperStartDiameterMm.ToString("R", CultureInfo.InvariantCulture),
                    TaperEndDiameterMm.ToString("R", CultureInfo.InvariantCulture),
                    TaperHostLengthMm.ToString("R", CultureInfo.InvariantCulture),
                    TaperRatio.ToString("R", CultureInfo.InvariantCulture));
            }
        }
    }

    /// <summary>
    /// DPI-aware engineering profile illustration. All graphics are explanatory only; this control
    /// does not create, modify, or validate Inventor geometry.
    /// </summary>
    internal sealed class ThreadEngineeringDiagram : Control
    {
        private ThreadEngineeringDiagramState _state = new ThreadEngineeringDiagramState();
        private string _stateKey = string.Empty;

        public ThreadEngineeringDiagram()
        {
            SetStyle(ControlStyles.UserPaint | ControlStyles.AllPaintingInWmPaint |
                     ControlStyles.OptimizedDoubleBuffer | ControlStyles.ResizeRedraw, true);
            BackColor = HelivantaUiTheme.Field;
            ForeColor = HelivantaUiTheme.Text;
            MinimumSize = new Size(240, 100);
            Margin = new Padding(0, 4, 0, 4);
            AccessibleRole = AccessibleRole.Graphic;
            AccessibleName = HelivantaLocalization.Translate("Инженерная схема выбранной резьбы" );
            AccessibleDescription = HelivantaLocalization.Translate("Схематический профиль выбранного стандарта. Показывает шаг P, угол, численную высоту, ширину вершины b или профильные радиусы, основные диаметры, закругление и состояние фаски. Размеры схематические и не являются производственным чертежом.");
        }

        public void SetState(ThreadEngineeringDiagramState state)
        {
            if (state == null) state = new ThreadEngineeringDiagramState();
            string key = state.DisplayKey;
            if (string.Equals(_stateKey, key, StringComparison.Ordinal)) return;
            _state = state;
            _stateKey = key;
            AccessibleName = HelivantaLocalization.Translate("Инженерная схема: " + (_state.Tapered ? GetTaperStandardTitle(_state.TaperStandard) : GetStandardName(_state.Standard)) +
                (_state.External ? ", наружная" : ", внутренняя") + (_state.Tapered ? ", коническая" : ", цилиндрическая"));
            Invalidate();
        }

        protected override void OnPaint(PaintEventArgs e)
        {
            base.OnPaint(e);
            Graphics g = e.Graphics;
            g.SmoothingMode = SmoothingMode.AntiAlias;
            g.TextRenderingHint = System.Drawing.Text.TextRenderingHint.ClearTypeGridFit;
            float scale = Math.Max(1f, DeviceDpi / 96f);
            Rectangle outer = new Rectangle(0, 0, Math.Max(0, Width - 1), Math.Max(0, Height - 1));
            if (outer.Width < 100 || outer.Height < 100) return;

            using (var background = new SolidBrush(HelivantaUiTheme.Field))
            using (var border = new Pen(HelivantaUiTheme.Border, Math.Max(1f, scale)))
            using (var grid = new Pen(Color.FromArgb(45, 75, 96), Math.Max(1f, scale)))
            using (var accent = new Pen(HelivantaUiTheme.Accent, Math.Max(1.8f, 2f * scale)))
            using (var profile = new Pen(Color.FromArgb(84, 205, 245), Math.Max(2f, 2.1f * scale)))
            using (var dimension = new Pen(HelivantaUiTheme.Warning, Math.Max(1.25f, 1.35f * scale)))
            using (var axis = new Pen(Color.FromArgb(143, 166, 185), Math.Max(1f, scale)))
            using (var mainText = new SolidBrush(HelivantaUiTheme.Text))
            using (var mutedText = new SolidBrush(HelivantaUiTheme.Muted))
            using (var accentText = new SolidBrush(Color.FromArgb(105, 204, 245)))
            using (var warningText = new SolidBrush(HelivantaUiTheme.Warning))
            using (var titleFont = new Font("Segoe UI", 10f, FontStyle.Bold, GraphicsUnit.Point))
            using (var labelFont = new Font("Segoe UI", 7.2f, FontStyle.Bold, GraphicsUnit.Point))
            using (var valueFont = new Font("Segoe UI", 9f, FontStyle.Bold, GraphicsUnit.Point))
            using (var smallFont = new Font("Segoe UI", 7.5f, FontStyle.Regular, GraphicsUnit.Point))
            using (var tinyFont = new Font("Segoe UI", 6.7f, FontStyle.Regular, GraphicsUnit.Point))
            {
                g.FillRectangle(background, outer);
                g.DrawRectangle(border, outer);
                int pad = Math.Max(11, (int)Math.Round(13 * scale));
                int headerHeight = Math.Max(34, (int)Math.Round(39 * scale));
                Rectangle header = new Rectangle(1, 1, outer.Width - 1, headerHeight);
                using (var headerBrush = new SolidBrush(HelivantaUiTheme.PanelSecondary)) g.FillRectangle(headerBrush, header);
                using (var accentBrush = new SolidBrush(HelivantaUiTheme.Accent)) g.FillRectangle(accentBrush, pad, 7, 3, Math.Max(15, headerHeight - 14));

                string standardTitle = _state.Tapered ? GetTaperStandardTitle(_state.TaperStandard) : GetStandardName(_state.Standard);
                string heading = HelivantaLocalization.Translate(standardTitle).ToUpperInvariant();
                g.DrawString(heading, titleFont, mainText, pad + 9, Math.Max(5, (headerHeight - titleFont.GetHeight(g)) / 2f));
                string kind = HelivantaLocalization.Translate(_state.External ? "НАРУЖНАЯ" : "ВНУТРЕННЯЯ");
                string mode = HelivantaLocalization.Translate(_state.Tapered ? "КОНИЧЕСКАЯ" : "ЦИЛИНДРИЧЕСКАЯ");
                string badgeText = kind + "  /  " + mode + (!_state.Tapered && _state.Standard == ThreadStandard.S && _state.Mirror ? "  /  " + HelivantaLocalization.Translate("ЗЕРКАЛО") : string.Empty);
                SizeF badgeSize = g.MeasureString(badgeText, labelFont);
                int badgeWidth = (int)Math.Ceiling(badgeSize.Width) + (int)(16 * scale);
                int badgeX = outer.Right - badgeWidth - pad;
                Rectangle badge = new Rectangle(Math.Max(pad + 95, badgeX), Math.Max(5, (headerHeight - (int)(21 * scale)) / 2),
                    Math.Max(86, Math.Min(badgeWidth, outer.Width / 2)), Math.Max(20, (int)(21 * scale)));
                // This badge repeats the thread kind already shown by the selected controls.
                // Keep it visually neutral; the preview's header must not introduce an amber accent.
                using (var badgeBrush = new SolidBrush(HelivantaUiTheme.PanelSecondary))
                using (var badgePen = new Pen(HelivantaUiTheme.Border, Math.Max(1f, scale)))
                using (var badgeTextBrush = new SolidBrush(HelivantaUiTheme.Muted))
                {
                    g.FillRectangle(badgeBrush, badge);
                    g.DrawRectangle(badgePen, badge);
                    g.DrawString(badgeText, labelFont, badgeTextBrush, badge.X + 7, badge.Y + (badge.Height - labelFont.GetHeight(g)) / 2f);
                }

                int contentTop = header.Bottom + Math.Max(8, (int)(10 * scale));
                if (_state.Tapered)
                {
                    // Match the cylindrical preview composition: profile occupies the broad left
                    // work area while table-derived values stay in a vertical panel on the right.
                    int gap = Math.Max(9, (int)(11 * scale));
                    int infoWidth = Math.Max(166, (int)(outer.Width * 0.315f));
                    int mainLeft = pad + 2;
                    int mainRight = outer.Right - pad - infoWidth - gap;
                    if (mainRight - mainLeft < 220)
                    {
                        infoWidth = Math.Max(145, outer.Width / 3);
                        mainRight = outer.Right - pad - infoWidth - gap;
                    }
                    int leftWidth = Math.Max(180, mainRight - mainLeft);
                    int taperHeight = Math.Max(68, (int)(74 * scale));
                    Rectangle taperSide = new Rectangle(mainLeft, contentTop, leftWidth, taperHeight);
                    DrawTaperSection(g, taperSide, scale, axis, dimension, mainText, mutedText, labelFont, smallFont);

                    int profileTitleTop = taperSide.Bottom + Math.Max(7, (int)(8 * scale));
                    int embeddedLegendHeight = _state.ShowLegend ? Math.Max(24, (int)(27 * scale)) : 0;
                    int profileBottom = outer.Bottom - pad - embeddedLegendHeight - Math.Max(5, (int)(6 * scale));
                    int plotTop = profileTitleTop + Math.Max(21, (int)(24 * scale));
                    Rectangle plot = new Rectangle(mainLeft, plotTop, leftWidth,
                        Math.Max(85, profileBottom - plotTop));
                    g.DrawString(HelivantaLocalization.Translate("ПРОФИЛЬ РЕЗЬБЫ · РАЗМЕРНЫЙ ЭСКИЗ"), labelFont, mutedText,
                        plot.X, profileTitleTop + 1);
                    if (_state.ShowLegend)
                        DrawFeatureLegend(g, Math.Max(plot.Left + 4, plot.Right - Math.Max(210, (int)(220 * scale))),
                            profileTitleTop + Math.Max(13, (int)(14 * scale)), plot.Right - 1, scale, tinyFont, mutedText);
                    DrawGrid(g, plot, grid, scale);
                    DrawProfile(g, plot, scale, profile, dimension, axis, mainText, warningText, labelFont, smallFont);

                    int legendReserve = _state.ShowLegend ? embeddedLegendHeight + Math.Max(3, (int)(4 * scale)) : 0;
                    Rectangle metrics = new Rectangle(mainRight + gap, contentTop, infoWidth,
                        Math.Max(100, outer.Bottom - pad - contentTop - legendReserve));
                    DrawTaperMetrics(g, metrics, scale, border, background, mainText, mutedText, valueFont, labelFont, smallFont);
                    if (_state.ShowLegend)
                    {
                        int legendY = outer.Bottom - pad - embeddedLegendHeight + Math.Max(2, (int)(3 * scale));
                        DrawLegend(g, pad, legendY, outer.Width - pad * 2, scale, profile, dimension, axis, tinyFont, mutedText);
                    }
                }
                else
                {
                    // The legend lives in the preview window's row under the transparency slider;
                    // using that row here gives both the profile and metric column more height.
                    int profileTop = contentTop + Math.Max(27, (int)(29 * scale));
                    int embeddedLegendHeight = _state.ShowLegend ? Math.Max(24, (int)(27 * scale)) : 0;
                    int profileBottom = outer.Bottom - pad - embeddedLegendHeight - Math.Max(5, (int)(6 * scale));
                    int infoWidth = Math.Max(145, (int)(outer.Width * 0.285f));
                    int mainLeft = pad + 2;
                    int gap = Math.Max(9, (int)(11 * scale));
                    int mainRight = outer.Right - pad - infoWidth - gap;
                    if (mainRight - mainLeft < 195)
                    {
                        infoWidth = Math.Max(125, outer.Width / 3);
                        mainRight = outer.Right - pad - infoWidth - gap;
                    }
                    Rectangle plot = new Rectangle(mainLeft, profileTop, Math.Max(160, mainRight - mainLeft), Math.Max(65, profileBottom - profileTop));
                    Rectangle info = new Rectangle(mainRight + gap, contentTop, infoWidth, Math.Max(100, profileBottom - contentTop));

                    g.DrawString(HelivantaLocalization.Translate("ПРОФИЛЬ РЕЗЬБЫ · РАЗМЕРНЫЙ ЭСКИЗ"), labelFont, mutedText, plot.X, contentTop + 2);
                    if (_state.ShowLegend)
                        DrawFeatureLegend(g, outer.Right - pad - Math.Max(260, (int)(276 * scale)), contentTop + 1,
                            outer.Right - pad, scale, tinyFont, mutedText);
                    DrawGrid(g, plot, grid, scale);
                    DrawProfile(g, plot, scale, profile, dimension, axis, mainText, warningText, labelFont, smallFont);
                    DrawMetrics(g, info, scale, border, background, mainText, mutedText, valueFont, labelFont, smallFont);
                    if (_state.ShowLegend)
                    {
                        int legendY = outer.Bottom - pad - embeddedLegendHeight + Math.Max(2, (int)(3 * scale));
                        DrawLegend(g, pad, legendY, outer.Width - pad * 2, scale, profile, dimension, axis, tinyFont, mutedText);
                    }
                }
            }
        }

        private void DrawGrid(Graphics g, Rectangle plot, Pen grid, float scale)
        {
            int step = Math.Max(12, (int)(18 * scale));
            for (int x = plot.Left; x <= plot.Right; x += step) g.DrawLine(grid, x, plot.Top + 2, x, plot.Bottom - 2);
            for (int y = plot.Top; y <= plot.Bottom; y += step) g.DrawLine(grid, plot.Left, y, plot.Right, y);
        }

        private void DrawProfile(Graphics g, Rectangle plot, float scale, Pen profile, Pen dimension, Pen axis,
            Brush mainText, Brush warningText, Font labelFont, Font smallFont)
        {
            if (_state.Tapered && (!_state.TaperResolved || _state.PitchMm <= 0.000001 || _state.TaperDepthMm <= 0.000001))
            {
                using (var card = new SolidBrush(HelivantaUiTheme.PanelSecondary))
                using (var outline = new Pen(HelivantaUiTheme.Border, Math.Max(1f, scale)))
                using (var placeholderTitle = new Font("Segoe UI", 9.2f, FontStyle.Bold, GraphicsUnit.Point))
                using (var placeholderText = new Font("Segoe UI", 8f, FontStyle.Regular, GraphicsUnit.Point))
                using (var muted = new SolidBrush(HelivantaUiTheme.Muted))
                {
                    g.FillRectangle(card, plot);
                    g.DrawRectangle(outline, plot);
                    string title = HelivantaLocalization.Translate("ОЖИДАЕТСЯ ТАБЛИЧНЫЙ ПРОФИЛЬ");
                    SizeF titleSize = g.MeasureString(title, placeholderTitle);
                    g.DrawString(title, placeholderTitle, mainText,
                        plot.Left + Math.Max(8, (plot.Width - titleSize.Width) / 2f), plot.Top + plot.Height * 0.34f);
                    string message = HelivantaLocalization.Translate("Выберите ребро и дождитесь обновления предпросмотра.");
                    SizeF messageSize = g.MeasureString(message, placeholderText);
                    g.DrawString(message, placeholderText, muted,
                        plot.Left + Math.Max(8, (plot.Width - messageSize.Width) / 2f), plot.Top + plot.Height * 0.34f + titleSize.Height + 7 * scale);
                }
                return;
            }

            ThreadProfileSpec spec = ThreadStandards.Spec(_state.Standard);
            double p = _state.PitchMm > 0.000001 ? _state.PitchMm : 1.0;
            double depth = _state.Tapered ? _state.TaperDepthMm : GetProfileDepth(spec, _state.External, p);
            double crest;
            double root;
            double threadAngle = spec.AngleDeg;
            if (_state.Tapered)
            {
                if (!TaperedThreadGeometryPolicy.TryGetThreadAngleDegrees(_state.TaperStandard, out threadAngle))
                    threadAngle = 60.0;
                // The tapered cutter uses a top opening of 0.962P. The displayed solid tooth is
                // its complement: a 0.038P crest land and a root land complementary to the table
                // depth / selected NPT (60°) or JIS Taper (55°) groove dimensions.
                double grooveTop, grooveRoot;
                string grooveError;
                if (TaperedThreadGeometryPolicy.TryGetPhysicalGrooveDimensionsMm(p, depth, threadAngle,
                    out grooveTop, out grooveRoot, out grooveError))
                {
                    crest = Math.Max(0.025, Math.Min(0.48, 1.0 - grooveTop / p));
                    root = Math.Max(0.04, Math.Min(0.90, 1.0 - grooveRoot / p));
                }
                else
                {
                    // Keep the profile's flank geometry tied to the selected included angle even
                    // if a nonstandard/free-height row cannot pass the strict cutter-width check.
                    // The width relation is b_root/P = 0.038 + 2*(h/P)*tan(alpha/2).
                    crest = 0.038;
                    root = 0.038 + 2.0 * (depth / p) * Math.Tan(threadAngle * Math.PI / 360.0);
                }
            }
            else
            {
                crest = _state.External ? spec.CrestFlatExt : spec.CrestFlatInt;
                root = GetRootFlat(spec, _state.Standard, _state.External);
                threadAngle = spec.AngleDeg;
            }
            if (_state.Tapered)
            {
                // Tapered top/root lands are derived independently from groove widths; preserve
                // their full table-derived range instead of applying cylindrical-flat clamps.
                crest = Math.Max(0.025, Math.Min(0.48, crest));
                root = Math.Max(0.04, Math.Min(0.975, root));
            }
            else
            {
                if (crest <= 0.01 || crest > 0.48) crest = 0.125;
                if (root <= 0.01 || root > 0.92) root = 0.25;
            }

            double angleLeft = 0.0, angleRight = 0.0;
            if (!_state.Tapered && _state.Standard == ThreadStandard.S)
            {
                angleLeft = spec.AngL > 0 ? spec.AngL : 30.0;
                angleRight = spec.AngR > 0 ? spec.AngR : 3.0;
                if (_state.Mirror)
                {
                    double angleSwap = angleLeft;
                    angleLeft = angleRight;
                    angleRight = angleSwap;
                }
            }

            int diameterColumn = Math.Max(34, (int)Math.Round(41 * scale));
            int topRoom = Math.Max(30, (int)Math.Round(34 * scale));
            float usableWidth = Math.Max(80f * scale, plot.Width - diameterColumn - 20f * scale);
            float pitchPx = Math.Max(18f * scale, usableWidth / 3.12f);
            double depthRatio = p > 0 ? depth / p : 0.6;
            // Keep the taper's flank angle true to the selected NPT 60° / JIS 55° profile.
            // In a short panel, reduce horizontal pitch before clipping tooth depth vertically.
            float maxDepthPx = Math.Max(25f * scale, plot.Height - topRoom - 22f * scale);
            if (_state.Tapered && depthRatio > 0.01)
            {
                float pitchForAvailableHeight = maxDepthPx / (float)depthRatio;
                pitchPx = Math.Min(pitchPx, Math.Max(18f * scale, pitchForAvailableHeight));
            }
            float profileLeft = plot.Left + diameterColumn;
            float depthPx = Math.Min((float)(pitchPx * Math.Max(0.15, depthRatio)), maxDepthPx);
            float verticalSlack = Math.Max(0f, plot.Height - topRoom - 22f * scale - depthPx);
            float yTop = plot.Top + topRoom + verticalSlack * 0.38f;
            float yBottom = yTop + depthPx;
            float crestPx = (float)crest * pitchPx;
            float rootPx = (float)root * pitchPx;

            // Diameter reference levels make the sketch read like an engineering drawing rather
            // than an unlabelled decorative waveform. They are reference lines, not a scale axis.
            float pitchLevel = yTop + depthPx * 0.52f;
            DrawDiameterReference(g, plot.Left + 2 * scale, profileLeft - 4 * scale, yTop,
                _state.External ? "d" : "D", smallFont, axis, mainText, scale);
            DrawDiameterReference(g, plot.Left + 2 * scale, profileLeft - 4 * scale, pitchLevel,
                _state.External ? "d₂*" : "D₂*", smallFont, axis, mainText, scale);
            DrawDiameterReference(g, plot.Left + 2 * scale, profileLeft - 4 * scale, yBottom,
                _state.External ? "d₃*" : "D₁*", smallFont, axis, mainText, scale);

            var points = new List<PointF>();
            if (_state.Tapered)
                BuildTaperedPoints(points, profileLeft, pitchPx, crestPx, rootPx, yTop, yBottom, 3.0f);
            else if (_state.Standard == ThreadStandard.S)
                BuildButtressPoints(points, profileLeft, pitchPx, crestPx, rootPx, yTop, yBottom, angleLeft, angleRight, 3.0f);
            else
                DrawFlatPoints(points, profileLeft, pitchPx, crestPx, rootPx, yTop, yBottom, 3.0f, 0f);

            // Diameter convention follows the selected thread side: for an internal thread the
            // major-diameter root lies opposite the minor-diameter crest. Reflect the profile
            // vertically so the d/D, d2/D2 and d3/D1 guide levels agree with the silhouette.
            if (!_state.External)
            {
                for (int i = 0; i < points.Count; i++)
                    points[i] = new PointF(points[i].X, yTop + yBottom - points[i].Y);
            }

            if (points.Count >= 2)
            {
                if (!_state.Tapered && _state.RoundProfile)
                {
                    double crestRadiusMm, rootRadiusMm;
                    ThreadStandards.Radii(_state.Standard, spec, _state.External, p, 1.0,
                        out crestRadiusMm, out rootRadiusMm);
                    float pixelsPerMm = Math.Min(pitchPx / Math.Max(0.000001f, (float)p),
                        depthPx / Math.Max(0.000001f, (float)depth));
                    using (var roundedPath = BuildRoundedPolyline(points, yTop, yBottom, _state.External,
                        crestRadiusMm * pixelsPerMm, rootRadiusMm * pixelsPerMm, scale))
                    {
                        if (roundedPath.PointCount >= 2) g.DrawPath(profile, roundedPath);
                        else g.DrawLines(profile, points.ToArray());
                    }
                }
                else
                {
                    using (var path = new GraphicsPath())
                    {
                        path.AddLines(points.ToArray());
                        g.DrawPath(profile, path);
                    }
                }
                DrawCrestRootFeatureLines(g, points, yTop, yBottom, _state.External, scale, _state.RoundProfile && !_state.Tapered);
                DrawProfileCallouts(g, plot, points, yTop, yBottom, p, spec, _state.External,
                    scale, dimension, warningText, smallFont);
            }
            using (var axisPen = (Pen)axis.Clone())
            {
                axisPen.DashPattern = new[] { 4f * scale, 3f * scale };
                g.DrawLine(axisPen, profileLeft - 4 * scale, yBottom + 8 * scale,
                    Math.Min(plot.Right - 2 * scale, profileLeft + pitchPx * 3f + 3 * scale), yBottom + 8 * scale);
            }

            // Pitch is measured between homologous crest locations, matching the selected profile.
            // The tapered tooth crest is centred within each pitch cell; cylindrical profile flats
            // retain their existing left-aligned convention.
            float firstCentre = _state.Tapered ? profileLeft + pitchPx / 2f : profileLeft + crestPx / 2f;
            float secondCentre = firstCentre + pitchPx;
            float dimY = plot.Top + Math.Max(22, (int)(24 * scale));
            DrawDimensionHorizontal(g, firstCentre, secondCentre, dimY, dimension, scale);
            float pitchTargetY = _state.External ? yTop : yBottom;
            g.DrawLine(dimension, firstCentre, dimY + 4 * scale, firstCentre, pitchTargetY - 2 * scale);
            g.DrawLine(dimension, secondCentre, dimY + 4 * scale, secondCentre, pitchTargetY - 2 * scale);
            string pitchLabel = _state.PitchMm > 0.000001 ? "P = " + Fmt(_state.PitchMm) + " " + HelivantaLocalization.Translate("мм") : "P";
            DrawCenteredLabel(g, pitchLabel, (firstCentre + secondCentre) / 2f,
                dimY - labelFont.GetHeight(g) - 2f * scale, labelFont, warningText, scale);

            float heightX = Math.Min(plot.Right - 9 * scale, profileLeft + pitchPx * 3.02f);
            DrawDimensionVertical(g, heightX, yTop, yBottom, dimension, scale);
            string depthSymbol = _state.Tapered ? "hₜ" :
                (_state.Standard == ThreadStandard.Tr || _state.Standard == ThreadStandard.S || _state.Standard == ThreadStandard.Rd
                    ? "H₁" : (_state.Standard == ThreadStandard.ISO && _state.External ? "h₃" : "h"));
            bool nominalH1DiffersFromDisplayedDepth = !_state.Tapered && spec.Trap && spec.H1 > 0.000001 &&
                Math.Abs(spec.H1 * p - depth) > Math.Max(0.0001, p * 0.002);
            string heightLabel = nominalH1DiffersFromDisplayedDepth ? "h" : depthSymbol;
            string heightText = depth > 0.000001
                ? heightLabel + " = " + Fmt(depth) + " " + HelivantaLocalization.Translate("мм")
                : heightLabel;
            g.DrawString(heightText, smallFont, warningText,
                heightX - g.MeasureString(heightText, smallFont).Width - 3 * scale,
                (yTop + yBottom) / 2f - smallFont.GetHeight(g) / 2f);

            string profileAngleLabel = _state.Tapered
                ? threadAngle.ToString("0.#", CultureInfo.InvariantCulture) + "°"
                : GetAngleLabel(spec, _state.Standard);
            if (!_state.Tapered && _state.Standard == ThreadStandard.S && _state.Mirror)
                profileAngleLabel = "3° / 30°";
            string angleText = (_state.Standard == ThreadStandard.S && !_state.Tapered ? "α₁/α₂ " : "α ") + profileAngleLabel;
            float angleX = Math.Min(plot.Right - 56 * scale, firstCentre + pitchPx * 0.72f);
            float angleY = yTop + depthPx * (_state.External ? 0.34f : 0.62f);
            RectangleF angleChip = new RectangleF(angleX - 3 * scale, angleY - 2 * scale,
                Math.Max(40 * scale, g.MeasureString(angleText, smallFont).Width + 8 * scale), smallFont.GetHeight(g) + 4 * scale);
            using (var chip = new SolidBrush(Color.FromArgb(238, HelivantaUiTheme.Field))) g.FillRectangle(chip, angleChip);
            g.DrawString(angleText, smallFont, warningText, angleChip.X + 3 * scale, angleChip.Y + 1 * scale);
        }

        private static GraphicsPath BuildRoundedPolyline(List<PointF> source, float yTop, float yBottom,
            bool external, double crestRadiusPx, double rootRadiusPx, float scale)
        {
            var path = new GraphicsPath();
            if (source == null || source.Count < 3) return path;
            var points = new List<PointF>(source.Count);
            foreach (PointF point in source)
            {
                if (points.Count == 0 || Distance(points[points.Count - 1], point) > 0.35f)
                    points.Add(point);
            }
            if (points.Count < 3) return path;

            var entry = new PointF[points.Count];
            var exit = new PointF[points.Count];
            var rounded = new bool[points.Count];
            entry[0] = exit[0] = points[0];
            entry[points.Count - 1] = exit[points.Count - 1] = points[points.Count - 1];

            for (int i = 1; i < points.Count - 1; i++)
            {
                PointF v = points[i], prev = points[i - 1], next = points[i + 1];
                double lenPrev = Distance(v, prev), lenNext = Distance(v, next);
                if (lenPrev < 0.5 || lenNext < 0.5) { entry[i] = exit[i] = v; continue; }
                double e1x = (prev.X - v.X) / lenPrev, e1y = (prev.Y - v.Y) / lenPrev;
                double e2x = (next.X - v.X) / lenNext, e2y = (next.Y - v.Y) / lenNext;
                double dot = Math.Max(-1.0, Math.Min(1.0, e1x * e2x + e1y * e2y));
                double phi = Math.Acos(dot);
                double tanHalf = Math.Tan(phi / 2.0);
                if (tanHalf <= 1e-5 || Math.Abs(Math.PI - phi) < 0.03)
                { entry[i] = exit[i] = v; continue; }
                bool nearTop = Math.Abs(v.Y - yTop) <= Math.Abs(v.Y - yBottom);
                bool actualCrest = external ? nearTop : !nearTop;
                double requestedRadius = actualCrest ? crestRadiusPx : rootRadiusPx;
                if (requestedRadius <= 0.75) { entry[i] = exit[i] = v; continue; }
                double tangentPerRadius = 1.0 / tanHalf;
                double maxTangent = Math.Min(lenPrev, lenNext) * 0.39;
                double radius = Math.Min(requestedRadius, maxTangent / Math.Max(1e-6, tangentPerRadius));
                double tangent = radius * tangentPerRadius;
                if (tangent < 0.75) { entry[i] = exit[i] = v; continue; }
                entry[i] = new PointF((float)(v.X + e1x * tangent), (float)(v.Y + e1y * tangent));
                exit[i] = new PointF((float)(v.X + e2x * tangent), (float)(v.Y + e2y * tangent));
                rounded[i] = true;
            }

            PointF cursor = points[0];
            path.StartFigure();
            for (int i = 1; i < points.Count - 1; i++)
            {
                if (rounded[i])
                {
                    if (Distance(cursor, entry[i]) > 0.2f) path.AddLine(cursor, entry[i]);
                    // A cubic with both controls at the vertex closely follows the tangent fillet,
                    // without requiring a platform-specific arc angle from a screen-space ellipse.
                    path.AddBezier(entry[i], points[i], points[i], exit[i]);
                    cursor = exit[i];
                }
                else
                {
                    if (Distance(cursor, points[i]) > 0.2f) path.AddLine(cursor, points[i]);
                    cursor = points[i];
                }
            }
            if (Distance(cursor, points[points.Count - 1]) > 0.2f)
                path.AddLine(cursor, points[points.Count - 1]);
            return path;
        }

        private static float Distance(PointF a, PointF b)
        {
            float dx = b.X - a.X, dy = b.Y - a.Y;
            return (float)Math.Sqrt(dx * dx + dy * dy);
        }

        private void DrawCrestRootFeatureLines(Graphics g, List<PointF> points, float yTop, float yBottom,
            bool external, float scale, bool rounded)
        {
            if (points == null || points.Count < 2) return;
            float crestY = external ? yTop : yBottom;
            float rootY = external ? yBottom : yTop;
            using (var crestPen = new Pen(Color.FromArgb(103, 211, 246), Math.Max(2f, 2.25f * scale)))
            using (var rootPen = new Pen(Color.FromArgb(99, 211, 164), Math.Max(2f, 2.1f * scale)))
            {
                for (int i = 0; i < points.Count - 1; i++)
                {
                    PointF a = points[i], b = points[i + 1];
                    if (Math.Abs(a.Y - b.Y) > 0.65f) continue;
                    float length = Math.Abs(b.X - a.X);
                    if (length < 4f * scale) continue;
                    bool crest = Math.Abs(a.Y - crestY) <= 1.2f * scale;
                    bool root = Math.Abs(a.Y - rootY) <= 1.2f * scale;
                    if (!crest && !root) continue;
                    float trim = rounded ? Math.Min(length * 0.45f, Math.Max(length * 0.35f, 1.5f * scale)) : 0.5f * scale;
                    float x1 = Math.Min(a.X, b.X) + trim;
                    float x2 = Math.Max(a.X, b.X) - trim;
                    if (x2 <= x1 + 0.5f) continue;
                    g.DrawLine(crest ? crestPen : rootPen, x1, (a.Y + b.Y) / 2f, x2, (a.Y + b.Y) / 2f);
                }
            }
        }

        private void DrawProfileCallouts(Graphics g, Rectangle plot, List<PointF> points, float yTop, float yBottom,
            double pitchMm, ThreadProfileSpec spec, bool external, float scale, Pen dimension,
            Brush warningText, Font smallFont)
        {
            if (points == null || points.Count < 2 || pitchMm <= 0.000001) return;
            float crestY = external ? yTop : yBottom;
            float rootY = external ? yBottom : yTop;
            var crestSegments = new List<Tuple<float, float>>();
            float rootStart = float.PositiveInfinity, rootEnd = float.NegativeInfinity;
            for (int i = 0; i < points.Count - 1; i++)
            {
                PointF a = points[i], b = points[i + 1];
                if (Math.Abs(a.Y - b.Y) > 0.65f) continue;
                float segmentStart = Math.Min(a.X, b.X), segmentEnd = Math.Max(a.X, b.X);
                float minCrestLandSpan = Math.Max(1f, scale);
                if (Math.Abs(a.Y - crestY) <= 1.2f * scale && segmentEnd - segmentStart > minCrestLandSpan)
                    crestSegments.Add(Tuple.Create(segmentStart, segmentEnd));
                if (Math.Abs(a.Y - rootY) <= 1.2f * scale && segmentEnd - segmentStart > rootEnd - rootStart)
                { rootStart = segmentStart; rootEnd = segmentEnd; }
            }

            // b belongs above a free crest land, not on a dimension line. The P dimension spans
            // the first two crest centres, so prefer the rightmost land away from the H dimension.
            bool hasCrestLandWidth = _state.Tapered ||
                (_state.Standard != ThreadStandard.BSW && _state.Standard != ThreadStandard.Rd);
            double flatFraction = _state.Tapered ? 0.038 :
                (external ? spec.CrestFlatExt : spec.CrestFlatInt);
            double bMm = flatFraction * pitchMm;
            if (hasCrestLandWidth && crestSegments.Count > 0)
            {
                float rightClearance = Math.Max(48f * scale, g.MeasureString("H₁ = 0,000 мм", smallFont).Width + 10f * scale);
                Tuple<float, float> freeLand = crestSegments
                    .Where(span => (span.Item1 + span.Item2) / 2f > plot.Left + plot.Width * 0.52f &&
                                   (span.Item1 + span.Item2) / 2f < plot.Right - rightClearance &&
                                   span.Item2 - span.Item1 >= Math.Max(1f, scale))
                    .OrderByDescending(span => (span.Item1 + span.Item2) / 2f)
                    .FirstOrDefault();
                if (freeLand == null)
                    freeLand = crestSegments.Where(span => span.Item2 - span.Item1 >= Math.Max(1f, scale))
                        .OrderByDescending(span => span.Item2 - span.Item1)
                        .ThenByDescending(span => (span.Item1 + span.Item2) / 2f).FirstOrDefault();
                if (freeLand != null)
                {
                    float centerX = (freeLand.Item1 + freeLand.Item2) / 2f;
                    string bLabel = "b = " + Fmt(bMm) + " " + HelivantaLocalization.Translate("мм");
                    float labelY = crestY - smallFont.GetHeight(g) - 4f * scale;
                    DrawCenteredLabel(g, bLabel, centerX, labelY, smallFont, warningText, scale);
                }
            }

            if (!_state.Tapered && _state.Standard == ThreadStandard.BSW && pitchMm > 0.000001)
            {
                double radius = 0.137329 * pitchMm;
                if (!float.IsInfinity(rootStart) && rootEnd > rootStart)
                {
                    float targetX = (rootStart + rootEnd) / 2f;
                    float targetY = rootY;
                    float labelX = Math.Min(plot.Right - 100 * scale, targetX + 8 * scale);
                    float labelY = external ? targetY - 18 * scale : targetY + 5 * scale;
                    using (var leader = new Pen(HelivantaUiTheme.Warning, Math.Max(1f, scale)))
                    {
                        g.DrawLine(leader, targetX, targetY, labelX + 2 * scale, labelY + smallFont.GetHeight(g) / 2f);
                        g.DrawString("R = " + Fmt(radius) + " " + HelivantaLocalization.Translate("мм"), smallFont, warningText, labelX, labelY);
                    }
                }
            }
            else if (!_state.Tapered && _state.Standard == ThreadStandard.Rd)
            {
                float crestStart = crestSegments.Count > 0 ? crestSegments.Min(x => x.Item1) : float.PositiveInfinity;
                float crestEnd = crestSegments.Count > 0 ? crestSegments.Max(x => x.Item2) : float.NegativeInfinity;
                if (!float.IsInfinity(crestStart) && crestEnd > crestStart)
                    g.DrawString("r₁", smallFont, warningText, crestStart + 2 * scale,
                        external ? crestY + 2 * scale : crestY - smallFont.GetHeight(g) - 2 * scale);
                if (!float.IsInfinity(rootStart) && rootEnd > rootStart)
                    g.DrawString("r₂", smallFont, warningText, rootStart + 2 * scale,
                        external ? rootY - smallFont.GetHeight(g) - 2 * scale : rootY + 2 * scale);
            }
        }

        private void DrawFeatureLegend(Graphics g, int x, int y, int right, float scale, Font font, Brush mutedText)
        {
            if (right - x < 160 * scale) return;
            float centerY = y + font.GetHeight(g) / 2f + 2f * scale;
            using (var crest = new Pen(Color.FromArgb(103, 211, 246), Math.Max(1.8f, 2f * scale)))
            using (var root = new Pen(Color.FromArgb(99, 211, 164), Math.Max(1.8f, 2f * scale)))
            using (var chamfer = new Pen(_state.ChamferEnabled ? HelivantaUiTheme.Warning : HelivantaUiTheme.Muted,
                Math.Max(1.6f, 1.8f * scale)))
            using (var text = new SolidBrush(_state.ChamferEnabled ? HelivantaUiTheme.Text : HelivantaUiTheme.Muted))
            {
                int lineW = Math.Max(12, (int)(14 * scale));
                float cx = x;
                g.DrawLine(crest, cx, centerY, cx + lineW, centerY);
                cx += lineW + 3 * scale;
                g.DrawString(HelivantaLocalization.Translate("ВЕРШИНА b"), font, mutedText, cx, y);
                cx += g.MeasureString(HelivantaLocalization.Translate("ВЕРШИНА b"), font).Width + 5 * scale;
                g.DrawLine(root, cx, centerY, cx + lineW, centerY);
                cx += lineW + 3 * scale;
                g.DrawString(HelivantaLocalization.Translate("ВПАДИНА"), font, mutedText, cx, y);
                cx += g.MeasureString(HelivantaLocalization.Translate("ВПАДИНА"), font).Width + 5 * scale;
                g.DrawLine(chamfer, cx, centerY + 2 * scale, cx + lineW * 0.55f, centerY - 3 * scale);
                g.DrawLine(chamfer, cx + lineW * 0.55f, centerY - 3 * scale, cx + lineW, centerY - 3 * scale);
                cx += lineW + 3 * scale;
                string label = _state.ChamferEnabled
                    ? HelivantaLocalization.Translate("ФАСКА") + " " + (_state.ChamferLengthMm > 0.0001 ? Fmt(_state.ChamferLengthMm) + " " + HelivantaLocalization.Translate("мм") : string.Empty)
                    : HelivantaLocalization.Translate("ФАСКА выкл.");
                g.DrawString(label, font, text, cx, y);
            }
        }

        private static void DrawDiameterReference(Graphics g, float x1, float x2, float y,
            string label, Font font, Pen axis, Brush text, float scale)
        {
            if (x2 <= x1 + 10 * scale) return;
            using (var guide = (Pen)axis.Clone())
            {
                guide.DashPattern = new[] { 3f * scale, 2f * scale };
                guide.Color = Color.FromArgb(115, axis.Color);
                g.DrawLine(guide, x1 + 23 * scale, y, x2, y);
            }
            g.DrawString(label, font, text, x1, y - font.GetHeight(g) / 2f);
        }

        private static Font CreateDpiCompensatedTableFont(Font source, float scale, float minimumPointSize)
        {
            if (source == null) throw new ArgumentNullException(nameof(source));
            // Build112 only used 1 / DPI compensation, which was not enough in Inventor's
            // hosted WinForms DPI context. Increase the compensation non-linearly starting
            // just above 100%, while keeping a role-specific floor for legibility.
            float safeScale = Math.Max(1f, scale);
            float compression = 1f + 3f * (safeScale - 1f);
            float pointSize = Math.Max(minimumPointSize, source.Size / compression);
            return new Font(source.FontFamily, pointSize, source.Style, GraphicsUnit.Point);
        }

        private static Font FitTableFontToHeight(Font source, Graphics g, float maxHeight, float minimumPointSize)
        {
            if (source == null) throw new ArgumentNullException(nameof(source));
            if (g == null) throw new ArgumentNullException(nameof(g));
            float available = Math.Max(1f, maxHeight);
            float measured = Math.Max(1f, source.GetHeight(g));
            float pointSize = source.Size;
            if (measured > available)
                pointSize = Math.Max(minimumPointSize, source.Size * (available / measured) * 0.92f);
            return new Font(source.FontFamily, pointSize, source.Style, GraphicsUnit.Point);
        }

        private void DrawMetrics(Graphics g, Rectangle info, float scale, Pen border, Brush background,
            Brush mainText, Brush mutedText, Font valueFont, Font labelFont, Font smallFont)
        {
            float tableScale = Math.Max(scale, g.DpiY / 96f);
            using (Font dpiValueFont = CreateDpiCompensatedTableFont(valueFont, tableScale, 4.0f))
            using (Font dpiLabelFont = CreateDpiCompensatedTableFont(labelFont, tableScale, 3.5f))
            using (Font dpiSmallFont = CreateDpiCompensatedTableFont(smallFont, tableScale, 3.6f))
            {
                using (var titleBrush = new SolidBrush(HelivantaUiTheme.PanelSecondary))
                using (var format = new StringFormat { Trimming = StringTrimming.EllipsisCharacter, FormatFlags = StringFormatFlags.NoWrap })
                {
                    g.FillRectangle(background, info);
                    int topH = Math.Max(24, (int)(28 * scale));
                    Rectangle title = new Rectangle(info.X, info.Y, info.Width, topH);
                    g.FillRectangle(titleBrush, title);
                    g.DrawRectangle(border, title);
                    g.DrawString(HelivantaLocalization.Translate("ОСНОВНЫЕ ПАРАМЕТРЫ"), dpiLabelFont, mainText, title.X + 7 * scale,
                        title.Y + (topH - dpiLabelFont.GetHeight(g)) / 2f);

                    ThreadProfileSpec spec = ThreadStandards.Spec(_state.Standard);
                    double p = _state.PitchMm;
                    double d = _state.DiameterMm;
                    double depth = p > 0 ? GetProfileDepth(spec, _state.External, p) : 0;
                    double minor = d > 0 && depth > 0 ? d - 2.0 * depth : 0;
                    double pitchDiameterOffset = GetPitchDiameterOffset(_state.Standard);
                    double pitchDiameter = d > 0 && p > 0 && pitchDiameterOffset > 0 ? d - pitchDiameterOffset * p : 0;
                    string angle = GetAngleLabel(spec, _state.Standard);
                    if (_state.Standard == ThreadStandard.S && _state.Mirror) angle = "3° / 30°";
                    double flat = _state.External ? spec.CrestFlatExt : spec.CrestFlatInt;
                    string diaMajorLabel = _state.External ? "НАРУЖНЫЙ ДИАМЕТР · d" : "НОМИНАЛЬНЫЙ ДИАМЕТР · D";
                    string diaMinorLabel = _state.External ? "МАЛЫЙ ДИАМЕТР · d₃*" : "МАЛЫЙ ДИАМЕТР · D₁*";
                    var metrics = new List<KeyValuePair<string, string>>();
                    metrics.Add(new KeyValuePair<string, string>(_state.Standard == ThreadStandard.S
                        ? "УГЛЫ ПРОФИЛЯ · α₁ / α₂" : "УГОЛ ПРОФИЛЯ · α", angle));
                    string heightMetricSymbol = _state.Standard == ThreadStandard.Tr || _state.Standard == ThreadStandard.S || _state.Standard == ThreadStandard.Rd
                        ? "H₁" : (_state.Standard == ThreadStandard.ISO && _state.External ? "h₃" : "h");
                    double nominalHeight = spec.Trap && spec.H1 > 0.000001 ? spec.H1 * p : depth;
                    metrics.Add(new KeyValuePair<string, string>("ВЫСОТА ПРОФИЛЯ · " + heightMetricSymbol,
                        p > 0 ? Fmt(nominalHeight) + " " + HelivantaLocalization.Translate("мм") : "не задана"));
                    if (_state.Standard == ThreadStandard.Rd)
                    {
                        double r1 = 0.23851 * p, r2 = 0.25597 * p;
                        metrics.Add(new KeyValuePair<string, string>("РАДИУСЫ Rd · r₁ / r₂",
                            p > 0 ? Fmt(r1) + " / " + Fmt(r2) + " " + HelivantaLocalization.Translate("мм") : (HelivantaUserSettings.Current.Language == "en" ? "0.23851 / 0.25597 P" : "0,23851 / 0,25597 P")));
                    }
                    else if (_state.Standard == ThreadStandard.BSW)
                        metrics.Add(new KeyValuePair<string, string>("РАДИУС ВИТВОРТА · R",
                            p > 0 ? (HelivantaUserSettings.Current.Language == "en" ? "0.137329P = " : "0,137329P = ") + Fmt(0.137329 * p) + " " + HelivantaLocalization.Translate("мм") : (HelivantaUserSettings.Current.Language == "en" ? "0.137329 P" : "0,137329 P")));
                    else
                        metrics.Add(new KeyValuePair<string, string>("ПЛОСКОСТЬ ВЕРШИНЫ · b",
                            p > 0 ? Fmt(flat * p) + " " + HelivantaLocalization.Translate("мм") : "по профилю"));
                    metrics.Add(new KeyValuePair<string, string>(diaMajorLabel, d > 0 ? "Ø " + Fmt(d) + " " + HelivantaLocalization.Translate("мм") : "не задан"));
                    metrics.Add(new KeyValuePair<string, string>(_state.External ? "СРЕДНИЙ ДИАМЕТР · d₂*" : "СРЕДНИЙ ДИАМЕТР · D₂*",
                        pitchDiameter > 0 ? "Ø " + Fmt(pitchDiameter) + " " + HelivantaLocalization.Translate("мм") : "по профилю"));
                    metrics.Add(new KeyValuePair<string, string>(diaMinorLabel, minor > 0 ? "Ø " + Fmt(minor) + " " + HelivantaLocalization.Translate("мм") : "схема"));
                    metrics.Add(new KeyValuePair<string, string>("ДЛИНА РЕЗЬБЫ · L", _state.FullLength
                        ? "вся доступная поверхность"
                        : (_state.LengthMm > 0.0001 ? Fmt(_state.LengthMm) + " " + HelivantaLocalization.Translate("мм") : "не задана")));
                    if (_state.OffsetMm > 0.0001)
                        metrics.Add(new KeyValuePair<string, string>("ОТСТУП ОТ РЕБРА · e", Fmt(_state.OffsetMm) + " " + HelivantaLocalization.Translate("мм")));
                    if (!string.IsNullOrWhiteSpace(_state.SizeName))
                        metrics.Add(new KeyValuePair<string, string>("ТИПОРАЗМЕР", HelivantaLocalization.Translate(_state.SizeName)));

                    int top = title.Bottom;
                    int availableH = Math.Max(1, info.Bottom - top);
                    int rowH = Math.Max(25, Math.Min((int)(41 * scale), availableH / Math.Max(1, metrics.Count)));
                    int row = 0;
                    foreach (var metric in metrics)
                    {
                        int y = top + row * rowH;
                        if (y + rowH > info.Bottom) break;
                        Rectangle box = new Rectangle(info.X, y, info.Width, rowH);
                        if (row % 2 == 0)
                        {
                            using (var alt = new SolidBrush(Color.FromArgb(28, HelivantaUiTheme.Panel)))
                                g.FillRectangle(alt, box);
                        }
                        g.DrawRectangle(border, box);
                        float horizontalPad = Math.Max(3f, 6f * scale);
                        float verticalPad = Math.Max(1f, 1.5f * scale);
                        float contentHeight = Math.Max(8f, box.Height - 2f * verticalPad);
                        float keyBandHeight = Math.Max(5f, contentHeight * 0.43f);
                        float valueBandHeight = Math.Max(5f, contentHeight - keyBandHeight);
                        float textWidth = Math.Max(8f, box.Width - 2f * horizontalPad);
                        GraphicsState cellState = g.Save();
                        g.SetClip(box, CombineMode.Intersect);
                        try
                        {
                            using (Font rowLabelFont = FitTableFontToHeight(dpiLabelFont, g, keyBandHeight, 3.3f))
                            {
                                RectangleF keyRect = new RectangleF(box.X + horizontalPad, box.Y + verticalPad,
                                    textWidth, keyBandHeight);
                                g.DrawString(HelivantaLocalization.Translate(metric.Key), rowLabelFont, mutedText, keyRect, format);
                            }

                            Font chosenValueFont = dpiValueFont;
                            if (g.MeasureString(HelivantaLocalization.Translate(metric.Value), chosenValueFont).Width > textWidth)
                                chosenValueFont = dpiSmallFont;
                            using (Font rowValueFont = FitTableFontToHeight(chosenValueFont, g, valueBandHeight, 3.4f))
                            {
                                RectangleF valueRect = new RectangleF(box.X + horizontalPad,
                                    box.Y + verticalPad + keyBandHeight, textWidth, valueBandHeight);
                                g.DrawString(HelivantaLocalization.Translate(metric.Value), rowValueFont, mainText, valueRect, format);
                            }
                        }
                        finally
                        {
                            g.Restore(cellState);
                        }
                        row++;
                    }
                }
            }
        }

        private void DrawTaperMetrics(Graphics g, Rectangle area, float scale, Pen border, Brush background,
            Brush mainText, Brush mutedText, Font valueFont, Font labelFont, Font smallFont)
        {
            float tableScale = Math.Max(scale, g.DpiY / 96f);
            using (Font dpiValueFont = CreateDpiCompensatedTableFont(valueFont, tableScale, 4.0f))
            using (Font dpiLabelFont = CreateDpiCompensatedTableFont(labelFont, tableScale, 3.5f))
            using (Font dpiSmallFont = CreateDpiCompensatedTableFont(smallFont, tableScale, 3.6f))
            using (var card = new SolidBrush(HelivantaUiTheme.Panel))
            using (var headerBrush = new SolidBrush(HelivantaUiTheme.PanelSecondary))
            using (var valueBrush = new SolidBrush(HelivantaUiTheme.Text))
            using (var keyBrush = new SolidBrush(HelivantaUiTheme.Muted))
            using (var format = new StringFormat { Trimming = StringTrimming.EllipsisCharacter, FormatFlags = StringFormatFlags.NoWrap })
            {
                double angle;
                if (!TaperedThreadGeometryPolicy.TryGetThreadAngleDegrees(_state.TaperStandard, out angle)) angle = 60.0;
                string designation = string.IsNullOrWhiteSpace(_state.TaperDesignation) ? HelivantaLocalization.Translate("не выбрано") : _state.TaperDesignation.Trim();
                string mode = HelivantaLocalization.Translate(_state.TaperFreeGeometry ? "свободная" : "по таблице");
                string unresolved = "—";
                double deltaD = _state.TaperResolved ? Math.Abs(_state.TaperEndDiameterMm - _state.TaperStartDiameterMm) : 0.0;
                double ratio = _state.TaperRatio > 0.000001 ? _state.TaperRatio : 1.0 / 16.0;
                var metrics = new List<KeyValuePair<string, string>>
                {
                    new KeyValuePair<string, string>("ТИПОРАЗМЕР / РЕЖИМ", designation + " · " + mode),
                    new KeyValuePair<string, string>("УГОЛ ПРОФИЛЯ · α", angle.ToString("0.#", CultureInfo.InvariantCulture) + "°"),
                    new KeyValuePair<string, string>("ВЫСОТА / ВЕРШИНА", _state.TaperResolved ? Fmt(_state.TaperDepthMm) + " " + HelivantaLocalization.Translate("мм") + " · " + Fmt(_state.PitchMm * 0.038) + " " + HelivantaLocalization.Translate("мм") : unresolved),
                    new KeyValuePair<string, string>("Ø НАЧАЛА → КОНЦА", _state.TaperResolved ? Fmt(_state.TaperStartDiameterMm) + " → " + Fmt(_state.TaperEndDiameterMm) + " " + HelivantaLocalization.Translate("мм") : unresolved),
                    new KeyValuePair<string, string>("КОНУСНОСТЬ / ΔD", "1:" + Math.Round(1.0 / ratio).ToString("0", CultureInfo.InvariantCulture) + (_state.TaperResolved ? " · " + Fmt(deltaD) + " " + HelivantaLocalization.Translate("мм") : " · ΔD —")),
                    new KeyValuePair<string, string>("ДЛИНА / ОТСТУП", _state.TaperResolved ? Fmt(_state.TaperHostLengthMm) + " " + HelivantaLocalization.Translate("мм") + " · " + Fmt(Math.Max(0.0, _state.OffsetMm)) + " " + HelivantaLocalization.Translate("мм") : unresolved)
                };

                int titleHeight = Math.Max(22, (int)(25 * scale));
                Rectangle title = new Rectangle(area.X, area.Y, area.Width, Math.Min(titleHeight, area.Height));
                g.FillRectangle(headerBrush, title);
                g.DrawRectangle(border, title);
                g.DrawString(HelivantaLocalization.Translate("КЛЮЧЕВЫЕ ПАРАМЕТРЫ"), dpiLabelFont, mainText,
                    title.X + Math.Max(5, 7 * scale), title.Y + (title.Height - dpiLabelFont.GetHeight(g)) / 2f);

                int rowsTop = title.Bottom;
                int available = Math.Max(metrics.Count * 24, area.Bottom - rowsTop);
                int rowHeight = Math.Max(24, available / metrics.Count);
                for (int i = 0; i < metrics.Count; i++)
                {
                    int y = rowsTop + i * rowHeight;
                    if (y >= area.Bottom) break;
                    int h = Math.Min(rowHeight, area.Bottom - y);
                    Rectangle cell = new Rectangle(area.X, y, area.Width, Math.Max(1, h));
                    g.FillRectangle(card, cell);
                    if (i % 2 == 0)
                    {
                        using (var alt = new SolidBrush(Color.FromArgb(22, HelivantaUiTheme.PanelSecondary))) g.FillRectangle(alt, cell);
                    }
                    g.DrawRectangle(border, cell);
                    float horizontalPad = Math.Max(3f, 5f * scale);
                    float verticalPad = Math.Max(1f, 2f * scale);
                    float textWidth = Math.Max(8f, cell.Width - 2f * horizontalPad);
                    float keyBandHeight = Math.Max(8f, Math.Min(cell.Height * 0.43f, dpiLabelFont.GetHeight(g) + 2f * scale));
                    GraphicsState state = g.Save();
                    g.SetClip(cell, CombineMode.Intersect);
                    try
                    {
                        using (Font rowLabelFont = FitTableFontToHeight(dpiLabelFont, g, keyBandHeight, 3.1f))
                        {
                            RectangleF keyRect = new RectangleF(cell.X + horizontalPad, cell.Y + verticalPad, textWidth, keyBandHeight);
                            g.DrawString(HelivantaLocalization.Translate(metrics[i].Key), rowLabelFont, keyBrush, keyRect, format);
                        }
                        Font chosen = dpiValueFont;
                        if (g.MeasureString(metrics[i].Value, chosen).Width > textWidth) chosen = dpiSmallFont;
                        using (Font rowValueFont = FitTableFontToHeight(chosen, g, Math.Max(8f, cell.Height - keyBandHeight - verticalPad), 3.2f))
                        {
                            RectangleF valueRect = new RectangleF(cell.X + horizontalPad, cell.Y + verticalPad + keyBandHeight,
                                textWidth, Math.Max(1f, cell.Height - keyBandHeight - verticalPad));
                            g.DrawString(HelivantaLocalization.Translate(metrics[i].Value), rowValueFont, valueBrush, valueRect, format);
                        }
                    }
                    finally { g.Restore(state); }
                }
            }
        }

        private void DrawTaperSection(Graphics g, Rectangle rect, float scale, Pen axis, Pen dimension,
            Brush mainText, Brush mutedText, Font labelFont, Font smallFont)
        {
            using (var panel = new SolidBrush(HelivantaUiTheme.PanelSecondary))
            using (var border = new Pen(HelivantaUiTheme.Border, Math.Max(1f, scale)))
            using (var taperPen = new Pen(Color.FromArgb(86, 202, 240), Math.Max(1.8f, 2f * scale)))
            {
                g.FillRectangle(panel, rect);
                g.DrawRectangle(border, rect);
                int left = rect.X + Math.Max(9, (int)(12 * scale));
                int right = rect.Right - Math.Max(12, (int)(14 * scale));
                g.DrawString(HelivantaLocalization.Translate("БОКОВОЙ ВИД КОНУСА"), labelFont, mainText, left, rect.Y + 4 * scale);

                int centerY = rect.Y + Math.Min(rect.Height - 12, Math.Max(38, (int)(43 * scale)));
                int lineStart = left + Math.Max(98, (int)(115 * scale));
                int lineEnd = right - Math.Max(100, (int)(116 * scale));
                if (lineEnd - lineStart < 110 * scale)
                {
                    // These coordinates are consumed by integer-based drawing overloads.
                    // Keep the DPI-scaled fallback coordinates integral explicitly.
                    lineStart = left + (int)(90 * scale);
                    lineEnd = right - (int)(86 * scale);
                }
                if (lineEnd <= lineStart + 30 * scale) return;

                double startD = _state.TaperResolved ? _state.TaperStartDiameterMm : 0.0;
                double endD = _state.TaperResolved ? _state.TaperEndDiameterMm : 0.0;
                double deltaD = startD > 0 && endD > 0 ? Math.Abs(endD - startD) : 0.0;
                float startHalf = 10.5f * scale;
                // Exaggerate the taper visually for legibility; show the real dimensions separately.
                float taperVisualDelta = 4.5f * scale;
                bool growsTowardEnd = _state.TaperResolved ? endD >= startD : _state.External;
                float endHalf = startHalf + (growsTowardEnd ? taperVisualDelta : -taperVisualDelta);
                endHalf = Math.Max(4.5f * scale, endHalf);

                using (var center = (Pen)axis.Clone())
                {
                    center.DashPattern = new[] { 4f * scale, 3f * scale };
                    g.DrawLine(center, lineStart - 3 * scale, centerY, lineEnd + 4 * scale, centerY);
                }
                g.DrawLine(taperPen, lineStart, centerY - startHalf, lineEnd, centerY - endHalf);
                g.DrawLine(taperPen, lineStart, centerY + startHalf, lineEnd, centerY + endHalf);
                g.DrawLine(taperPen, lineStart, centerY - startHalf, lineStart, centerY + startHalf);
                g.DrawLine(taperPen, lineEnd, centerY - endHalf, lineEnd, centerY + endHalf);

                float dimY = rect.Y + Math.Max(21, (int)(25 * scale));
                DrawDimensionHorizontal(g, lineStart, lineEnd, dimY, dimension, scale);
                string lengthLabel = _state.TaperResolved
                    ? "L = " + Fmt(_state.TaperHostLengthMm) + " " + HelivantaLocalization.Translate("мм")
                    : "L — длина конуса";
                DrawCenteredLabel(g, lengthLabel, (lineStart + lineEnd) / 2f,
                    dimY - smallFont.GetHeight(g) - 1.5f * scale, smallFont, mainText, scale);

                string leftDia = _state.TaperResolved ? "Ø" + Fmt(startD) : "Ø нач.";
                string rightDia = _state.TaperResolved ? "Ø" + Fmt(endD) : "Ø кон.";
                g.DrawString(leftDia, smallFont, mutedText, lineStart - g.MeasureString(leftDia, smallFont).Width - 5 * scale,
                    centerY - smallFont.GetHeight(g) / 2f);
                g.DrawString(rightDia, smallFont, mutedText, lineEnd + 5 * scale,
                    centerY - smallFont.GetHeight(g) / 2f);
                string taperNote = _state.TaperResolved
                    ? "ΔD = " + Fmt(deltaD) + " " + HelivantaLocalization.Translate("мм") + " · 1:" + Math.Round(1.0 / Math.Max(0.000001, _state.TaperRatio)).ToString("0", CultureInfo.InvariantCulture) +
                        (_state.TaperFreeGeometry ? " · " + HelivantaLocalization.Translate("свободная геометрия") : " · " + HelivantaLocalization.Translate("размеры таблицы")) + " · " + HelivantaLocalization.Translate("схема не в масштабе")
                    : HelivantaLocalization.Translate("Конусность 1:16 · размеры появятся после чтения таблицы Inventor");
                RectangleF noteRect = new RectangleF(left, rect.Bottom - smallFont.GetHeight(g) - 3 * scale,
                    Math.Max(40, rect.Width - 2 * (left - rect.X)), smallFont.GetHeight(g) + 2 * scale);
                using (var noteFormat = new StringFormat { Trimming = StringTrimming.EllipsisCharacter, FormatFlags = StringFormatFlags.NoWrap })
                    g.DrawString(taperNote, smallFont, mutedText, noteRect, noteFormat);
            }
        }

        private static void DrawLegend(Graphics g, int x, int y, int width, float scale,
            Pen profile, Pen dimension, Pen axis, Font font, Brush mutedText)
        {
            float cy = y + font.GetHeight(g) / 2f + 1f;
            int lineW = Math.Max(20, (int)(25 * scale));
            int gap = Math.Max(9, (int)(12 * scale));
            g.DrawLine(profile, x, cy, x + lineW, cy);
            g.DrawString(HelivantaLocalization.Translate("ПРОФИЛЬ"), font, mutedText, x + lineW + 4 * scale, y);
            int x2 = x + lineW + 4 * (int)scale + (int)g.MeasureString(HelivantaLocalization.Translate("ПРОФИЛЬ"), font).Width + gap;
            g.DrawLine(dimension, x2, cy, x2 + lineW, cy);
            g.DrawString(HelivantaLocalization.Translate("РАЗМЕРЫ"), font, mutedText, x2 + lineW + 4 * scale, y);
            int x3 = x2 + lineW + 4 * (int)scale + (int)g.MeasureString(HelivantaLocalization.Translate("РАЗМЕРЫ"), font).Width + gap;
            using (var dashed = (Pen)axis.Clone())
            {
                dashed.DashPattern = new[] { 3f * scale, 2f * scale };
                g.DrawLine(dashed, x3, cy, x3 + lineW, cy);
            }
            g.DrawString(HelivantaLocalization.Translate("ОСЬ"), font, mutedText, x3 + lineW + 4 * scale, y);
            string note = "* — ОЦЕНКА БАЗОВОГО ПРОФИЛЯ · БЕЗ ДОПУСКОВ";
            SizeF noteSize = g.MeasureString(note, font);
            if (x3 + lineW + noteSize.Width + 90 * scale < x + width)
                g.DrawString(note, font, mutedText, x + width - noteSize.Width, y);
        }

        private static void BuildTaperedPoints(List<PointF> points, float x, float pitch, float crestPx, float rootPx,
            float yTop, float yBottom, float periods)
        {
            // Here crestPx and rootPx are independent widths at different profile heights:
            // tooth crest = P - groove opening, tooth root = P - groove-root width. Do not add
            // them sequentially as if both occupied the same horizontal pitch interval; that
            // created near-vertical spikes in the earlier schematic.
            if (points == null || pitch <= 1f) return;
            float minLand = Math.Max(1f, pitch * 0.025f);
            crestPx = Math.Max(minLand, Math.Min(pitch * 0.25f, crestPx));
            rootPx = Math.Max(crestPx + minLand, Math.Min(pitch * 0.975f, rootPx));
            int count = Math.Max(1, (int)Math.Ceiling(periods));
            for (int i = 0; i < count; i++)
            {
                float cellLeft = x + i * pitch;
                float rootStart = cellLeft + (pitch - rootPx) / 2f;
                float crestStart = cellLeft + (pitch - crestPx) / 2f;
                float crestEnd = crestStart + crestPx;
                float rootEnd = rootStart + rootPx;
                if (i == 0) points.Add(new PointF(rootStart, yBottom));
                points.Add(new PointF(crestStart, yTop));
                points.Add(new PointF(crestEnd, yTop));
                points.Add(new PointF(rootEnd, yBottom));
                if (i < count - 1)
                {
                    float nextRootStart = cellLeft + pitch + (pitch - rootPx) / 2f;
                    points.Add(new PointF(nextRootStart, yBottom));
                }
            }
        }

        private static void DrawFlatPoints(List<PointF> points, float x, float pitch, float crestPx, float rootPx,
            float yTop, float yBottom, float periods, float rounding)
        {
            float depth = yBottom - yTop;
            float availableFlanks = Math.Max(1f, pitch - crestPx - rootPx);
            float flank = availableFlanks / 2f;
            if (rounding > 0.1f)
            {
                // BSW crest/root rounding is simplified as small softened corner transitions in this schematic.
                rounding = Math.Min(rounding, Math.Min(flank * 0.22f, depth * 0.08f));
            }
            points.Add(new PointF(x, yTop));
            int count = (int)Math.Ceiling(periods);
            for (int i = 0; i < count; i++)
            {
                float c = x + i * pitch;
                float crestStart = c;
                float crestEnd = c + crestPx;
                float rootStart = c + crestPx + flank;
                float rootEnd = rootStart + rootPx;
                float nextCrest = c + pitch;
                points.Add(new PointF(crestStart, yTop));
                points.Add(new PointF(crestEnd, yTop));
                if (rounding > 0.1f)
                {
                    points.Add(new PointF(crestEnd + rounding, yTop + rounding));
                    points.Add(new PointF(rootStart - rounding, yBottom - rounding));
                }
                points.Add(new PointF(rootStart, yBottom));
                points.Add(new PointF(rootEnd, yBottom));
                if (rounding > 0.1f)
                {
                    points.Add(new PointF(rootEnd + rounding, yBottom - rounding));
                    points.Add(new PointF(nextCrest - rounding, yTop + rounding));
                }
                points.Add(new PointF(nextCrest, yTop));
            }
        }

        private static void BuildButtressPoints(List<PointF> points, float x, float pitch, float crestPx, float rootPx,
            float yTop, float yBottom, double leftAngle, double rightAngle, float periods)
        {
            float depth = yBottom - yTop;
            double riseRun = depth * Math.Tan(Math.Max(0.1, leftAngle) * Math.PI / 180.0);
            double fallRun = depth * Math.Tan(Math.Max(0.1, rightAngle) * Math.PI / 180.0);
            double desired = crestPx + rootPx + riseRun + fallRun;
            double factor = desired > 0.05 ? pitch / desired : 1.0;
            crestPx = (float)(crestPx * factor);
            rootPx = (float)(rootPx * factor);
            float fallPx = (float)(fallRun * factor);
            points.Add(new PointF(x, yTop));
            int count = (int)Math.Ceiling(periods);
            for (int i = 0; i < count; i++)
            {
                float c = x + i * pitch;
                float crestEnd = c + crestPx;
                float rootStart = crestEnd + fallPx;
                float rootEnd = rootStart + rootPx;
                float nextCrest = c + pitch;
                points.Add(new PointF(c, yTop));
                points.Add(new PointF(crestEnd, yTop));
                points.Add(new PointF(rootStart, yBottom));
                points.Add(new PointF(rootEnd, yBottom));
                points.Add(new PointF(nextCrest, yTop));
            }
        }

        private static void BuildRoundedPoints(List<PointF> points, float x, float pitch, float yTop, float yBottom,
            float periods, float scale)
        {
            float depth = yBottom - yTop;
            int samplesPerPitch = Math.Max(18, (int)(28 * scale));
            int total = (int)Math.Ceiling(periods * samplesPerPitch);
            for (int i = 0; i <= total; i++)
            {
                float t = i / (float)samplesPerPitch;
                float fraction = t - (float)Math.Floor(t);
                float y = yTop + (float)((1.0 - Math.Cos(2.0 * Math.PI * fraction)) * 0.5 * depth);
                points.Add(new PointF(x + t * pitch, y));
            }
        }

        private static void DrawDimensionHorizontal(Graphics g, float x1, float x2, float y, Pen pen, float scale)
        {
            if (x2 <= x1 + 2) return;
            g.DrawLine(pen, x1, y - 3 * scale, x1, y + 4 * scale);
            g.DrawLine(pen, x2, y - 3 * scale, x2, y + 4 * scale);
            g.DrawLine(pen, x1, y, x2, y);
            DrawArrowHead(g, x1, y, 0f, pen, scale);
            DrawArrowHead(g, x2, y, 180f, pen, scale);
        }

        private static void DrawDimensionVertical(Graphics g, float x, float y1, float y2, Pen pen, float scale)
        {
            if (y2 <= y1 + 2) return;
            g.DrawLine(pen, x - 3 * scale, y1, x + 4 * scale, y1);
            g.DrawLine(pen, x - 3 * scale, y2, x + 4 * scale, y2);
            g.DrawLine(pen, x, y1, x, y2);
            DrawArrowHead(g, x, y1, 90f, pen, scale);
            DrawArrowHead(g, x, y2, 270f, pen, scale);
        }

        private static void DrawArrowHead(Graphics g, float x, float y, float angleDeg, Pen pen, float scale)
        {
            double a = angleDeg * Math.PI / 180.0;
            float len = 5f * scale;
            float x2 = x + (float)Math.Cos(a + 2.65) * len;
            float y2 = y + (float)Math.Sin(a + 2.65) * len;
            float x3 = x + (float)Math.Cos(a - 2.65) * len;
            float y3 = y + (float)Math.Sin(a - 2.65) * len;
            using (var head = new SolidBrush(pen.Color))
                g.FillPolygon(head, new[] { new PointF(x, y), new PointF(x2, y2), new PointF(x3, y3) });
        }

        private static void DrawCenteredLabel(Graphics g, string text, float centerX, float y, Font font, Brush brush, float scale)
        {
            SizeF size = g.MeasureString(text, font);
            float x = centerX - size.Width / 2f;
            using (var back = new SolidBrush(HelivantaUiTheme.Field)) g.FillRectangle(back, x - 2 * scale, y, size.Width + 4 * scale, size.Height);
            g.DrawString(text, font, brush, x, y);
        }

        private double GetProfileDepth(ThreadProfileSpec spec, bool external, double pitch)
        {
            if (pitch <= 0) return 0;
            double depth = (external ? spec.DepthExt : spec.DepthInt) * pitch;
            // Tr and buttress clearance affects the external groove depth in the actual profile builder.
            if (spec.Trap && (external ? spec.AddAcToExternalDepth : spec.AddAcToInternalDepth))
                depth += ThreadStandards.Ac(spec, pitch);
            return depth;
        }

        private static double GetPitchDiameterOffset(ThreadStandard standard)
        {
            // Basic-profile approximations for the reference (pitch) diameter. Actual table
            // values, tolerances, clearance and fit allowances are intentionally not implied.
            switch (standard)
            {
                case ThreadStandard.ISO:
                case ThreadStandard.ANSI: return 0.64952;
                case ThreadStandard.BSW: return 0.640327;
                case ThreadStandard.Tr: return 0.5;
                case ThreadStandard.S: return 0.75;
                case ThreadStandard.Rd: return 0.5;
                default: return 0.0;
            }
        }

        private static double GetRootFlat(ThreadProfileSpec spec, ThreadStandard standard, bool external)
        {
            switch (standard)
            {
                case ThreadStandard.Tr: return 0.36603;
                case ThreadStandard.S: return 0.26384;
                case ThreadStandard.Rd: return 0.24; // rounded form; flat is only a drawing anchor
                case ThreadStandard.BSW: return 1.0 / 6.0;
                default: return external ? 1.0 / 8.0 : 1.0 / 4.0;
            }
        }

        private static string GetAngleLabel(ThreadProfileSpec spec, ThreadStandard standard)
        {
            // Order follows the visible left/right flanks in the schematic; the S mirror switch swaps them.
            if (standard == ThreadStandard.S) return "30° / 3°";
            return spec.AngleDeg.ToString("0.#", CultureInfo.InvariantCulture) + "°";
        }

        private static string GetTaperStandardTitle(string standard)
        {
            if (string.Equals((standard ?? string.Empty).Trim(), "NPT", StringComparison.OrdinalIgnoreCase))
                return "NPT · 60°";
            if (string.Equals((standard ?? string.Empty).Trim(), "JIS Taper", StringComparison.OrdinalIgnoreCase))
                return "JIS TAPER · 55°";
            return string.IsNullOrWhiteSpace(standard) ? HelivantaLocalization.Translate("КОНИЧЕСКАЯ РЕЗЬБА") : standard.Trim() + " · " + HelivantaLocalization.Translate("КОНИЧЕСКАЯ");
        }

        private static string GetStandardName(ThreadStandard standard)
        {
            switch (standard)
            {
                case ThreadStandard.ISO: return HelivantaLocalization.Translate("ISO · метрическая");
                case ThreadStandard.BSW: return HelivantaLocalization.Translate("BSW · Витворта");
                case ThreadStandard.ANSI: return HelivantaLocalization.Translate("ANSI · UN / UNC / UNF");
                case ThreadStandard.Tr: return HelivantaLocalization.Translate("Tr · трапецеидальная");
                case ThreadStandard.S: return HelivantaLocalization.Translate("S · упорная");
                case ThreadStandard.Rd: return HelivantaLocalization.Translate("Rd · круглая");
                default: return HelivantaLocalization.Translate("РЕЗЬБА");
            }
        }

        private static string Fmt(double value) => value.ToString("0.###", CultureInfo.GetCultureInfo(HelivantaUserSettings.Current.Language == "en" ? "en-US" : "ru-RU"));
    }

}
