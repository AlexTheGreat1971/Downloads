﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.IO;
using System.Reflection;
using System.Linq;
using System.Windows.Forms;

namespace ThreadPro
{
    public sealed class HelpDialog : Form
    {
        private static Color UiSurface => HelivantaUiTheme.Surface;
        private static Color UiPanel => HelivantaUiTheme.Panel;
        private static Color UiHeader => HelivantaUiTheme.Header;
        private static Color UiField => HelivantaUiTheme.Field;
        private static Color UiText => HelivantaUiTheme.Text;
        private static Color UiMuted => HelivantaUiTheme.Muted;
        private static Color UiBorder => HelivantaUiTheme.Border;
        private static Color UiAccent => HelivantaUiTheme.Accent;
        private static Color UiAccentHover => HelivantaUiTheme.AccentHover;

        private Panel panel;
        private TableLayoutPanel content;
        private PictureBox _wordmarkPicture;

        private sealed class HelpArticleLabelTag
        {
            internal readonly string SourceText;
            internal readonly bool WrapsText;
            internal HelpArticleLabelTag(string sourceText, bool wrapsText)
            {
                SourceText = sourceText ?? string.Empty;
                WrapsText = wrapsText;
            }
        }

        // Remember Help window position/size only for the current add-in session.
        private static Rectangle _sessionBounds;
        private static bool _hasSessionBounds;
        private bool _restoringSessionBounds;
        private readonly System.Windows.Forms.Timer _layoutTimer;
        private bool _inSizing;

        private static readonly KeyValuePair<string, string>[] EnglishArticlePrefixes = new KeyValuePair<string, string>[]
        {
            new KeyValuePair<string, string>("Откройте деталь (.ipt)", "Open a part (.ipt) and click the Create Thread command on the Inventor ribbon. Select a circular edge where the thread should begin. You can select multiple edges with the same diameter and type; click a selected edge again to deselect it. Edges with incompatible diameters/types, or regions that overlap an existing thread, are rejected."),
            new KeyValuePair<string, string>("В секции «Тип резьбы»", "In Thread Type, choose external or internal, right-hand or left-hand, and a standard: ISO, BSW, ANSI, Tr, S, or Rd. For a tapered thread, enable “Tapered thread — prepare surface automatically”, then select NPT or JIS Taper and a tabulated designation. Changing the standard rebuilds the size list and pitch suggestions for that family. When editing an existing thread, its nominal diameter is preserved: if the new table has no exact row, the size is shown as Custom instead of being silently replaced with the nearest tabulated diameter. The closed Template field shows the confirmed standard used to build the thread. You can select a designation or enter diameter and pitch manually."),
            new KeyValuePair<string, string>("Типоразмер —", "Designation — standard combinations of nominal diameter and pitch. When an edge is selected, its diameter is preserved as the nominal diameter for both external and internal threads. If the selected standard has no matching nominal diameter, Custom is selected; the diameter is not automatically increased to the nearest tabulated size. For a custom diameter, the pitch list offers pitches from the active family and common metric values; manual input is also supported."),
            new KeyValuePair<string, string>("При построении внутренней резьбы", "When creating an internal thread, the original hole may first be filled with a ring of material up to the calculated minor diameter; the helical groove then forms the profile out to the nominal diameter. A warning describes a real body change, not a change to the nominal value displayed in the field. Process clearance is applied separately."),
            new KeyValuePair<string, string>("Тех. зазор —", "Process clearance — additional total radial clearance between mating physical surfaces. For 3D printing, it can compensate for shrinkage and process-specific effects. With clearance c, each side is offset by c/2; this is not an ISO 965 tolerance field and does not replace 6H/6g tolerance classes. Presets are available for metal (0 mm), resin (0.10 mm), SLS (0.15 mm), and FDM (0.30 mm). The committed technology remains visible after the list is closed and the dialog reopened, and its clearance is applied immediately. Other lets you enter a custom value."),
            new KeyValuePair<string, string>("Число заходов —", "Number of starts — the number of independent helical starts. This cylindrical parameter is hidden in tapered mode."),
            new KeyValuePair<string, string>("Длина резьбы —", "Thread length — the axial build length. When Full surface length is enabled, this field is disabled and the selected surface determines the length."),
            new KeyValuePair<string, string>("Отступ от ребра —", "Edge offset — distance from the selected start edge to the beginning of the working region."),
            new KeyValuePair<string, string>("Выход инструмента за деталь —", "Tool runout beyond part — allows the working geometry to extend past the far end of a cylindrical surface when appropriate for the part. This option is hidden in tapered mode."),
            new KeyValuePair<string, string>("Длина сбега, шагов —", "Runout length, pitches — the requested gradual fade-out length of the thread profile, measured in pitches. On a short surface, a safety limit may make the actual runout shorter than requested. The Information section reports the actual length, pitch count, and number of turns."),
            new KeyValuePair<string, string>("При включённой конической резьбе", "When tapered thread is enabled, Strict tapered-thread standard is available. Strict mode uses cone diameters from the Inventor table. Free mode preserves the original cylindrical surface diameter at the far end and calculates the diameter at the selected edge using a 1:16 taper, so that result is not claimed to comply with a published standard. Cylindrical features that do not apply to this build path are hidden; edge offset, runout, and chamfers remain available. Tapered-thread process clearance is zero. Only the smooth-runout mode is available. For tapered threads, Helivanta builds a Loft and, if Inventor rejects it, automatically attempts a segmented Coil fallback in the same transaction. Visually inspect the fallback result: its existence alone does not prove a perfectly smooth end. Processing time depends on thread size, runout length, and the number of Inventor operations. A safety policy may shorten the actual runout on a short surface."),
            new KeyValuePair<string, string>("Фаски включены по умолчанию", "Chamfers are enabled by default: position is At start and length is 1 mm. You can place a chamfer at the start, at the end, or at both ends, and set a different length. Clear the Chamfers checkbox to omit them. If Inventor cannot create a chamfer next to an existing fillet/chamfer, disable Chamfers and retry. If a chamfer is required, reduce its length or try the other end."),
            new KeyValuePair<string, string>("«Скруглять» добавляет", "Round profile adds fillets to the crests and roots. Mirror (for buttress threads) is available for standard S and reverses the asymmetric profile orientation. The static example below shows ISO M10×1.5 notation; the Preview Controls window displays the selected profile, dimensions, and NPT/JIS tapered table type when tapered mode is enabled."),
            new KeyValuePair<string, string>("«Сортировать резьбы по папкам» включён", "Sort threads into folders is enabled by default. The main features of each thread are grouped into a “Thread — …” folder. The folder name ends with its hand: Right (R) or Left (L); standard S also shows Direct profile or Mirrored profile. This helps verify buttress-thread orientation directly in the model browser. Technical features used for runout are placed in a separate collapsed “Runout — …” folder even when general sorting is disabled. The add-in attempts to group nodes in one batched Inventor API call; if that fails, it falls back to moving items one by one. Diagnostics report the actual grouping method and duration."),
            new KeyValuePair<string, string>("Кнопка «Предпросмотр» показывается", "The Preview button appears only after at least one valid circular edge has been selected in the active part; it disappears when the last edge is deselected by clicking it again, the selection is reset, or the active document changes. After each click, the selection handler clears Inventor’s temporary selection list and uses a separate Helivanta list, so another click immediately toggles the selection state. The preview displays a temporary translucent surface mesh and its contours in the Inventor model window. The color legend is in the compact Preview Controls window: cyan lines are thread crests, amber lines are roots, light lines mark the axial ends, and blue fill is the approximate surface. Legend lines are short and thick, with captions centered beneath them. The Phantom transparency slider controls only the temporary preview mesh from 0% to 100%; the default is 80%. It does not change the source body appearance or the saved geometry properties. Hide source body is enabled by default; it temporarily hides the selected body and restores its original visibility when preview is hidden. The Hide Preview button and the close button of Preview Controls perform the same action: hide the temporary graphics and stop refreshing them. Selected edges remain highlighted in Inventor and stay selected for Build; do not select them again. To show the preview again, click Preview in the main dialog. When Full surface length is enabled, the phantom uses all available length minus the edge offset. When it is disabled, the length comes directly from Thread length; the same axial length is used for contours and shaded mesh. The preview status reports the applied length. If the manual length is almost the same as the surface length, the phantom may look full length; reduce Thread length for a shorter preview. The mesh is approximate: it is generated from basic profile parameters and schematically displays the teeth and runout, but it does not reproduce exact fillets, chamfers, every flank surface, or final CAD B-rep geometry. Normal scene depth testing is retained, so real front-facing surfaces should remain visible. Preview does not create persistent features or change the model browser. It is cleared when parameters or selected edges change, when reset/build is clicked, when the main dialog closes, or when the active document changes. Enable Preview again after changing parameters. Use Build to create accurate geometry."),
            new KeyValuePair<string, string>("Построить — создаёт", "Build creates physical geometry for the selected threads. The cursor shows a busy indicator during the operation; wait for it to finish."),
            new KeyValuePair<string, string>("Отмена — пошагово", "Undo reverses the latest Helivanta build. Repeated clicks undo earlier builds from the current session."),
            new KeyValuePair<string, string>("Список занятых зон синхронизируется", "The list of occupied regions is synchronized with Inventor Undo/Redo. If a build is undone with Ctrl+Z, selecting the same edge after undo must not be blocked as if a thread still exists there; after Ctrl+Y, the region guard is restored."),
            new KeyValuePair<string, string>("Сброс — снимает", "Reset clears uncommitted edge selections and restores default parameters, including smooth runout and 1 mm chamfers at the start."),
            new KeyValuePair<string, string>("Выход — закрывает", "Exit closes the dialog; already-created geometry remains in the document."),
            new KeyValuePair<string, string>("Для резьбы Helivanta выберите", "For a Helivanta thread, select its entire “Thread — …” folder in the Inventor model browser (you do not need to expand it), select any object inside it, or run Edit Thread from the ribbon. Helivanta parameters are loaded from saved IPT metadata; the main button changes to Update, and after a successful edit the group retains its original ThreadId. Older groups without metadata are not guessed automatically. If there are downstream features in the history, a warning appears; the decision to continue or cancel remains with you. Replacement is transactional. If it fails, restoration of the original group is checked; if rollback is not confirmed, do not save the IPT and reopen the latest saved copy. Test this workflow on a copy first. For a native cylindrical Inventor thread, select the Inventor Thread feature in the model browser and run Edit Thread. The regular Helivanta dialog opens; after configuring pitch, starts, hand, length, offset, clearance, runout, fillets, and chamfers, Convert replaces the cosmetic Inventor thread with real Helivanta physical geometry through the standard build pipeline. This does not edit Inventor’s cosmetic-thread parameters. Tapered/unknown profiles, unit mismatches, and reversed feature direction are currently rejected without modifying the model. Conversion uses one transaction with a rollback attempt and a check that the original Inventor thread has been restored. If restoration is not confirmed, do not save the IPT. Test conversion on a copy first."),
            new KeyValuePair<string, string>("Поля выбора имеют графитовый фон", "Selection fields use a graphite background; the technology list uses the same surface as the other fields. The numeric ▲/▼ buttons are highlighted in the accent color and change the same values as the keyboard and direct input. Scrolling the mouse wheel over a closed selector or numeric field scrolls the main dialog instead of accidentally changing the value. When a list is open, the wheel again moves through its items. After building, the Information section shows the result, total duration, and key parameters without cluttering the window with technical timings. The full build log is stored at %LOCALAPPDATA%\\Helivanta\\Logs\\build-diagnostics.log. The active log and archives are limited to about 1 MB; up to four archives are kept per log, and archives older than 14 days are deleted. On failure, the UI shows a short hint rather than a long COM exception stack. If Inventor rejects a chamfer, disable Chamfers first; if a chamfer is needed, reduce its length or try the other end. For another cylindrical-thread geometry failure, try disabling Tool runout beyond part and Round profile one at a time, then reduce runout length. These cylindrical functions are hidden for tapered threads; do not bypass a minimum-wall-thickness warning. Full exception text and stack traces are saved to %LOCALAPPDATA%\\Helivanta\\Logs\\build-diagnostics.log. If an operation is marked No result, check the selected surface, length, chamfers, and runout; undo the latest build and retry after changing the parameters if needed.")
        };

        private static string TranslateArticleText(string text)
        {
            if (string.IsNullOrEmpty(text) || HelivantaUserSettings.Current.Language != "en")
                return text;

            bool bullet = text.StartsWith("• ", StringComparison.Ordinal);
            string body = bullet ? text.Substring(2) : text;
            foreach (KeyValuePair<string, string> pair in EnglishArticlePrefixes)
            {
                if (body.StartsWith(pair.Key, StringComparison.Ordinal))
                    return (bullet ? "• " : string.Empty) + pair.Value;
            }
            return HelivantaLocalization.Translate(text);
        }

        public HelpDialog()
        {
            Text = "Инструкция по использованию — Helivanta";
            FormBorderStyle = FormBorderStyle.Sizable;
            StartPosition = FormStartPosition.Manual;
            MaximizeBox = true;
            MinimizeBox = true;
            ShowInTaskbar = false;
            AutoScaleMode = AutoScaleMode.Dpi;
            Load += (sender, args) => RefreshLocalizationAndTheme();
            Activated += (sender, args) => RefreshLocalizationAndTheme();
            ClientSize = new Size(680, 620);
            MinimumSize = new Size(440, 440);
            Font = new Font("Segoe UI", 9f);
            BackColor = UiSurface;
            ForeColor = UiText;
            SetStyle(ControlStyles.OptimizedDoubleBuffer | ControlStyles.AllPaintingInWmPaint | ControlStyles.ResizeRedraw, true);
            DoubleBuffered = true;
            UpdateStyles();

            _layoutTimer = new System.Windows.Forms.Timer { Interval = 70 };
            _layoutTimer.Tick += (s, e) =>
            {
                _layoutTimer.Stop();
                if (!_inSizing && !IsDisposed) UpdateContentLayout();
            };
            try { Icon = LoadEmbeddedIcon(); } catch { }

            var root = new BufferedTableLayoutPanel
            {
                Dock = DockStyle.Fill,
                ColumnCount = 1,
                RowCount = 2,
                BackColor = UiSurface,
                Padding = new Padding(10, 8, 10, 8),
                Margin = Padding.Empty
            };
            root.RowStyles.Add(new RowStyle(SizeType.AutoSize));
            root.RowStyles.Add(new RowStyle(SizeType.Percent, 100f));
            Controls.Add(root);

            var header = new BufferedTableLayoutPanel
            {
                Dock = DockStyle.Fill,
                ColumnCount = 2,
                RowCount = 2,
                Height = 52,
                BackColor = UiSurface,
                Margin = new Padding(0, 0, 0, 6),
                Padding = Padding.Empty
            };
            header.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 150));
            header.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100f));
            header.RowStyles.Add(new RowStyle(SizeType.Absolute, 25));
            header.RowStyles.Add(new RowStyle(SizeType.Absolute, 24));

            var icon = _wordmarkPicture = new PictureBox
            {
                Dock = DockStyle.Fill,
                SizeMode = PictureBoxSizeMode.Zoom,
                BackColor = Color.Transparent,
                Margin = new Padding(0, 1, 8, 1)
            };
            try { icon.Image = LoadWordmarkForCurrentTheme(); } catch { }
            header.Controls.Add(icon, 0, 0);
            header.SetRowSpan(icon, 2);

            header.Controls.Add(new Label
            {
                Text = "Как пользоваться Helivanta",
                Dock = DockStyle.Fill,
                Font = new Font("Segoe UI Semibold", 11.5f, FontStyle.Bold),
                ForeColor = UiText,
                TextAlign = ContentAlignment.MiddleLeft,
                Margin = Padding.Empty,
                AutoEllipsis = true
            }, 1, 0);
            header.Controls.Add(new Label
            {
                Text = "Построение реальной геометрии резьбы в Autodesk Inventor 2027",
                Dock = DockStyle.Fill,
                ForeColor = UiMuted,
                TextAlign = ContentAlignment.MiddleLeft,
                Margin = Padding.Empty,
                AutoEllipsis = true
            }, 1, 1);
            root.Controls.Add(header, 0, 0);

            panel = new BufferedPanel
            {
                Dock = DockStyle.Fill,
                BackColor = UiPanel,
                BorderStyle = BorderStyle.None,
                AutoScroll = false,
                Padding = new Padding(10, 8, 10, 8),
                Margin = Padding.Empty
            };
            root.Controls.Add(panel, 0, 1);

            content = new BufferedTableLayoutPanel
            {
                Dock = DockStyle.Top,
                AutoSize = true,
                ColumnCount = 1,
                RowCount = 0,
                BackColor = UiPanel,
                Margin = Padding.Empty,
                Padding = Padding.Empty
            };
            content.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100f));
            panel.Controls.Add(content);

            AddHeading(content, "Выбор рёбер");
            AddText(content,
                "Откройте деталь (.ipt) и нажмите команду ленты «Создать резьбу». Выберите круговое ребро, от которого должна начинаться резьба. " +
                "Можно выбрать несколько рёбер одного диаметра и типа. Повторный щелчок по выбранному ребру снимает его выбор. " +
                "Рёбра с несовместимым диаметром/типом или зоны, перекрывающие уже построенную резьбу, не принимаются.");

            AddHeading(content, "Тип резьбы и направление");
            AddText(content,
                "В секции «Тип резьбы» выберите наружную или внутреннюю резьбу, правое или левое направление и стандарт: ISO, BSW, ANSI, Tr, S или Rd. Для конической резьбы включите отдельный флажок «Коническая резьба — подготовить поверхность автоматически», затем выберите NPT или JIS Taper и табличный типоразмер. " +
                "При переключении стандарта список размеров и подсказки шага перестраиваются под выбранное семейство. При редактировании существующей резьбы номинальный диаметр сохраняется: если точной строки для него в новой таблице нет, размер отображается как «Пользовательский», а не подменяется ближайшим табличным диаметром. Закрытое поле «Шаблон» показывает подтверждённый стандарт, используемый при построении. " +
                "Типоразмер можно выбрать из списка либо задать диаметр и шаг вручную.");

            AddHeading(content, "Размер и технологический зазор");
            AddBullet(content, "Типоразмер — стандартные сочетания номинального диаметра и шага. При выборе ребра его диаметр сохраняется как номинальный и для наружной, и для внутренней резьбы. Если в выбранном стандарте нет такого номинального диаметра, выбирается «Пользовательский» — диаметр не увеличивается автоматически до ближайшего табличного размера. Для пользовательского диаметра список шага предлагает шаги активного семейства и распространённые метрические значения; поле также допускает ручной ввод.");
            AddBullet(content, "При построении внутренней резьбы исходное отверстие может быть предварительно заполнено кольцом материала до расчётного малого диаметра, после чего винтовая канавка формирует профиль до номинального диаметра. Если показано предупреждение, оно описывает реальное изменение тела, а не изменение номинального значения в поле. Технический зазор применяется отдельно.");
            AddBullet(content, "Тех. зазор — дополнительный полный радиальный зазор между сопряжёнными физическими поверхностями. Для печати он может компенсировать усадку и особенности процесса. При зазоре c каждая сторона смещается на c/2; это не поле допуска ISO 965 и не заменяет классы 6H/6g. Для материалов доступны готовые значения: металл — 0 мм, смола — 0,10 мм, SLS — 0,15 мм, FDM — 0,30 мм. Подтверждённая технология остаётся отображённой после закрытия списка и повторного открытия диалога; соответствующий зазор применяется сразу. «Другое» позволяет задать значение вручную.");

            AddHeading(content, "Параметры построения");
            AddBullet(content, "Число заходов — количество независимых винтовых заходов. В коническом режиме этот цилиндрический параметр скрывается.");
            AddBullet(content, "Длина резьбы — осевая длина построения. При включённом «На всю длину поверхности» поле блокируется и длина определяется выбранной поверхностью.");
            AddBullet(content, "Отступ от ребра — расстояние от выбранного стартового ребра до начала рабочей зоны.");
            AddBullet(content, "Выход инструмента за деталь — разрешает выход рабочей геометрии за дальний конец цилиндрической поверхности, когда это допустимо для детали. В коническом режиме отдельная настройка скрывается.");
            AddBullet(content, "Длина сбега, шагов — заданная длина постепенного затухания профиля в шагах резьбы. Фактическая длина может быть меньше заданной на короткой поверхности, если срабатывает защитное ограничение. Значения в секции «Информация» показывают фактическую длину, число шагов и оборотов.");

            AddHeading(content, "Конический режим, плавный сбег и резервный механизм");
            AddText(content,
                "При включённой конической резьбе доступен флажок «Строго по стандарту конических резьб». Строгий режим использует диаметры конуса из таблицы Inventor; свободный режим сохраняет диаметр исходной цилиндрической поверхности на дальнем конце и рассчитывает диаметр у выбранного ребра по конусности 1:16, поэтому результат не заявляется как соответствующий стандарту. В коническом режиме скрываются цилиндрические функции, которые не применяются к этому пути построения; отступ, длина сбега и фаски остаются доступны. Технологический зазор конической резьбы равен нулю. " +
                "Используется один режим плавного сбега. Для конической резьбы Helivanta строит Loft и, если Inventor отклоняет операцию, автоматически пробует резервный сегментный Coil в той же транзакции. " +
                "Резервный результат нужно визуально проверить: его наличие само по себе не доказывает идеальную гладкость окончания. " +
                "Время зависит от размера резьбы, длины сбега и числа операций Inventor. На короткой поверхности защитная политика может уменьшить фактическую длину сбега.");
            AddHeading(content, "Фаски");
            AddText(content,
                "Фаски включены по умолчанию: расположение — «В начале», длина — 1 мм. Можно выбрать фаску в начале, в конце или с обоих краёв и задать другую длину. Снимите флажок «Фаски», чтобы не создавать их. " +
                "Если Inventor не может создать фаску рядом с уже существующим сопряжённым скруглением/фаской, отключите «Фаски» и повторите построение. Если фаска необходима, уменьшите её длину или попробуйте другой край.");

            AddHeading(content, "Форма профиля");
            AddText(content,
                "«Скруглять» добавляет скругления вершин и впадин. «Зеркально (для упорных резьб)» доступно для стандарта S и меняет ориентацию асимметричного профиля. Ниже дан статический пример обозначений ISO M10×1,5; окно «Управление предпросмотром» показывает уже выбранный профиль, размеры и тип конической таблицы NPT/JIS, когда соответствующий режим включён.");
            var helpDiagram = new ThreadEngineeringDiagram { Dock = DockStyle.Top, Height = 390 };
            helpDiagram.SetState(new ThreadEngineeringDiagramState
            {
                Standard = ThreadStandard.ISO,
                External = true,
                RoundProfile = true,
                SizeName = "Пример ISO M10×1,5",
                DiameterMm = 10.0,
                PitchMm = 1.5,
                LengthMm = 20.0
            });
            int diagramRow = content.RowCount++;
            content.RowStyles.Add(new RowStyle(SizeType.AutoSize));
            content.Controls.Add(helpDiagram, 0, diagramRow);

            AddHeading(content, "Сортировка дерева модели");
            AddText(content,
                "«Сортировать резьбы по папкам» включён по умолчанию. Основные операции каждой резьбы группируются в папку «Резьба — ...». В конце имени папки указывается направление: «Правая (R)» или «Левая (L)»; для стандарта S дополнительно показывается «Прямой профиль» или «Зеркальный профиль». Это обозначение помогает проверить ориентацию упорной резьбы прямо в дереве модели. " +
                "Технические операции, созданные для сбега, помещаются в отдельную свёрнутую папку «Сбег — ...» даже если общая сортировка выключена. " +
                "Плагин пытается группировать узлы одним пакетным вызовом API Inventor; при отказе используется резервное перемещение элементов по одному. Диагностика указывает фактический способ и время группировки.");

            AddHeading(content, "Предварительный просмотр");

            AddText(content,
                "Кнопка «Предпросмотр» показывается только после выбора хотя бы одного допустимого кругового ребра в активной детали и скрывается, когда снят выбор последнего ребра одним повторным щелчком, выбор сброшен или активный документ изменён. После каждого щелчка выборная система очищает собственный временный список Inventor и использует отдельный список Helivanta, поэтому повторный щелчок сразу переключает состояние. Она показывает в окне модели Inventor временную полупрозрачную сетку поверхности и контуры. Цветовая легенда находится в компактном окне «Управление предпросмотром»: голубые линии — вершины зубьев, янтарные — впадины, светлые — границы по длине, синяя заливка — приближённая поверхность. Линии легенды сделаны короче и толще, а подписи выровнены по центру под своими линиями. " +
                "Ползунок «Прозрачность фантома» задаёт прозрачность только временной сетки предпросмотра от 0% до 100%; по умолчанию — 80%. Он не меняет внешний вид исходного тела и не меняет свойства сохраняемой геометрии. Флажок «Скрывать исходное тело» по умолчанию включён; он временно скрывает выбранное тело и восстанавливает его исходную видимость при скрытии предпросмотра. " +
                "Кнопка «Скрыть предпросмотр» внутри окна управления и крестик этого окна выполняют одинаковое действие: скрывают временную графику и останавливают её обновление. При этом выбранные рёбра остаются визуально выделенными в Inventor и сохраняются для кнопки «Построить». Не нужно выбирать их повторно. Для повторного показа нажмите «Предпросмотр» в главном диалоге. " +
                "При включённом «На всю длину поверхности» фантом использует всю доступную длину за вычетом отступа. Когда флажок снят, длина берётся строго из поля «Длина резьбы»; эта же осевая длина используется для контуров и затенённой сетки. В статусе предпросмотра отображается применённая длина. Если ручная длина почти совпадает с длиной поверхности, фантом будет выглядеть почти полноразмерным — уменьшите значение «Длина резьбы». " +
                "Сетка приблизительная: она строится по основным параметрам профиля и схематично показывает форму зубьев и сбег, но не воспроизводит точные скругления, фаски, все боковые поверхности и итоговую CAD B-Rep-геометрию. Обычная проверка глубины сцены сохраняется, поэтому реальные передние поверхности должны оставаться видимыми. " +
                "Предпросмотр не создаёт постоянных операций и не изменяет дерево модели. Он очищается при изменении параметров или выбранных рёбер, сбросе, построении, закрытии главного диалога или переключении активного документа. После изменения параметров включите «Предпросмотр» ещё раз. Для создания точной геометрии используйте «Построить».");

            AddHeading(content, "Построение, отмена и сброс");
            AddBullet(content, "Построить — создаёт физическую геометрию выбранных резьб. Во время операции курсор показывает ожидание; дождитесь завершения.");
            AddBullet(content, "Отмена — пошагово отменяет последнее построение Helivanta. Повторные нажатия отменяют предыдущие построения текущей сессии.");
            AddText(content, "Список занятых зон синхронизируется и с командами Undo/Redo самого Inventor. Если построение отменено через Ctrl+Z, выбор того же ребра после отмены не должен блокироваться как уже имеющаяся резьба; после Ctrl+Y защита зоны восстанавливается.");
            AddBullet(content, "Сброс — снимает неподтверждённый выбор рёбер и возвращает параметры по умолчанию, включая плавный сбег и фаски 1 мм в начале.");
            AddBullet(content, "Выход — закрывает диалог; уже построенная геометрия остаётся в документе.");

            AddHeading(content, "Редактирование существующей резьбы");
            AddText(content,
                "Для резьбы Helivanta выберите целиком её папку «Резьба — …» в дереве модели Inventor (раскрывать папку не требуется), любой объект внутри неё или запустите команду ленты «Изменить резьбу». Параметры Helivanta загружаются из сохранённых метаданных IPT; основная кнопка окна меняется на «Обновить», а после успешного изменения группа сохраняет прежний ThreadId. Старые группы без метаданных автоматически не угадываются. Если ниже резьбы в истории есть другие операции, появится предупреждение; решение продолжать или отменить остаётся за пользователем. Замена выполняется транзакционно. При сбое проверяется восстановление исходной группы; если откат не подтверждён, не сохраняйте IPT и откройте последнюю сохранённую копию. Проверяйте процедуру сначала на копии детали. " +
                "Для штатной цилиндрической резьбы Inventor выберите в левом дереве построений операцию «Резьба Inventor» и запустите «Изменить резьбу». Откроется обычное окно Helivanta: после настройки шага, числа заходов, направления, длины, смещения, зазора, сбега, скруглений и фасок кнопка «Преобразовать» заменяет косметическую резьбу Inventor реальной физической геометрией Helivanta через штатный конвейер построения. Это не редактирование косметических параметров Inventor. Конические/неизвестные профили, несовпадение единиц и реверсированное направление операции пока отклоняются без изменения модели. Преобразование выполняется одной транзакцией с попыткой отката и проверкой восстановления исходной резьбы Inventor. Если восстановление не подтверждено, не сохраняйте IPT. Сначала проверяйте конвертацию на копии детали.");

            AddHeading(content, "Колёсико мыши и диагностика");
            AddText(content,
                "Поля выбора имеют графитовый фон; технологический список использует ту же поверхность, что и остальные поля. Кнопки ▲/▼ числовых параметров выделены янтарным цветом и изменяют то же значение, что клавиатура и прямой ввод. " +
                "Наведённое на закрытый список или числовое поле колёсико не меняет значение случайно: прокручивается основная область диалога. Когда список раскрыт, колёсико снова перемещает выбор по его вариантам. " +
                "После построения секция «Информация» показывает результат, общее время и основные параметры; подробные технические замеры не загромождают окно. " +
                "Полный журнал построений хранится в %LOCALAPPDATA%\\Helivanta\\Logs\\build-diagnostics.log. Активный файл и архивы ограничиваются примерно 1 МБ; для каждого лога сохраняется до четырёх архивов, архивы старше 14 дней удаляются. " +
                "При ошибке интерфейс показывает короткую подсказку, а не длинный стек COM-ошибки. Если Inventor отказал при создании фаски, сначала отключите «Фаски»; если фаска нужна — уменьшите длину или попробуйте другой край. " +
                "При другой геометрической ошибке цилиндрической резьбы попробуйте по очереди отключить «Выход инструмента за деталь» и «Скруглять», уменьшить длину сбега. Для конической резьбы эти цилиндрические функции скрыты; не пытайтесь обходить предупреждение о минимальной толщине стенки. " +
                "Полный текст исключения и стек вызовов сохраняются в %LOCALAPPDATA%\\Helivanta\\Logs\\build-diagnostics.log. Если операция помечена как «Без результата», проверьте выбранную поверхность, длину, фаски и сбег; при необходимости отмените последнее построение и повторите после изменения параметров.");

            // Footer removed: the article viewport now uses the full available height.

            Resize += (s, e) =>
            {
                if (!_restoringSessionBounds && WindowState == FormWindowState.Normal)
                    SaveSessionBounds();
                ScheduleContentLayout();
            };
            Move += (s, e) =>
            {
                if (!_restoringSessionBounds && WindowState == FormWindowState.Normal)
                    SaveSessionBounds();
            };
            DpiChanged += (s, e) => ScheduleContentLayout(true);
            Shown += (s, e) =>
            {
                RestoreSessionBounds();
                UpdateContentLayout();
            };
            FormClosed += (s, e) =>
            {
                _layoutTimer.Stop();
                _layoutTimer.Dispose();
                SaveSessionBounds();
            };
        }

        private void RefreshLocalizationAndTheme()
        {
            ApplyArticleLocalization();
            HelivantaLocalization.Apply(this);
            RefreshWordmarkForCurrentTheme();
            BackColor = UiSurface;
            ForeColor = UiText;
            if (panel != null) panel.BackColor = UiPanel;
            if (content != null) content.BackColor = UiPanel;
            if (IsHandleCreated) ScheduleContentLayout(true);
        }

        private void ApplyArticleLocalization()
        {
            if (content == null) return;
            foreach (Control control in content.Controls)
            {
                if (control is Label label && label.Tag is HelpArticleLabelTag tag)
                    label.Text = TranslateArticleText(tag.SourceText);
            }
        }

        private void RefreshWordmarkForCurrentTheme()
        {
            if (_wordmarkPicture == null || _wordmarkPicture.IsDisposed) return;
            Image next = null;
            try { next = LoadWordmarkForCurrentTheme(); } catch { }
            if (next == null) return;
            Image previous = _wordmarkPicture.Image;
            _wordmarkPicture.Image = next;
            if (previous != null) previous.Dispose();
            _wordmarkPicture.Invalidate();
        }

        protected override void WndProc(ref Message m)
        {
            const int WM_ENTERSIZEMOVE = 0x0231;
            const int WM_EXITSIZEMOVE = 0x0232;

            bool exitingSizeMove = m.Msg == WM_EXITSIZEMOVE;
            if (m.Msg == WM_ENTERSIZEMOVE)
            {
                _inSizing = true;
                _layoutTimer.Stop();
            }

            base.WndProc(ref m);

            if (exitingSizeMove)
            {
                _inSizing = false;
                ScheduleContentLayout(true);
            }
        }

        private void ScheduleContentLayout(bool immediate = false)
        {
            if (IsDisposed || _inSizing) return;
            _layoutTimer.Stop();
            if (immediate)
            {
                UpdateContentLayout();
                return;
            }
            _layoutTimer.Start();
        }

        private void SaveSessionBounds()
        {
            if (IsDisposed || WindowState != FormWindowState.Normal || Width <= 0 || Height <= 0) return;
            _sessionBounds = Bounds;
            _hasSessionBounds = true;
        }

        private void RestoreSessionBounds()
        {
            if (!_hasSessionBounds)
            {
                // First opening of the current session: keep the familiar centered placement.
                var owner = Owner as Form;
                if (owner != null)
                {
                    var wa = Screen.FromControl(owner).WorkingArea;
                    Location = new Point(
                        wa.Left + Math.Max(0, (wa.Width - Width) / 2),
                        wa.Top + Math.Max(0, (wa.Height - Height) / 2));
                }
                else
                {
                    var wa = Screen.PrimaryScreen.WorkingArea;
                    Location = new Point(
                        wa.Left + Math.Max(0, (wa.Width - Width) / 2),
                        wa.Top + Math.Max(0, (wa.Height - Height) / 2));
                }
                SaveSessionBounds();
                return;
            }

            _restoringSessionBounds = true;
            try
            {
                var saved = _sessionBounds;
                var screen = Screen.AllScreens
                    .OrderByDescending(s => s.WorkingArea.IntersectsWith(saved))
                    .ThenBy(s => Math.Abs(s.WorkingArea.Left - saved.Left) + Math.Abs(s.WorkingArea.Top - saved.Top))
                    .FirstOrDefault() ?? Screen.PrimaryScreen;

                var wa = screen.WorkingArea;
                int width = Math.Max(MinimumSize.Width, Math.Min(saved.Width, wa.Width));
                int height = Math.Max(MinimumSize.Height, Math.Min(saved.Height, wa.Height));
                int x = Math.Max(wa.Left, Math.Min(saved.Left, wa.Right - width));
                int y = Math.Max(wa.Top, Math.Min(saved.Top, wa.Bottom - height));

                ClientSize = new Size(
                    Math.Min(width, wa.Width),
                    Math.Min(height, wa.Height));
                Location = new Point(x, y);
            }
            finally
            {
                _restoringSessionBounds = false;
            }
        }

        private void UpdateContentLayout()
        {
            if (IsDisposed || panel == null || content == null) return;

            int viewportHeight = Math.Max(1, panel.ClientSize.Height - panel.Padding.Vertical);
            int fullWidth = Math.Max(120, panel.ClientSize.Width - panel.Padding.Horizontal);
            int widthWithVScroll = Math.Max(120, fullWidth - SystemInformation.VerticalScrollBarWidth - 2);

            panel.SuspendLayout();
            content.SuspendLayout();
            try
            {
                bool previousAutoScroll = panel.AutoScroll;
                panel.AutoScroll = false;
                content.Width = fullWidth;
                ApplyTextWidths(fullWidth);
                content.PerformLayout();
                int preferredHeight = content.GetPreferredSize(new Size(fullWidth, 0)).Height;
                bool needVertical = preferredHeight > viewportHeight;

                int targetWidth = needVertical ? widthWithVScroll : fullWidth;
                if (content.Width != targetWidth)
                {
                    content.Width = targetWidth;
                    ApplyTextWidths(targetWidth);
                    content.PerformLayout();
                }
                if (previousAutoScroll != needVertical)
                    panel.AutoScroll = needVertical;
                else
                    panel.AutoScroll = needVertical;

                panel.HorizontalScroll.Enabled = false;
            }
            finally
            {
                content.ResumeLayout(true);
                panel.ResumeLayout(true);
            }
        }

        private void ApplyTextWidths(int availableWidth)
        {
            int width = Math.Max(80, availableWidth - 8);
            foreach (Control c in content.Controls)
            {
                if (c is Label label && label.Tag is HelpArticleLabelTag articleTag && articleTag.WrapsText)
                    label.MaximumSize = new Size(width, 0);
            }
        }

        private static void AddHeading(TableLayoutPanel panel, string text)
        {
            int row = panel.RowCount++;
            var label = new Label
            {
                Text = TranslateArticleText(text),
                Tag = new HelpArticleLabelTag(text, false),
                AutoSize = true,
                Dock = DockStyle.Fill,
                ForeColor = UiText,
                BackColor = UiHeader,
                Font = new Font("Segoe UI Semibold", 9.5f, FontStyle.Bold),
                Padding = new Padding(7, 4, 7, 4),
                Margin = new Padding(0, 7, 0, 3)
            };
            panel.RowStyles.Add(new RowStyle(SizeType.AutoSize));
            panel.Controls.Add(label, 0, row);
        }

        private static void AddText(TableLayoutPanel panel, string text)
        {
            int row = panel.RowCount++;
            var label = new Label
            {
                Text = TranslateArticleText(text),
                Tag = new HelpArticleLabelTag(text, true),
                AutoSize = true,
                Dock = DockStyle.Fill,
                MaximumSize = new Size(600, 0), // recalculated on resize
                ForeColor = UiText,
                BackColor = UiPanel,
                Margin = new Padding(4, 0, 4, 3),
                Padding = new Padding(2, 0, 2, 0),
            };
            panel.RowStyles.Add(new RowStyle(SizeType.AutoSize));
            panel.Controls.Add(label, 0, row);
        }

        private static void AddBullet(TableLayoutPanel panel, string text)
        {
            AddText(panel, "• " + text);
        }

        private sealed class BufferedPanel : Panel
        {
            public BufferedPanel()
            {
                SetStyle(ControlStyles.UserPaint | ControlStyles.AllPaintingInWmPaint |
                          ControlStyles.OptimizedDoubleBuffer | ControlStyles.ResizeRedraw, true);
                DoubleBuffered = true;
            }
        }

        protected override CreateParams CreateParams
        {
            get
            {
                var cp = base.CreateParams;
                // Buffer the entire WinForms hierarchy during live resizing to prevent
                // flicker and transient blank areas in the text/layout controls.
                cp.ExStyle |= 0x02000000; // WS_EX_COMPOSITED
                return cp;
            }
        }

        private sealed class BufferedTableLayoutPanel : TableLayoutPanel
        {
            public BufferedTableLayoutPanel()
            {
                SetStyle(ControlStyles.UserPaint | ControlStyles.AllPaintingInWmPaint |
                          ControlStyles.OptimizedDoubleBuffer | ControlStyles.ResizeRedraw, true);
                DoubleBuffered = true;
            }
        }

        private static Image LoadWordmarkForCurrentTheme()
        {
            Image image = HelivantaUiTheme.LoadWordmarkImage(false);
            if (image == null) throw new FileNotFoundException("Embedded Helivanta wordmark for the active theme was not found.");
            return image;
        }

        private static Image LoadEmbeddedPng()
        {
            Assembly asm = Assembly.GetExecutingAssembly();
            foreach (string name in asm.GetManifestResourceNames())
            {
                if (name.EndsWith("Helivanta.png", StringComparison.OrdinalIgnoreCase))
                {
                    using (Stream s = asm.GetManifestResourceStream(name))
                    using (var temp = Image.FromStream(s))
                        return new Bitmap(temp);
                }
            }
            throw new FileNotFoundException("Embedded icon not found.");
        }

        private static Icon LoadEmbeddedIcon()
        {
            Assembly asm = Assembly.GetExecutingAssembly();
            foreach (string name in asm.GetManifestResourceNames())
            {
                if (name.EndsWith("Helivanta.ico", StringComparison.OrdinalIgnoreCase))
                {
                    using (Stream s = asm.GetManifestResourceStream(name))
                        return new Icon(s);
                }
            }
            return SystemIcons.Question;
        }
    }
}
