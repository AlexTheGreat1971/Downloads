﻿using System;

namespace ThreadPro
{
    /// <summary>
    /// Auto-selection policy: the picked cylinder defines the displayed nominal diameter
    /// for both internal and external threads. Standard lookup must never convert an
    /// internal bore diameter to a different nominal major diameter.
    /// </summary>
    public static class ThreadNominalDiameterPolicy
    {
        // Match the precision already used by the dialog's exact type-size synchronizer.
        // This tolerance absorbs numeric noise only; it is not a nearest-size tolerance.
        public const double StandardDiameterToleranceMm = 0.00049;

        public static double PreserveSelectedDiameter(double selectedEdgeDiameterMm)
        {
            if (double.IsNaN(selectedEdgeDiameterMm) || double.IsInfinity(selectedEdgeDiameterMm) || selectedEdgeDiameterMm <= 0.0)
                throw new ArgumentOutOfRangeException(nameof(selectedEdgeDiameterMm), "Selected edge diameter must be a positive finite value.");
            return selectedEdgeDiameterMm;
        }

        public static double DiameterDifferenceMm(double selectedEdgeDiameterMm, double nominalDiameterMm)
        {
            if (double.IsNaN(selectedEdgeDiameterMm) || double.IsInfinity(selectedEdgeDiameterMm) ||
                double.IsNaN(nominalDiameterMm) || double.IsInfinity(nominalDiameterMm))
                return double.PositiveInfinity;
            return Math.Abs(selectedEdgeDiameterMm - nominalDiameterMm);
        }

        public static bool MatchesStandardDiameter(double selectedEdgeDiameterMm, double nominalDiameterMm)
        {
            if (selectedEdgeDiameterMm <= 0.0 || nominalDiameterMm <= 0.0 ||
                double.IsNaN(selectedEdgeDiameterMm) || double.IsInfinity(selectedEdgeDiameterMm) ||
                double.IsNaN(nominalDiameterMm) || double.IsInfinity(nominalDiameterMm))
                return false;
            return DiameterDifferenceMm(selectedEdgeDiameterMm, nominalDiameterMm) <= StandardDiameterToleranceMm;
        }
    }
}
