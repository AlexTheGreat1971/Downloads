﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Globalization;
using System.IO;
using System.Text;
using System.Windows.Forms;

namespace ThreadPro
{
    internal sealed class ThreadIntegrityDialog : Form
    {
        private static Color UiSurface => HelivantaUiTheme.Surface;
        private static Color UiPanel => HelivantaUiTheme.Panel;
        private static Color UiHeader => HelivantaUiTheme.Header;
        private static Color UiField => HelivantaUiTheme.Field;
        private static Color UiText => HelivantaUiTheme.Text;
        private static Color UiMuted => HelivantaUiTheme.Muted;
        private static Color UiBorder => HelivantaUiTheme.Border;
        private static Color UiSuccess => HelivantaUiTheme.Success;
        private static Color UiWarning => HelivantaUiTheme.Warning;
        private static Color UiError => HelivantaUiTheme.Error;
        private static Color PassBack => HelivantaUiTheme.IsLight ? Color.FromArgb(226, 243, 232) : Color.FromArgb(39, 67, 57);
        private static Color WarningBack => HelivantaUiTheme.IsLight ? Color.FromArgb(255, 244, 211) : Color.FromArgb(72, 61, 37);
        private static Color ErrorBack => HelivantaUiTheme.IsLight ? Color.FromArgb(252, 229, 229) : Color.FromArgb(79, 43, 49);

        private readonly ThreadIntegrityReport _report;
        private readonly string _documentName;
        private readonly Inventor.Application _app;
        private readonly Inventor.PartDocument _document;
        private readonly DataGridView _grid;
        private readonly ToolTip _toolTip;
        private TableLayoutPanel _contentLayout;
        private Control _headerControl;
        private Control _summaryControl;
        private Control _footerControl;
        private Image _wordmarkImage;
        private bool _fittingHeight;
        private readonly List<DisplayRow> _displayRows = new List<DisplayRow>();

        private sealed class DisplayRow
        {
            internal ThreadIntegritySeverity Severity;
            internal string ThreadId;
            internal string DisplayLabel;
            internal string StandardLabel;
            internal string ParameterSummary;
            internal string Message;
            internal bool IsSummary;
        }

        private ThreadIntegrityDialog(ThreadIntegrityReport report, string documentName, Inventor.Application app, Inventor.PartDocument document)
        {
            _report = report ?? new ThreadIntegrityReport();
            _documentName = documentName ?? "";
            _app = app;
            _document = document;
            Text = HelivantaUserSettings.Current.Language == "en" ? "Helivanta — Thread Integrity" : "Helivanta — Проверка резьб";
            StartPosition = FormStartPosition.CenterParent;
            FormBorderStyle = FormBorderStyle.Sizable;
            MinimizeBox = false;
            MaximizeBox = false;
            ShowInTaskbar = false;
            MinimumSize = new Size(900, 300);
            Size = new Size(1120, 620);
            AutoScaleMode = AutoScaleMode.Dpi;
            Load += (sender, args) => HelivantaLocalization.Apply(this);
            Font = new Font("Segoe UI", 9f);
            BackColor = UiSurface;
            ForeColor = UiText;
            Opacity = 0.0; // Fit to report content before the first visible frame.
            try { Icon = LoadEmbeddedIcon(); } catch { }

            _toolTip = new ToolTip { ShowAlways = true, AutoPopDelay = 18000, InitialDelay = 450, ReshowDelay = 100 };

            var layout = new TableLayoutPanel
            {
                Dock = DockStyle.Fill,
                Padding = new Padding(12),
                Margin = Padding.Empty,
                BackColor = UiSurface,
                ColumnCount = 1,
                RowCount = 4
            };
            _contentLayout = layout;
            layout.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100f));
            layout.RowStyles.Add(new RowStyle(SizeType.AutoSize));
            layout.RowStyles.Add(new RowStyle(SizeType.AutoSize));
            layout.RowStyles.Add(new RowStyle(SizeType.Percent, 100f));
            layout.RowStyles.Add(new RowStyle(SizeType.AutoSize));
            Controls.Add(layout);

            var header = new TableLayoutPanel
            {
                Dock = DockStyle.Top,
                AutoSize = true,
                AutoSizeMode = AutoSizeMode.GrowAndShrink,
                ColumnCount = 2,
                RowCount = 2,
                BackColor = UiSurface,
                Margin = new Padding(0, 0, 0, 8),
                Padding = Padding.Empty
            };
            _headerControl = header;
            header.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 210));
            header.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100f));
            header.RowStyles.Add(new RowStyle(SizeType.Absolute, 32));
            header.RowStyles.Add(new RowStyle(SizeType.Absolute, 24));

            var wordmark = new PictureBox
            {
                Dock = DockStyle.Fill,
                SizeMode = PictureBoxSizeMode.Zoom,
                Margin = new Padding(0, 1, 14, 1),
                BackColor = Color.Transparent,
                TabStop = false
            };
            try
            {
                _wordmarkImage = LoadEmbeddedWordmark();
                wordmark.Image = _wordmarkImage;
            }
            catch { }
            header.Controls.Add(wordmark, 0, 0);
            header.SetRowSpan(wordmark, 2);
            var title = new Label
            {
                Text = HelivantaLocalization.Translate("Проверка параметров построенных резьб"),
                Font = new Font("Segoe UI Semibold", 13f, FontStyle.Bold),
                ForeColor = UiText,
                Margin = new Padding(0, 0, 0, 3),
                AutoSize = false,
                AutoEllipsis = true,
                Dock = DockStyle.Fill,
                TextAlign = ContentAlignment.MiddleLeft
            };
            var documentLabel = new Label
            {
                Text = HelivantaLocalization.Translate("Документ: ") + _documentName,
                AutoSize = false,
                ForeColor = UiMuted,
                AutoEllipsis = true,
                Margin = Padding.Empty,
                Dock = DockStyle.Fill,
                TextAlign = ContentAlignment.MiddleLeft
            };
            _toolTip.SetToolTip(documentLabel, _documentName);
            header.Controls.Add(title, 1, 0);
            header.Controls.Add(documentLabel, 1, 1);
            layout.Controls.Add(header, 0, 0);

            var summary = new FlowLayoutPanel
            {
                Dock = DockStyle.Top,
                AutoSize = true,
                AutoSizeMode = AutoSizeMode.GrowAndShrink,
                FlowDirection = FlowDirection.LeftToRight,
                WrapContents = true,
                BackColor = UiPanel,
                Padding = new Padding(8, 6, 8, 6),
                Margin = new Padding(0, 0, 0, 8)
            };
            _summaryControl = summary;
            summary.Controls.Add(MakeSummaryChip(HelivantaLocalization.Translate("Группы Helivanta: ") + _report.ValidGroups.ToString(CultureInfo.InvariantCulture), UiText, UiHeader));
            summary.Controls.Add(MakeSummaryChip(HelivantaLocalization.Translate("Косметические Inventor: ") + _report.NativeThreads.ToString(CultureInfo.InvariantCulture), UiText, UiHeader));
            summary.Controls.Add(MakeSummaryChip(HelivantaLocalization.Translate("Ошибки:") + " " + _report.Errors.ToString(CultureInfo.InvariantCulture), UiError, ErrorBack));
            summary.Controls.Add(MakeSummaryChip(HelivantaLocalization.Translate("Предупреждения:") + " " + _report.Warnings.ToString(CultureInfo.InvariantCulture), UiWarning, WarningBack));
            summary.Controls.Add(MakeSummaryChip(HelivantaLocalization.Translate(_report.ScanComplete ? "Проверка завершена" : "Проверка неполная"),
                _report.ScanComplete ? UiSuccess : UiError, _report.ScanComplete ? PassBack : ErrorBack));
            var legend = new Label
            {
                AutoSize = true,
                Text = HelivantaLocalization.Translate("Зелёный — проверка пройдена · жёлтый — предупреждение/пользовательский типоразмер · красный — ошибка или пересечение"),
                ForeColor = UiMuted,
                Margin = new Padding(3, 7, 3, 2),
                MaximumSize = new Size(1040, 0)
            };
            summary.Controls.Add(legend);
            summary.Controls.Add(new Label
            {
                AutoSize = true,
                Text = HelivantaLocalization.Translate("Только чтение: геометрия, видимость тел и Undo/Redo не изменяются."),
                ForeColor = UiMuted,
                Margin = new Padding(3, 4, 3, 2),
                MaximumSize = new Size(1040, 0)
            });
            layout.Controls.Add(summary, 0, 1);

            _grid = new DataGridView
            {
                Dock = DockStyle.Fill,
                BackgroundColor = UiField,
                BorderStyle = BorderStyle.FixedSingle,
                GridColor = UiBorder,
                EnableHeadersVisualStyles = false,
                ColumnHeadersDefaultCellStyle = new DataGridViewCellStyle
                {
                    BackColor = UiHeader,
                    ForeColor = UiText,
                    Font = new Font("Segoe UI Semibold", 9f, FontStyle.Bold),
                    Alignment = DataGridViewContentAlignment.MiddleLeft,
                    WrapMode = DataGridViewTriState.True,
                    Padding = new Padding(5, 4, 5, 4)
                },
                ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize,
                DefaultCellStyle = new DataGridViewCellStyle
                {
                    BackColor = UiField,
                    ForeColor = UiText,
                    SelectionBackColor = UiHeader,
                    SelectionForeColor = UiText,
                    WrapMode = DataGridViewTriState.True,
                    Alignment = DataGridViewContentAlignment.TopLeft,
                    Padding = new Padding(6, 5, 6, 5)
                },
                RowHeadersVisible = false,
                ReadOnly = true,
                AllowUserToAddRows = false,
                AllowUserToDeleteRows = false,
                AllowUserToOrderColumns = false,
                AllowUserToResizeRows = true,
                MultiSelect = false,
                SelectionMode = DataGridViewSelectionMode.FullRowSelect,
                AutoGenerateColumns = false,
                AutoSizeRowsMode = DataGridViewAutoSizeRowsMode.AllCells,
                ScrollBars = ScrollBars.Both,
                Margin = Padding.Empty
            };
            _grid.Columns.Add(MakeColumn("Статус", 98, DataGridViewAutoSizeColumnMode.None));
            _grid.Columns.Add(MakeColumn("Резьба / группа", 170, DataGridViewAutoSizeColumnMode.None));
            _grid.Columns.Add(MakeColumn("Стандарт", 150, DataGridViewAutoSizeColumnMode.None));
            _grid.Columns.Add(MakeColumn("Параметры", 270, DataGridViewAutoSizeColumnMode.None));
            _grid.Columns.Add(MakeColumn("Результат проверки", 300, DataGridViewAutoSizeColumnMode.Fill));
            layout.Controls.Add(_grid, 0, 2);

            var footer = new FlowLayoutPanel
            {
                Dock = DockStyle.Fill,
                AutoSize = true,
                AutoSizeMode = AutoSizeMode.GrowAndShrink,
                FlowDirection = FlowDirection.RightToLeft,
                WrapContents = true,
                BackColor = UiSurface,
                Padding = new Padding(0, 9, 0, 0),
                Margin = Padding.Empty
            };
            _footerControl = footer;
            var close = MakeFooterButton("Закрыть", 100);
            close.Click += (s, e) => Close();
            var focus = MakeFooterButton("Показать на модели", 170);
            focus.Click += (s, e) =>
            {
                DisplayRow selected = GetSelectedFinding();
                if (selected == null)
                {
                    MessageBox.Show(this, HelivantaLocalization.Translate("Сначала выберите строку конкретной резьбы (не строку сводки)."), "Helivanta", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    return;
                }
                FocusSelectedFinding();
            };
            focus.Enabled = _displayRows.Exists(r => r != null && !r.IsSummary && !string.IsNullOrWhiteSpace(r.ThreadId));
            _grid.SelectionChanged += (s, e) => UpdateFocusButton(focus);
            _grid.CurrentCellChanged += (s, e) => UpdateFocusButton(focus);
            _grid.CellClick += (s, e) =>
            {
                if (e.RowIndex >= 0 && e.RowIndex < _grid.Rows.Count)
                {
                    DataGridViewRow clicked = _grid.Rows[e.RowIndex];
                    if (clicked.Tag is DisplayRow item && !item.IsSummary)
                    {
                        _grid.ClearSelection();
                        clicked.Selected = true;
                        if (clicked.Cells.Count > 0) _grid.CurrentCell = clicked.Cells[0];
                    }
                }
                UpdateFocusButton(focus);
            };
            _grid.CellDoubleClick += (s, e) =>
            {
                if (e.RowIndex >= 0 && e.RowIndex < _grid.Rows.Count && _grid.Rows[e.RowIndex].Tag is DisplayRow item && !item.IsSummary)
                {
                    _grid.ClearSelection();
                    _grid.Rows[e.RowIndex].Selected = true;
                    if (_grid.Rows[e.RowIndex].Cells.Count > 0) _grid.CurrentCell = _grid.Rows[e.RowIndex].Cells[0];
                    FocusSelectedFinding();
                }
            };
            var export = MakeFooterButton("Экспорт CSV…", 130);
            export.Click += (s, e) => ExportCsv();
            footer.Controls.Add(close);
            footer.Controls.Add(focus);
            footer.Controls.Add(export);
            layout.Controls.Add(footer, 0, 3);
            AcceptButton = close;
            CancelButton = close;

            BuildDisplayRows();
            PopulateGrid();
            Shown += (s, e) =>
            {
                // Run after WinForms has created native grid handles and measured wrapped
                // cells, but before revealing the form so it never flashes at an oversized
                // default height.
                try
                {
                    BeginInvoke((Action)(() =>
                    {
                        if (IsDisposed) return;
                        FitWindowHeightToContent();
                        try { CenterToParent(); } catch { }
                        Opacity = 1.0;
                    }));
                }
                catch
                {
                    FitWindowHeightToContent();
                    Opacity = 1.0;
                }
            };
            SizeChanged += (s, e) => AdjustColumns();
            DpiChanged += (s, e) =>
            {
                try
                {
                    BeginInvoke((Action)(() =>
                    {
                        if (IsDisposed) return;
                        FitWindowHeightToContent();
                        AdjustColumns();
                    }));
                }
                catch { }
            };
        }

        internal static void ShowForActiveDocument(Inventor.Application app, IWin32Window owner)
        {
            Inventor.PartDocument doc = null;
            string name = "";
            try { doc = app == null ? null : app.ActiveDocument as Inventor.PartDocument; } catch { }
            try { if (doc != null) name = doc.DisplayName; } catch { }
            ThreadIntegrityReport report = ThreadIntegrityChecker.Check(doc, app);
            using (var dialog = new ThreadIntegrityDialog(report, name, app, doc)) dialog.ShowDialog(owner);
        }

        private void UpdateFocusButton(Button button)
        {
            if (button == null || button.IsDisposed) return;
            button.Enabled = GetSelectedFinding() != null;
        }

        private DisplayRow GetSelectedFinding()
        {
            try
            {
                // Prefer the explicit full-row selection. CurrentRow may still point at
                // the summary row during WinForms selection event ordering.
                foreach (DataGridViewRow selectedRow in _grid.SelectedRows)
                {
                    DisplayRow selected = selectedRow.Tag as DisplayRow;
                    if (selected != null && !selected.IsSummary && !string.IsNullOrWhiteSpace(selected.ThreadId)) return selected;
                }
                if (_grid.CurrentCell != null && _grid.CurrentCell.RowIndex >= 0 && _grid.CurrentCell.RowIndex < _grid.Rows.Count)
                {
                    DisplayRow current = _grid.Rows[_grid.CurrentCell.RowIndex].Tag as DisplayRow;
                    if (current != null && !current.IsSummary && !string.IsNullOrWhiteSpace(current.ThreadId)) return current;
                }
                if (_grid.CurrentRow != null)
                {
                    DisplayRow current = _grid.CurrentRow.Tag as DisplayRow;
                    if (current != null && !current.IsSummary && !string.IsNullOrWhiteSpace(current.ThreadId)) return current;
                }
            }
            catch { }
            return null;
        }

        private void FocusSelectedFinding()
        {
            DisplayRow row = GetSelectedFinding();
            if (row == null || row.IsSummary || _document == null || _app == null)
            {
                MessageBox.Show(this, HelivantaLocalization.Translate("Выберите конкретную резьбу или результат проверки."), "Helivanta", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }

            try
            {
                string id = row.ThreadId ?? string.Empty;
                object target = null;
                object[] selectableGeometry = null;
                var helivantaFeatures = new List<object>();
                string helivantaFolderName = null;
                string resolutionError = string.Empty;

                if (id.StartsWith("INV:", StringComparison.Ordinal))
                {
                    // Resolve through the same native-thread enumerator used by the checker.
                    // This avoids relying on a guessed collection index/order.
                    bool scanComplete;
                    string scanError;
                    List<NativeThreadOverlapSnapshot> native = NativeThreadOverlapGuard.Enumerate(
                        _app, _document, out scanComplete, out scanError);
                    string nativeName = id.Substring(4);
                    int suffix = nativeName.LastIndexOf('#');
                    if (suffix > 0) nativeName = nativeName.Substring(0, suffix);
                    foreach (NativeThreadOverlapSnapshot item in native)
                    {
                        if (item == null || item.Feature == null) continue;
                        if (string.Equals(item.Name ?? string.Empty, nativeName, StringComparison.OrdinalIgnoreCase))
                        {
                            target = item.Feature;
                            try
                            {
                                Inventor.Faces faces = item.Feature.ThreadedFace as Inventor.Faces;
                                if (faces != null && faces.Count > 0)
                                {
                                    var list = new List<object>();
                                    foreach (Inventor.Face face in faces) if (face != null) list.Add(face);
                                    selectableGeometry = list.ToArray();
                                }
                            }
                            catch { }
                            break;
                        }
                    }
                    if (target == null && !string.IsNullOrWhiteSpace(scanError)) resolutionError = scanError;
                }
                else
                {
                    ThreadMetadataGroup group;
                    string error;
                    if (ThreadMetadataStore.TryLoadGroup(_document, id, out group, out error) &&
                        group != null && group.MembersByIndex != null)
                    {
                        // Helivanta's thread is represented by the CoilFeature(s), not by the
                        // original cylindrical face. Selecting that face merely highlights the
                        // solid-body node and sends the user to the wrong browser folder.
                        for (int i = 0; i < group.MembersByIndex.Count; i++)
                        {
                            object candidate = group.MembersByIndex[i];
                            if (candidate == null) continue;
                            if (candidate is Inventor.CoilFeature)
                                helivantaFeatures.Add(candidate);
                        }
                        if (helivantaFeatures.Count > 0)
                            target = helivantaFeatures[helivantaFeatures.Count - 1];
                        else
                        {
                            // Older metadata groups may contain no CoilFeature (e.g. a partial
                            // legacy build). Use the last actual feature, never the source face.
                            for (int i = group.MembersByIndex.Count - 1; i >= 0; i--)
                            {
                                object candidate = group.MembersByIndex[i];
                                if (candidate == null) continue;
                                string typeName = candidate.GetType().Name;
                                if (typeName.EndsWith("Feature", StringComparison.OrdinalIgnoreCase) ||
                                    typeName.IndexOf("Loft", StringComparison.OrdinalIgnoreCase) >= 0)
                                { target = candidate; break; }
                            }
                        }
                        try
                        {
                            if (group.Record != null && group.Record.Parameters != null)
                            {
                                ThreadParametersSnapshot ps = group.Record.Parameters;
                                helivantaFolderName = ps.Tapered
                                    ? ThreadFolderNamePolicy.BuildTaperedThreadFolderName(ps.TaperStandard, ps.TaperDisplayDesignation, ps.TaperDesignation, ps.Starts, ps.RightHand)
                                    : ThreadFolderNamePolicy.BuildThreadFolderName(
                                        ps.SizeName, ps.Starts, ps.RightHand, (ThreadStandard)ps.Standard, ps.Mirror);
                            }
                        }
                        catch { }
                    }
                    else if (!string.IsNullOrWhiteSpace(error)) resolutionError = error;
                }

                if (target == null)
                {
                    string detail = string.IsNullOrWhiteSpace(resolutionError) ? string.Empty : "\r\n" + resolutionError;
                    MessageBox.Show(this, HelivantaLocalization.Translate("Не удалось найти объект модели для выбранного результата. Геометрия не изменена.") + HelivantaLocalization.Translate(detail),
                        "Helivanta", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }

                // For Helivanta builds, select the generated thread feature(s) so the actual
                // helical geometry is highlighted. Native cosmetic threads have no physical
                // helical B-rep, so their ThreadFeature/ThreadedFace fallback remains separate.
                bool selected = false;
                try
                {
                    dynamic selectSet = _document.SelectSet;
                    selectSet.Clear();
                    if (helivantaFeatures.Count > 0)
                    {
                        foreach (object feature in helivantaFeatures)
                        {
                            try { selectSet.Select(feature); selected = true; } catch { }
                        }
                    }
                    else if (selectableGeometry != null && selectableGeometry.Length > 0)
                    {
                        foreach (object geometry in selectableGeometry)
                        {
                            try { selectSet.Select(geometry); selected = true; } catch { }
                        }
                    }
                    if (!selected && target != null) { selectSet.Select(target); selected = true; }
                }
                catch { }

                // Prefer the Helivanta folder node when available. The previous implementation
                // selected ThreadedFace/solid geometry first, which highlighted the body node
                // under "Твердые тела" instead of the logical thread folder.
                try
                {
                    foreach (Inventor.BrowserPane pane in _document.BrowserPanes)
                    {
                        if (pane == null || !pane.TreeBrowser) continue;
                        Inventor.BrowserNode node = null;
                        if (helivantaFeatures.Count > 0)
                        {
                            foreach (object feature in helivantaFeatures)
                            {
                                try { node = pane.GetBrowserNodeFromObject(feature); } catch { node = null; }
                                if (node == null) continue;
                                try { node.EnsureVisible(); } catch { }
                                // Walk parent nodes looking for the logical Helivanta folder.
                                Inventor.BrowserNode current = node;
                                for (int depth = 0; current != null && depth < 8; depth++)
                                {
                                    string nodeName = string.Empty;
                                    try { nodeName = current.BrowserNodeDefinition.Label ?? string.Empty; } catch { }
                                    if (!string.IsNullOrWhiteSpace(helivantaFolderName) &&
                                        string.Equals(nodeName, helivantaFolderName, StringComparison.OrdinalIgnoreCase))
                                    {
                                        try { current.EnsureVisible(); } catch { }
                                        try { ((dynamic)current).DoSelect(); selected = true; } catch { }
                                        break;
                                    }
                                    try { current = current.Parent as Inventor.BrowserNode; } catch { current = null; }
                                }
                                if (selected) break;
                            }
                        }
                        if (!selected)
                        {
                            try { node = pane.GetBrowserNodeFromObject(target); } catch { node = null; }
                            if (node != null)
                            {
                                try { node.EnsureVisible(); } catch { }
                                try { ((dynamic)node).DoSelect(); selected = true; } catch { }
                            }
                        }
                        if (selected) break;
                    }
                }
                catch { }

                if (!selected)
                {
                    MessageBox.Show(this, HelivantaLocalization.Translate("Inventor нашёл запись резьбы, но не предоставил выбираемый объект модели. Попробуйте раскрыть соответствующий элемент в браузере. Геометрия не изменена."),
                        "Helivanta", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }

                bool zoomed = false;
                try
                {
                    dynamic definitions = _app.CommandManager.ControlDefinitions;
                    dynamic zoomSelect = definitions.Item("AppZoomSelectCmd");
                    zoomSelect.Execute();
                    zoomed = true;
                }
                catch { }
                try { _app.ActiveView.Update(); } catch { }
                if (!zoomed)
                    MessageBox.Show(this, HelivantaLocalization.Translate("Объект выбран в модели/браузере. Inventor не выполнил команду приближения; выделение сохранено."),
                        "Helivanta", MessageBoxButtons.OK, MessageBoxIcon.Information);
                else
                    _toolTip.SetToolTip(_grid, HelivantaLocalization.Translate("Выбранный результат выделен и показан в модели Inventor."));
            }
            catch (Exception ex)
            {
                MessageBox.Show(this, HelivantaLocalization.Translate("Не удалось сфокусировать модель на выбранном результате:\r\n") + HelivantaLocalization.Translate(ex.Message),
                    "Helivanta", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }

        private void BuildDisplayRows()
        {
            var map = new Dictionary<string, DisplayRow>(StringComparer.Ordinal);
            foreach (ThreadIntegrityFinding finding in _report.Findings)
            {
                if (finding == null) continue;
                string id = finding.ThreadId ?? "";
                string key = string.IsNullOrWhiteSpace(id) ? "__SUMMARY__" : id;
                DisplayRow row;
                if (!map.TryGetValue(key, out row))
                {
                    row = new DisplayRow
                    {
                        Severity = finding.Severity,
                        ThreadId = id,
                        DisplayLabel = finding.DisplayLabel ?? "",
                        StandardLabel = finding.StandardLabel ?? "",
                        ParameterSummary = finding.ParameterSummary ?? "",
                        Message = "",
                        IsSummary = string.IsNullOrWhiteSpace(id)
                    };
                    map.Add(key, row);
                    _displayRows.Add(row);
                }
                else
                {
                    if ((int)finding.Severity > (int)row.Severity) row.Severity = finding.Severity;
                    if (string.IsNullOrWhiteSpace(row.DisplayLabel)) row.DisplayLabel = finding.DisplayLabel ?? "";
                    if (string.IsNullOrWhiteSpace(row.StandardLabel)) row.StandardLabel = finding.StandardLabel ?? "";
                    if (string.IsNullOrWhiteSpace(row.ParameterSummary)) row.ParameterSummary = finding.ParameterSummary ?? "";
                }

                string message = (finding.Message ?? "").Trim();
                string recommendation = (finding.Recommendation ?? "").Trim();
                if (recommendation.Length > 0 && finding.Severity != ThreadIntegritySeverity.Info)
                    message += (message.Length > 0 ? Environment.NewLine : string.Empty) + "Рекомендация: " + recommendation;
                if (message.Length > 0 && row.Message.IndexOf(message, StringComparison.Ordinal) < 0)
                    row.Message = row.Message.Length == 0 ? message : row.Message + Environment.NewLine + message;
            }
        }

        private void PopulateGrid()
        {
            _grid.SuspendLayout();
            try
            {
                foreach (DisplayRow item in _displayRows)
                {
                    string status = item.Severity == ThreadIntegritySeverity.Error ? "ОШИБКА" :
                        item.Severity == ThreadIntegritySeverity.Warning ? "ВНИМАНИЕ" :
                        item.IsSummary ? "СВОДКА" : "ПРОЙДЕНО";
                    status = HelivantaLocalization.Translate(status);
                    string label = HelivantaLocalization.Translate(item.DisplayLabel ?? string.Empty);
                    if (!string.IsNullOrWhiteSpace(item.ThreadId))
                        label = string.IsNullOrWhiteSpace(label) ? item.ThreadId : label + Environment.NewLine + item.ThreadId;
                    string standardLabel = HelivantaLocalization.Translate(item.StandardLabel ?? string.Empty);
                    string parameters = HelivantaLocalization.Translate(item.ParameterSummary ?? string.Empty);
                    string message = HelivantaLocalization.Translate(item.Message ?? string.Empty);
                    int rowIndex = _grid.Rows.Add(status, label, standardLabel, parameters, message);
                    DataGridViewRow row = _grid.Rows[rowIndex];
                    row.Tag = item;
                    Color fore, back;
                    GetSeverityColors(item, out fore, out back);
                    row.DefaultCellStyle.BackColor = back;
                    row.DefaultCellStyle.ForeColor = fore;
                    row.DefaultCellStyle.SelectionBackColor = Color.FromArgb(45, 91, 132);
                    row.DefaultCellStyle.SelectionForeColor = Color.White;
                    row.Cells[0].Style.Font = new Font("Segoe UI Semibold", 8.5f, FontStyle.Bold);
                    row.Cells[0].ToolTipText = message;
                    row.Cells[1].ToolTipText = item.ThreadId;
                    row.Cells[2].ToolTipText = standardLabel;
                    row.Cells[3].ToolTipText = parameters;
                    row.Cells[4].ToolTipText = message;
                }
            }
            finally { _grid.ResumeLayout(); }
        }

        private void FitWindowHeightToContent()
        {
            if (_fittingHeight || IsDisposed || _grid == null || _contentLayout == null) return;
            _fittingHeight = true;
            try
            {
                Rectangle workArea = Screen.FromControl(this).WorkingArea;
                float scale = Math.Max(1f, DeviceDpi / 96f);
                int screenMargin = (int)Math.Round(32 * scale);
                int availableWidth = Math.Max(1, workArea.Width - screenMargin);
                int availableHeight = Math.Max(1, workArea.Height - screenMargin);
                int preferredWidth = (int)Math.Round(1120 * scale);
                int minimumWidth = Math.Min((int)Math.Round(900 * scale), availableWidth);
                int targetWidth = Math.Max(minimumWidth, Math.Min(preferredWidth, availableWidth));
                // MinimumSize is an outer-window size and must not prevent the report from
                // fitting on a smaller or high-DPI display.
                int minimumHeight = Math.Min((int)Math.Round(300 * scale), availableHeight);
                MinimumSize = new Size(minimumWidth, minimumHeight);
                if (ClientSize.Width != targetWidth) ClientSize = new Size(targetWidth, ClientSize.Height);

                PerformLayout();
                AdjustColumns();
                try { _grid.AutoResizeRows(DataGridViewAutoSizeRowsMode.AllCellsExceptHeaders); } catch { }
                _contentLayout.PerformLayout();

                int gridContentHeight = _grid.ColumnHeadersHeight + 4;
                foreach (DataGridViewRow row in _grid.Rows)
                    if (row != null && !row.IsNewRow) gridContentHeight += row.Height;

                int fixedContentHeight = _contentLayout.Padding.Vertical;
                if (_headerControl != null) fixedContentHeight += _headerControl.Height + _headerControl.Margin.Vertical;
                if (_summaryControl != null) fixedContentHeight += _summaryControl.Height + _summaryControl.Margin.Vertical;
                if (_footerControl != null) fixedContentHeight += _footerControl.Height + _footerControl.Margin.Vertical;
                int chromeHeight = Math.Max(0, Height - ClientSize.Height);
                int margin = screenMargin;
                int maxClientHeight = Math.Max(1, workArea.Height - chromeHeight - margin);
                int minClientHeight = Math.Min((int)Math.Round(300 * scale), maxClientHeight);
                int desiredClientHeight = fixedContentHeight + gridContentHeight + 4;
                int finalClientHeight = Math.Max(minClientHeight, Math.Min(desiredClientHeight, maxClientHeight));
                if (Math.Abs(ClientSize.Height - finalClientHeight) > 2)
                    ClientSize = new Size(ClientSize.Width, finalClientHeight);
                _contentLayout.PerformLayout();
                AdjustColumns();
            }
            finally { _fittingHeight = false; }
        }

        private static Image LoadEmbeddedWordmark()
        {
            return HelivantaUiTheme.LoadWordmarkImage(false);
        }

        private static Icon LoadEmbeddedIcon()
        {
            var assembly = System.Reflection.Assembly.GetExecutingAssembly();
            foreach (string name in assembly.GetManifestResourceNames())
            {
                if (!name.EndsWith("Helivanta.ico", StringComparison.OrdinalIgnoreCase)) continue;
                using (Stream stream = assembly.GetManifestResourceStream(name))
                    return new Icon(stream);
            }
            return SystemIcons.Application;
        }

        private void AdjustColumns()
        {
            if (_grid == null || _grid.IsDisposed || _grid.Columns.Count != 5) return;
            int width = _grid.ClientSize.Width - SystemInformation.VerticalScrollBarWidth - 4;
            if (width <= 0) return;
            float scale = Math.Max(1f, DeviceDpi / 96f);
            int scaledStatus = (int)Math.Round(96 * scale);
            int minThread = (int)Math.Round(135 * scale);
            int maxThread = (int)Math.Round(170 * scale);
            int minStandard = (int)Math.Round(125 * scale);
            int maxStandard = (int)Math.Round(150 * scale);
            int minParameters = (int)Math.Round(190 * scale);
            int maxParameters = (int)Math.Round(270 * scale);
            _grid.Columns[0].Width = scaledStatus;
            _grid.Columns[1].Width = Math.Max(minThread, Math.Min(maxThread, width / 6));
            _grid.Columns[2].Width = Math.Max(minStandard, Math.Min(maxStandard, width / 6));
            _grid.Columns[3].Width = Math.Max(minParameters, Math.Min(maxParameters, width / 3));
            _grid.Columns[4].AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill;
        }

        private void ExportCsv()
        {
            using (var dialog = new SaveFileDialog
            {
                Title = HelivantaLocalization.Translate("Экспорт отчёта проверки Helivanta"),
                Filter = "CSV UTF-8 (*.csv)|*.csv",
                DefaultExt = "csv",
                AddExtension = true,
                FileName = "Helivanta-thread-check.csv"
            })
            {
                if (dialog.ShowDialog(this) != DialogResult.OK) return;
                var csv = new StringBuilder();
                csv.AppendLine("Status,ThreadId,Thread,Standard,Parameters,ResultAndRecommendation");
                foreach (DisplayRow row in _displayRows)
                {
                    string severity = HelivantaLocalization.Translate(row.Severity == ThreadIntegritySeverity.Error ? "Ошибка" :
                        row.Severity == ThreadIntegritySeverity.Warning ? "Предупреждение" :
                        row.IsSummary ? "Сводка" : "Пройдена");
                    csv.Append(Csv(severity)).Append(',')
                        .Append(Csv(row.ThreadId)).Append(',')
                        .Append(Csv(HelivantaLocalization.Translate(row.DisplayLabel))).Append(',')
                        .Append(Csv(HelivantaLocalization.Translate(row.StandardLabel))).Append(',')
                        .Append(Csv(HelivantaLocalization.Translate(row.ParameterSummary))).Append(',')
                        .Append(Csv(HelivantaLocalization.Translate(row.Message))).AppendLine();
                }
                try
                {
                    File.WriteAllText(dialog.FileName, csv.ToString(), new UTF8Encoding(true));
                    MessageBox.Show(this, HelivantaLocalization.Translate("Отчёт сохранён:\r\n") + dialog.FileName, "Helivanta", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
                catch (Exception ex)
                {
                    MessageBox.Show(this, HelivantaLocalization.Translate("Не удалось сохранить CSV:\r\n") + HelivantaLocalization.Translate(ex.Message), "Helivanta", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        private static DataGridViewTextBoxColumn MakeColumn(string title, int width, DataGridViewAutoSizeColumnMode mode)
        {
            return new DataGridViewTextBoxColumn
            {
                HeaderText = HelivantaLocalization.Translate(title),
                Width = width,
                AutoSizeMode = mode,
                SortMode = DataGridViewColumnSortMode.NotSortable,
                Resizable = DataGridViewTriState.True
            };
        }

        private static Label MakeSummaryChip(string text, Color fore, Color back)
        {
            return new Label
            {
                AutoSize = true,
                Text = text,
                ForeColor = fore,
                BackColor = back,
                Padding = new Padding(8, 5, 8, 5),
                Margin = new Padding(2, 1, 4, 4),
                Font = new Font("Segoe UI Semibold", 8.5f, FontStyle.Bold)
            };
        }

        private static Button MakeFooterButton(string text, int width)
        {
            var button = new Button
            {
                Text = HelivantaLocalization.Translate(text),
                Size = new Size(width, 34),
                MinimumSize = new Size(width, 34),
                Margin = new Padding(6, 0, 0, 0),
                Font = new Font("Segoe UI", 9f),
                FlatStyle = FlatStyle.Flat,
                BackColor = UiPanel,
                ForeColor = UiText,
                UseVisualStyleBackColor = false
            };
            button.FlatAppearance.BorderColor = UiBorder;
            button.FlatAppearance.MouseOverBackColor = UiHeader;
            button.FlatAppearance.MouseDownBackColor = UiField;
            return button;
        }

        private static void GetSeverityColors(DisplayRow row, out Color fore, out Color back)
        {
            if (row.Severity == ThreadIntegritySeverity.Error)
            {
                fore = UiError;
                back = ErrorBack;
            }
            else if (row.Severity == ThreadIntegritySeverity.Warning)
            {
                fore = UiWarning;
                back = WarningBack;
            }
            else if (row.IsSummary)
            {
                fore = UiMuted;
                back = UiHeader;
            }
            else
            {
                fore = UiSuccess;
                back = PassBack;
            }
        }

        private static string Csv(string value)
        {
            string s = value ?? "";
            return "\"" + s.Replace("\"", "\"\"") + "\"";
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                try { _toolTip?.Dispose(); } catch { }
                try { _wordmarkImage?.Dispose(); } catch { }
                _wordmarkImage = null;
            }
            base.Dispose(disposing);
        }
    }
}
