﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices;
using Inventor;

namespace ThreadPro
{
    /// <summary>
    /// Captured definition of a supported native Inventor ThreadFeature. Conversion replaces
    /// the cosmetic operation with physical Helivanta geometry in the same feature-history slot.
    /// </summary>
    internal sealed class NativeThreadConversionPlan
    {
        internal ThreadFeature Feature;
        internal Edge OriginalStartEdge;
        internal ThreadTarget InitialTarget;
        internal ThreadTargetSnapshot TargetIdentity;
        internal ThreadParametersSnapshot Parameters;
        internal string DocumentInternalName;
        internal string FeatureName;
        internal string ThreadTypeIdentifier;
        internal string ThreadDesignation;
        internal string NativeNominalSize;
        internal string ThreadClass;
        internal bool Internal;
        internal bool RightHanded;
        internal bool Metric;
        internal bool FullDepth;
        internal bool DirectionReversed;
        internal double NativePitchMm;
        internal double NativeDepthMm;
        internal double NativeOffsetMm;
    }

    internal static class NativeThreadConversionService
    {
        private sealed class EndOfPartSnapshot
        {
            internal bool WasAtBottom;
            internal object AnchorAfterMarker;
        }

        internal static bool TryResolveFeature(PartDocument doc, object selected, out ThreadFeature feature)
        {
            feature = null;
            if (doc == null || selected == null) return false;
            try { feature = ResolveFeature(selected, 0); } catch { feature = null; }
            return feature != null;
        }

        private static ThreadFeature ResolveFeature(object candidate, int depth)
        {
            if (candidate == null || depth > 6) return null;
            ThreadFeature direct = candidate as ThreadFeature;
            if (direct != null) return direct;

            try
            {
                BrowserNode node = candidate as BrowserNode;
                if (node != null)
                {
                    object native = null;
                    try { native = node.NativeObject; } catch { }
                    ThreadFeature fromNode = ResolveFeature(native, depth + 1);
                    if (fromNode != null) return fromNode;
                }
            }
            catch { }

            try
            {
                BrowserFolder folder = candidate as BrowserFolder;
                if (folder != null && folder.BrowserNode != null)
                {
                    ThreadFeature fromFolder = ResolveFeature(folder.BrowserNode, depth + 1);
                    if (fromFolder != null) return fromFolder;
                }
            }
            catch { }

            try
            {
                dynamic dynamicCandidate = candidate;
                object native = dynamicCandidate.NativeObject;
                if (native != null && !ReferenceEquals(native, candidate))
                {
                    ThreadFeature fromNative = ResolveFeature(native, depth + 1);
                    if (fromNative != null) return fromNative;
                }
            }
            catch { }

            try
            {
                dynamic dynamicCandidate = candidate;
                object browserNodeObject = dynamicCandidate.BrowserNode;
                BrowserNode browserNode = browserNodeObject as BrowserNode;
                if (browserNode != null && !ReferenceEquals(browserNode, candidate))
                {
                    ThreadFeature fromBrowserNode = ResolveFeature(browserNode, depth + 1);
                    if (fromBrowserNode != null) return fromBrowserNode;
                }
            }
            catch { }

            return null;
        }

        private sealed class StartEdgeAnalysis
        {
            internal Edge Edge;
            internal ThreadTarget Target;
        }

        /// <summary>
        /// Inventor's ThreadFeature.StartEdge returns an Edges collection. Some valid ThreadFeatures
        /// expose an empty collection (notably after earlier features in a sequential conversion have
        /// changed topology). Analyze StartEdge first; if it is empty or yields no usable circle, fall
        /// back to the analytic cylindrical faces returned by ThreadedFace. The fallback infers the
        /// start station from the cylinder axis and DirectionReversed and still fails closed on ambiguity.
        /// </summary>
        private static bool TryResolveStartEdge(Inventor.Application app, ThreadFeature feature,
                                                bool expectedExternal, out Edge chosenEdge,
                                                out ThreadTarget chosenTarget, out string error,
                                                bool preferFreeEnd = true)
        {
            chosenEdge = null;
            chosenTarget = null;
            error = null;

            Edges startEdges = null;
            try { startEdges = feature.StartEdge as Edges; }
            catch (Exception ex)
            {
                string accessError = "Не удалось получить коллекцию ThreadFeature.StartEdge: " + ex.Message;
                return TryResolveStartEdgeFallbackOrExplain(app, feature, expectedExternal, accessError,
                    out chosenEdge, out chosenTarget, out error, preferFreeEnd);
            }

            if (startEdges == null)
            {
                return TryResolveStartEdgeFallbackOrExplain(app, feature, expectedExternal,
                    "Inventor не вернул коллекцию ThreadFeature.StartEdge", out chosenEdge, out chosenTarget, out error, preferFreeEnd);
            }

            int count;
            try { count = startEdges.Count; }
            catch (Exception ex)
            {
                return TryResolveStartEdgeFallbackOrExplain(app, feature, expectedExternal,
                    "Не удалось прочитать количество начальных рёбер: " + ex.Message,
                    out chosenEdge, out chosenTarget, out error, preferFreeEnd);
            }
            if (count < 1)
            {
                return TryResolveStartEdgeFallbackOrExplain(app, feature, expectedExternal,
                    "Коллекция ThreadFeature.StartEdge пуста", out chosenEdge, out chosenTarget, out error, preferFreeEnd);
            }

            var analyzed = new List<StartEdgeAnalysis>();
            string firstFailure = null;
            int circularCount = 0;
            int enumeratedCount = 0;
            try
            {
                foreach (Edge edge in startEdges)
                {
                    enumeratedCount++;
                    if (edge == null) continue;

                    bool circular;
                    try
                    {
                        circular = edge.GeometryType == CurveTypeEnum.kCircleCurve ||
                                   edge.GeometryType == CurveTypeEnum.kCircularArcCurve;
                    }
                    catch { circular = false; }
                    if (!circular) continue;
                    circularCount++;

                    ThreadTarget candidate;
                    try { candidate = ThreadBuilder.Analyze(app, edge); }
                    catch (Exception ex)
                    {
                        if (firstFailure == null) firstFailure = ex.Message;
                        continue;
                    }
                    if (candidate == null || candidate.IsExternal != expectedExternal) continue;

                    int sameIndex = analyzed.FindIndex(item => SameStartCylinder(item.Target, candidate));
                    if (sameIndex < 0)
                    {
                        analyzed.Add(new StartEdgeAnalysis { Edge = edge, Target = candidate });
                    }
                    else if (IsBetterStartEdgeCandidate(edge, candidate, analyzed[sameIndex].Edge, analyzed[sameIndex].Target))
                    {
                        analyzed[sameIndex] = new StartEdgeAnalysis { Edge = edge, Target = candidate };
                    }
                }
            }
            catch (Exception ex)
            {
                return TryResolveStartEdgeFallbackOrExplain(app, feature, expectedExternal,
                    "Не удалось перечислить ThreadFeature.StartEdge: " + ex.Message +
                    ". Прочитано элементов: " + enumeratedCount.ToString(CultureInfo.InvariantCulture) +
                    " из " + count.ToString(CultureInfo.InvariantCulture),
                    out chosenEdge, out chosenTarget, out error, preferFreeEnd);
            }

            if (analyzed.Count == 1)
            {
                if (!preferFreeEnd)
                {
                    chosenEdge = analyzed[0].Edge;
                    chosenTarget = analyzed[0].Target;
                    error = null;
                    return true;
                }
                if (TryPreferFreeEndAsStart(app, analyzed[0].Edge, analyzed[0].Target,
                    out chosenEdge, out chosenTarget, out error))
                    return true;

                string freeEndFailure = error;
                return TryResolveStartEdgeFallbackOrExplain(app, feature, expectedExternal,
                    freeEndFailure, out chosenEdge, out chosenTarget, out error, preferFreeEnd);
            }
            if (analyzed.Count > 1)
            {
                error = "Коллекция ThreadFeature.StartEdge указывает на несколько различных цилиндрических целей. Автоматический выбор небезопасен; операция не изменена.";
                return false;
            }

            string analysisError = "StartEdge содержит " + count.ToString(CultureInfo.InvariantCulture) +
                " рёбер, круговых среди них — " + circularCount.ToString(CultureInfo.InvariantCulture) +
                ", но ни одно не определило цилиндрическую поверхность требуемого типа (" +
                (expectedExternal ? "наружную" : "внутреннюю") + ")." +
                (string.IsNullOrWhiteSpace(firstFailure) ? string.Empty : " Причина анализа: " + firstFailure);
            return TryResolveStartEdgeFallbackOrExplain(app, feature, expectedExternal, analysisError,
                out chosenEdge, out chosenTarget, out error, preferFreeEnd);
        }

        private sealed class ThreadedFaceEdgeCandidate
        {
            internal Edge Edge;
            internal ThreadTarget Target;
            internal double AxialStation;
        }

        private static bool TryResolveStartEdgeFallbackOrExplain(Inventor.Application app, ThreadFeature feature,
                                                                  bool expectedExternal, string startEdgeFailure,
                                                                  out Edge chosenEdge, out ThreadTarget chosenTarget,
                                                                  out string error, bool preferFreeEnd = true)
        {
            string fallbackError;
            if (TryResolveStartEdgeFromThreadedFace(app, feature, expectedExternal,
                out chosenEdge, out chosenTarget, out fallbackError, preferFreeEnd))
            {
                error = null;
                return true;
            }

            chosenEdge = null;
            chosenTarget = null;
            error = (startEdgeFailure ?? "StartEdge недоступен") +
                ". Резервное определение по ThreadFeature.ThreadedFace также не удалось: " +
                (fallbackError ?? "неизвестная причина") + ". Операция не изменена.";
            return false;
        }

        /// <summary>
        /// Fallback for a valid native ThreadFeature whose StartEdge collection is empty/stale.
        /// ThreadedFace returns the cylindrical face(s) which the cosmetic thread was applied to.
        /// We derive candidate circles from those faces and select the station consistent with the
        /// cylinder axis and DirectionReversed; we never choose a random edge from the whole part.
        /// </summary>
        private static bool TryResolveStartEdgeFromThreadedFace(Inventor.Application app, ThreadFeature feature,
                                                                 bool expectedExternal, out Edge chosenEdge,
                                                                 out ThreadTarget chosenTarget, out string error,
                                                                 bool preferFreeEnd = true)
        {
            chosenEdge = null;
            chosenTarget = null;
            error = null;
            Faces threadedFaces = null;
            try { threadedFaces = feature.ThreadedFace as Faces; }
            catch (Exception ex)
            {
                error = "ThreadedFace не удалось прочитать: " + ex.Message;
                return false;
            }
            if (threadedFaces == null)
            {
                error = "Inventor не вернул коллекцию ThreadedFace.";
                return false;
            }

            double[] referenceAxis = null;
            double[] referenceBasePoint = null;
            double referenceRadius = 0.0;
            string referenceBodyName = string.Empty;
            var candidates = new List<ThreadedFaceEdgeCandidate>();
            int faceCount = 0;
            int cylindricalFaceCount = 0;
            int circularEdgeCount = 0;
            int axisAlignedCount = 0;
            string firstFailure = null;

            try
            {
                foreach (Face face in threadedFaces)
                {
                    faceCount++;
                    if (face == null) continue;
                    try { if (face.SurfaceType != SurfaceTypeEnum.kCylinderSurface) continue; }
                    catch { continue; }

                    Cylinder cylinder;
                    try { cylinder = face.Geometry as Cylinder; }
                    catch { cylinder = null; }
                    if (cylinder == null) continue;
                    cylindricalFaceCount++;

                    UnitVector localAxisVector = null;
                    Point localCylinderBasePoint = null;
                    try
                    {
                        localAxisVector = cylinder.AxisVector;
                        localCylinderBasePoint = cylinder.BasePoint;
                    }
                    catch (Exception ex)
                    {
                        if (firstFailure == null) firstFailure = "не удалось получить ось/базовую точку цилиндра: " + ex.Message;
                        continue;
                    }
                    if (localAxisVector == null || localCylinderBasePoint == null) continue;
                    double[] localAxis = NormalizeVector(localAxisVector.X, localAxisVector.Y, localAxisVector.Z);
                    double[] localBasePoint = new[] { localCylinderBasePoint.X, localCylinderBasePoint.Y, localCylinderBasePoint.Z };
                    if (localAxis == null) continue;

                    string localBodyName = string.Empty;
                    try { localBodyName = face.SurfaceBody == null ? string.Empty : face.SurfaceBody.Name; } catch { }
                    if (referenceAxis == null)
                    {
                        referenceAxis = localAxis;
                        referenceBasePoint = localBasePoint;
                        referenceRadius = cylinder.Radius;
                        referenceBodyName = localBodyName;
                    }
                    else if (!SameCylinderFaceGeometry(referenceRadius, referenceAxis, referenceBasePoint, referenceBodyName,
                                                       cylinder.Radius, localAxis, localBasePoint, localBodyName))
                    {
                        error = "ThreadedFace содержит несколько различных цилиндрических поверхностей. Автоматический выбор исходного цилиндра небезопасен.";
                        return false;
                    }

                    Edges faceEdges = null;
                    try { faceEdges = face.Edges; } catch { }
                    if (faceEdges == null) continue;
                    foreach (Edge edge in faceEdges)
                    {
                        if (edge == null) continue;
                        bool circular;
                        try
                        {
                            circular = edge.GeometryType == CurveTypeEnum.kCircleCurve ||
                                       edge.GeometryType == CurveTypeEnum.kCircularArcCurve;
                        }
                        catch { circular = false; }
                        if (!circular) continue;
                        circularEdgeCount++;

                        ThreadTarget target;
                        try { target = ThreadBuilder.Analyze(app, edge); }
                        catch (Exception ex)
                        {
                            if (firstFailure == null) firstFailure = ex.Message;
                            continue;
                        }
                        if (target == null || target.IsExternal != expectedExternal || target.Center == null ||
                            target.Center.Length < 3 || target.U == null || target.U.Length < 3) continue;
                        if (Math.Abs(target.RadiusCm - referenceRadius) > Math.Max(0.001, referenceRadius * 1e-5)) continue;
                        if (!string.IsNullOrWhiteSpace(referenceBodyName) && !string.IsNullOrWhiteSpace(target.BodyName) &&
                            !string.Equals(referenceBodyName, target.BodyName, StringComparison.OrdinalIgnoreCase)) continue;

                        double directionDot = Dot3(target.U, referenceAxis);
                        double expectedSign = feature.DirectionReversed ? -1.0 : 1.0;
                        if (directionDot * expectedSign < 0.999) continue;
                        axisAlignedCount++;

                        double[] delta = new[]
                        {
                            target.Center[0] - referenceBasePoint[0],
                            target.Center[1] - referenceBasePoint[1],
                            target.Center[2] - referenceBasePoint[2]
                        };
                        double axial = Dot3(delta, referenceAxis);
                        double radialX = delta[0] - referenceAxis[0] * axial;
                        double radialY = delta[1] - referenceAxis[1] * axial;
                        double radialZ = delta[2] - referenceAxis[2] * axial;
                        double radialDistance = Math.Sqrt(radialX * radialX + radialY * radialY + radialZ * radialZ);
                        if (radialDistance > Math.Max(0.001, referenceRadius * 1e-5)) continue;

                        candidates.Add(new ThreadedFaceEdgeCandidate
                        {
                            Edge = edge,
                            Target = target,
                            AxialStation = axial
                        });
                    }
                }
            }
            catch (Exception ex)
            {
                string logPath = WriteNativeConversionDiagnostic("ResolveThreadedFace", "перечисление граней/границ ThreadedFace", ex, feature);
                error = "Не удалось перечислить ThreadedFace и её границы: " + ex.Message +
                    (string.IsNullOrWhiteSpace(logPath) ? "\nТехническая ошибка: " + ex.ToString() :
                     "\nПодробный стек ошибки записан в: " + logPath);
                return false;
            }

            if (referenceAxis == null || cylindricalFaceCount == 0)
            {
                error = "ThreadedFace не содержит распознаваемой цилиндрической грани (граней: " +
                    faceCount.ToString(CultureInfo.InvariantCulture) + ").";
                return false;
            }
            if (candidates.Count == 0)
            {
                error = "В ThreadedFace найдено цилиндрических граней: " + cylindricalFaceCount.ToString(CultureInfo.InvariantCulture) +
                    ", круговых границ: " + circularEdgeCount.ToString(CultureInfo.InvariantCulture) +
                    ", границ с направлением и типом цели, подходящими для преобразования: " + axisAlignedCount.ToString(CultureInfo.InvariantCulture) +
                    "." + (string.IsNullOrWhiteSpace(firstFailure) ? string.Empty : " Причина анализа: " + firstFailure);
                return false;
            }

            double startStation;
            if (!NativeThreadConversionPolicy.TryResolveStartStation(
                candidates.Select(item => item.AxialStation).ToList(), feature.DirectionReversed, out startStation))
            {
                error = "Не удалось определить осевую позицию начала резьбы из границ ThreadedFace.";
                return false;
            }

            // Split boundary arcs at the same axial station represent one start edge. Prefer the
            // longest connected cylinder segment and then a complete circle, as in StartEdge mode.
            var atStart = candidates.Where(item => Math.Abs(item.AxialStation - startStation) <= 0.001).ToList();
            var unique = new List<StartEdgeAnalysis>();
            foreach (ThreadedFaceEdgeCandidate candidate in atStart)
            {
                int existingIndex = unique.FindIndex(item => SameStartCylinder(item.Target, candidate.Target));
                if (existingIndex < 0)
                    unique.Add(new StartEdgeAnalysis { Edge = candidate.Edge, Target = candidate.Target });
                else if (IsBetterStartEdgeCandidate(candidate.Edge, candidate.Target,
                                                    unique[existingIndex].Edge, unique[existingIndex].Target))
                    unique[existingIndex] = new StartEdgeAnalysis { Edge = candidate.Edge, Target = candidate.Target };
            }

            if (unique.Count != 1)
            {
                error = unique.Count == 0
                    ? "В ThreadedFace не найдено подходящей круговой границы на расчётной начальной позиции."
                    : "На расчётной начальной позиции ThreadedFace найдено несколько различных цилиндрических целей.";
                return false;
            }

            if (!preferFreeEnd)
            {
                chosenEdge = unique[0].Edge;
                chosenTarget = unique[0].Target;
                error = null;
                return true;
            }
            return TryPreferFreeEndAsStart(app, unique[0].Edge, unique[0].Target,
                out chosenEdge, out chosenTarget, out error);
        }

        private static bool SameCylinderFaceGeometry(double leftRadius, double[] leftAxis, double[] leftBasePoint,
                                                     string leftBodyName, double rightRadius, double[] rightAxis,
                                                     double[] rightBasePoint, string rightBodyName)
        {
            if (Math.Abs(leftRadius - rightRadius) > Math.Max(0.001, Math.Max(leftRadius, rightRadius) * 1e-5)) return false;
            if (!string.IsNullOrWhiteSpace(leftBodyName) && !string.IsNullOrWhiteSpace(rightBodyName) &&
                !string.Equals(leftBodyName, rightBodyName, StringComparison.OrdinalIgnoreCase)) return false;
            if (Math.Abs(Dot3(leftAxis, rightAxis)) < 0.999) return false;
            double[] delta = new[]
            {
                rightBasePoint[0] - leftBasePoint[0],
                rightBasePoint[1] - leftBasePoint[1],
                rightBasePoint[2] - leftBasePoint[2]
            };
            double axial = Dot3(delta, leftAxis);
            double rx = delta[0] - leftAxis[0] * axial;
            double ry = delta[1] - leftAxis[1] * axial;
            double rz = delta[2] - leftAxis[2] * axial;
            return Math.Sqrt(rx * rx + ry * ry + rz * rz) <= 0.001;
        }

        private static double[] NormalizeVector(double x, double y, double z)
        {
            double length = Math.Sqrt(x * x + y * y + z * z);
            if (double.IsNaN(length) || double.IsInfinity(length) || length < 1e-12) return null;
            return new[] { x / length, y / length, z / length };
        }

        private static double Dot3(double[] left, double[] right)
        {
            if (left == null || right == null || left.Length < 3 || right.Length < 3) return 0.0;
            return left[0] * right[0] + left[1] * right[1] + left[2] * right[2];
        }

        private static bool SameStartCylinder(ThreadTarget left, ThreadTarget right)
        {
            if (left == null || right == null || left.Center == null || right.Center == null ||
                left.Center.Length < 3 || right.Center.Length < 3 || left.U == null || right.U == null ||
                left.U.Length < 3 || right.U.Length < 3 || left.IsExternal != right.IsExternal ||
                Math.Abs(left.RadiusCm - right.RadiusCm) > 0.001 ||
                Distance(left.Center, right.Center) > 0.001)
                return false;

            if (!string.IsNullOrWhiteSpace(left.BodyName) && !string.IsNullOrWhiteSpace(right.BodyName) &&
                !string.Equals(left.BodyName, right.BodyName, StringComparison.OrdinalIgnoreCase))
                return false;

            double dot = left.U[0] * right.U[0] + left.U[1] * right.U[1] + left.U[2] * right.U[2];
            return dot > 0.999;
        }

        private static bool IsBetterStartEdgeCandidate(Edge candidateEdge, ThreadTarget candidateTarget,
                                                       Edge currentEdge, ThreadTarget currentTarget)
        {
            if (candidateTarget != null && currentTarget != null &&
                Math.Abs(candidateTarget.LengthCm - currentTarget.LengthCm) > 1e-6)
                return candidateTarget.LengthCm > currentTarget.LengthCm;

            bool candidateCircle = IsCompleteCircle(candidateEdge);
            bool currentCircle = IsCompleteCircle(currentEdge);
            return candidateCircle && !currentCircle;
        }

        private static bool IsCompleteCircle(Edge edge)
        {
            try { return edge != null && edge.GeometryType == CurveTypeEnum.kCircleCurve; }
            catch { return false; }
        }

        private static bool SameOppositeEndCylinder(ThreadTarget source, ThreadTarget candidate)
        {
            if (source == null || candidate == null || source.Center == null || candidate.Center == null ||
                source.Center.Length < 3 || candidate.Center.Length < 3 || source.U == null || candidate.U == null ||
                source.U.Length < 3 || candidate.U.Length < 3 || source.IsExternal != candidate.IsExternal) return false;
            double tolerance = Math.Max(0.001, source.RadiusCm * 1e-5);
            if (Math.Abs(source.RadiusCm - candidate.RadiusCm) > tolerance ||
                Math.Abs(source.LengthCm - candidate.LengthCm) > Math.Max(0.001, source.LengthCm * 1e-5)) return false;
            if (!string.IsNullOrWhiteSpace(source.BodyName) && !string.IsNullOrWhiteSpace(candidate.BodyName) &&
                !string.Equals(source.BodyName, candidate.BodyName, StringComparison.OrdinalIgnoreCase)) return false;

            // Analyze() points U into the cylinder from each endpoint, so opposite ends must have
            // antiparallel axes and centers separated by the complete cylindrical-face length.
            if (Dot3(source.U, candidate.U) > -0.999) return false;
            double[] delta = new[]
            {
                candidate.Center[0] - source.Center[0],
                candidate.Center[1] - source.Center[1],
                candidate.Center[2] - source.Center[2]
            };
            double axial = Dot3(delta, source.U);
            double radialX = delta[0] - source.U[0] * axial;
            double radialY = delta[1] - source.U[1] * axial;
            double radialZ = delta[2] - source.U[2] * axial;
            double radialDistance = Math.Sqrt(radialX * radialX + radialY * radialY + radialZ * radialZ);
            return radialDistance <= tolerance &&
                Math.Abs(Math.Abs(axial) - source.LengthCm) <= Math.Max(0.001, source.LengthCm * 1e-5);
        }

        private static bool TryPreferFreeEndAsStart(Inventor.Application app, Edge selectedEdge,
            ThreadTarget selectedTarget, out Edge resolvedEdge, out ThreadTarget resolvedTarget, out string error)
        {
            resolvedEdge = selectedEdge;
            resolvedTarget = selectedTarget;
            error = null;
            if (selectedTarget == null)
            {
                error = "Не удалось определить цилиндр выбранного начального ребра.";
                return false;
            }

            if (!NativeThreadConversionPolicy.ShouldReverseStartToPreferFreeEnd(
                selectedTarget.StartIsShoulder, selectedTarget.EndIsShoulder))
                return true;

            var alternatives = new List<StartEdgeAnalysis>();
            try
            {
                foreach (Edge edge in selectedTarget.EndEdges)
                {
                    if (edge == null) continue;
                    bool circular;
                    try
                    {
                        circular = edge.GeometryType == CurveTypeEnum.kCircleCurve ||
                                   edge.GeometryType == CurveTypeEnum.kCircularArcCurve;
                    }
                    catch { circular = false; }
                    if (!circular) continue;

                    ThreadTarget candidate;
                    try { candidate = ThreadBuilder.Analyze(app, edge); }
                    catch { continue; }
                    if (candidate == null || candidate.StartIsShoulder ||
                        !SameOppositeEndCylinder(selectedTarget, candidate)) continue;

                    int sameIndex = alternatives.FindIndex(item => SameStartCylinder(item.Target, candidate));
                    if (sameIndex < 0) alternatives.Add(new StartEdgeAnalysis { Edge = edge, Target = candidate });
                    else if (IsBetterStartEdgeCandidate(edge, candidate,
                                                        alternatives[sameIndex].Edge, alternatives[sameIndex].Target))
                        alternatives[sameIndex] = new StartEdgeAnalysis { Edge = edge, Target = candidate };
                }
            }
            catch (Exception ex)
            {
                error = "Начальная граница находится у плеча; не удалось безопасно проверить противоположный свободный край: " + ex.Message;
                return false;
            }

            if (alternatives.Count != 1)
            {
                error = alternatives.Count == 0
                    ? "Начальная граница штатной резьбы находится у плеча, но противоположный свободный край не удалось однозначно определить. Операция не изменена."
                    : "У плеча найдено несколько возможных противоположных границ резьбы. Автоматический выбор небезопасен; операция не изменена.";
                return false;
            }

            resolvedEdge = alternatives[0].Edge;
            resolvedTarget = alternatives[0].Target;
            return true;
        }

        /// <summary>
        /// Reads the source cylinder and axial range of a native cosmetic thread without converting
        /// it. Unlike TryPrepare, this inspection path allows reversed native direction because it
        /// is used only for collision detection, not for B-Rep conversion.
        /// </summary>
        internal static bool TryGetOverlapSnapshot(Inventor.Application app, ThreadFeature feature,
            out ThreadTarget target, out bool fullDepth, out double lengthMm, out double offsetMm, out string error)
        {
            target = null;
            fullDepth = false;
            lengthMm = 0.0;
            offsetMm = 0.0;
            error = null;
            if (app == null || feature == null)
            {
                error = "Штатная резьба Inventor не задана.";
                return false;
            }

            try
            {
                PartDocument doc = app.ActiveDocument as PartDocument;
                if (doc == null || !FeatureBelongsToDocument(doc, feature))
                {
                    error = "Штатная резьба не принадлежит активной детали.";
                    return false;
                }

                StandardThreadInfo info = feature.ThreadInfo as StandardThreadInfo;
                if (info == null)
                {
                    error = "Тип ThreadInfo штатной резьбы не поддерживается для точного расчёта интервала.";
                    return false;
                }

                Edge startEdge;
                if (!TryResolveStartEdge(app, feature, !info.Internal, out startEdge, out target, out error, preferFreeEnd: false) || target == null)
                {
                    if (string.IsNullOrWhiteSpace(error)) error = "Не удалось определить цилиндр штатной резьбы.";
                    return false;
                }

                fullDepth = feature.FullDepth;
                Parameter depthParameter = null;
                if (!fullDepth)
                {
                    try { depthParameter = feature.ThreadDepth; }
                    catch (Exception ex)
                    {
                        error = "Не удалось прочитать ThreadDepth штатной резьбы: " + ex.Message;
                        return false;
                    }
                }

                Parameter offsetParameter;
                try { offsetParameter = feature.ThreadOffset; }
                catch (Exception ex)
                {
                    error = "Не удалось прочитать ThreadOffset штатной резьбы: " + ex.Message;
                    return false;
                }

                double depthCm = 0.0;
                double offsetCm = 0.0;
                if (!fullDepth && depthParameter != null)
                {
                    try { depthCm = Convert.ToDouble(depthParameter.Value, CultureInfo.InvariantCulture); }
                    catch (Exception ex)
                    {
                        error = "Не удалось прочитать значение ThreadDepth штатной резьбы: " + ex.Message;
                        return false;
                    }
                }
                if (offsetParameter != null)
                {
                    try { offsetCm = Convert.ToDouble(offsetParameter.Value, CultureInfo.InvariantCulture); }
                    catch (Exception ex)
                    {
                        error = "Не удалось прочитать значение ThreadOffset штатной резьбы: " + ex.Message;
                        return false;
                    }
                }

                double depthMm;
                if (!NativeThreadConversionPolicy.TryResolveNativeThreadLengths(fullDepth,
                    depthParameter != null, depthCm, offsetParameter != null, offsetCm,
                    target.LengthCm, out depthMm, out offsetMm, out lengthMm, out error))
                    return false;

                return true;
            }
            catch (Exception ex)
            {
                error = "Не удалось прочитать параметры штатной косметической резьбы: " + ex.Message;
                return false;
            }
        }

        internal static bool SameComObjectIdentity(object left, object right)
        {
            return SameComObject(left, right);
        }

        internal static bool TryPrepare(Inventor.Application app, ThreadFeature feature,
                                        out NativeThreadConversionPlan plan, out string error)
        {
            plan = null;
            error = null;
            if (app == null || feature == null)
            {
                error = "Не выбрана штатная операция «Резьба Inventor».";
                return false;
            }

            string stage = "проверка активного документа";
            try
            {
                PartDocument doc = app.ActiveDocument as PartDocument;
                if (doc == null)
                {
                    error = "Для преобразования штатной резьбы откройте деталь Inventor (.ipt).";
                    return false;
                }
                stage = "проверка принадлежности ThreadFeature активной детали";
                if (!FeatureBelongsToDocument(doc, feature))
                {
                    error = "Выбранная штатная резьба не принадлежит активной детали. Операция не изменена.";
                    return false;
                }

                stage = "чтение StandardThreadInfo штатной резьбы";
                StandardThreadInfo info = feature.ThreadInfo as StandardThreadInfo;
                if (info == null)
                {
                    error = "Этот тип ThreadInfo пока не поддерживается. Для преобразования требуется штатная цилиндрическая резьба с параметрами StandardThreadInfo. Коническая резьба не изменена.";
                    return false;
                }
                if (feature.DirectionReversed)
                {
                    error = "Пока не поддерживается ThreadFeature с реверсированным направлением. Для безопасности исходная резьба не изменена.";
                    return false;
                }

                stage = "определение исходной цилиндрической поверхности по StartEdge/ThreadedFace";
                Edge startEdge;
                ThreadTarget target;
                if (!TryResolveStartEdge(app, feature, !info.Internal, out startEdge, out target, out error))
                    return false;
                if (target == null || target.Center == null || target.Center.Length < 3 ||
                    target.U == null || target.U.Length < 3 || target.Body == null)
                {
                    error = "Определитель штатной резьбы вернул неполную цель: отсутствует цилиндр, ось, центр или SurfaceBody. Операция не изменена.";
                    return false;
                }

                stage = "сопоставление обозначения и профиля штатной резьбы";
                NativeThreadConversionPolicy.ProfileDefinition profile;
                if (!NativeThreadConversionPolicy.TryResolveProfile(
                    SafeString(() => info.ThreadTypeIdentifier),
                    SafeString(() => info.ThreadDesignation),
                    SafeString(() => info.NominalSize),
                    info.Metric,
                    Convert.ToDouble(info.Pitch, CultureInfo.InvariantCulture),
                    out profile, out error))
                    return false;

                stage = "чтение ThreadDepth/ThreadOffset и разрешение полной или ограниченной длины";
                bool fullDepth = feature.FullDepth;
                Inventor.Parameter depthParameter = null;
                Inventor.Parameter offsetParameter;
                // Do not even query ThreadDepth for FullDepth features: Inventor variants can
                // legitimately omit this COM Parameter because length is defined by the target face.
                if (!fullDepth)
                {
                    try { depthParameter = feature.ThreadDepth; }
                    catch (Exception ex)
                    {
                        error = "Не удалось получить параметр ThreadDepth штатной резьбы с ограниченной длиной: " + ex.Message + ". Операция не изменена.";
                        return false;
                    }
                }
                try { offsetParameter = feature.ThreadOffset; }
                catch (Exception ex)
                {
                    error = "Не удалось получить параметр ThreadOffset штатной резьбы: " + ex.Message + ". Операция не изменена.";
                    return false;
                }
                double depthCm = 0.0;
                double offsetCm = 0.0;
                if (!fullDepth && depthParameter != null)
                {
                    try { depthCm = Convert.ToDouble(depthParameter.Value, CultureInfo.InvariantCulture); }
                    catch (Exception ex)
                    {
                        error = "Не удалось прочитать значение ThreadDepth штатной резьбы: " + ex.Message + ". Операция не изменена.";
                        return false;
                    }
                }
                if (offsetParameter != null)
                {
                    try { offsetCm = Convert.ToDouble(offsetParameter.Value, CultureInfo.InvariantCulture); }
                    catch (Exception ex)
                    {
                        error = "Не удалось прочитать значение ThreadOffset штатной резьбы: " + ex.Message + ". Операция не изменена.";
                        return false;
                    }
                }
                double offsetMm, depthMm, lengthMm;
                if (!NativeThreadConversionPolicy.TryResolveNativeThreadLengths(fullDepth,
                    depthParameter != null, depthCm, offsetParameter != null, offsetCm,
                    target.LengthCm, out depthMm, out offsetMm, out lengthMm, out error))
                {
                    error = (error ?? "Не удалось разрешить длину штатной резьбы.") + " Операция Inventor не изменена.";
                    return false;
                }

                stage = "подготовка параметров физического построения и контрольного снимка";
                List<ThreadSize> sizes = ThreadStandards.Sizes(profile.Standard);
                string sizeName = ThreadSizeNamePolicy.Build(profile.Standard, sizes, profile.DiameterMm, profile.PitchMm);
                var parameters = new ThreadParametersSnapshot
                {
                    Standard = (int)profile.Standard,
                    SizeName = sizeName,
                    PitchMm = profile.PitchMm,
                    NominalDiaMm = profile.DiameterMm,
                    Starts = profile.Starts,
                    ClearanceMm = 0.0,
                    External = target.IsExternal,
                    Round = true,
                    Smooth = true,
                    SimplifiedRunout = false,
                    RunSteps = 1.0,
                    Mirror = false,
                    SortThreadsIntoFolders = true,
                    FullLength = fullDepth,
                    LengthMm = lengthMm,
                    OffsetMm = offsetMm,
                    RunOut = true,
                    RightHand = info.RightHanded,
                    // A native Inventor ThreadOffset places the physical thread start
                    // inside the cylindrical face, where no circular boundary edge exists.
                    // Do not request a start-edge chamfer in that case: ThreadBuilder's
                    // edge lookup is intentionally based on the actual cylinder boundary.
                    // Keep the legacy 1 mm start chamfer only when the native thread starts
                    // at the cylinder edge; smooth run-out handles the offset start instead.
                    ChamferMode = offsetMm <= 1e-6 ? 1 : 0,
                    ChamferMm = 1.0
                };

                plan = new NativeThreadConversionPlan
                {
                    Feature = feature,
                    OriginalStartEdge = startEdge,
                    InitialTarget = target,
                    TargetIdentity = new ThreadTargetSnapshot
                    {
                        Center = (double[])target.Center.Clone(),
                        Axis = (double[])target.U.Clone(),
                        RadiusCm = target.RadiusCm,
                        LengthCm = target.LengthCm,
                        IsExternal = target.IsExternal,
                        BodyName = target.BodyName ?? string.Empty,
                        StartIsShoulder = target.StartIsShoulder,
                        EndIsShoulder = target.EndIsShoulder
                    },
                    Parameters = parameters,
                    DocumentInternalName = SafeString(() => doc.InternalName),
                    FeatureName = SafeString(() => feature.Name),
                    ThreadTypeIdentifier = SafeString(() => info.ThreadTypeIdentifier),
                    ThreadDesignation = SafeString(() => info.ThreadDesignation),
                    NativeNominalSize = SafeString(() => info.NominalSize),
                    ThreadClass = SafeString(() => info.Class),
                    Internal = info.Internal,
                    RightHanded = info.RightHanded,
                    Metric = info.Metric,
                    FullDepth = fullDepth,
                    DirectionReversed = feature.DirectionReversed,
                    NativePitchMm = profile.PitchMm,
                    NativeDepthMm = depthMm,
                    NativeOffsetMm = offsetMm
                };
                return true;
            }
            catch (Exception ex)
            {
                plan = null;
                string logPath = WriteNativeConversionDiagnostic("Prepare", stage, ex, feature);
                error = "Не удалось подготовить преобразование штатной резьбы Inventor на этапе «" + stage + "»: " + ex.Message +
                    (string.IsNullOrWhiteSpace(logPath) ? "\nТехническая ошибка: " + ex.ToString() :
                     "\nПодробный стек ошибки записан в: " + logPath);
                return false;
            }
        }

        private static bool ValidateNoExistingHelivantaOverlap(PartDocument doc, ThreadTarget proposed,
            ThreadParams parameters, out string error)
        {
            error = null;
            if (doc == null || proposed == null || parameters == null)
            {
                error = "Преобразование остановлено: невозможно проверить сохранённые физические резьбы Helivanta.";
                return false;
            }

            List<ThreadMetadataGroup> groups;
            string loadError;
            if (!ThreadMetadataStore.TryLoadAllGroups(doc, out groups, out loadError))
            {
                error = "Преобразование остановлено: не удалось прочитать сохранённые группы Helivanta для проверки пересечений. " +
                    (loadError ?? "Результат проверки неполон.");
                return false;
            }

            foreach (ThreadMetadataGroup group in groups)
            {
                if (group == null || group.Record == null || group.Record.Target == null || group.Record.Parameters == null)
                {
                    error = "Преобразование остановлено: обнаружена неполная запись физической резьбы Helivanta. Проверьте метаданные и повторите операцию.";
                    return false;
                }

                ThreadTargetSnapshot existing = group.Record.Target;
                if (existing.Center == null || existing.Center.Length < 3 || existing.Axis == null || existing.Axis.Length < 3 ||
                    double.IsNaN(existing.RadiusCm) || double.IsInfinity(existing.RadiusCm) || existing.RadiusCm <= 0.0 ||
                    double.IsNaN(existing.LengthCm) || double.IsInfinity(existing.LengthCm) || existing.LengthCm <= 0.0)
                {
                    error = "Преобразование остановлено: геометрические метаданные существующей резьбы Helivanta неполны, поэтому безопасно исключить пересечение невозможно.";
                    return false;
                }
                if (!ThreadTargetIsolationPolicy.SameCylinderGeometry(existing.BodyName, proposed.BodyName,
                    existing.RadiusCm, proposed.RadiusCm, existing.Center, existing.Axis,
                    proposed.Center, proposed.U, requireBodyNames: false))
                    continue;

                ThreadParametersSnapshot oldParameters = group.Record.Parameters;
                double newStart = 0.0, newEnd = 0.0, oldStart = 0.0, oldEnd = 0.0;
                bool intervalsKnown = NativeThreadOverlapPolicy.TryGetInterval(
                    proposed.Center, proposed.U, proposed.LengthCm,
                    parameters.FullLength, parameters.LengthMm, parameters.OffsetMm,
                    proposed.Center, proposed.U, out newStart, out newEnd) &&
                    NativeThreadOverlapPolicy.TryGetInterval(
                    existing.Center, existing.Axis, existing.LengthCm,
                    oldParameters.FullLength, oldParameters.LengthMm, oldParameters.OffsetMm,
                    proposed.Center, proposed.U, out oldStart, out oldEnd);

                if (NativeThreadOverlapPolicy.ShouldBlock(true, intervalsKnown,
                    intervalsKnown ? newStart : 0.0, intervalsKnown ? newEnd : 0.0,
                    intervalsKnown ? oldStart : 0.0, intervalsKnown ? oldEnd : 0.0))
                {
                    string reason = intervalsKnown
                        ? "осевые интервалы пересекаются"
                        : "не удалось достоверно определить осевой интервал на том же цилиндре";
                    error = "Преобразование запрещено: новая физическая резьба пересекается с уже построенной резьбой Helivanta (" +
                        reason + "). Исходная косметическая ThreadFeature не изменена.";
                    return false;
                }
            }
            return true;
        }

        internal static bool TryGetDownstreamOperationCount(PartDocument doc, ThreadFeature feature,
                                                             out int count, out string error)
        {
            count = 0;
            error = null;
            try
            {
                if (doc == null || feature == null)
                {
                    error = "Не удалось определить деталь или штатную резьбу для проверки истории. Преобразование не начато.";
                    return false;
                }

                // BrowserPane is a presentation tree, not an authoritative feature-history list.
                // Its top-level nodes may include origin/body/group folders and nested nodes;
                // counting them produced false downstream totals for a ThreadFeature at the tail.
                // ComponentDefinition.Features is the ordered Inventor feature collection and is
                // also the ordering source used by ThreadEditService for Helivanta history checks.
                PartFeatures features = doc.ComponentDefinition.Features;
                int total = 0;
                int selectedIndex = -1;
                int matches = 0;
                foreach (object historyFeature in features)
                {
                    if (SameComObject(historyFeature, feature))
                    {
                        selectedIndex = total;
                        matches++;
                    }
                    total++;
                }

                if (matches != 1)
                {
                    error = matches == 0
                        ? "Выбранная штатная резьба не найдена в упорядоченной истории ComponentDefinition.Features. Преобразование не начато."
                        : "Выбранная штатная резьба неоднозначно сопоставилась нескольким элементам истории. Преобразование не начато.";
                    return false;
                }

                int resolved = NativeThreadConversionPolicy.ResolveDownstreamOperationCount(total, selectedIndex);
                if (resolved < 0)
                {
                    error = "Inventor вернул недопустимый индекс штатной резьбы в истории построений. Преобразование не начато.";
                    return false;
                }

                count = resolved;
                return true;
            }
            catch (Exception ex)
            {
                string logPath = WriteNativeConversionDiagnostic("DownstreamCount", "подсчёт последующих операций в ComponentDefinition.Features", ex, feature);
                error = "Не удалось надёжно проверить последующие операции в истории построений: " + ex.Message +
                    (string.IsNullOrWhiteSpace(logPath) ? "\nТехническая ошибка: " + ex.ToString() :
                     "\nПодробный стек ошибки записан в: " + logPath) + ". Преобразование не начато.";
                return false;
            }
        }

        internal static bool TryConvert(Inventor.Application app, NativeThreadConversionPlan plan,
                                        ThreadParams parameters, out string threadId,
                                        out string warning, out string error)
        {
            threadId = null;
            warning = null;
            error = null;
            if (app == null || plan == null || plan.Feature == null || parameters == null)
            {
                error = "Нет подготовленной штатной резьбы или параметров физического построения.";
                return false;
            }

            PartDocument doc = null;
            Transaction transaction = null;
            bool transactionOpened = false;
            string stage = "проверка исходной штатной резьбы";
            bool abortSucceeded = true;
            try
            {
                doc = app.ActiveDocument as PartDocument;
                if (doc == null) throw new InvalidOperationException("Активный документ должен быть деталью Inventor (.ipt).");
                if (!string.Equals(plan.DocumentInternalName, SafeString(() => doc.InternalName), StringComparison.OrdinalIgnoreCase))
                    throw new InvalidOperationException("Активная деталь отличается от детали, где была выбрана штатная резьба. Выберите операцию заново.");
                if (!SourceFeatureStillMatches(plan))
                    throw new InvalidOperationException("Параметры штатной резьбы изменились после открытия Helivanta. Закройте окно и выберите операцию заново.");
                if (parameters.External != plan.TargetIdentity.IsExternal)
                    throw new InvalidOperationException("Тип резьбы нельзя переключить с наружного на внутренний или наоборот при преобразовании выбранной цилиндрической поверхности.");
                if (!NativeThreadConversionPolicy.NearlyEqual(parameters.NominalDiaMm, plan.Parameters.NominalDiaMm, 0.0006))
                    throw new InvalidOperationException("Номинальный диаметр исходной штатной резьбы зафиксирован. Изменение диаметра потребовало бы отдельной операции подготовки цилиндра.");
                if (parameters.PitchMm <= 0.0 || parameters.Starts < 1 || parameters.Starts > 12 || parameters.OffsetMm < 0.0 ||
                    (!parameters.FullLength && parameters.LengthMm <= 0.0))
                    throw new InvalidOperationException("Параметры физической резьбы недопустимы.");

                // Defense in depth: validate persisted Helivanta physical zones inside the service,
                // immediately before any transaction/history mutation. The dialog preflight is not
                // the sole safety barrier for native ThreadFeature conversion.
                stage = "проверка пересечения с сохранёнными физическими резьбами Helivanta";
                string physicalOverlapError;
                if (!ValidateNoExistingHelivantaOverlap(doc, plan.InitialTarget, parameters, out physicalOverlapError))
                    throw new InvalidOperationException(physicalOverlapError);

                // Check the original solid before opening a transaction or deleting the native
                // cosmetic ThreadFeature. A thin-wall rejection must leave that feature untouched.
                ThreadBuilder.ValidateTargetWallThicknessOrThrow(app, plan.InitialTarget, parameters);

                EndOfPartSnapshot eop;
                if (!TryCaptureEndOfPartPosition(doc, plan.Feature, out eop, out error))
                    throw new InvalidOperationException(error);

                threadId = Guid.NewGuid().ToString("N");
                stage = "открытие общей транзакции преобразования";
                TransactionLifecycleDiagnostics.Write("NativeThreadConversionService", "StartTransaction.before", app, doc,
                    null, false, "stage=" + stage + "; feature=" + (plan.FeatureName ?? string.Empty) + "; threadId=" + threadId);
                transaction = app.TransactionManager.StartTransaction(
                    (Inventor._Document)(object)doc,
                    ThreadBuilder.TransactionPrefix + " — преобразование штатной резьбы " + plan.FeatureName);
                if (transaction == null) throw new InvalidOperationException("Inventor не создал транзакцию преобразования.");
                transactionOpened = true;
                TransactionLifecycleDiagnostics.Write("NativeThreadConversionService", "StartTransaction.after", app, doc,
                    transaction, false, "stage=" + stage + "; feature=" + (plan.FeatureName ?? string.Empty) + "; threadId=" + threadId);

                stage = "откат истории к штатной операции Thread";
                TransactionLifecycleDiagnostics.Write("NativeThreadConversionService", "SetEndOfPart.before", app, doc,
                    transaction, false, "feature=" + (plan.FeatureName ?? string.Empty));
                plan.Feature.SetEndOfPart(true);
                TransactionLifecycleDiagnostics.Write("NativeThreadConversionService", "SetEndOfPart.after", app, doc,
                    transaction, false, "feature=" + (plan.FeatureName ?? string.Empty));
                bool updateAfterEopSucceeded = doc.Update2(true);
                TransactionLifecycleDiagnostics.Write("NativeThreadConversionService", "Update2.after-EOP", app, doc,
                    transaction, true, "success=" + updateAfterEopSucceeded);
                if (!updateAfterEopSucceeded) throw new InvalidOperationException("Inventor не смог откатить модель к исходной операции Thread.");

                stage = "удаление косметической операции Inventor с сохранением последующих построений";
                // Keep dependent features in the history. They must be recalculated against the
                // replacement physical geometry, and any failure must abort the whole transaction.
                TransactionLifecycleDiagnostics.Write("NativeThreadConversionService", "ThreadFeature.Delete.before", app, doc,
                    transaction, false, "feature=" + (plan.FeatureName ?? string.Empty));
                ((dynamic)plan.Feature).Delete(true, true, true);
                TransactionLifecycleDiagnostics.Write("NativeThreadConversionService", "ThreadFeature.Delete.after", app, doc,
                    transaction, false, "feature=" + (plan.FeatureName ?? string.Empty));
                bool updateAfterDeleteSucceeded = doc.Update2(true);
                TransactionLifecycleDiagnostics.Write("NativeThreadConversionService", "Update2.after-delete", app, doc,
                    transaction, true, "success=" + updateAfterDeleteSucceeded);
                if (!updateAfterDeleteSucceeded) throw new InvalidOperationException("Inventor не смог обновить модель после удаления штатной резьбы.");

                stage = "повторный поиск исходного цилиндра после отката истории";
                ThreadTarget target = ResolveBaseTarget(app, doc, plan, out error);
                if (target == null) throw new InvalidOperationException(error ?? "Исходный цилиндр не найден однозначно.");

                ThreadParams replacement = parameters;
                replacement.External = target.IsExternal;
                ThreadBuilder.LastWarning = null;
                ThreadBuilder.LastError = null;
                ThreadBuilder.LastUserError = null;
                ThreadBuilder.LastRunoutPerformance = null;
                ThreadBuilder.LastMetadataStatus = null;
                ThreadBuilder.LastMetadataAttachSucceeded = false;
                ThreadBuilder.ResetBrowserFolderPerformance();

                stage = "построение физической резьбы Helivanta в исходной позиции истории";
                TransactionLifecycleDiagnostics.Write("NativeThreadConversionService", "ThreadBuilder.Build.before", app, doc,
                    transaction, false, "threadId=" + threadId + "; feature=" + (plan.FeatureName ?? string.Empty));
                ThreadBuilder.Build(app, target, replacement, false, threadId);
                TransactionLifecycleDiagnostics.Write("NativeThreadConversionService", "ThreadBuilder.Build.after", app, doc,
                    transaction, true, "threadId=" + threadId + "; metadataAttached=" + ThreadBuilder.LastMetadataAttachSucceeded);
                if (!ThreadBuilder.LastMetadataAttachSucceeded)
                    throw new InvalidOperationException("Физическая геометрия была построена, но метаданные группы Helivanta не удалось сохранить. Транзакция отменяется.");

                stage = "восстановление исходного положения End-of-Part и перестроение последующих операций";
                TransactionLifecycleDiagnostics.Write("NativeThreadConversionService", "RestoreEndOfPartPosition.before", app, doc,
                    transaction, false, "threadId=" + threadId);
                RestoreEndOfPartPosition(doc, eop);
                TransactionLifecycleDiagnostics.Write("NativeThreadConversionService", "RestoreEndOfPartPosition.after", app, doc,
                    transaction, false, "threadId=" + threadId);
                bool updateAfterRestoreSucceeded = doc.Update2(true);
                TransactionLifecycleDiagnostics.Write("NativeThreadConversionService", "Update2.after-EOP-restore", app, doc,
                    transaction, true, "success=" + updateAfterRestoreSucceeded + "; threadId=" + threadId);
                if (!updateAfterRestoreSucceeded)
                    throw new InvalidOperationException("Inventor сообщил об ошибке после перестроения последующих операций. Преобразование отменяется, чтобы сохранить исходную деталь.");

                ThreadMetadataGroup createdGroup;
                string metadataError;
                if (!ThreadMetadataStore.TryLoadGroup(doc, threadId, out createdGroup, out metadataError))
                    throw new InvalidOperationException("После перестроения не удалось проверить метаданные новой физической резьбы: " + metadataError);

                warning = ThreadBuilder.LastWarning;
                TransactionLifecycleDiagnostics.Write("NativeThreadConversionService", "Transaction.End.before", app, doc,
                    transaction, false, "stage=" + stage + "; threadId=" + threadId);
                transaction.End();
                TransactionLifecycleDiagnostics.Write("NativeThreadConversionService", "Transaction.End.after", app, doc,
                    transaction, true, "stage=" + stage + "; threadId=" + threadId);
                transaction = null;
                transactionOpened = false;
                return true;
            }
            catch (Exception ex)
            {
                TransactionLifecycleDiagnostics.Write("NativeThreadConversionService", "Convert.exception-before-abort", app, doc,
                    transaction, true, "stage=" + stage + "; exception=" + ex);
                string logPath = WriteNativeConversionDiagnostic("Convert", stage, ex, plan == null ? null : plan.Feature, plan);
                error = "Преобразование штатной резьбы остановлено на этапе «" + stage + ": " + ex.Message +
                    (string.IsNullOrWhiteSpace(logPath) ? "\nТехническая ошибка: " + ex.ToString() :
                     "\nПодробный стек ошибки записан в: " + logPath);
                if (transactionOpened && transaction != null)
                {
                    TransactionLifecycleDiagnostics.Write("NativeThreadConversionService", "Transaction.Abort.before", app, doc,
                        transaction, false, "stage=" + stage);
                    try
                    {
                        transaction.Abort();
                        TransactionLifecycleDiagnostics.Write("NativeThreadConversionService", "Transaction.Abort.after", app, doc,
                            transaction, true, "stage=" + stage + "; result=success");
                    }
                    catch (Exception abortEx)
                    {
                        abortSucceeded = false;
                        TransactionLifecycleDiagnostics.Write("NativeThreadConversionService", "Transaction.Abort.failed", app, doc,
                            transaction, true, "stage=" + stage + "; exception=" + abortEx);
                        error += " Не удалось выполнить Abort: " + abortEx.Message;
                    }
                }
                transaction = null;
                transactionOpened = false;

                bool nativeRestored = abortSucceeded && doc != null && SourceFeatureExists(doc, plan);
                if (!nativeRestored)
                {
                    error += " КРИТИЧЕСКИ: не удалось подтвердить восстановление исходной операции Inventor после отката. НЕ СОХРАНЯЙТЕ этот IPT; закройте документ без сохранения и откройте последнюю сохранённую копию.";
                }
                else
                {
                    error += " Транзакция отменена; исходная штатная операция Inventor обнаружена после отката.";
                }
                return false;
            }
            finally
            {
                if (transaction != null)
                {
                    TransactionLifecycleDiagnostics.Write("NativeThreadConversionService", "finally.Transaction.Abort.before", app, doc,
                        transaction, false, "stage=" + stage);
                    try
                    {
                        transaction.Abort();
                        TransactionLifecycleDiagnostics.Write("NativeThreadConversionService", "finally.Transaction.Abort.after", app, doc,
                            transaction, true, "stage=" + stage + "; result=success");
                    }
                    catch (Exception abortEx)
                    {
                        TransactionLifecycleDiagnostics.Write("NativeThreadConversionService", "finally.Transaction.Abort.failed", app, doc,
                            transaction, true, "stage=" + stage + "; exception=" + abortEx);
                    }
                }
            }
        }

        private static bool TryReadParameterMillimeters(Inventor.Parameter parameter, bool missingMeansZero, out double millimeters)
        {
            millimeters = 0.0;
            if (parameter == null) return missingMeansZero;
            try
            {
                double cm = Convert.ToDouble(parameter.Value, CultureInfo.InvariantCulture);
                millimeters = NativeThreadConversionPolicy.DatabaseCentimetersToMillimeters(cm);
                return !double.IsNaN(millimeters) && !double.IsInfinity(millimeters);
            }
            catch { return false; }
        }

        private static bool NativeOffsetStillMatches(ThreadFeature feature, double expectedOffsetMm)
        {
            if (feature == null) return false;
            double currentOffsetMm;
            return TryReadParameterMillimeters(feature.ThreadOffset, true, out currentOffsetMm) &&
                   NativeThreadConversionPolicy.NearlyEqual(currentOffsetMm, expectedOffsetMm, 1e-5);
        }

        private static string WriteNativeConversionDiagnostic(string operation, string stage, Exception ex,
                                                              ThreadFeature feature, NativeThreadConversionPlan plan = null)
        {
            try
            {
                string baseDir = System.IO.Path.Combine(System.Environment.GetFolderPath(System.Environment.SpecialFolder.LocalApplicationData),
                    "Helivanta", "Logs");
                System.IO.Directory.CreateDirectory(baseDir);
                string path = System.IO.Path.Combine(baseDir, "native-thread-conversion.log");
                string featureName = "<unavailable>";
                string designation = "<unavailable>";
                string nominalSize = "<unavailable>";
                bool? isFullDepth = null;
                try { if (feature != null) featureName = SafeString(() => feature.Name); } catch { }
                try
                {
                    StandardThreadInfo info = feature == null ? null : feature.ThreadInfo as StandardThreadInfo;
                    if (info != null)
                    {
                        designation = SafeString(() => info.ThreadDesignation);
                        nominalSize = SafeString(() => info.NominalSize);
                    }
                }
                catch { }
                try { if (feature != null) isFullDepth = feature.FullDepth; } catch { }
                var text = new System.Text.StringBuilder();
                text.AppendLine("----- " + DateTime.Now.ToString("O", CultureInfo.InvariantCulture) + " -----");
                text.AppendLine("Operation: " + (operation ?? "unknown"));
                text.AppendLine("Stage: " + (stage ?? "unknown"));
                text.AppendLine("Feature: " + featureName);
                text.AppendLine("Designation: " + designation);
                text.AppendLine("NominalSize: " + nominalSize);
                text.AppendLine("FullDepth: " + (isFullDepth.HasValue ? isFullDepth.Value.ToString() : "<unavailable>"));
                if (plan != null)
                {
                    text.AppendLine("PlannedDocument: " + (plan.DocumentInternalName ?? "<null>"));
                    text.AppendLine("PlannedTargetBody: " + (plan.TargetIdentity == null ? "<null>" : plan.TargetIdentity.BodyName ?? "<null>"));
                    text.AppendLine("PlannedTargetRadiusCm: " + (plan.TargetIdentity == null ? "<null>" : plan.TargetIdentity.RadiusCm.ToString("R", CultureInfo.InvariantCulture)));
                }
                text.AppendLine(ex == null ? "Exception: <null>" : ex.ToString());
                text.AppendLine();
                DiagnosticLogMaintenance.Append(baseDir, "native-thread-conversion.log", text.ToString());
                return path;
            }
            catch { return null; }
        }

        private static bool SourceFeatureStillMatches(NativeThreadConversionPlan plan)
        {
            return plan != null && MatchesNativeFeatureSnapshot(plan.Feature, plan);
        }

        internal static bool VerifyOriginalFeatureRestored(PartDocument doc, NativeThreadConversionPlan plan)
        {
            return doc != null && plan != null && SourceFeatureExists(doc, plan);
        }

        internal static bool TryRefreshAfterUndo(Inventor.Application app, NativeThreadConversionPlan previousPlan,
                                                  out NativeThreadConversionPlan refreshedPlan, out string error)
        {
            refreshedPlan = null;
            error = null;
            PartDocument doc = app == null ? null : app.ActiveDocument as PartDocument;
            if (doc == null || previousPlan == null)
            {
                error = "Нет активной детали или исходного плана штатной резьбы после Undo.";
                return false;
            }

            var matches = new List<ThreadFeature>();
            try
            {
                foreach (ThreadFeature feature in doc.ComponentDefinition.Features.ThreadFeatures)
                    if (MatchesNativeFeatureSnapshot(feature, previousPlan)) matches.Add(feature);
            }
            catch (Exception ex)
            {
                error = "Не удалось повторно найти восстановленную штатную резьбу после Undo: " + ex.Message;
                return false;
            }

            if (matches.Count != 1)
            {
                error = matches.Count == 0
                    ? "Исходная ThreadFeature не найдена после Undo."
                    : "После Undo найдено несколько одинаковых ThreadFeature; безопасное повторное изменение неоднозначно.";
                return false;
            }

            if (!TryPrepare(app, matches[0], out refreshedPlan, out error))
            {
                refreshedPlan = null;
                error = "Исходная ThreadFeature восстановлена, но её параметры не удалось повторно загрузить: " +
                    (error ?? "причина не определена");
                return false;
            }
            return true;
        }

        private static bool MatchesNativeFeatureSnapshot(ThreadFeature feature, NativeThreadConversionPlan plan)
        {
            try
            {
                if (feature == null || plan == null) return false;
                StandardThreadInfo info = feature.ThreadInfo as StandardThreadInfo;
                if (info == null) return false;
                if (!string.Equals(SafeString(() => feature.Name), plan.FeatureName, StringComparison.Ordinal) ||
                    !string.Equals(SafeString(() => info.ThreadTypeIdentifier), plan.ThreadTypeIdentifier, StringComparison.Ordinal) ||
                    !string.Equals(SafeString(() => info.ThreadDesignation), plan.ThreadDesignation, StringComparison.Ordinal) ||
                    !string.Equals(SafeString(() => info.NominalSize), plan.NativeNominalSize, StringComparison.Ordinal) ||
                    !string.Equals(SafeString(() => info.Class), plan.ThreadClass, StringComparison.Ordinal)) return false;
                if (info.Internal != plan.Internal || info.RightHanded != plan.RightHanded || info.Metric != plan.Metric ||
                    feature.FullDepth != plan.FullDepth || feature.DirectionReversed != plan.DirectionReversed) return false;
                if (!NativeThreadConversionPolicy.NearlyEqual(
                    Convert.ToDouble(info.Pitch, CultureInfo.InvariantCulture) * (info.Metric ? 1.0 : 25.4),
                    plan.NativePitchMm, 1e-5)) return false;
                if (!plan.FullDepth)
                {
                    double depthMm;
                    if (!TryReadParameterMillimeters(feature.ThreadDepth, false, out depthMm) ||
                        !NativeThreadConversionPolicy.NearlyEqual(depthMm, plan.NativeDepthMm, 1e-5)) return false;
                }
                return NativeOffsetStillMatches(feature, plan.NativeOffsetMm);
            }
            catch { return false; }
        }

        private static bool SourceFeatureExists(PartDocument doc, NativeThreadConversionPlan plan)
        {
            try
            {
                int matchingFeatures = 0;
                foreach (ThreadFeature feature in doc.ComponentDefinition.Features.ThreadFeatures)
                    if (MatchesNativeFeatureSnapshot(feature, plan)) matchingFeatures++;
                // Names and parameters normally identify the original operation uniquely, but
                // recovery is reported only if there is exactly one matching feature.
                return matchingFeatures == 1;
            }
            catch { return false; }
        }

        private static bool FeatureBelongsToDocument(PartDocument doc, ThreadFeature feature)
        {
            if (doc == null || feature == null) return false;
            try
            {
                foreach (ThreadFeature candidate in doc.ComponentDefinition.Features.ThreadFeatures)
                    if (SameComObject(candidate, feature)) return true;
            }
            catch { }
            return false;
        }

        private static bool TryCaptureEndOfPartPosition(PartDocument doc, ThreadFeature feature,
                                                        out EndOfPartSnapshot snapshot, out string error)
        {
            snapshot = null;
            error = null;
            try
            {
                BrowserPane pane = FindTreeBrowserPane(doc);
                if (pane == null || pane.TopNode == null)
                {
                    error = "Не удалось получить дерево построений для сохранения позиции конвертируемой резьбы. Преобразование не начато.";
                    return false;
                }
                List<BrowserNode> nodes = pane.TopNode.BrowserNodes.Cast<BrowserNode>().ToList();
                int featureIndex = FindTopLevelIndex(nodes, feature);
                int markerIndex = -1;
                for (int i = 0; i < nodes.Count; i++)
                {
                    object native = null;
                    try { native = nodes[i].NativeObject; } catch { }
                    if (native is EndOfFeatures) { markerIndex = i; break; }
                }
                if (featureIndex < 0 || markerIndex < 0)
                {
                    error = "Не удалось определить позицию ThreadFeature или End-of-Part. Преобразование не начато.";
                    return false;
                }
                if (featureIndex > markerIndex)
                {
                    error = "Маркер End-of-Part находится перед выбранной штатной резьбой. Переместите маркер в конец истории и повторите преобразование.";
                    return false;
                }

                object anchor = null;
                for (int i = markerIndex + 1; i < nodes.Count; i++)
                {
                    anchor = FindEndOfPartAnchorInNode(nodes[i], 0);
                    if (anchor != null) break;
                }
                snapshot = new EndOfPartSnapshot { WasAtBottom = anchor == null, AnchorAfterMarker = anchor };
                return true;
            }
            catch (Exception ex)
            {
                error = "Не удалось сохранить исходное положение конца истории: " + ex.Message;
                return false;
            }
        }

        private static void RestoreEndOfPartPosition(PartDocument doc, EndOfPartSnapshot snapshot)
        {
            if (doc == null || snapshot == null) throw new InvalidOperationException("Не сохранено исходное положение End-of-Part.");
            if (snapshot.WasAtBottom)
            {
                doc.ComponentDefinition.SetEndOfPartToTopOrBottom(false);
                return;
            }
            if (snapshot.AnchorAfterMarker == null)
                throw new InvalidOperationException("Исходный якорь конца истории больше недоступен.");
            ((dynamic)snapshot.AnchorAfterMarker).SetEndOfPart(true);
        }

        private static ThreadTarget ResolveBaseTarget(Inventor.Application app, PartDocument doc,
                                                       NativeThreadConversionPlan plan, out string error)
        {
            error = null;
            ThreadTarget direct;
            try
            {
                // The native StartEdge usually remains a reference to the original base edge
                // after End-of-Part rolls back the native feature. Prefer that exact reference.
                direct = ThreadBuilder.Analyze(app, plan.OriginalStartEdge);
                if (MatchesTargetIdentity(direct, plan.TargetIdentity)) return direct;
            }
            catch { }

            var matches = new List<ThreadTarget>();
            var geometricallySeen = new List<Edge>();
            try
            {
                foreach (SurfaceBody body in doc.ComponentDefinition.SurfaceBodies)
                {
                    if (body == null) continue;
                    if (!string.IsNullOrWhiteSpace(plan.TargetIdentity.BodyName) &&
                        !string.Equals(body.Name, plan.TargetIdentity.BodyName, StringComparison.OrdinalIgnoreCase)) continue;
                    foreach (Face face in body.Faces)
                    {
                        if (face == null || face.SurfaceType != SurfaceTypeEnum.kCylinderSurface) continue;
                        Cylinder cylinder = face.Geometry as Cylinder;
                        if (cylinder == null || Math.Abs(cylinder.Radius - plan.TargetIdentity.RadiusCm) > 0.001) continue;
                        Edges faceEdges = null;
                        try { faceEdges = face.Edges; } catch { }
                        if (faceEdges == null) continue;
                        foreach (Edge edge in faceEdges)
                        {
                            if (edge == null) continue;
                            double[] center = EdgeCenter(edge);
                            if (center == null || Distance(center, plan.TargetIdentity.Center) > 0.001) continue;
                            if (geometricallySeen.Any(existing => SameGeometricEdge(existing, edge))) continue;
                            ThreadTarget candidate;
                            try { candidate = ThreadBuilder.Analyze(app, edge); } catch { continue; }
                            if (!MatchesTargetIdentity(candidate, plan.TargetIdentity)) continue;
                            geometricallySeen.Add(edge);
                            matches.Add(candidate);
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                string logPath = WriteNativeConversionDiagnostic("ResolveBaseTarget", "повторный поиск базового цилиндра после удаления ThreadFeature", ex, plan == null ? null : plan.Feature, plan);
                error = "Не удалось повторно найти исходный цилиндр после отката: " + ex.Message +
                    (string.IsNullOrWhiteSpace(logPath) ? "\nТехническая ошибка: " + ex.ToString() :
                     "\nПодробный стек ошибки записан в: " + logPath);
                return null;
            }

            if (matches.Count != 1)
            {
                error = matches.Count == 0
                    ? "Исходная цилиндрическая поверхность не найдена после удаления ThreadFeature. Конвертация отменяется."
                    : "Для штатной резьбы найдено несколько совпадающих цилиндрических поверхностей. Конвертация отменяется без произвольного выбора.";
                return null;
            }
            return matches[0];
        }

        private static bool MatchesTargetIdentity(ThreadTarget target, ThreadTargetSnapshot identity)
        {
            if (target == null || identity == null || target.Center == null || identity.Center == null ||
                target.U == null || identity.Axis == null) return false;
            if (target.IsExternal != identity.IsExternal || Math.Abs(target.RadiusCm - identity.RadiusCm) > 0.001 ||
                Distance(target.Center, identity.Center) > 0.001) return false;
            if (target.Center.Length < 3 || identity.Center.Length < 3 || target.U.Length < 3 || identity.Axis.Length < 3) return false;
            if (!string.IsNullOrWhiteSpace(identity.BodyName) && !string.IsNullOrWhiteSpace(target.BodyName) &&
                !string.Equals(target.BodyName, identity.BodyName, StringComparison.OrdinalIgnoreCase)) return false;
            double dot = target.U[0] * identity.Axis[0] + target.U[1] * identity.Axis[1] + target.U[2] * identity.Axis[2];
            return dot > 0.999;
        }

        private static int FindTopLevelIndex(IList<BrowserNode> nodes, object target)
        {
            for (int i = 0; i < nodes.Count; i++)
                if (ContainsObject(nodes[i], target, 0)) return i;
            return -1;
        }

        private static bool ContainsObject(BrowserNode node, object target, int depth)
        {
            if (node == null || target == null || depth > 64) return false;
            object native = null;
            try { native = node.NativeObject; } catch { }
            if (SameComObject(native, target)) return true;
            try
            {
                foreach (BrowserNode child in node.BrowserNodes)
                    if (ContainsObject(child, target, depth + 1)) return true;
            }
            catch { }
            return false;
        }

        private static bool ContainsHistoryObject(BrowserNode node, int depth)
        {
            if (node == null || depth > 64) return false;
            try
            {
                object native = node.NativeObject;
                if (native is PartFeature || native is PlanarSketch || native is Sketch3D ||
                    native is WorkPlane || native is WorkAxis || native is WorkPoint) return true;
            }
            catch { }
            try
            {
                foreach (BrowserNode child in node.BrowserNodes)
                    if (ContainsHistoryObject(child, depth + 1)) return true;
            }
            catch { }
            return false;
        }

        private static object FindEndOfPartAnchorInNode(BrowserNode node, int depth)
        {
            if (node == null || depth > 64) return null;
            try
            {
                object native = node.NativeObject;
                if (native is PartFeature || native is PlanarSketch || native is Sketch3D ||
                    native is WorkPlane || native is WorkAxis || native is WorkPoint) return native;
            }
            catch { }
            try
            {
                foreach (BrowserNode child in node.BrowserNodes)
                {
                    object found = FindEndOfPartAnchorInNode(child, depth + 1);
                    if (found != null) return found;
                }
            }
            catch { }
            return null;
        }

        private static BrowserPane FindTreeBrowserPane(PartDocument doc)
        {
            if (doc == null) return null;
            try
            {
                BrowserPane active = doc.BrowserPanes.ActivePane;
                if (active != null && active.TreeBrowser) return active;
            }
            catch { }
            try
            {
                foreach (BrowserPane pane in doc.BrowserPanes)
                    if (pane != null && pane.TreeBrowser) return pane;
            }
            catch { }
            return null;
        }

        private static bool SameComObject(object left, object right)
        {
            if (ReferenceEquals(left, right)) return true;
            long a = GetComIdentity(left), b = GetComIdentity(right);
            return a != 0 && b != 0 && a == b;
        }

        /// <summary>Compares two selected Inventor objects by COM identity for picker de-bouncing.</summary>
        internal static bool SameSelectionIdentity(object left, object right)
        {
            if (ReferenceEquals(left, right)) return true;
            if (left == null || right == null) return false;
            try { if (left.Equals(right)) return true; } catch { }
            return SameComObject(left, right);
        }

        private static long GetComIdentity(object obj)
        {
            IntPtr pointer = IntPtr.Zero;
            try
            {
                if (obj == null || !Marshal.IsComObject(obj)) return 0;
                pointer = Marshal.GetIUnknownForObject(obj);
                return pointer.ToInt64();
            }
            catch { return 0; }
            finally
            {
                if (pointer != IntPtr.Zero)
                {
                    try { Marshal.Release(pointer); } catch { }
                }
            }
        }

        private static double[] EdgeCenter(Edge edge)
        {
            try
            {
                if (edge.GeometryType == CurveTypeEnum.kCircleCurve)
                {
                    Circle circle = (Circle)edge.Geometry;
                    return new[] { circle.Center.X, circle.Center.Y, circle.Center.Z };
                }
                if (edge.GeometryType == CurveTypeEnum.kCircularArcCurve)
                {
                    Arc3d arc = (Arc3d)edge.Geometry;
                    return new[] { arc.Center.X, arc.Center.Y, arc.Center.Z };
                }
            }
            catch { }
            return null;
        }

        private static bool SameGeometricEdge(Edge left, Edge right)
        {
            double[] a = EdgeCenter(left), b = EdgeCenter(right);
            if (a == null || b == null || Distance(a, b) > 1e-7) return false;
            return Math.Abs(EdgeRadius(left) - EdgeRadius(right)) <= 1e-7;
        }

        private static double EdgeRadius(Edge edge)
        {
            try
            {
                if (edge.GeometryType == CurveTypeEnum.kCircleCurve) return ((Circle)edge.Geometry).Radius;
                if (edge.GeometryType == CurveTypeEnum.kCircularArcCurve) return ((Arc3d)edge.Geometry).Radius;
            }
            catch { }
            return 0.0;
        }

        private static double Distance(double[] left, double[] right)
        {
            if (left == null || right == null || left.Length < 3 || right.Length < 3) return double.MaxValue;
            double dx = left[0] - right[0], dy = left[1] - right[1], dz = left[2] - right[2];
            return Math.Sqrt(dx * dx + dy * dy + dz * dz);
        }

        private static string SafeString(Func<string> getter)
        {
            try { return getter() ?? string.Empty; } catch { return string.Empty; }
        }
    }
}
