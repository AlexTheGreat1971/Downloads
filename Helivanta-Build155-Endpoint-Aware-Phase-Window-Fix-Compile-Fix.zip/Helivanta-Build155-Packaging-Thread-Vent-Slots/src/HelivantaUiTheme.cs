﻿using System;
using System.Drawing;
using System.IO;
using System.Reflection;
using System.Windows.Forms;

namespace ThreadPro
{
    /// <summary>Shared, user-selectable visual tokens for all Helivanta WinForms dialogs.</summary>
    internal static class HelivantaUiTheme
    {
        private static Color C(int r,int g,int b) => Color.FromArgb(r,g,b);
        private static bool Light => HelivantaUserSettings.Current.Theme == "Light";
        private static string AccentName => HelivantaUserSettings.Current.Accent ?? "Amber";
        private static Color AccentColor => AccentName == "Blue" ? C(39,140,212) : AccentName == "Gray" ? C(112,126,140) : C(191,123,24);
        internal static Color Surface => Light ? C(239,242,245) : C(37,48,63);
        internal static Color Panel => Light ? C(250,251,252) : C(48,63,80);
        internal static Color PanelSecondary => Light ? C(231,235,239) : C(43,57,73);
        internal static Color Header => Light ? C(222,228,234) : C(55,71,89);
        internal static Color Field => Light ? C(255,255,255) : C(33,44,58);
        internal static Color Text => Light ? C(35,45,55) : C(235,241,247);
        internal static Color Muted => Light ? C(86,99,112) : C(176,189,202);
        internal static Color Border => Light ? C(173,183,192) : C(78,98,118);
        internal static Color Accent => AccentColor;
        internal static Color AccentHover => ControlPaint.Light(AccentColor, .18f);
        internal static Color AccentSoft => Light ? ControlPaint.Light(AccentColor, .78f) : ControlPaint.Dark(AccentColor, .55f);
        internal static Color Success => C(45,153,100);
        internal static Color Warning => C(190,126,24);
        internal static Color Error => C(198,67,67);
        internal static Color ControlBorder => Light ? C(153,166,178) : C(91,115,138);
        internal static Color ModalSurface => Light ? C(248,249,250) : C(53,65,81);
        internal static Color ModalPanel => Light ? C(255,255,255) : C(62,75,91);
        internal static Color ModalBorder => AccentColor;
        internal static Color ModalHeader => AccentColor;
        internal static Color ModalHeaderText => C(255,255,255);

        internal static bool IsLight => Light;

        /// <summary>Returns a detached, theme-correct official Helivanta wordmark bitmap.</summary>
        internal static Image LoadWordmarkImage(bool preferCropped = false)
        {
            Assembly assembly = Assembly.GetExecutingAssembly();
            string[] preferred = Light
                ? (preferCropped
                    ? new[] { "Helivanta-Wordmark-Light-Cropped.png", "Helivanta-Wordmark-Light.png", "Helivanta-Wordmark.png" }
                    : new[] { "Helivanta-Wordmark-Light.png", "Helivanta-Wordmark-Light-Cropped.png", "Helivanta-Wordmark.png" })
                : (preferCropped
                    ? new[] { "Helivanta-Wordmark-Dark-Cropped.png", "Helivanta-Wordmark-Dark.png", "Helivanta-Wordmark.png" }
                    : new[] { "Helivanta-Wordmark-Dark.png", "Helivanta-Wordmark-Dark-Cropped.png", "Helivanta-Wordmark.png" });

            string[] available = assembly.GetManifestResourceNames();
            foreach (string wanted in preferred)
            {
                foreach (string resourceName in available)
                {
                    if (!resourceName.EndsWith(wanted, StringComparison.OrdinalIgnoreCase)) continue;
                    using (Stream stream = assembly.GetManifestResourceStream(resourceName))
                    {
                        if (stream == null) continue;
                        using (Image source = Image.FromStream(stream)) return new Bitmap(source);
                    }
                }
            }
            return null;
        }
    }
}
