﻿using System;
using System.Drawing;
using System.Runtime.InteropServices;
using System.Windows.Forms;

namespace ThreadPro
{
    /// <summary>
    /// Positions owned add-in windows using native desktop-pixel coordinates. This avoids
    /// mixing WinForms DPI-scaled Location values with GetWindowRect/SetWindowPos coordinates.
    /// </summary>
    internal static class NativeWindowPositioning
    {
        private const uint MONITOR_DEFAULTTONEAREST = 2;
        private const uint SWP_NOSIZE = 0x0001;
        private const uint SWP_NOZORDER = 0x0004;
        private const uint SWP_NOACTIVATE = 0x0010;
        private const uint SWP_NOMOVE = 0x0002;

        [StructLayout(LayoutKind.Sequential)]
        private struct NativeRect
        {
            public int Left;
            public int Top;
            public int Right;
            public int Bottom;
        }

        [StructLayout(LayoutKind.Sequential, CharSet = CharSet.Auto)]
        private struct NativeMonitorInfo
        {
            public int cbSize;
            public NativeRect rcMonitor;
            public NativeRect rcWork;
            public uint dwFlags;
        }

        [DllImport("user32.dll", SetLastError = true)]
        private static extern IntPtr MonitorFromWindow(IntPtr hwnd, uint flags);

        [DllImport("user32.dll", CharSet = CharSet.Auto, SetLastError = true)]
        private static extern bool GetMonitorInfo(IntPtr hMonitor, ref NativeMonitorInfo lpmi);

        [DllImport("user32.dll", EntryPoint = "GetWindowRect", SetLastError = true)]
        private static extern bool GetNativeWindowRect(IntPtr hWnd, out NativeRect rect);

        [DllImport("user32.dll", EntryPoint = "SetWindowPos", SetLastError = true)]
        private static extern bool SetNativeWindowPos(IntPtr hWnd, IntPtr hWndInsertAfter,
            int x, int y, int cx, int cy, uint flags);

        [DllImport("user32.dll", SetLastError = true)]
        private static extern bool SetForegroundWindow(IntPtr hWnd);

        [DllImport("user32.dll", SetLastError = true)]
        private static extern IntPtr GetForegroundWindow();

        internal static IntPtr GetForegroundWindowHandle()
        {
            try { return GetForegroundWindow(); }
            catch { return IntPtr.Zero; }
        }

        internal static bool IsForegroundWindow(IntPtr windowHandle)
        {
            return windowHandle != IntPtr.Zero && GetForegroundWindowHandle() == windowHandle;
        }

        internal static string DescribeWindowHandle(IntPtr windowHandle)
        {
            if (windowHandle == IntPtr.Zero) return "hwnd=0x0;pid=0;thread=0";
            try
            {
                uint processId;
                uint threadId = GetWindowThreadProcessId(windowHandle, out processId);
                return "hwnd=0x" + windowHandle.ToInt64().ToString("X") +
                    ";pid=" + processId.ToString() + ";thread=" + threadId.ToString();
            }
            catch
            {
                return "hwnd=0x" + windowHandle.ToInt64().ToString("X") + ";pid=?;thread=?";
            }
        }

        [DllImport("user32.dll", SetLastError = true)]
        private static extern uint GetWindowThreadProcessId(IntPtr hWnd, out uint processId);

        [DllImport("kernel32.dll")]
        private static extern uint GetCurrentThreadId();

        [DllImport("user32.dll", SetLastError = true)]
        private static extern bool AttachThreadInput(uint idAttach, uint idAttachTo, bool fAttach);

        internal static Rectangle GetNativeWorkingArea(IntPtr referenceWindowHandle)
        {
            try
            {
                if (referenceWindowHandle != IntPtr.Zero)
                {
                    IntPtr monitor = MonitorFromWindow(referenceWindowHandle, MONITOR_DEFAULTTONEAREST);
                    if (monitor != IntPtr.Zero)
                    {
                        var info = new NativeMonitorInfo { cbSize = Marshal.SizeOf(typeof(NativeMonitorInfo)) };
                        if (GetMonitorInfo(monitor, ref info) && info.rcWork.Right > info.rcWork.Left && info.rcWork.Bottom > info.rcWork.Top)
                            return Rectangle.FromLTRB(info.rcWork.Left, info.rcWork.Top, info.rcWork.Right, info.rcWork.Bottom);
                    }
                }
            }
            catch { }

            try
            {
                if (referenceWindowHandle != IntPtr.Zero)
                    return Screen.FromHandle(referenceWindowHandle).WorkingArea;
            }
            catch { }

            return Screen.PrimaryScreen != null ? Screen.PrimaryScreen.WorkingArea : SystemInformation.WorkingArea;
        }

        internal static bool MoveToRight(IntPtr windowHandle, IntPtr referenceWindowHandle, int rightMargin = 18, int edgeMargin = 8)
        {
            if (windowHandle == IntPtr.Zero) return false;
            try
            {
                NativeRect rect;
                if (!GetNativeWindowRect(windowHandle, out rect)) return false;
                int width = Math.Max(1, rect.Right - rect.Left);
                int height = Math.Max(1, rect.Bottom - rect.Top);
                Rectangle work = GetNativeWorkingArea(referenceWindowHandle);

                int x = Math.Max(work.Left + edgeMargin, work.Right - width - rightMargin);
                int topOffset = Math.Min(20, Math.Max(edgeMargin, (work.Height - height) / 5));
                int y = work.Top + topOffset;
                y = Math.Max(work.Top + edgeMargin, Math.Min(y, work.Bottom - height - edgeMargin));

                return SetNativeWindowPos(windowHandle, IntPtr.Zero, x, y, 0, 0,
                    SWP_NOSIZE | SWP_NOZORDER | SWP_NOACTIVATE);
            }
            catch { return false; }
        }

        /// <summary>
        /// Activate a known window without restoring, minimizing, resizing or maximizing it.
        /// If Windows denies the foreground request because input queues differ, briefly attach
        /// the target and calling queues to the foreground queue, then always detach.
        /// </summary>
        internal static bool ActivateWindowPreservingState(IntPtr targetHandle)
        {
            if (targetHandle == IntPtr.Zero) return false;
            try
            {
                if (GetForegroundWindow() == targetHandle) return true;

                uint ownerProcess;
                uint ownerThread = GetWindowThreadProcessId(targetHandle, out ownerProcess);

                // Try the normal foreground request first. Do not call ShowWindow, restore,
                // SetActiveWindow, or SetFocus: those can change the host's display state or
                // leave an unwanted focus cue around Inventor.
                SetForegroundWindow(targetHandle);
                if (GetForegroundWindow() == targetHandle) return true;

                // Put the existing target HWND at the top of the Z-order without resizing or
                // changing its show state. This helps keep activation inside the intended window
                // family during the hand-off from one modeless tool window to another.
                try
                {
                    SetNativeWindowPos(targetHandle, IntPtr.Zero, 0, 0, 0, 0,
                        SWP_NOSIZE | SWP_NOMOVE | SWP_NOACTIVATE);
                }
                catch { }

                IntPtr foreground = GetForegroundWindow();
                if (foreground == IntPtr.Zero) return GetForegroundWindow() == targetHandle;
                uint foregroundProcess;
                uint foregroundThread = GetWindowThreadProcessId(foreground, out foregroundProcess);
                uint currentThread = GetCurrentThreadId();
                if (foregroundThread == 0) return GetForegroundWindow() == targetHandle;

                // SetForegroundWindow is subject to Windows' foreground-lock rules. Briefly
                // attach both the calling UI queue and the Inventor owner queue to the current
                // foreground queue, if needed, then detach in reverse order. The owner thread is
                // included explicitly because some Inventor/WinForms builds can use distinct UI
                // queues for host and add-in windows.
                bool currentAttached = false;
                bool ownerAttached = false;
                try
                {
                    if (currentThread != foregroundThread)
                        currentAttached = AttachThreadInput(currentThread, foregroundThread, true);

                    if (ownerThread != 0 && ownerThread != foregroundThread && ownerThread != currentThread)
                        ownerAttached = AttachThreadInput(ownerThread, foregroundThread, true);

                    SetForegroundWindow(targetHandle);
                }
                finally
                {
                    if (ownerAttached)
                    {
                        try { AttachThreadInput(ownerThread, foregroundThread, false); } catch { }
                    }
                    if (currentAttached)
                    {
                        try { AttachThreadInput(currentThread, foregroundThread, false); } catch { }
                    }
                }

                if (GetForegroundWindow() == targetHandle) return true;
                // One final ordinary request after input queues have been detached.
                SetForegroundWindow(targetHandle);
                return GetForegroundWindow() == targetHandle;
            }
            catch { return false; }
        }

        internal static bool ActivateOwnerAfterClose(IntPtr ownerHandle)
        {
            // Retained for existing AddIn close paths; the implementation is shared with preview
            // palette transitions and deliberately does not change the target window's size/state.
            return ActivateWindowPreservingState(ownerHandle);
        }

        internal static bool MoveToCenter(IntPtr windowHandle, IntPtr referenceWindowHandle)
        {
            if (windowHandle == IntPtr.Zero) return false;
            try
            {
                NativeRect rect;
                if (!GetNativeWindowRect(windowHandle, out rect)) return false;
                int width = Math.Max(1, rect.Right - rect.Left);
                int height = Math.Max(1, rect.Bottom - rect.Top);
                Rectangle work = GetNativeWorkingArea(referenceWindowHandle);
                int x = work.Left + Math.Max(0, (work.Width - width) / 2);
                int y = work.Top + Math.Max(0, (work.Height - height) / 2);
                return SetNativeWindowPos(windowHandle, IntPtr.Zero, x, y, 0, 0,
                    SWP_NOSIZE | SWP_NOZORDER | SWP_NOACTIVATE);
            }
            catch { return false; }
        }
    }
}
