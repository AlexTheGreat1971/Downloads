using System;
using System.Globalization;

namespace ThreadPro
{
    /// <summary>Creates short, ASCII-only, document-unique browser labels for experimental packaging Coil features.</summary>
    internal static class PackagingThreadFeatureNamePolicy
    {
        internal static string CreateSafeUniqueName(int startIndex, int startCount, double phaseDegrees, Guid uniqueToken)
        {
            if (startCount < 1 || startCount > 12) throw new ArgumentOutOfRangeException(nameof(startCount));
            if (startIndex < 1 || startIndex > startCount) throw new ArgumentOutOfRangeException(nameof(startIndex));
            if (double.IsNaN(phaseDegrees) || double.IsInfinity(phaseDegrees)) throw new ArgumentOutOfRangeException(nameof(phaseDegrees));

            string token = uniqueToken.ToString("N", CultureInfo.InvariantCulture).Substring(0, 12).ToUpperInvariant();
            string phase = Math.Round(phaseDegrees, MidpointRounding.AwayFromZero).ToString("0", CultureInfo.InvariantCulture);
            // Do not place slash, degree symbol, em dash or localized punctuation in the Inventor name.
            // The token keeps repeated builds on opposite ends of one document from colliding.
            return string.Format(CultureInfo.InvariantCulture, "HVPkg_{0}_S{1}of{2}_P{3}deg", token, startIndex, startCount, phase);
        }
    }
}
