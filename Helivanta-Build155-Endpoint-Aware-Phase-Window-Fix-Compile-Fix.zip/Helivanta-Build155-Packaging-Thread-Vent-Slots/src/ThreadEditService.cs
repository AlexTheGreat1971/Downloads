using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text.Json;
using Inventor;

namespace ThreadPro
{
    /// <summary>
    /// Conservative transactional replacement of one persisted Helivanta thread group.
    /// It deliberately reuses ThreadBuilder's proven geometry path and never edits formulas.
    /// </summary>
    internal static class ThreadEditService
    {
        /// <summary>
        /// Captures the user's original End-of-Part position. If the marker was before
        /// the edited group, the replacement group becomes the restore anchor; otherwise
        /// an untouched downstream object is used. A bottom marker is restored to bottom.
        /// </summary>
        private sealed class EndOfPartPositionSnapshot
        {
            internal bool WasAtBottom;
            internal bool NextAnchorIsEditedThread;
            internal object NextAnchor;
        }

        internal static bool TryGetEditableGroup(PartDocument doc, string threadId,
                                                  out ThreadMetadataGroup group, out string error)
        {
            group = null;
            error = null;
            if (!ThreadMetadataStore.TryLoadGroup(doc, threadId, out group, out error)) return false;
            if (!CanFindGroupFeatureInHistory(doc, group, out error))
            {
                group = null;
                return false;
            }
            return true;
        }

        internal static bool TryReplace(Inventor.Application app, string threadId, ThreadParams replacement,
                                        out ThreadTarget rebuiltTarget, out string warning, out string error)
        {
            rebuiltTarget = null;
            warning = null;
            error = null;
            PartDocument doc = null;
            Transaction transaction = null;
            bool transactionOpened = false;
            string originalRecordJson = null;
            int originalMemberCount = 0;
            EndOfPartPositionSnapshot originalEndOfPartPosition = null;
            bool originalEndOfPartRestored = false;
            string originalThreadFolderName = null;
            string stage = "проверка активного документа";
            try
            {
                doc = app == null ? null : app.ActiveDocument as PartDocument;
                if (doc == null) throw new InvalidOperationException("Активный документ должен быть деталью (.ipt).");
                if (replacement == null) throw new ArgumentNullException("replacement");

                stage = "загрузка и проверка сохранённой группы резьбы";
                ThreadMetadataGroup group;
                string groupError;
                if (!ThreadMetadataStore.TryLoadGroup(doc, threadId, out group, out groupError))
                    throw new InvalidOperationException(groupError);
                if (!CanFindGroupFeatureInHistory(doc, group, out groupError))
                    throw new InvalidOperationException(groupError);
                stage = "проверка зависимых операций и пересечений";
                if (replacement.External != group.Record.Target.IsExternal)
                    throw new InvalidOperationException("Тип резьбы (наружная/внутренняя) не может отличаться от исходной цилиндрической поверхности. Модель не изменена.");
                double savedNominalDiameter = group.Record.Parameters.NominalDiaMm;
                if (!ThreadEditSafetyPolicy.IsNominalDiameterPreserved(savedNominalDiameter, replacement.NominalDiaMm))
                    throw new InvalidOperationException(string.Format(
                        "При редактировании номинальный диаметр существующей резьбы фиксирован на Ø{0:0.###} мм. Выбран Ø{1:0.###} мм. Такая замена потребовала бы изменить базовый цилиндр добавлением/удалением материала, а не только отредактировать резьбу. Измените стандарт и/или шаг, сохранив диаметр, либо отмените редактирование и создайте новую резьбу на подходящей цилиндрической поверхности.",
                        savedNominalDiameter, replacement.NominalDiaMm));
                if (!ValidateNoMetadataGroupOverlap(doc, group, replacement, out groupError))
                    throw new InvalidOperationException(groupError);

                // Keep an immutable recovery fingerprint before the first model mutation.
                // It lets the failure path distinguish a verified rollback from an Abort call
                // that threw or a group whose persisted membership/parameters did not return.
                originalRecordJson = JsonSerializer.Serialize(group.Record);
                originalMemberCount = group.MembersByIndex.Count;

                // Capture the original history marker and resolve a concrete tagged member
                // BEFORE mutation. If either cannot be determined, refuse the edit rather than
                // risking a rebuild at the end of the tree.
                stage = "сохранение исходного положения конца истории";
                string historyPositionError;
                if (!TryCaptureEndOfPartPosition(doc, group.Record.ThreadId,
                        out originalEndOfPartPosition, out historyPositionError))
                    throw new InvalidOperationException(historyPositionError);

                object insertionAnchor;
                if (!TryFindFirstThreadHistoryAnchor(doc, group.Record.ThreadId, out insertionAnchor, out historyPositionError))
                    throw new InvalidOperationException(historyPositionError);

                // Inventor can fail to map newly-created features back to BrowserNodes after a
                // rebuild. Capture the old folder name before deleting its tagged members so the
                // surviving folder can still be renamed even when its children no longer expose
                // the current ThreadId during the post-build tree scan.
                originalThreadFolderName = FindThreadFolderNameForGroup(doc, group.Record.ThreadId);

                stage = "открытие транзакции Inventor";
                TransactionLifecycleDiagnostics.Write("ThreadEditService", "StartTransaction.before", app, doc,
                    null, false, "threadId=" + group.Record.ThreadId + "; stage=" + stage);
                transaction = app.TransactionManager.StartTransaction(app.ActiveDocument, ThreadBuilder.EditTransactionPrefix + " " + group.Record.ThreadId);
                if (transaction == null)
                    throw new InvalidOperationException("Inventor не вернул транзакцию редактирования.");
                transactionOpened = true;
                TransactionLifecycleDiagnostics.Write("ThreadEditService", "StartTransaction.after", app, doc,
                    transaction, false, "threadId=" + group.Record.ThreadId + "; stage=" + stage);

                PartComponentDefinition definition = doc.ComponentDefinition;

                // Roll the model back to the first object in this Helivanta thread group before
                // deleting/rebuilding it. Inventor then inserts the replacement at the old
                // feature-history position, so downstream features are evaluated against it
                // when the user's original End-of-Part position is restored below.
                stage = "перемещение конца истории перед исходной группой резьбы";
                bool captureTaperedBrowserTrace = replacement.Tapered ||
                    (group.Record.Parameters != null && group.Record.Parameters.Tapered);
                if (captureTaperedBrowserTrace)
                    BrowserTreeDiagnostics.WriteSnapshot("ThreadEditService", "before-set-end-of-part", doc,
                        FindTreeBrowserPane(doc), group.MembersByIndex, "threadId=" + group.Record.ThreadId +
                        "; anchorType=" + (insertionAnchor == null ? "<null>" : insertionAnchor.GetType().FullName));
                TransactionLifecycleDiagnostics.Write("ThreadEditService", "SetEndOfPartBefore.before", app, doc,
                    transaction, false, "threadId=" + group.Record.ThreadId);
                SetEndOfPartBefore(insertionAnchor);
                TransactionLifecycleDiagnostics.Write("ThreadEditService", "SetEndOfPartBefore.after", app, doc,
                    transaction, false, "threadId=" + group.Record.ThreadId);
                if (captureTaperedBrowserTrace)
                    BrowserTreeDiagnostics.WriteSnapshot("ThreadEditService", "after-set-end-of-part-before-update", doc,
                        FindTreeBrowserPane(doc), group.MembersByIndex, "threadId=" + group.Record.ThreadId);
                bool updateBeforeDeleteSucceeded = doc.Update2(true);
                TransactionLifecycleDiagnostics.Write("ThreadEditService", "Update2.after-SetEndOfPartBefore", app, doc,
                    transaction, false, "success=" + updateBeforeDeleteSucceeded + "; threadId=" + group.Record.ThreadId);
                if (captureTaperedBrowserTrace)
                    BrowserTreeDiagnostics.WriteSnapshot("ThreadEditService", "after-set-end-of-part-update", doc,
                        FindTreeBrowserPane(doc), group.MembersByIndex, "success=" + updateBeforeDeleteSucceeded + "; threadId=" + group.Record.ThreadId);

                // Do not send a mixed Feature/Sketch/WorkPlane collection to one COM call.
                // The diagnostic log showed E_INVALIDARG at DeleteObjects for that collection.
                // Validate every member BEFORE the first mutation, then delete one object per call.
                var memberKinds = new List<ThreadEditMemberKind>(group.MembersByIndex.Count);
                for (int i = 0; i < group.MembersByIndex.Count; i++)
                {
                    ThreadEditMemberKind kind = ClassifyMemberForDeletion(group.MembersByIndex[i]);
                    memberKinds.Add(kind);
                }
                int[] deleteOrder;
                if (!ThreadEditSafetyPolicy.TryBuildDeletionOrder(memberKinds, out deleteOrder))
                    throw new InvalidOperationException("В исходной группе есть тип объекта, который нельзя безопасно удалить автоматически. До удаления проверьте метаданные и типы всех объектов.");

                for (int orderIndex = 0; orderIndex < deleteOrder.Length; orderIndex++)
                {
                    int memberIndex = deleteOrder[orderIndex];
                    object member = group.MembersByIndex[memberIndex];
                    string memberDescription = DescribeMemberForDeletion(member, memberKinds[memberIndex], memberIndex);
                    stage = "удаление исходной группы резьбы: " + memberDescription;
                    ObjectCollection singleMember = app.TransientObjects.CreateObjectCollection();
                    singleMember.Add(member);
                    // Preserve dependencies for this call: group members are deleted explicitly in
                    // controlled order, so Inventor must not recursively consume the next member.
                    TransactionLifecycleDiagnostics.Write("ThreadEditService", "DeleteObjects.before", app, doc,
                        transaction, false, "threadId=" + group.Record.ThreadId + "; member=" + memberDescription);
                    definition.DeleteObjects(singleMember, true, true, true);
                    TransactionLifecycleDiagnostics.Write("ThreadEditService", "DeleteObjects.after", app, doc,
                        transaction, false, "threadId=" + group.Record.ThreadId + "; member=" + memberDescription);
                }
                stage = "обновление детали после удаления старой группы";
                bool updateAfterDeleteSucceeded = doc.Update2(true);
                TransactionLifecycleDiagnostics.Write("ThreadEditService", "Update2.after-delete-old-group", app, doc,
                    transaction, false, "success=" + updateAfterDeleteSucceeded + "; threadId=" + group.Record.ThreadId);

                stage = "повторный поиск исходной цилиндрической поверхности";
                ThreadTarget target = ResolveOriginalTarget(app, doc, group.Record.Target, out groupError);
                if (target == null) throw new InvalidOperationException(groupError);

                ThreadBuilder.LastWarning = null;
                ThreadBuilder.LastError = null;
                ThreadBuilder.LastUserError = null;
                ThreadBuilder.LastRunoutPerformance = null;
                ThreadBuilder.ResetBrowserFolderPerformance();
                ThreadBuilder.LastMetadataStatus = null;
                ThreadBuilder.LastMetadataAttachSucceeded = false;

                stage = "построение новой геометрии с шагом " + replacement.PitchMm.ToString("0.###", System.Globalization.CultureInfo.InvariantCulture) + " мм";
                TransactionLifecycleDiagnostics.Write("ThreadEditService", "ThreadBuilder.Build.before", app, doc,
                    transaction, false, "threadId=" + group.Record.ThreadId);
                ThreadBuilder.Build(app, target, replacement, false, group.Record.ThreadId);
                TransactionLifecycleDiagnostics.Write("ThreadEditService", "ThreadBuilder.Build.after", app, doc,
                    transaction, false, "threadId=" + group.Record.ThreadId + "; metadataAttached=" + ThreadBuilder.LastMetadataAttachSucceeded);
                if (!ThreadBuilder.LastMetadataAttachSucceeded)
                    throw new InvalidOperationException("Новая геометрия была построена, но повторная запись метаданных не удалась. Операция отменена, исходная резьба восстановлена.");

                // ThreadBuilder groups the new geometry immediately after creating it, which
                // also moves End-of-Part. Restore the marker to the user's original position
                // before updating the model, so downstream features rebuild in their original
                // history order instead of leaving the replacement at the tree bottom.
                stage = "возврат конца истории в исходное положение";
                RestoreEndOfPartPosition(doc, originalEndOfPartPosition, group.Record.ThreadId);
                originalEndOfPartRestored = true;

                stage = "перестроение детали и последующих операций";
                doc.Update2(true);
                warning = ThreadBuilder.LastWarning;
                if (replacement.SortThreadsIntoFolders || replacement.Tapered)
                {
                    string folderNameError;
                    if (TryRefreshThreadFolderName(doc, group.Record.ThreadId, replacement,
                        originalThreadFolderName, out folderNameError))
                    {
                        // The old BrowserFolder can survive feature replacement while the new
                        // objects inherit its membership. If so, the name update recovers from
                        // a failed created-object-to-BrowserNode lookup in ThreadBuilder.
                        warning = RemoveResolvedFolderMappingWarning(warning, replacement.Tapered
                            ? ThreadFolderNamePolicy.BuildTaperedThreadFolderName(replacement.TaperStandard, replacement.TaperDisplayDesignation, replacement.TaperDesignation, replacement.Starts, replacement.RightHand)
                            : ThreadFolderNamePolicy.BuildThreadFolderName(replacement.SizeName, replacement.Starts,
                                replacement.RightHand, replacement.Standard, replacement.Mirror));
                    }
                    else
                    {
                        warning = AppendWarning(warning, folderNameError);
                    }
                }
                rebuiltTarget = target;
                // Inventor browser folders are not model features, so deleting the old
                // group's features can leave an empty folder behind. Remove only empty
                // Helivanta thread folders, after the replacement has succeeded.
                CleanupEmptyThreadFolders(doc);
                TransactionLifecycleDiagnostics.Write("ThreadEditService", "Transaction.End.before", app, doc,
                    transaction, false, "threadId=" + group.Record.ThreadId + "; stage=" + stage);
                transaction.End();
                TransactionLifecycleDiagnostics.Write("ThreadEditService", "Transaction.End.after", app, doc,
                    transaction, false, "threadId=" + group.Record.ThreadId + "; stage=" + stage);
                transaction = null;
                return true;
            }
            catch (Exception ex)
            {
                TransactionLifecycleDiagnostics.Write("ThreadEditService", "Edit.exception-before-abort", app, doc,
                    transaction, false, "threadId=" + threadId + "; stage=" + stage + "; exception=" + ex);
                bool rollbackVerified = !transactionOpened;
                bool abortSucceeded = !transactionOpened;
                string abortFailure = null;
                string rollbackCheckFailure = null;

                if (transactionOpened)
                {
                    if (transaction != null)
                    {
                        try
                        {
                            TransactionLifecycleDiagnostics.Write("ThreadEditService", "Transaction.Abort.before", app, doc,
                                transaction, false, "threadId=" + threadId + "; stage=" + stage);
                            transaction.Abort();
                            abortSucceeded = true;
                            TransactionLifecycleDiagnostics.Write("ThreadEditService", "Transaction.Abort.after", app, doc,
                                transaction, false, "threadId=" + threadId + "; result=success");
                        }
                        catch (Exception abortEx)
                        {
                            TransactionLifecycleDiagnostics.Write("ThreadEditService", "Transaction.Abort.failed", app, doc,
                                transaction, false, "threadId=" + threadId + "; exception=" + abortEx);
                            abortSucceeded = false;
                            abortFailure = "Transaction.Abort завершился ошибкой: " + abortEx.Message;
                        }
                        transaction = null;
                    }
                    else
                    {
                        abortSucceeded = false;
                        abortFailure = "Транзакция редактирования была открыта, но ссылка на неё недоступна для Abort.";
                    }

                    if (abortSucceeded && doc != null && !string.IsNullOrWhiteSpace(originalRecordJson))
                    {
                        try
                        {
                            // Abort should restore the marker together with the model transaction;
                            // explicitly restore it too, and include that check in rollback status.
                            try
                            {
                                RestoreEndOfPartPosition(doc, originalEndOfPartPosition, threadId);
                                originalEndOfPartRestored = true;
                            }
                            catch (Exception markerEx)
                            {
                                originalEndOfPartRestored = false;
                                rollbackCheckFailure = "Не удалось восстановить исходное положение конца истории после Abort: " + markerEx.Message;
                            }

                            if (originalEndOfPartRestored) doc.Update2(true);
                            ThreadMetadataGroup restoredGroup;
                            string restoreError;
                            bool groupFound = ThreadMetadataStore.TryLoadGroup(doc, threadId, out restoredGroup, out restoreError);
                            string restoredRecordJson = groupFound ? JsonSerializer.Serialize(restoredGroup.Record) : null;
                            bool recordsMatch = groupFound && string.Equals(originalRecordJson, restoredRecordJson, StringComparison.Ordinal);
                            int restoredCount = groupFound && restoredGroup.MembersByIndex != null
                                ? restoredGroup.MembersByIndex.Count : 0;
                            rollbackVerified = originalEndOfPartRestored && ThreadEditSafetyPolicy.IsRollbackVerified(
                                abortSucceeded, groupFound, recordsMatch, originalMemberCount, restoredCount);
                            if (!rollbackVerified && string.IsNullOrWhiteSpace(rollbackCheckFailure))
                                rollbackCheckFailure = groupFound
                                    ? "После Abort состав или сохранённые параметры исходной группы не совпали с контрольным снимком."
                                    : "После Abort исходная группа не найдена: " + (restoreError ?? "причина не определена");
                        }
                        catch (Exception verifyEx)
                        {
                            rollbackVerified = false;
                            rollbackCheckFailure = string.IsNullOrWhiteSpace(rollbackCheckFailure)
                                ? "Не удалось проверить восстановление группы после Abort: " + verifyEx.Message
                                : rollbackCheckFailure + " Дополнительная ошибка проверки группы: " + verifyEx.Message;
                        }
                    }
                    else if (!abortSucceeded)
                    {
                        rollbackVerified = false;
                    }
                }

                string stageFailure = "Редактирование не выполнено на этапе: " + stage + ".";
                string recoveryMessage;
                if (!transactionOpened)
                {
                    recoveryMessage = "Транзакция изменения геометрии не была открыта; модель не изменялась.";
                }
                else if (rollbackVerified)
                {
                    recoveryMessage = "Транзакция отменена; исходная группа проверена по метаданным и восстановлена.";
                }
                else
                {
                    recoveryMessage = "Не удалось подтвердить полное восстановление исходной группы после ошибки. НЕ СОХРАНЯЙТЕ этот IPT. Закройте документ без сохранения и откройте последнюю сохранённую копию.";
                }
                string recoveryDetails = string.Join(" ", new[] { abortFailure, rollbackCheckFailure }.Where(x => !string.IsNullOrWhiteSpace(x)));
                error = stageFailure + " " + recoveryMessage +
                        (string.IsNullOrWhiteSpace(recoveryDetails) ? "" : " " + recoveryDetails) + " " + GetDetailedMessage(ex);
                // The dialog writes this technical trace to the existing rotated diagnostic log.
                // Build() is called with its own transaction disabled during editing, so its normal
                // BuildAll catch does not populate LastError for this failure path.
                ThreadBuilder.LastError = stageFailure + System.Environment.NewLine + recoveryMessage +
                    (string.IsNullOrWhiteSpace(recoveryDetails) ? "" : System.Environment.NewLine + recoveryDetails) +
                    System.Environment.NewLine + ex.ToString();
                rebuiltTarget = null;
                return false;
            }
        }


        private static bool TryCaptureEndOfPartPosition(PartDocument doc, string threadId,
                                                        out EndOfPartPositionSnapshot snapshot, out string error)
        {
            snapshot = null;
            error = null;
            try
            {
                BrowserPane pane = FindTreeBrowserPane(doc);
                if (pane == null || pane.TopNode == null)
                {
                    error = "Не удалось получить дерево построений Inventor; безопасное сохранение позиции резьбы невозможно. Редактирование не начато.";
                    return false;
                }

                bool markerFound = false;
                foreach (BrowserNode topNode in pane.TopNode.BrowserNodes)
                {
                    object native = null;
                    try { native = topNode.NativeObject; } catch { }
                    if (native is EndOfFeatures)
                    {
                        markerFound = true;
                        continue;
                    }
                    if (!markerFound) continue;

                    object threadAnchor = FindThreadMemberInNode(topNode, threadId, 0);
                    if (threadAnchor != null)
                    {
                        snapshot = new EndOfPartPositionSnapshot
                        {
                            WasAtBottom = false,
                            NextAnchorIsEditedThread = true
                        };
                        return true;
                    }

                    object downstreamAnchor = FindEndOfPartAnchorInNode(topNode, 0);
                    if (downstreamAnchor != null)
                    {
                        snapshot = new EndOfPartPositionSnapshot
                        {
                            WasAtBottom = false,
                            NextAnchorIsEditedThread = false,
                            NextAnchor = downstreamAnchor
                        };
                        return true;
                    }
                }

                if (!markerFound)
                {
                    error = "Не удалось найти маркер конца истории построений Inventor. Редактирование отменено до изменения модели.";
                    return false;
                }

                // No model feature follows the marker: it was at the bottom of the tree.
                snapshot = new EndOfPartPositionSnapshot { WasAtBottom = true };
                return true;
            }
            catch (Exception ex)
            {
                error = "Не удалось сохранить положение маркера конца истории: " + ex.Message + ". Редактирование не начато.";
                return false;
            }
        }

        private static bool TryFindFirstThreadHistoryAnchor(PartDocument doc, string threadId,
                                                            out object anchor, out string error)
        {
            anchor = null;
            error = null;
            try
            {
                BrowserPane pane = FindTreeBrowserPane(doc);
                if (pane == null || pane.TopNode == null)
                {
                    error = "Не удалось получить дерево построений Inventor, поэтому исходная позиция резьбы не определена. Редактирование не начато.";
                    return false;
                }

                foreach (BrowserNode node in pane.TopNode.BrowserNodes)
                {
                    anchor = FindThreadMemberInNode(node, threadId, 0);
                    if (anchor != null) return true;
                }

                error = "Не удалось найти объект резьбы в дереве построений для фиксации исходной позиции. Редактирование не начато.";
                return false;
            }
            catch (Exception ex)
            {
                error = "Не удалось определить исходную позицию резьбы в дереве построений: " + ex.Message + ". Редактирование не начато.";
                return false;
            }
        }

        private static BrowserPane FindTreeBrowserPane(PartDocument doc)
        {
            if (doc == null) return null;
            try
            {
                BrowserPane active = doc.BrowserPanes.ActivePane;
                if (active != null && active.TreeBrowser) return active;
            }
            catch { }
            try
            {
                foreach (BrowserPane pane in doc.BrowserPanes)
                    if (pane != null && pane.TreeBrowser) return pane;
            }
            catch { }
            return null;
        }

        private static object FindThreadMemberInNode(BrowserNode node, string threadId, int depth)
        {
            if (node == null || depth > 64) return null;
            try
            {
                object native = node.NativeObject;
                string foundThreadId;
                if (ThreadMetadataStore.TryGetThreadId(native, out foundThreadId) &&
                    string.Equals(foundThreadId, threadId, StringComparison.Ordinal) &&
                    ClassifyMemberForDeletion(native) != ThreadEditMemberKind.Unsupported)
                    return native;
            }
            catch { }
            try
            {
                foreach (BrowserNode child in node.BrowserNodes)
                {
                    object found = FindThreadMemberInNode(child, threadId, depth + 1);
                    if (found != null) return found;
                }
            }
            catch { }
            return null;
        }

        private static object FindEndOfPartAnchorInNode(BrowserNode node, int depth)
        {
            if (node == null || depth > 64) return null;
            try
            {
                object native = node.NativeObject;
                if (native is PartFeature || native is PlanarSketch || native is Sketch3D ||
                    native is WorkPlane || native is WorkAxis || native is WorkPoint)
                    return native;
            }
            catch { }
            try
            {
                foreach (BrowserNode child in node.BrowserNodes)
                {
                    object found = FindEndOfPartAnchorInNode(child, depth + 1);
                    if (found != null) return found;
                }
            }
            catch { }
            return null;
        }

        private static void SetEndOfPartBefore(object anchor)
        {
            if (anchor == null) throw new InvalidOperationException("Не задан объект-якорь для маркера конца истории.");
            dynamic positionable = anchor;
            positionable.SetEndOfPart(true);
        }

        private static void RestoreEndOfPartPosition(PartDocument doc,
                                                      EndOfPartPositionSnapshot snapshot,
                                                      string threadId)
        {
            if (doc == null || snapshot == null)
                throw new InvalidOperationException("Не сохранено исходное положение конца истории построений.");

            PartComponentDefinition definition = doc.ComponentDefinition;
            if (snapshot.WasAtBottom)
            {
                definition.SetEndOfPartToTopOrBottom(false);
                return;
            }

            object anchor = snapshot.NextAnchorIsEditedThread
                ? FindFirstThreadHistoryAnchor(doc, threadId)
                : snapshot.NextAnchor;
            if (anchor == null)
                throw new InvalidOperationException("Не удалось восстановить исходный якорь конца истории построений.");
            SetEndOfPartBefore(anchor);
        }

        private static object FindFirstThreadHistoryAnchor(PartDocument doc, string threadId)
        {
            BrowserPane pane = FindTreeBrowserPane(doc);
            if (pane == null || pane.TopNode == null) return null;
            foreach (BrowserNode node in pane.TopNode.BrowserNodes)
            {
                object anchor = FindThreadMemberInNode(node, threadId, 0);
                if (anchor != null) return anchor;
            }
            return null;
        }

        private static string FindThreadFolderNameForGroup(PartDocument doc, string threadId)
        {
            try
            {
                BrowserPane pane = FindTreeBrowserPane(doc);
                if (pane == null || pane.TopNode == null) return null;
                var names = new List<string>();
                foreach (BrowserFolder folder in pane.TopNode.BrowserFolders)
                {
                    if (folder == null) continue;
                    string folderName;
                    try { folderName = folder.Name ?? string.Empty; } catch { continue; }
                    if (!folderName.StartsWith("Резьба — ", StringComparison.OrdinalIgnoreCase)) continue;
                    BrowserNode node = null;
                    try { node = folder.BrowserNode; } catch { }
                    if (node != null && FindThreadMemberInNode(node, threadId, 0) != null)
                        names.Add(folderName);
                }
                return names.Count == 1 ? names[0] : null;
            }
            catch { return null; }
        }

        private static bool TryRefreshThreadFolderName(PartDocument doc, string threadId,
            ThreadParams parameters, string originalFolderName, out string error)
        {
            error = null;
            if (doc == null || string.IsNullOrWhiteSpace(threadId) || parameters == null)
            {
                error = "Не удалось обновить имя папки: отсутствует документ, ID группы или параметры резьбы.";
                return false;
            }

            BrowserPane pane = FindTreeBrowserPane(doc);
            if (pane == null || pane.TopNode == null)
            {
                error = "Геометрия обновлена, но не удалось получить дерево Inventor для обновления имени папки резьбы.";
                return false;
            }

            string desiredName = parameters.Tapered
                ? ThreadFolderNamePolicy.BuildTaperedThreadFolderName(parameters.TaperStandard, parameters.TaperDisplayDesignation, parameters.TaperDesignation, parameters.Starts, parameters.RightHand)
                : ThreadFolderNamePolicy.BuildThreadFolderName(parameters.SizeName,
                    parameters.Starts, parameters.RightHand, parameters.Standard, parameters.Mirror);
            var matchingFolders = new List<BrowserFolder>();
            try
            {
                foreach (BrowserFolder folder in pane.TopNode.BrowserFolders)
                {
                    if (folder == null) continue;
                    string folderName = string.Empty;
                    try { folderName = folder.Name ?? string.Empty; } catch { }
                    if (!folderName.StartsWith("Резьба — ", StringComparison.OrdinalIgnoreCase)) continue;

                    BrowserNode folderNode = null;
                    try { folderNode = folder.BrowserNode; } catch { }
                    if (folderNode != null && FindThreadMemberInNode(folderNode, threadId, 0) != null)
                        matchingFolders.Add(folder);
                }
            }
            catch (Exception ex)
            {
                error = "Геометрия обновлена, но не удалось определить папку текущей резьбы в дереве Inventor: " + ex.Message;
                return false;
            }

            BrowserFolder selectedFolder = null;
            if (matchingFolders.Count == 1)
            {
                selectedFolder = matchingFolders[0];
            }
            else if (matchingFolders.Count > 1)
            {
                List<BrowserFolder> exactMatches = matchingFolders.Where(folder =>
                {
                    try { return string.Equals(folder.Name, desiredName, StringComparison.OrdinalIgnoreCase); }
                    catch { return false; }
                }).ToList();
                if (exactMatches.Count == 1) selectedFolder = exactMatches[0];
                else
                {
                    error = "Геометрия обновлена, но имя папки не изменено: текущая группа неоднозначно соответствует нескольким папкам резьбы.";
                    return false;
                }
            }
            else if (!string.IsNullOrWhiteSpace(originalFolderName))
            {
                // If replacing the tagged features invalidated their BrowserNode association,
                // fall back only to the exact folder identified by the same ThreadId before the
                // transaction. Never pick an arbitrary folder by position or by a guessed name.
                List<BrowserFolder> previousMatches = new List<BrowserFolder>();
                foreach (BrowserFolder folder in pane.TopNode.BrowserFolders)
                {
                    if (folder == null) continue;
                    string folderName = string.Empty;
                    try { folderName = folder.Name ?? string.Empty; } catch { }
                    if (string.Equals(folderName, originalFolderName, StringComparison.OrdinalIgnoreCase))
                        previousMatches.Add(folder);
                }
                if (previousMatches.Count == 1)
                    selectedFolder = previousMatches[0];
                else
                {
                    error = previousMatches.Count == 0
                        ? "Геометрия обновлена, но папка исходной группы резьбы больше не найдена; имя в дереве не удалось обновить."
                        : "Геометрия обновлена, но исходное имя папки соответствует нескольким папкам; автоматическое переименование небезопасно.";
                    return false;
                }
            }
            else
            {
                error = "Геометрия обновлена, но не найдена папка «Резьба» с объектами текущей группы; имя в дереве не удалось обновить.";
                return false;
            }

            string currentName = string.Empty;
            try { currentName = selectedFolder.Name ?? string.Empty; } catch { }
            string uniqueName = UniqueFolderNameExcluding(pane.TopNode, desiredName, selectedFolder);
            if (string.Equals(currentName, uniqueName, StringComparison.OrdinalIgnoreCase)) return true;

            try
            {
                selectedFolder.Name = uniqueName;
                string verifiedName = selectedFolder.Name ?? string.Empty;
                if (!string.Equals(verifiedName, uniqueName, StringComparison.OrdinalIgnoreCase))
                {
                    error = "Inventor не подтвердил новое имя папки резьбы: ожидалось «" + uniqueName + "», получено «" + verifiedName + "».";
                    return false;
                }
                return true;
            }
            catch (Exception ex)
            {
                error = "Геометрия обновлена, но Inventor не позволил изменить имя папки резьбы: " + ex.Message;
                return false;
            }
        }

        private static string UniqueFolderNameExcluding(BrowserNode topNode, string desiredName, BrowserFolder currentFolder)
        {
            bool exactExists = false;
            int maxSuffix = 1;
            string suffixPrefix = desiredName + " #";
            try
            {
                foreach (BrowserFolder folder in topNode.BrowserFolders)
                {
                    if (folder == null || ThreadBuilder.SameBrowserComObject(folder, currentFolder)) continue;
                    string name = string.Empty;
                    try { name = folder.Name ?? string.Empty; } catch { }
                    if (string.Equals(name, desiredName, StringComparison.OrdinalIgnoreCase)) exactExists = true;
                    else if (name.StartsWith(suffixPrefix, StringComparison.OrdinalIgnoreCase))
                    {
                        int suffix;
                        if (int.TryParse(name.Substring(suffixPrefix.Length), out suffix)) maxSuffix = Math.Max(maxSuffix, suffix);
                    }
                }
            }
            catch { }
            return exactExists ? desiredName + " #" + (maxSuffix + 1).ToString() : desiredName;
        }

        private static string RemoveResolvedFolderMappingWarning(string warning, string attemptedBaseName)
        {
            if (string.IsNullOrWhiteSpace(warning)) return warning;
            string resolved = "Не удалось сопоставить созданные операции с узлами дерева для папки «" + attemptedBaseName + "».";
            string[] lines = warning.Split(new[] { "\r\n", "\n" }, StringSplitOptions.None);
            var remaining = lines.Where(line => !string.Equals(line.Trim(), resolved, StringComparison.Ordinal)).ToArray();
            return string.Join(System.Environment.NewLine, remaining).Trim();
        }

        private static string AppendWarning(string warning, string addition)
        {
            if (string.IsNullOrWhiteSpace(addition)) return warning;
            if (string.IsNullOrWhiteSpace(warning)) return addition;
            return warning + System.Environment.NewLine + addition;
        }

        private static void CleanupEmptyThreadFolders(PartDocument doc)
        {
            try
            {
                BrowserPane pane = null;
                try
                {
                    BrowserPane active = doc.BrowserPanes.ActivePane;
                    if (active != null && active.TreeBrowser) pane = active;
                }
                catch { }
                if (pane == null)
                {
                    foreach (BrowserPane candidate in doc.BrowserPanes)
                        if (candidate != null && candidate.TreeBrowser) { pane = candidate; break; }
                }
                if (pane == null || pane.TopNode == null) return;

                var emptyFolders = new List<BrowserFolder>();
                foreach (BrowserFolder folder in pane.TopNode.BrowserFolders)
                {
                    if (folder == null) continue;
                    string name = string.Empty;
                    try { name = folder.Name ?? string.Empty; } catch { }
                    if (!ThreadBrowserFolderPolicy.IsManagedThreadFolder(name)) continue;
                    bool empty = false;
                    try
                    {
                        BrowserNode node = folder.BrowserNode;
                        empty = node == null || node.BrowserNodes == null || node.BrowserNodes.Count == 0;
                    }
                    catch { }
                    if (empty) emptyFolders.Add(folder);
                }

                foreach (BrowserFolder folder in emptyFolders)
                {
                    try { ((dynamic)folder).Delete(); } catch { }
                }
            }
            catch { /* Folder cleanup must never invalidate a successfully rebuilt thread. */ }
        }

        private static ThreadEditMemberKind ClassifyMemberForDeletion(object member)
        {
            if (member == null) return ThreadEditMemberKind.Unsupported;
            // Only types emitted by ThreadBuilder into its persisted group are accepted.
            if (member is WorkPlane) return ThreadEditMemberKind.WorkFeature;
            if (member is PlanarSketch) return ThreadEditMemberKind.Sketch;
            if (member is ThreadFeature || member is RevolveFeature || member is ChamferFeature || member is CoilFeature ||
                member is LoftFeature || member is SweepFeature)
                return ThreadEditMemberKind.Feature;
            return ThreadEditMemberKind.Unsupported;
        }

        private static string DescribeMemberForDeletion(object member, ThreadEditMemberKind kind, int index)
        {
            string clrType = "<null>";
            try { if (member != null) clrType = member.GetType().FullName ?? member.GetType().Name; } catch { }
            string label = kind.ToString();
            try
            {
                if (member is WorkPlane) label = "WorkPlane";
                else if (member is PlanarSketch) label = "PlanarSketch";
                else if (member is ThreadFeature) label = "ThreadFeature";
                else if (member is RevolveFeature) label = "RevolveFeature";
                else if (member is ChamferFeature) label = "ChamferFeature";
                else if (member is CoilFeature) label = "CoilFeature";
                else if (member is LoftFeature) label = "LoftFeature";
                else if (member is SweepFeature) label = "SweepFeature";
            }
            catch { }
            return "объект №" + index + " (" + label + "; CLR=" + clrType + ")";
        }

        internal static bool TryGetHistoryRisk(PartDocument doc, string threadId, out bool hasDownstreamOperations,
                                               out int downstreamOperationCount, out string error)
        {
            hasDownstreamOperations = false;
            downstreamOperationCount = 0;
            error = null;
            if (doc == null || string.IsNullOrWhiteSpace(threadId))
            {
                error = "Не удалось определить деталь и идентификатор резьбы для проверки истории построений.";
                return false;
            }

            try
            {
                PartFeatures features = doc.ComponentDefinition.Features;
                int count = 0;
                int lastGroupFeatureIndex = -1;
                foreach (object feature in features)
                {
                    string id;
                    if (ThreadMetadataStore.TryGetThreadId(feature, out id) &&
                        string.Equals(id, threadId, StringComparison.Ordinal))
                        lastGroupFeatureIndex = count;
                    count++;
                }

                if (lastGroupFeatureIndex < 0)
                {
                    error = "В истории построений не найдена ни одна операция выбранной резьбы. Обновление отменено, модель не изменена.";
                    return false;
                }
                downstreamOperationCount = Math.Max(0, count - lastGroupFeatureIndex - 1);
                hasDownstreamOperations = ThreadEditSafetyPolicy.RequiresDownstreamWarning(lastGroupFeatureIndex, count);
                return true;
            }
            catch (Exception ex)
            {
                error = "Не удалось надёжно проверить историю построений; редактирование не начато: " + ex.Message;
                return false;
            }
        }

        private static bool CanFindGroupFeatureInHistory(PartDocument doc, ThreadMetadataGroup group, out string error)
        {
            error = null;
            if (doc == null || group == null || group.Record == null)
            {
                error = "Не удалось проверить группу резьбы.";
                return false;
            }

            try
            {
                PartFeatures features = doc.ComponentDefinition.Features;
                int count = 0;
                int lastGroupFeatureIndex = -1;
                foreach (object feature in features)
                {
                    string id;
                    if (ThreadMetadataStore.TryGetThreadId(feature, out id) &&
                        string.Equals(id, group.Record.ThreadId, StringComparison.Ordinal))
                        lastGroupFeatureIndex = count;
                    count++;
                }

                if (lastGroupFeatureIndex < 0)
                {
                    error = "В группе не найдено ни одной помеченной операции моделирования. Автоматическая замена невозможна.";
                    return false;
                }
                // Later features are permitted after an explicit, styled risk confirmation
                // in the dialog. Here we only require that the requested group still exists.
                return true;
            }
            catch (Exception ex)
            {
                error = "Не удалось проверить порядок операций детали, поэтому изменение заблокировано: " + ex.Message;
                return false;
            }
        }

        private static ThreadTarget ResolveOriginalTarget(Inventor.Application app, PartDocument doc,
                                                          ThreadTargetSnapshot snapshot, out string error)
        {
            error = null;
            var matches = new List<Edge>();
            var seenUnknowns = new HashSet<long>();
            try
            {
                PartComponentDefinition definition = doc.ComponentDefinition;
                foreach (SurfaceBody body in definition.SurfaceBodies)
                {
                    if (!string.IsNullOrWhiteSpace(snapshot.BodyName) &&
                        !string.Equals(body.Name, snapshot.BodyName, StringComparison.OrdinalIgnoreCase))
                        continue;

                    foreach (Face face in body.Faces)
                    {
                        if (face.SurfaceType != SurfaceTypeEnum.kCylinderSurface) continue;
                        Cylinder cylinder = face.Geometry as Cylinder;
                        if (cylinder == null || Math.Abs(cylinder.Radius - snapshot.RadiusCm) > 0.001) continue;

                        foreach (Edge edge in face.Edges)
                        {
                            double[] center = EdgeCenter(edge);
                            if (center == null || Distance(center, snapshot.Center) > 0.001) continue;

                            ThreadTarget candidate;
                            try { candidate = ThreadBuilder.Analyze(app, edge); }
                            catch { continue; }
                            if (candidate.IsExternal != snapshot.IsExternal ||
                                Math.Abs(candidate.RadiusCm - snapshot.RadiusCm) > 0.001 ||
                                Math.Abs(candidate.LengthCm - snapshot.LengthCm) > 0.01 ||
                                candidate.Center == null || Distance(candidate.Center, snapshot.Center) > 0.001 ||
                                !AxisMatches(candidate.U, snapshot.Axis))
                                continue;
                            if (candidate.StartIsShoulder != snapshot.StartIsShoulder ||
                                candidate.EndIsShoulder != snapshot.EndIsShoulder)
                                continue;

                            long identity = GetComIdentity(edge);
                            if (identity != 0)
                            {
                                if (!seenUnknowns.Add(identity)) continue;
                            }
                            else if (matches.Any(existing => SameGeometricEdge(existing, edge)))
                            {
                                continue;
                            }
                            matches.Add(edge);
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                error = "Не удалось восстановить исходную цилиндрическую поверхность после удаления группы: " + ex.Message;
                return null;
            }

            if (!ThreadEditSafetyPolicy.IsUniqueCandidateCount(matches.Count))
            {
                error = matches.Count == 0
                    ? "Исходный цилиндр не найден после подготовки к замене. Возможно, поверхность детали изменилась. Операция отменена."
                    : "Найдено несколько возможных исходных цилиндров. Из-за неоднозначности операция отменена без выбора произвольной поверхности.";
                return null;
            }

            try { return ThreadBuilder.Analyze(app, matches[0]); }
            catch (Exception ex)
            {
                error = "Не удалось повторно проанализировать исходное ребро: " + ex.Message;
                return null;
            }
        }

        private static bool SameGeometricEdge(Edge a, Edge b)
        {
            double[] ca = EdgeCenter(a), cb = EdgeCenter(b);
            return ca != null && cb != null && Distance(ca, cb) <= 1e-7 &&
                   Math.Abs(EdgeRadius(a) - EdgeRadius(b)) <= 1e-7;
        }

        private static long GetComIdentity(object obj)
        {
            IntPtr pointer = IntPtr.Zero;
            try
            {
                pointer = Marshal.GetIUnknownForObject(obj);
                return pointer.ToInt64();
            }
            catch { return 0; }
            finally
            {
                if (pointer != IntPtr.Zero)
                {
                    try { Marshal.Release(pointer); } catch { }
                }
            }
        }

        private static double[] EdgeCenter(Edge edge)
        {
            try
            {
                if (edge.GeometryType == CurveTypeEnum.kCircleCurve)
                {
                    Circle c = (Circle)edge.Geometry;
                    return new[] { c.Center.X, c.Center.Y, c.Center.Z };
                }
                if (edge.GeometryType == CurveTypeEnum.kCircularArcCurve)
                {
                    Arc3d a = (Arc3d)edge.Geometry;
                    return new[] { a.Center.X, a.Center.Y, a.Center.Z };
                }
            }
            catch { }
            return null;
        }

        private static double EdgeRadius(Edge edge)
        {
            try
            {
                if (edge.GeometryType == CurveTypeEnum.kCircleCurve) return ((Circle)edge.Geometry).Radius;
                if (edge.GeometryType == CurveTypeEnum.kCircularArcCurve) return ((Arc3d)edge.Geometry).Radius;
            }
            catch { }
            return 0.0;
        }

        private static bool AxisMatches(double[] a, double[] b)
        {
            if (a == null || b == null || a.Length < 3 || b.Length < 3) return false;
            double dot = a[0] * b[0] + a[1] * b[1] + a[2] * b[2];
            return dot >= 0.999;
        }

        private static double Distance(double[] a, double[] b)
        {
            if (a == null || b == null || a.Length < 3 || b.Length < 3) return double.MaxValue;
            double x = a[0] - b[0], y = a[1] - b[1], z = a[2] - b[2];
            return Math.Sqrt(x * x + y * y + z * z);
        }

        private static bool ValidateNoMetadataGroupOverlap(PartDocument doc, ThreadMetadataGroup current,
                                                           ThreadParams replacement, out string error)
        {
            error = null;
            List<ThreadMetadataGroup> groups;
            if (!ThreadMetadataStore.TryLoadAllGroups(doc, out groups, out error)) return false;

            ThreadTargetSnapshot source = current.Record.Target;
            double newLo, newHi;
            GetInterval(source, replacement.FullLength, replacement.LengthMm, replacement.OffsetMm,
                        source.Center, source.Axis, out newLo, out newHi);

            foreach (ThreadMetadataGroup other in groups)
            {
                if (other == null || other.Record == null ||
                    string.Equals(other.Record.ThreadId, current.Record.ThreadId, StringComparison.Ordinal)) continue;
                ThreadTargetSnapshot target = other.Record.Target;
                if (!ThreadTargetIsolationPolicy.SameCylinder(source, target)) continue;

                double oldLo, oldHi;
                GetInterval(target, other.Record.Parameters.FullLength, other.Record.Parameters.LengthMm,
                            other.Record.Parameters.OffsetMm, source.Center, source.Axis, out oldLo, out oldHi);
                if (ThreadEditSafetyPolicy.IntervalsOverlap(newLo, newHi, oldLo, oldHi))
                {
                    error = "Изменение перекрывает другую сохранённую резьбу на той же цилиндрической поверхности Ø " +
                            (source.RadiusCm * 20.0).ToString("0.###", System.Globalization.CultureInfo.InvariantCulture) +
                            " мм. Уменьшите длину/измените отступ; исходная модель не изменена.";
                    return false;
                }
            }
            return true;
        }

        private static void GetInterval(ThreadTargetSnapshot target, bool fullLength, double lengthMm, double offsetMm,
                                        double[] referenceOrigin, double[] referenceAxis, out double lo, out double hi)
        {
            double offset = offsetMm / 10.0;
            double length = fullLength ? target.LengthCm - offset : lengthMm / 10.0;
            double dx = target.Center[0] - referenceOrigin[0];
            double dy = target.Center[1] - referenceOrigin[1];
            double dz = target.Center[2] - referenceOrigin[2];
            double startProjection = dx * referenceAxis[0] + dy * referenceAxis[1] + dz * referenceAxis[2];
            double direction = target.Axis[0] * referenceAxis[0] + target.Axis[1] * referenceAxis[1] + target.Axis[2] * referenceAxis[2];
            double a = startProjection + direction * offset;
            double b = startProjection + direction * (offset + length);
            lo = Math.Min(a, b);
            hi = Math.Max(a, b);
        }

        private static string GetDetailedMessage(Exception ex)
        {
            if (ex == null) return "Неизвестная ошибка.";
            var parts = new List<string>();
            for (Exception current = ex; current != null; current = current.InnerException)
            {
                if (!string.IsNullOrWhiteSpace(current.Message) && (parts.Count == 0 || parts[parts.Count - 1] != current.Message))
                    parts.Add(current.Message);
            }
            return string.Join(" → ", parts);
        }
    }
}
