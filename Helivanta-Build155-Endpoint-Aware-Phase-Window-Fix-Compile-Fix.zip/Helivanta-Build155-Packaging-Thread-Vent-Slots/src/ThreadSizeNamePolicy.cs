﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;

namespace ThreadPro
{
    /// <summary>
    /// Builds a displayed/folder size name from the CURRENT standard and its size table.
    /// Do not trust a ComboBox's selected item here: during a template switch, a stale
    /// selected item from the previous standard can have the same diameter and pitch.
    /// </summary>
    public static class ThreadSizeNamePolicy
    {
        public static string Build(ThreadStandard standard, IEnumerable<ThreadSize> currentStandardSizes,
                                   double diameterMm, double pitchMm)
        {
            IEnumerable<ThreadSize> sizes = currentStandardSizes ?? Enumerable.Empty<ThreadSize>();
            ThreadSize exact = sizes.FirstOrDefault(s => s != null &&
                Math.Abs(s.DiameterMm - diameterMm) < 0.0006 &&
                Math.Abs(s.PitchMm - pitchMm) < 0.0006);
            if (exact != null && !string.IsNullOrWhiteSpace(exact.Name)) return exact.Name;

            string diameter = diameterMm.ToString("0.###", CultureInfo.InvariantCulture);
            string pitch = pitchMm.ToString("0.###", CultureInfo.InvariantCulture);
            switch (standard)
            {
                case ThreadStandard.ISO:
                    return "M" + diameter + " x " + pitch;
                case ThreadStandard.Tr:
                    return "Tr " + diameter + " x " + pitch;
                case ThreadStandard.S:
                    return "S " + diameter + " x " + pitch;
                case ThreadStandard.Rd:
                    return "Rd " + diameter + " x " + pitch;
                default:
                    return "Ø" + diameter + " x " + pitch + " мм";
            }
        }
    }
}
