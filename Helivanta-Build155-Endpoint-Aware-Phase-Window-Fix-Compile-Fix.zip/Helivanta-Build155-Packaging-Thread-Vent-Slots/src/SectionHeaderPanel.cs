using System;
using System.Collections.Generic;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Windows.Forms;

namespace ThreadPro
{
    /// <summary>
    /// Section heading surface using the existing UI palette with a very subtle diagonal
    /// technical hatch. The hatch remains aligned when transparent child controls paint.
    /// </summary>
    internal sealed class SectionHeaderPanel : TableLayoutPanel
    {
        // Runtime-only rendering switch. Keep this as a field rather than a WinForms
        // Designer-serialized property; it is configured in code, never in the designer.
        internal bool HatchEnabled = true;

        public SectionHeaderPanel()
        {
            SetStyle(ControlStyles.UserPaint | ControlStyles.AllPaintingInWmPaint |
                     ControlStyles.OptimizedDoubleBuffer | ControlStyles.ResizeRedraw |
                     ControlStyles.SupportsTransparentBackColor, true);
            DoubleBuffered = true;
        }

        protected override void OnPaintBackground(PaintEventArgs e)
        {
            PaintHatchedSurface(e.Graphics, ClientRectangle, 0, 0, ClientSize.Width, ClientSize.Height);
        }

        /// <summary>
        /// Paints this header's exact pattern phase into a child control's client area.
        /// WinForms transparent controls normally delegate background painting to the parent;
        /// SectionGlyph uses this method to guarantee phase continuity across the icon bounds.
        /// </summary>
        internal void PaintChildBackground(Graphics graphics, Rectangle clientBounds, int childX, int childY)
        {
            PaintHatchedSurface(graphics, clientBounds, childX, childY, ClientSize.Width, ClientSize.Height);
        }

        private void PaintHatchedSurface(Graphics graphics, Rectangle bounds, int originX, int originY,
            int fullWidth, int fullHeight)
        {
            if (bounds.Width <= 0 || bounds.Height <= 0) return;
            using (var fill = new SolidBrush(BackColor))
                graphics.FillRectangle(fill, bounds);

            if (!HatchEnabled || SystemInformation.HighContrast || fullWidth <= 0 || fullHeight <= 0)
                return;

            // Half-tone lighter than the base surface, not a bright border or accent.
            Color baseColor = BackColor;
            Color hatchColor = Color.FromArgb(
                Math.Min(255, baseColor.R + 8),
                Math.Min(255, baseColor.G + 9),
                Math.Min(255, baseColor.B + 10));
            int spacing = Math.Max(7, (int)Math.Round(8.0 * Math.Max(96, DeviceDpi) / 96.0));
            using (var hatchPen = new Pen(hatchColor, 1f))
            {
                hatchPen.StartCap = LineCap.Flat;
                hatchPen.EndCap = LineCap.Flat;
                hatchPen.LineJoin = LineJoin.Miter;

                // Lines follow x + y = constant. Their phase is based on the complete header,
                // so a transparent glyph/title cannot make the diagonal texture jump at its edge.
                int globalStart = originX + originY;
                int globalEnd = globalStart + bounds.Width + bounds.Height;
                int first = (int)Math.Floor(globalStart / (double)spacing) * spacing;
                for (int c = first; c <= globalEnd; c += spacing)
                {
                    float localC = c - originX - originY;
                    var points = new List<PointF>(4);
                    AddIntersection(points, new PointF(0, localC), bounds.Width, bounds.Height, true);
                    AddIntersection(points, new PointF(localC, 0), bounds.Width, bounds.Height, true);
                    AddIntersection(points, new PointF(bounds.Width - 1, localC - (bounds.Width - 1)), bounds.Width, bounds.Height, true);
                    AddIntersection(points, new PointF(localC - (bounds.Height - 1), bounds.Height - 1), bounds.Width, bounds.Height, true);
                    if (points.Count >= 2)
                        graphics.DrawLine(hatchPen, points[0], points[1]);
                }
            }
        }

        private static void AddIntersection(List<PointF> points, PointF point, int width, int height, bool deduplicate)
        {
            if (point.X < -0.01f || point.Y < -0.01f || point.X > width - 1 + 0.01f || point.Y > height - 1 + 0.01f)
                return;
            if (deduplicate)
            {
                for (int i = 0; i < points.Count; i++)
                {
                    float dx = points[i].X - point.X;
                    float dy = points[i].Y - point.Y;
                    if (dx * dx + dy * dy < 0.25f) return;
                }
            }
            points.Add(point);
        }
    }
}
