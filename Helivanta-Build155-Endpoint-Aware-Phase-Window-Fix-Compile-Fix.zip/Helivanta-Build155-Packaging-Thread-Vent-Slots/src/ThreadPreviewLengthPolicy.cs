﻿using System;

namespace ThreadPro
{
    /// <summary>
    /// Resolves the axial span for transient preview geometry. All distances entering and
    /// leaving this helper follow Inventor's centimetre convention except the UI values,
    /// which are millimetres. Kept independent from Inventor COM so the policy can be tested.
    /// </summary>
    internal static class ThreadPreviewLengthPolicy
    {
        internal static double ResolveLengthCm(bool fullLength, double surfaceLengthCm,
            double offsetMm, double lengthMm)
        {
            if (double.IsNaN(surfaceLengthCm) || double.IsInfinity(surfaceLengthCm) || surfaceLengthCm <= 0.0)
                throw new InvalidOperationException("Не удалось определить длину цилиндрической поверхности.");
            if (double.IsNaN(offsetMm) || double.IsInfinity(offsetMm) || offsetMm < 0.0)
                throw new InvalidOperationException("Отступ от ребра должен быть неотрицательным.");

            double offsetCm = offsetMm / 10.0;
            if (offsetCm >= surfaceLengthCm - 1e-9)
                throw new InvalidOperationException("Отступ от ребра должен быть меньше длины цилиндрической поверхности.");

            double availableCm = surfaceLengthCm - offsetCm;
            double lengthCm;
            if (fullLength)
            {
                lengthCm = availableCm;
            }
            else
            {
                if (double.IsNaN(lengthMm) || double.IsInfinity(lengthMm) || lengthMm <= 0.0)
                    throw new InvalidOperationException("Задайте положительную длину резьбы в миллиметрах.");
                lengthCm = lengthMm / 10.0;
                if (offsetCm + lengthCm > surfaceLengthCm + 1e-6)
                    throw new InvalidOperationException("Длина резьбы вместе с отступом выходит за пределы цилиндрической поверхности.");
            }

            if (lengthCm <= 0.0)
                throw new InvalidOperationException("Длина предпросмотра должна быть больше нуля.");
            return lengthCm;
        }
    }
}
