﻿using System;

namespace ThreadPro
{
    /// <summary>
    /// Pure policy for schematic preview of end chamfers. Coordinates and distances are cm.
    /// The preview is visual-only; ThreadBuilder remains responsible for the exact B-Rep cut.
    /// </summary>
    internal static class ThreadPreviewChamferPolicy
    {
        public static bool IncludesStart(int mode) { return mode == 1 || mode == 3; }
        public static bool IncludesEnd(int mode) { return mode == 2 || mode == 3; }

        /// <summary>Returns the 0..1 factor of a linear 45-degree preview bevel.</summary>
        public static double DepthFactor(double axialPositionCm, double totalLengthCm, int mode, double chamferDepthCm)
        {
            if (!Finite(axialPositionCm) || !Finite(totalLengthCm) || totalLengthCm <= 0.0 ||
                !Finite(chamferDepthCm) || chamferDepthCm <= 0.0 || mode < 1 || mode > 3)
                return 0.0;
            double factor = 0.0;
            if (IncludesStart(mode) && axialPositionCm >= 0.0 && axialPositionCm < chamferDepthCm)
                factor = Math.Max(factor, 1.0 - axialPositionCm / chamferDepthCm);
            double distanceFromEnd = totalLengthCm - axialPositionCm;
            if (IncludesEnd(mode) && distanceFromEnd >= 0.0 && distanceFromEnd < chamferDepthCm)
                factor = Math.Max(factor, 1.0 - distanceFromEnd / chamferDepthCm);
            return Math.Max(0.0, Math.Min(1.0, factor));
        }

        /// <summary>Caps only the displayed bevel when requested dimensions cannot fit; build parameters are untouched.</summary>
        public static double ResolveVisualDepthCm(double requestedDepthCm, double referenceRadiusCm,
            double totalLengthCm, int mode)
        {
            if (!Finite(requestedDepthCm) || requestedDepthCm <= 0.0 ||
                !Finite(referenceRadiusCm) || referenceRadiusCm <= 0.0 ||
                !Finite(totalLengthCm) || totalLengthCm <= 0.0 || mode < 1 || mode > 3)
                return 0.0;
            double lengthFraction = mode == 3 ? 0.49 : 0.90;
            return Math.Max(0.0, Math.Min(requestedDepthCm,
                Math.Min(referenceRadiusCm * 0.90, totalLengthCm * lengthFraction)));
        }

        public static bool WasVisualDepthCapped(double requestedDepthCm, double visualDepthCm)
        {
            return Finite(requestedDepthCm) && requestedDepthCm > 0.0 &&
                Finite(visualDepthCm) && visualDepthCm + 1e-9 < requestedDepthCm;
        }

        private static bool Finite(double value) { return !double.IsNaN(value) && !double.IsInfinity(value); }
    }
}
