﻿using System;
using System.IO;
using System.Text.Json;

namespace ThreadPro
{
    internal sealed class HelivantaSettingsData
    {
        public string Theme { get; set; } = "Dark";
        public string Accent { get; set; } = "Amber";
        public string Language { get; set; } = "ru";
        public int PreviewOpacity { get; set; } = 80;
        public int PreviewLineScale { get; set; } = 100;
        public bool AutoPreview { get; set; } = true;
        public bool RememberPreview { get; set; } = true;
        public string DefaultStandard { get; set; } = "ISO";
        public string DefaultTechnology { get; set; } = "Metal";
        public bool DefaultExternal { get; set; } = true;
        public bool DefaultRightHand { get; set; } = true;
        public bool Tooltips { get; set; } = true;
    }

    internal static class HelivantaUserSettings
    {
        private static readonly object Sync = new object();
        private static readonly string FilePath = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "Helivanta", "settings.json");
        private static readonly JsonSerializerOptions JsonOptions = new JsonSerializerOptions
        {
            WriteIndented = true,
            PropertyNameCaseInsensitive = true
        };
        internal static HelivantaSettingsData Current { get; private set; } = Load();
        internal static event EventHandler SettingsSaved;
        internal static string SettingsPath => FilePath;

        private static HelivantaSettingsData Normalize(HelivantaSettingsData source)
        {
            if (source == null) source = new HelivantaSettingsData();
            return new HelivantaSettingsData
            {
                Theme = string.Equals(source.Theme, "Light", StringComparison.OrdinalIgnoreCase) ? "Light" : "Dark",
                Accent = string.Equals(source.Accent, "Blue", StringComparison.OrdinalIgnoreCase) ? "Blue"
                    : string.Equals(source.Accent, "Gray", StringComparison.OrdinalIgnoreCase) ? "Gray" : "Amber",
                Language = string.Equals(source.Language, "en", StringComparison.OrdinalIgnoreCase) ? "en" : "ru",
                PreviewOpacity = Math.Max(0, Math.Min(100, source.PreviewOpacity)),
                PreviewLineScale = Math.Max(50, Math.Min(200, source.PreviewLineScale)),
                AutoPreview = source.AutoPreview,
                RememberPreview = source.RememberPreview,
                DefaultStandard = string.IsNullOrWhiteSpace(source.DefaultStandard) ? "ISO" : source.DefaultStandard,
                DefaultTechnology = string.IsNullOrWhiteSpace(source.DefaultTechnology) ? "Metal" : source.DefaultTechnology,
                DefaultExternal = source.DefaultExternal,
                DefaultRightHand = source.DefaultRightHand,
                Tooltips = source.Tooltips
            };
        }

        private static HelivantaSettingsData Load()
        {
            try
            {
                if (File.Exists(FilePath))
                    return Normalize(JsonSerializer.Deserialize<HelivantaSettingsData>(File.ReadAllText(FilePath), JsonOptions));
            }
            catch { }
            return Normalize(new HelivantaSettingsData());
        }
        internal static void ReloadPersisted()
        {
            lock (Sync)
            {
                try
                {
                    if (!File.Exists(FilePath)) return;
                    var loaded = JsonSerializer.Deserialize<HelivantaSettingsData>(File.ReadAllText(FilePath), JsonOptions);
                    if (loaded != null) Current = Normalize(loaded);
                }
                catch { /* Keep the last valid in-memory settings if the file is temporarily unreadable. */ }
            }
        }

        internal static void Save(HelivantaSettingsData data)
        {
            if (data == null) return;
            lock (Sync)
            {
                Directory.CreateDirectory(Path.GetDirectoryName(FilePath));
                string tmp = FilePath + ".tmp";
                HelivantaSettingsData snapshot = Normalize(data);
                File.WriteAllText(tmp, JsonSerializer.Serialize(snapshot, JsonOptions));
                if (File.Exists(FilePath)) File.Replace(tmp, FilePath, null); else File.Move(tmp, FilePath);

                // Read the file back rather than trusting the form's mutable data object. The
                // in-memory source of truth therefore matches exactly what a new Settings window
                // will load, including the selected Light/Dark theme.
                var persisted = JsonSerializer.Deserialize<HelivantaSettingsData>(File.ReadAllText(FilePath), JsonOptions);
                if (persisted == null) throw new InvalidDataException("Saved Helivanta settings could not be read back.");
                Current = Normalize(persisted);
                if (!string.Equals(Current.Theme, snapshot.Theme, StringComparison.Ordinal) ||
                    !string.Equals(Current.Language, snapshot.Language, StringComparison.Ordinal))
                    throw new IOException("Saved Helivanta settings did not match the requested theme/language.");
            }
            // Notify UI clients only after Current and settings.json agree.
            SettingsSaved?.Invoke(null, EventArgs.Empty);
        }
    }
}
