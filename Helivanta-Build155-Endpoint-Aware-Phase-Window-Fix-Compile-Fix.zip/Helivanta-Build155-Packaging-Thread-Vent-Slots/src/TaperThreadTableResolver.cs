﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;

namespace ThreadPro
{
    /// <summary>
    /// Resolves UI-facing pipe-thread family labels to the type identifier accepted by Inventor's
    /// ThreadTableQuery. Inventor installations may expose localized/split JIS family names while
    /// the UI intentionally uses a stable English label.
    /// </summary>
    internal static class TaperThreadTableResolver
    {
        internal static string ResolveQueryType(object queryObject, string displayStandard,
            bool external, out string diagnostic)
        {
            diagnostic = null;
            if (queryObject == null) throw new ArgumentNullException("queryObject");
            if (string.IsNullOrWhiteSpace(displayStandard))
                throw new InvalidOperationException("Не выбран стандарт конической резьбы.");

            dynamic query = queryObject;
            string[] available;
            try
            {
                available = query.GetAvailableThreadTypes() as string[];
                if (available == null) available = Array.Empty<string>();
            }
            catch (Exception ex)
            {
                diagnostic = "GetAvailableThreadTypes: " + ex.GetType().Name + ": " + ex.Message;
                throw new InvalidOperationException("Inventor не смог перечислить типы резьбы из Thread.xls. " + diagnostic, ex);
            }

            bool jis = string.Equals(displayStandard.Trim(), "JIS Taper", StringComparison.OrdinalIgnoreCase);
            bool npt = string.Equals(displayStandard.Trim(), "NPT", StringComparison.OrdinalIgnoreCase);
            var candidates = new List<string>();
            if (jis)
            {
                foreach (string typeName in available)
                {
                    if (string.IsNullOrWhiteSpace(typeName)) continue;
                    string key = Normalize(typeName);
                    if (!key.Contains("jis") || !(key.Contains("taper") || key.Contains("конич"))) continue;
                    bool namesExternal = key.Contains("external") || key.Contains("внеш") || key.Contains("наруж");
                    bool namesInternal = key.Contains("internal") || key.Contains("внутрен");
                    if (namesExternal && !external) continue;
                    if (namesInternal && external) continue;
                    candidates.Add(typeName);
                }
            }
            else if (npt)
            {
                foreach (string typeName in available)
                {
                    if (string.IsNullOrWhiteSpace(typeName)) continue;
                    string key = Normalize(typeName);
                    if (key.Equals("npt", StringComparison.OrdinalIgnoreCase)) candidates.Add(typeName);
                }
                // Older/English tables may only expose one NPT-labelled family.
                if (candidates.Count == 0)
                    foreach (string typeName in available)
                        if (!string.IsNullOrWhiteSpace(typeName) && Normalize(typeName).StartsWith("npt", StringComparison.OrdinalIgnoreCase) &&
                            !Normalize(typeName).Contains("pvc")) candidates.Add(typeName);
            }
            else
            {
                foreach (string typeName in available)
                    if (string.Equals(typeName, displayStandard, StringComparison.OrdinalIgnoreCase)) candidates.Add(typeName);
            }

            // Exact UI label is tried last because localized tables may not use it as a sheet name.
            if (!candidates.Contains(displayStandard, StringComparer.OrdinalIgnoreCase)) candidates.Add(displayStandard);
            string lastFailure = null;
            foreach (string candidate in candidates.Distinct(StringComparer.OrdinalIgnoreCase))
            {
                var queryTypes = new List<string>();
                try
                {
                    string identifier = Convert.ToString(query.GetThreadTypeIdentifier(candidate), CultureInfo.InvariantCulture);
                    if (!string.IsNullOrWhiteSpace(identifier)) queryTypes.Add(identifier);
                }
                catch (Exception ex) { lastFailure = candidate + ": GetThreadTypeIdentifier " + ex.GetType().Name + ": " + ex.Message; }
                queryTypes.Add(candidate);

                foreach (string queryType in queryTypes.Distinct(StringComparer.OrdinalIgnoreCase))
                {
                    try
                    {
                        string[] sizes = query.GetAvailableThreadSizes(!external, queryType) as string[];
                        if (sizes != null && sizes.Length > 0)
                        {
                            diagnostic = "display=" + displayStandard + "; localizedType=" + candidate +
                                "; queryType=" + queryType + "; external=" + external + "; sizeCount=" + sizes.Length;
                            return queryType;
                        }
                        lastFailure = candidate + " -> " + queryType + ": no sizes";
                    }
                    catch (Exception ex)
                    {
                        lastFailure = candidate + " -> " + queryType + ": " + ex.GetType().Name + ": " + ex.Message;
                    }
                }
            }

            string tableTypes = string.Join("; ", available);
            diagnostic = "display=" + displayStandard + "; external=" + external + "; available=" + tableTypes +
                "; lastAttempt=" + (lastFailure ?? "none");
            throw new InvalidOperationException("Не удалось сопоставить стандарт «" + displayStandard +
                "» с доступным типом Thread.xls для " + (external ? "наружной" : "внутренней") +
                " конической резьбы. " + diagnostic);
        }

        private static string Normalize(string value)
        {
            string text = (value ?? string.Empty).Trim().ToLowerInvariant();
            text = text.Replace("ё", "е").Replace("_", " ").Replace("-", " ");
            while (text.Contains("  ")) text = text.Replace("  ", " ");
            return text;
        }
    }
}
