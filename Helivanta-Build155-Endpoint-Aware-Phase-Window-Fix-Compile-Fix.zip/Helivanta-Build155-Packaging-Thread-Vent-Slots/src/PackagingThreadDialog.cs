﻿using System;
using System.Drawing;
using System.Globalization;
using System.Windows.Forms;
using Inventor;
using DrawingColor = System.Drawing.Color;
using FormsApplication = System.Windows.Forms.Application;

namespace ThreadPro
{
    /// <summary>Parameter-entry and selection-validation surface for the semi-standard packaging thread.</summary>
    internal sealed class PackagingThreadDialog : Form
    {
        private readonly Inventor.Application _app;
        private readonly NumericUpDown _pitch, _starts, _ratio, _length, _clearance, _wall;
        private readonly ComboBox _hand, _extent;
        private readonly CheckBox _smoothStart, _smoothEnd, _ventSlots;
        private readonly NumericUpDown _ventSlotCount, _ventSlotWidth;
        private bool _ventSlotCountEditedByUser;
        private bool _ventSlotWidthEditedByUser;
        private bool _updatingVentSlotDefaults;
        private readonly Button _build, _cancelBuild, _close, _refreshSelection, _validate;
        private readonly Label _selection, _summary;
        private readonly Timer _undoStateTimer;
        private PartDocument _lastPackagingBuildDocument;
        private string _lastPackagingBuildTransactionName;
        private bool _buildInProgress;
        private bool _cancelRequested;

        internal PackagingThreadDialog(Inventor.Application app)
        {
            _app = app;
            Text = "Helivanta — Упаковочная резьба (эксперимент)";
            StartPosition = FormStartPosition.CenterParent;
            FormBorderStyle = FormBorderStyle.FixedDialog;
            MaximizeBox = false; MinimizeBox = false; ShowInTaskbar = false;
            ClientSize = new Size(760, 590);
            Font = new Font("Segoe UI", 9F);
            BackColor = DrawingColor.FromArgb(38, 41, 46); ForeColor = DrawingColor.Gainsboro;

            var layout = new TableLayoutPanel { Dock = DockStyle.Fill, Padding = new Padding(16), ColumnCount = 2, RowCount = 16, BackColor = BackColor };
            layout.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 54)); layout.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 46));
            Controls.Add(layout);
            AddLabel(layout, "Круговое ребро у края резьбы (выберите в модели)", 0, 2);
            _selection = new Label { Text = SelectionDescription(), Dock = DockStyle.Fill, ForeColor = DrawingColor.FromArgb(240, 180, 70), AutoSize = true };
            layout.Controls.Add(_selection, 0, 1); layout.SetColumnSpan(_selection, 2);
            AddLabel(layout, "Шаг, мм", 2, 0); _pitch = Number(2.7m, .25m, 12m, .05m, 2); AddControl(layout, _pitch, 2);
            AddLabel(layout, "Число заходов", 3, 0); _starts = Number(1, 1, 12, 1, 0); AddControl(layout, _starts, 3);
            AddLabel(layout, "Высота профиля / диаметр", 4, 0); _ratio = Number(.025m, .005m, .06m, .001m, 3); AddControl(layout, _ratio, 4);
            AddLabel(layout, "Длина / ход", 5, 0); _extent = new ComboBox { DropDownStyle = ComboBoxStyle.DropDownList, Dock = DockStyle.Fill, BackColor = DrawingColor.FromArgb(55,58,63), ForeColor = ForeColor };
            _extent.Items.AddRange(new object[] { "Длина, мм", "Число оборотов" }); _extent.SelectedIndex = 0; AddControl(layout, _extent, 5);
            AddLabel(layout, "Значение длины / оборотов", 6, 0); _length = Number(10, .1m, 1000m, .5m, 2); AddControl(layout, _length, 6);
            AddLabel(layout, "Зазор печати, мм (отдельно)", 7, 0); _clearance = Number(0, 0, .5m, .05m, 2); AddControl(layout, _clearance, 7);
            AddLabel(layout, "Толщина стенки (измерить), мм", 8, 0); _wall = Number(1.0m, .1m, 100m, .1m, 2); AddControl(layout, _wall, 8);
            AddLabel(layout, "Направление", 9, 0); _hand = new ComboBox { DropDownStyle = ComboBoxStyle.DropDownList, Dock = DockStyle.Fill, BackColor = DrawingColor.FromArgb(55,58,63), ForeColor = ForeColor };
            _hand.Items.AddRange(new object[] { "Правая", "Левая" }); _hand.SelectedIndex = 0; AddControl(layout, _hand, 9);
            var runoutOptions = new FlowLayoutPanel { Dock = DockStyle.Fill, FlowDirection = FlowDirection.LeftToRight, WrapContents = false, AutoSize = true, BackColor = BackColor, Margin = new Padding(0, 2, 0, 2) };
            _smoothStart = new CheckBox { Text = "Плавный сбег в начале", Checked = true, AutoSize = true, ForeColor = ForeColor, Margin = new Padding(0, 4, 18, 4) };
            _smoothEnd = new CheckBox { Text = "Плавный сбег в конце", Checked = true, AutoSize = true, ForeColor = ForeColor, Margin = new Padding(0, 4, 0, 4) };
            runoutOptions.Controls.Add(_smoothStart); runoutOptions.Controls.Add(_smoothEnd);
            layout.Controls.Add(runoutOptions, 0, 10); layout.SetColumnSpan(runoutOptions, 2);
            _ventSlots = new CheckBox { Text = "Вентиляционные пропилы по резьбе до исходного цилиндра", Checked = false, AutoSize = true, ForeColor = ForeColor, Margin = new Padding(0, 4, 0, 4) };
            layout.Controls.Add(_ventSlots, 0, 11); layout.SetColumnSpan(_ventSlots, 2);
            var ventSlotOptions = new FlowLayoutPanel { Dock = DockStyle.Fill, FlowDirection = FlowDirection.LeftToRight, WrapContents = false, AutoSize = true, BackColor = BackColor, Margin = new Padding(0, 0, 0, 2) };
            _ventSlotCount = Number(4, 1, 20, 1, 0); _ventSlotCount.Width = 62; _ventSlotCount.Enabled = false;
            _ventSlotWidth = Number((decimal)PackagingThreadVentSlotPolicy.GetDefaultWidthDegrees(false), 0.5m, 120m, 1m, 1); _ventSlotWidth.Width = 66; _ventSlotWidth.Enabled = false;
            var countLabel = new Label { Text = "Количество", AutoSize = true, ForeColor = ForeColor, Margin = new Padding(0, 7, 5, 0) };
            var widthLabel = new Label { Text = "Ширина, °", AutoSize = true, ForeColor = ForeColor, Margin = new Padding(12, 7, 5, 0) };
            ventSlotOptions.Controls.Add(countLabel); ventSlotOptions.Controls.Add(_ventSlotCount); ventSlotOptions.Controls.Add(widthLabel); ventSlotOptions.Controls.Add(_ventSlotWidth);
            layout.Controls.Add(ventSlotOptions, 0, 12); layout.SetColumnSpan(ventSlotOptions, 2);
            var ventSlotNote = new Label { Text = "PCO1881: угол по чертежу 56°; рабочая ширина по умолчанию сейчас 14°. Для отверстия 8×14° — предположение.", Dock = DockStyle.Fill, AutoSize = true, ForeColor = DrawingColor.FromArgb(180, 185, 192), Margin = new Padding(0, 0, 0, 4) };
            layout.Controls.Add(ventSlotNote, 0, 13); layout.SetColumnSpan(ventSlotNote, 2);
            _ventSlots.CheckedChanged += (_, __) => { _ventSlotCount.Enabled = _ventSlots.Checked; _ventSlotWidth.Enabled = _ventSlots.Checked; };
            _ventSlotCount.ValueChanged += (_, __) => { if (!_updatingVentSlotDefaults) _ventSlotCountEditedByUser = true; };
            _ventSlotWidth.ValueChanged += (_, __) => { if (!_updatingVentSlotDefaults) _ventSlotWidthEditedByUser = true; };
            _summary = new Label { Dock = DockStyle.Fill, AutoSize = true, ForeColor = DrawingColor.Gainsboro, Text = "Параметры пока не проверены." };
            layout.Controls.Add(_summary, 0, 14); layout.SetColumnSpan(_summary, 2);
            var buttons = new FlowLayoutPanel { Dock = DockStyle.Fill, FlowDirection = FlowDirection.RightToLeft, AutoSize = true };
            _close = new Button { Text = "Закрыть", AutoSize = true };
            _refreshSelection = new Button { Text = "Обновить выбор ребра", AutoSize = true };
            _validate = new Button { Text = "Проверить", AutoSize = true };
            _build = new Button { Text = "Построить резьбу", AutoSize = true, BackColor = DrawingColor.FromArgb(226, 160, 48), ForeColor = DrawingColor.Black, FlatStyle = FlatStyle.Flat };
            _cancelBuild = new Button { Text = "Отменить построение", AutoSize = true, Enabled = false, FlatStyle = FlatStyle.Flat, BackColor = DrawingColor.FromArgb(226, 160, 48), ForeColor = DrawingColor.Black, UseVisualStyleBackColor = false };
            _cancelBuild.FlatAppearance.BorderColor = DrawingColor.FromArgb(245, 190, 85);
            _cancelBuild.FlatAppearance.BorderSize = 1;
            _close.Click += (_, __) => CloseDialog();
            _refreshSelection.Click += (_, __) => RefreshSelectionDescription();
            _validate.Click += (_, __) => ValidateParameters(false);
            _build.Click += (_, __) => ValidateParameters(true);
            _cancelBuild.Click += (_, __) => HandleBuildActionClick();
            _undoStateTimer = new Timer { Interval = 500 };
            _undoStateTimer.Tick += (_, __) => { if (!_buildInProgress && !IsDisposed) RefreshBuildActionState(); };
            Disposed += (_, __) => { try { _undoStateTimer.Stop(); _undoStateTimer.Dispose(); } catch { } };
            buttons.Controls.Add(_close); buttons.Controls.Add(_validate); buttons.Controls.Add(_build); buttons.Controls.Add(_cancelBuild); buttons.Controls.Add(_refreshSelection);
            layout.Controls.Add(buttons, 0, 15); layout.SetColumnSpan(buttons, 2);
            AcceptButton = _validate; CancelButton = _close;
            FormClosing += (_, e) =>
            {
                if (_buildInProgress)
                {
                    e.Cancel = true;
                    RequestBuildCancellation("Запрошено закрытие окна во время построения; сначала отменяется транзакция.");
                }
            };
            foreach (Control c in layout.Controls) if (c is Label l && l != _selection && l != _summary && l != ventSlotNote) l.ForeColor = DrawingColor.Gainsboro;
            RefreshSelectionDescription();
            RefreshBuildActionState();
            _undoStateTimer.Start();
        }

        private static NumericUpDown Number(decimal value, decimal min, decimal max, decimal increment, int places) => new NumericUpDown { Value = value, Minimum = min, Maximum = max, Increment = increment, DecimalPlaces = places, Dock = DockStyle.Fill, BackColor = DrawingColor.FromArgb(55,58,63), ForeColor = DrawingColor.White };
        private static void AddLabel(TableLayoutPanel p, string text, int row, int unused) => p.Controls.Add(new Label { Text = text, AutoSize = true, Anchor = AnchorStyles.Left, Padding = new Padding(0, 7, 4, 7) }, 0, row);
        private static void AddControl(TableLayoutPanel p, Control c, int row) => p.Controls.Add(c, 1, row);

        private void RefreshSelectionDescription()
        {
            _selection.Text = SelectionDescription();
            _selection.Refresh();
            bool internalThread;
            if (TryGetSelectedThreadType(out internalThread)) UpdateVentSlotDefaults(internalThread);
        }

        private bool TryGetSelectedThreadType(out bool internalThread)
        {
            internalThread = false;
            try
            {
                PartDocument doc = _app.ActiveDocument as PartDocument;
                if (doc == null || doc.SelectSet == null || doc.SelectSet.Count != 1) return false;
                Edge edge = doc.SelectSet[1] as Edge;
                Face face = FindCylindricalFace(edge);
                if (face == null) return false;
                internalThread = PackagingThreadGeometryPolicy.IsInternalFromFaceParamReversed(face.IsParamReversed);
                return true;
            }
            catch { return false; }
        }

        private void UpdateVentSlotDefaults(bool internalThread)
        {
            _updatingVentSlotDefaults = true;
            try
            {
                if (!_ventSlotCountEditedByUser) _ventSlotCount.Value = PackagingThreadVentSlotPolicy.GetDefaultCount(internalThread);
                if (!_ventSlotWidthEditedByUser) _ventSlotWidth.Value = (decimal)PackagingThreadVentSlotPolicy.GetDefaultWidthDegrees(internalThread);
            }
            finally { _updatingVentSlotDefaults = false; }
        }

        private string SelectionDescription()
        {
            try
            {
                PartDocument doc = _app.ActiveDocument as PartDocument;
                if (doc == null || doc.SelectSet == null || doc.SelectSet.Count != 1) return "Не выбрано одно круговое торцевое ребро. Выберите ребро в модели и нажмите «Обновить выбор ребра».";
                Edge edge = doc.SelectSet[1] as Edge;
                Face face = FindCylindricalFace(edge);
                if (face == null) return "У выбранного ребра не найдена смежная цилиндрическая грань.";
                dynamic cylinder = face.Geometry;
                double diameterMm = Convert.ToDouble(cylinder.Radius, CultureInfo.InvariantCulture) * 20.0;
                bool internalThread = PackagingThreadGeometryPolicy.IsInternalFromFaceParamReversed(face.IsParamReversed);
                string kind = internalThread ? "ВНУТРЕННЯЯ поверхность отверстия — будет положительный валик внутрь" : "НАРУЖНАЯ поверхность вала — будет выступ наружу";
                return "Автоопределение: " + kind + ". Диаметр ≈ " + diameterMm.ToString("0.###", CultureInfo.InvariantCulture) + " мм. Толщина стенки автоматически не подтверждена.";
            }
            catch { return "Не удалось проверить выбранное ребро. Выберите одно круговое ребро на цилиндрической поверхности."; }
        }

        private static Face FindCylindricalFace(Edge edge)
        {
            if (edge == null) return null;
            double edgeRadiusCm;
            try
            {
                dynamic curve = edge.Geometry;
                edgeRadiusCm = Convert.ToDouble(curve.Radius, CultureInfo.InvariantCulture);
            }
            catch { return null; }
            if (double.IsNaN(edgeRadiusCm) || double.IsInfinity(edgeRadiusCm) || edgeRadiusCm <= 0.0) return null;

            Face bestFace = null;
            double bestRadiusDifference = double.PositiveInfinity;
            try
            {
                foreach (Face candidate in edge.Faces)
                {
                    if (candidate == null || candidate.SurfaceType != SurfaceTypeEnum.kCylinderSurface) continue;
                    Cylinder candidateCylinder = candidate.Geometry as Cylinder;
                    if (candidateCylinder == null) continue;
                    double difference = Math.Abs(candidateCylinder.Radius - edgeRadiusCm);
                    if (difference < bestRadiusDifference)
                    {
                        bestRadiusDifference = difference;
                        bestFace = candidate;
                    }
                }
            }
            catch { return null; }

            double toleranceCm = Math.Max(0.001, edgeRadiusCm * 1e-5); // 0.01 mm minimum tolerance
            return bestFace != null && bestRadiusDifference <= toleranceCm ? bestFace : null;
        }

        private void ValidateParameters(bool buildGeometry)
        {
            double diameterMm;
            bool internalThread = false;
            string diagnosticStage = "resolve-selection";
            string diagnosticContext = "document=" + PackagingThreadDiagnostics.CleanDocumentName(_app);
            try
            {
                PartDocument doc = _app.ActiveDocument as PartDocument;
                Edge edge = doc?.SelectSet.Count == 1 ? doc.SelectSet[1] as Edge : null;
                Face face = FindCylindricalFace(edge);
                if (edge == null || face == null) throw new InvalidOperationException("Сначала выберите одно круговое торцевое ребро в модели и нажмите «Обновить выбор ребра».");
                internalThread = PackagingThreadGeometryPolicy.IsInternalFromFaceParamReversed(face.IsParamReversed);
                UpdateVentSlotDefaults(internalThread);
                dynamic cylinder = face.Geometry;
                diameterMm = Convert.ToDouble(cylinder.Radius, CultureInfo.InvariantCulture) * 20.0;
            }
            catch (Exception ex)
            {
                string logPath = PackagingThreadDiagnostics.WriteException(diagnosticStage, diagnosticContext, ex);
                string report = PackagingThreadDiagnostics.BuildErrorReport(diagnosticStage, diagnosticContext, ex, logPath);
                _summary.Text = "Не удалось получить выбранное ребро. Подробности записаны в лог.";
                PackagingThreadDiagnostics.ShowErrorDialog(this, Text, report, logPath);
                return;
            }
            PackagingThreadGeometryPolicy.ResolvedParameters p; string error;
            if (!PackagingThreadGeometryPolicy.TryResolve(diameterMm, (double)_pitch.Value, (int)_starts.Value, (double)_ratio.Value, (double)_clearance.Value, (double)_wall.Value, internalThread, out p, out error))
            {
                diagnosticStage = "validate-policy";
                diagnosticContext = string.Format(CultureInfo.InvariantCulture,
                    "document={0}; D={1:0.###} mm; P={2:0.###} mm; starts={3}; height/diameter={4:0.###}; clearance={5:0.###} mm; wall={6:0.###} mm; kind={7}",
                    PackagingThreadDiagnostics.CleanDocumentName(_app), diameterMm, (double)_pitch.Value, (int)_starts.Value,
                    (double)_ratio.Value, (double)_clearance.Value, (double)_wall.Value, internalThread ? "internal-positive-rib (auto)" : "external (auto)");
                PackagingThreadDiagnostics.WriteEvent(diagnosticStage, diagnosticContext, "Rejected by policy: " + error);
                _summary.Text = "Проверка не пройдена: " + error;
                return;
            }
            double value = (double)_length.Value;
            double axialLength = _extent.SelectedIndex == 0 ? value : value * p.LeadMm;
            diagnosticContext = string.Format(CultureInfo.InvariantCulture,
                "document={0}; D={1:0.###} mm; P={2:0.###} mm; starts={3}; lead={4:0.###} mm; ratio={5:0.###}; H={6:0.###} mm; embed={7:0.###} mm; clearance={8:0.###} mm; wall={9:0.###} mm; axialLength={10:0.###} mm; RH={11}; extentMode={12}; type={13}",
                PackagingThreadDiagnostics.CleanDocumentName(_app), p.DiameterMm, p.PitchMm, p.Starts, p.LeadMm,
                (double)_ratio.Value, p.HeightMm, p.EmbedMm, p.ClearanceMm, (double)_wall.Value, axialLength,
                _hand.SelectedIndex == 0, _extent.SelectedIndex == 0 ? "length" : "turns", internalThread ? "internal-positive-rib (auto)" : "external (auto)") +
                string.Format(CultureInfo.InvariantCulture, "; ventSlots={0}; ventSlotCount={1}; ventSlotWidthDeg={2:0.###}",
                    _ventSlots.Checked, (int)_ventSlotCount.Value, (double)_ventSlotWidth.Value);
            if (axialLength <= 0 || axialLength > 1000)
            {
                _summary.Text = "Длина по оси должна быть больше 0 и не превышать 1000 мм.";
                PackagingThreadDiagnostics.WriteEvent("validate-length", diagnosticContext, "Rejected: axial length outside (0, 1000] mm.");
                return;
            }
            PackagingThreadVentSlotPolicy.Plan ventSlotPlan;
            string ventSlotError;
            if (!PackagingThreadVentSlotPolicy.TryResolve(_ventSlots.Checked, internalThread,
                (int)_ventSlotCount.Value, (double)_ventSlotWidth.Value, out ventSlotPlan, out ventSlotError))
            {
                _summary.Text = "Проверка пропилов не пройдена: " + ventSlotError;
                PackagingThreadDiagnostics.WriteEvent("validate-vent-slots", diagnosticContext, "Rejected: " + ventSlotError);
                return;
            }
            if (!buildGeometry)
            {
                PackagingThreadDiagnostics.WriteEvent("validate-success", diagnosticContext, "Parameter policy accepted; geometry not requested.");
                _summary.Text = string.Format(CultureInfo.InvariantCulture,
                    "Проверка параметров пройдена. D={0:0.###} мм; P={1:0.###} мм; заходов={2}; ход={3:0.###} мм; H={4:0.###} мм; длина={5:0.###} мм; зазор печати={6:0.###} мм (не меняет номинальный профиль).",
                    p.DiameterMm, p.PitchMm, p.Starts, p.LeadMm, p.HeightMm, axialLength, p.ClearanceMm);
                return;
            }
            diagnosticStage = "builder-call";
            PackagingThreadDiagnostics.WriteEvent(diagnosticStage, diagnosticContext,
                "Starting additive packaging-thread builder; internal=" + internalThread + " (auto-detected from selected cylindrical face IsParamReversed); " +
                "; smoothStart=" + _smoothStart.Checked + "; smoothEnd=" + _smoothEnd.Checked +
                "; ventSlots=" + ventSlotPlan.Enabled + "; ventSlotCount=" + ventSlotPlan.SlotCount +
                "; ventSlotWidthDeg=" + ventSlotPlan.WidthDegrees.ToString("0.###", CultureInfo.InvariantCulture) + ".");
            if (_buildInProgress) return;
            _buildInProgress = true;
            _cancelRequested = false;
            SetBuildInProgressUi(true);
            try
            {
                _summary.Text = internalThread ? "Строю внутренний положительный валик и сбеги…" : "Строю наружную аддитивную резьбу и сбеги…";
                FormsApplication.DoEvents();
                if (_cancelRequested) throw new OperationCanceledException("Построение отменено до первого геометрического шага.");
                PartDocument buildDocument = _app.ActiveDocument as PartDocument;
                if (buildDocument == null) throw new InvalidOperationException("Активный документ перестал быть деталью перед построением.");
                Edge selectedEdge = buildDocument.SelectSet[1] as Edge;
                string result = PackagingThreadGeometryBuilder.Build(_app, selectedEdge, p, axialLength, _hand.SelectedIndex == 0,
                    internalThread, _smoothStart.Checked, _smoothEnd.Checked,
                    ventSlotPlan.Enabled, ventSlotPlan.SlotCount, ventSlotPlan.WidthDegrees,
                    () => PumpMessagesAndCheckCancellation());
                _lastPackagingBuildDocument = buildDocument;
                _lastPackagingBuildTransactionName = PackagingThreadGeometryBuilder.LastCommittedTransactionName;
                _summary.Text = result + "\r\nПосле построения можно нажать «Отменить последнее построение», если это всё ещё последнее действие в этой детали.";
                PackagingThreadDiagnostics.WriteEvent("build-success", diagnosticContext, result + " Post-build modal message suppressed so it cannot block the cancel UI state.");
            }
            catch (OperationCanceledException ex)
            {
                PackagingThreadDiagnostics.WriteEvent("build-cancelled-ui", diagnosticContext,
                    "Операция отменена пользователем. " + ex.Message);
                _summary.Text = "Построение отменено. Изменения отменены транзакцией; окно остаётся открытым.";
            }
            catch (Exception ex)
            {
                string logPath = PackagingThreadDiagnostics.WriteException(diagnosticStage, diagnosticContext, ex);
                string report = PackagingThreadDiagnostics.BuildErrorReport(diagnosticStage, diagnosticContext, ex, logPath);
                _summary.Text = "Построение не выполнено; подробности записаны в лог.";
                PackagingThreadDiagnostics.ShowErrorDialog(this, Text, report, logPath);
            }
            finally
            {
                _buildInProgress = false;
                _cancelRequested = false;
                SetBuildInProgressUi(false);
                RefreshSelectionDescription();
            }
        }

        private void HandleBuildActionClick()
        {
            if (_buildInProgress)
            {
                RequestBuildCancellation("Отмена запрошена пользователем.");
                return;
            }
            UndoLastPackagingBuild();
        }

        private void RefreshBuildActionState()
        {
            if (_buildInProgress)
            {
                _cancelBuild.Text = _cancelRequested ? "Отмена запрошена…" : "Отменить построение";
                _cancelBuild.Enabled = true;
                _cancelBuild.BackColor = DrawingColor.FromArgb(226, 160, 48);
                _cancelBuild.ForeColor = DrawingColor.Black;
                CancelButton = _cancelBuild;
                return;
            }

            bool hasCandidate = !string.IsNullOrWhiteSpace(_lastPackagingBuildTransactionName) && _lastPackagingBuildDocument != null;
            bool canUndo = hasCandidate && PackagingThreadGeometryBuilder.CanUndoLastBuild(
                _app, _lastPackagingBuildDocument, _lastPackagingBuildTransactionName);
            _cancelBuild.Text = hasCandidate ? "Отменить последнее построение" : "Отменить построение";
            _cancelBuild.Enabled = canUndo;
            _cancelBuild.BackColor = canUndo ? DrawingColor.FromArgb(226, 160, 48) : DrawingColor.FromArgb(55, 58, 63);
            _cancelBuild.ForeColor = canUndo ? DrawingColor.Black : DrawingColor.Gainsboro;
            _cancelBuild.UseVisualStyleBackColor = false;
            CancelButton = _close;
        }

        private void UndoLastPackagingBuild()
        {
            if (_buildInProgress) return;
            if (!PackagingThreadGeometryBuilder.CanUndoLastBuild(_app, _lastPackagingBuildDocument, _lastPackagingBuildTransactionName))
            {
                RefreshBuildActionState();
                _summary.Text = "Отмена недоступна: построение уже не является последним действием в активной детали. Чтобы не отменить чужую операцию, запрос отклонён.";
                PackagingThreadDiagnostics.WriteEvent("packaging-build-undo-refused", PackagingThreadDiagnostics.CleanDocumentName(_app),
                    "Undo refused because the exact packaging transaction was not the newest committed transaction in the active build document.");
                return;
            }

            try
            {
                string transactionName = _lastPackagingBuildTransactionName;
                PackagingThreadGeometryBuilder.UndoLastBuild(_app, _lastPackagingBuildDocument, transactionName);
                _lastPackagingBuildDocument = null;
                _lastPackagingBuildTransactionName = null;
                _summary.Text = "Последнее построение упаковочной резьбы отменено. Предыдущие действия модели не затронуты.";
                RefreshBuildActionState();
                RefreshSelectionDescription();
            }
            catch (Exception ex)
            {
                string logPath = PackagingThreadDiagnostics.WriteException("packaging-build-undo", PackagingThreadDiagnostics.CleanDocumentName(_app), ex);
                _summary.Text = "Не удалось отменить последнее построение. Подробности записаны в диагностический журнал.";
                PackagingThreadDiagnostics.ShowErrorDialog(this, Text,
                    PackagingThreadDiagnostics.BuildErrorReport("packaging-build-undo", PackagingThreadDiagnostics.CleanDocumentName(_app), ex, logPath), logPath);
                RefreshBuildActionState();
            }
        }

        private void CloseDialog()
        {
            if (_buildInProgress)
            {
                RequestBuildCancellation("Кнопка закрытия нажата во время построения; сначала будет выполнен безопасный откат транзакции.");
                return;
            }

            PackagingThreadDiagnostics.WriteEvent("dialog-close-request", PackagingThreadDiagnostics.CleanDocumentName(_app),
                "Close button clicked while idle; closing modeless packaging-thread dialog.");
            try
            {
                Close();
                // This is a modeless form owned by Inventor. If another handler cancels Close,
                // do not leave a visible window with an unresponsive Close button.
                if (!IsDisposed)
                {
                    Hide();
                    Dispose();
                }
            }
            catch (Exception ex)
            {
                try { PackagingThreadDiagnostics.WriteException("dialog-close", PackagingThreadDiagnostics.CleanDocumentName(_app), ex); } catch { }
                try { Hide(); } catch { }
                try { Dispose(); } catch { }
            }
        }

        private void RequestBuildCancellation(string reason)
        {
            if (!_buildInProgress || _cancelRequested) return;
            _cancelRequested = true;
            _cancelBuild.Text = "Отмена запрошена…";
            _cancelBuild.Enabled = true;
            _cancelBuild.BackColor = DrawingColor.FromArgb(245, 190, 85);
            _cancelBuild.Refresh();
            _summary.Text = "Отмена запрошена. Жду завершения текущей операции Inventor, затем откатываю всю транзакцию…";
            _summary.Refresh();
            PackagingThreadDiagnostics.WriteEvent("build-cancel-button", PackagingThreadDiagnostics.CleanDocumentName(_app), reason);
        }

        private bool PumpMessagesAndCheckCancellation()
        {
            // The geometry builder calls this only between Inventor API operations. This permits
            // the Cancel button's click handler to run without re-entering an in-flight COM call.
            if (!IsDisposed && IsHandleCreated) FormsApplication.DoEvents();
            return _cancelRequested;
        }

        private void SetBuildInProgressUi(bool busy)
        {
            _pitch.Enabled = !busy;
            _starts.Enabled = !busy;
            _ratio.Enabled = !busy;
            _length.Enabled = !busy;
            _extent.Enabled = !busy;
            _clearance.Enabled = !busy;
            _wall.Enabled = !busy;
            _hand.Enabled = !busy;
            _smoothStart.Enabled = !busy;
            _smoothEnd.Enabled = !busy;
            _ventSlots.Enabled = !busy;
            _ventSlotCount.Enabled = !busy && _ventSlots.Checked;
            _ventSlotWidth.Enabled = !busy && _ventSlots.Checked;
            _close.Enabled = !busy;
            _refreshSelection.Enabled = !busy;
            _validate.Enabled = !busy;
            _build.Enabled = !busy;
            RefreshBuildActionState();
            _cancelBuild.Refresh();
        }
    }
}
