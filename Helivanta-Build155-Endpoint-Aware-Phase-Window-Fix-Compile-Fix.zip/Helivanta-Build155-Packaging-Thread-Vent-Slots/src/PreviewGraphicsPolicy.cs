﻿namespace ThreadPro
{
    /// <summary>
    /// Rendering policy for temporary preview graphics. Use BurnThrough instead of changing
    /// SurfaceBody.Visible: source-body visibility changes create persistent Inventor
    /// Show/Hide transactions, whereas these preview primitives live in non-transacting graphics.
    /// </summary>
    internal static class PreviewGraphicsPolicy
    {
        internal static bool BurnThroughModel { get { return true; } }
        internal static bool ChangesSourceBodyVisibility { get { return false; } }
        internal static int DepthPriority { get { return 10; } }
    }
}
