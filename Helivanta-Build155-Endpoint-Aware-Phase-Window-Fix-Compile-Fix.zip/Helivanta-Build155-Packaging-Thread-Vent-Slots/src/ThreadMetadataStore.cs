﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Text.Json;
using Inventor;

namespace ThreadPro
{
    /// <summary>
    /// Persists the data needed to identify and reload one logical thread build.
    /// AttributeSets are attached to every created WorkPlane, Sketch and feature;
    /// the visible/model geometry algorithms are deliberately not modified here.
    /// </summary>
    internal sealed class ThreadMetadataGroup
    {
        internal ThreadMetadataRecord Record;
        internal List<object> MembersByIndex;
    }

    internal static class ThreadMetadataStore
    {
        internal const string AttributeSetName = "HelivantaThreadMeta";
        private const string ThreadIdAttribute = "ThreadId";
        private const string RecordJsonAttribute = "RecordJson";
        private const string ObjectIndexAttribute = "ObjectIndex";
        private const string ObjectCountAttribute = "ObjectCount";
        private static readonly JsonSerializerOptions JsonOptions = new JsonSerializerOptions
        {
            PropertyNameCaseInsensitive = true
        };

        internal static bool TryAttach(IList<object> created, ThreadParams parameters, ThreadTarget target,
                                       out string threadId, out string error, string threadIdOverride = null)
        {
            threadId = null;
            error = null;
            if (created == null || created.Count == 0 || parameters == null || target == null)
            {
                error = "Нет полного набора объектов или параметров для записи метаданных.";
                return false;
            }

            var nonNullObjects = new List<object>(created.Count);
            foreach (object obj in created)
                if (obj != null) nonNullObjects.Add(obj);
            if (nonNullObjects.Count == 0)
            {
                error = "Список созданных объектов пуст.";
                return false;
            }

            var record = new ThreadMetadataRecord
            {
                SchemaVersion = 1,
                ThreadId = string.IsNullOrWhiteSpace(threadIdOverride) ? Guid.NewGuid().ToString("N") : threadIdOverride,
                ProducerVersion = GetProducerVersion(),
                ObjectCount = nonNullObjects.Count,
                Parameters = new ThreadParametersSnapshot
                {
                    Standard = (int)parameters.Standard,
                    SizeName = parameters.SizeName ?? string.Empty,
                    PitchMm = parameters.PitchMm,
                    NominalDiaMm = parameters.NominalDiaMm,
                    Starts = parameters.Starts,
                    ClearanceMm = parameters.ClearanceMm,
                    External = parameters.External,
                    Round = parameters.Round,
                    Smooth = parameters.Smooth,
                    SimplifiedRunout = parameters.SimplifiedRunout,
                    RunSteps = parameters.RunSteps,
                    Mirror = parameters.Mirror,
                    SortThreadsIntoFolders = parameters.SortThreadsIntoFolders,
                    FullLength = parameters.FullLength,
                    LengthMm = parameters.LengthMm,
                    OffsetMm = parameters.OffsetMm,
                    RunOut = parameters.RunOut,
                    RightHand = parameters.RightHand,
                    ChamferMode = parameters.ChamferMode,
                    ChamferMm = parameters.ChamferMm,
                    ToleranceClass = parameters.ToleranceClass ?? string.Empty,
                    Tapered = parameters.Tapered,
                    TaperGeometryMode = (int)parameters.TaperGeometryMode,
                    TaperStandard = parameters.TaperStandard ?? string.Empty,
                    TaperDesignation = parameters.TaperDesignation ?? string.Empty,
                    TaperDisplayDesignation = string.IsNullOrWhiteSpace(parameters.TaperDisplayDesignation)
                        ? (parameters.TaperDesignation ?? string.Empty) : parameters.TaperDisplayDesignation,
                    TaperRatio = parameters.TaperRatio,
                    TaperReferenceDiameterMm = parameters.TaperReferenceDiameterMm,
                    TaperReferenceLengthMm = parameters.TaperReferenceLengthMm,
                    TaperStartDiameterMm = parameters.TaperStartDiameterMm,
                    TaperEndDiameterMm = parameters.TaperEndDiameterMm,
                    TaperThreadDepthMm = parameters.TaperThreadDepthMm
                },
                Target = new ThreadTargetSnapshot
                {
                    Center = CopyVector(target.Center),
                    Axis = CopyVector(target.U),
                    RadiusCm = target.RadiusCm,
                    LengthCm = target.LengthCm,
                    IsExternal = target.IsExternal,
                    BodyName = target.BodyName ?? string.Empty,
                    StartIsShoulder = target.StartIsShoulder,
                    EndIsShoulder = target.EndIsShoulder
                }
            };

            if (!record.IsValid())
            {
                error = "Снимок параметров не прошёл проверку целостности; метаданные не записаны.";
                return false;
            }

            string json;
            try { json = JsonSerializer.Serialize(record); }
            catch (Exception ex)
            {
                error = "Не удалось сериализовать параметры резьбы: " + ex.Message;
                return false;
            }

            var taggedObjects = new List<object>();
            try
            {
                for (int i = 0; i < nonNullObjects.Count; i++)
                {
                    object owner = nonNullObjects[i];
                    AttributeSets sets = GetAttributeSets(owner);
                    if (sets == null)
                        throw new InvalidOperationException("Один из объектов Inventor не поддерживает AttributeSets.");
                    if (sets.NameIsUsed[AttributeSetName])
                        throw new InvalidOperationException("На новом объекте уже существует набор метаданных Helivanta.");

                    AttributeSet set = sets.Add(AttributeSetName, false);
                    taggedObjects.Add(owner);
                    set.Add(ThreadIdAttribute, ValueTypeEnum.kStringType, record.ThreadId);
                    set.Add(RecordJsonAttribute, ValueTypeEnum.kStringType, json);
                    set.Add(ObjectIndexAttribute, ValueTypeEnum.kIntegerType, i);
                    set.Add(ObjectCountAttribute, ValueTypeEnum.kIntegerType, nonNullObjects.Count);
                }

                threadId = record.ThreadId;
                return true;
            }
            catch (Exception ex)
            {
                // Metadata is optional in this first Preview 14 checkpoint. Do not jeopardize
                // a successfully generated thread just because an Inventor object refused a tag.
                // Remove all partial tags so a later editor cannot mistake a partial group for a
                // complete/editable one.
                for (int i = taggedObjects.Count - 1; i >= 0; i--)
                    TryRemoveSet(taggedObjects[i]);

                error = ex.Message;
                return false;
            }
        }

        private static bool TryReadMember(object owner, out ThreadMetadataRecord record,
                                          out int objectIndex, out int objectCount, out string rawJson)
        {
            record = null;
            objectIndex = -1;
            objectCount = 0;
            rawJson = null;
            if (owner == null) return false;
            try
            {
                AttributeSets sets = GetAttributeSets(owner);
                if (sets == null || !sets.NameIsUsed[AttributeSetName]) return false;

                AttributeSet set = sets[AttributeSetName];
                if (set == null || !set.NameIsUsed[RecordJsonAttribute] || !set.NameIsUsed[ThreadIdAttribute] ||
                    !set.NameIsUsed[ObjectIndexAttribute] || !set.NameIsUsed[ObjectCountAttribute])
                    return false;

                string threadId = Convert.ToString(set[ThreadIdAttribute].Value);
                string json = Convert.ToString(set[RecordJsonAttribute].Value);
                int index = Convert.ToInt32(set[ObjectIndexAttribute].Value);
                int count = Convert.ToInt32(set[ObjectCountAttribute].Value);
                // A realistic Helivanta thread group is far smaller; cap untrusted/corrupt
                // metadata before allocating arrays indexed by ObjectCount.
                const int MaxThreadGroupObjects = 100000;
                if (string.IsNullOrWhiteSpace(json) || count < 1 || count > MaxThreadGroupObjects) return false;

                ThreadMetadataRecord parsed = JsonSerializer.Deserialize<ThreadMetadataRecord>(json, JsonOptions);
                if (parsed == null || !parsed.IsValid() || parsed.ObjectCount > MaxThreadGroupObjects || count != parsed.ObjectCount ||
                    index < 0 || index >= count ||
                    !string.Equals(parsed.ThreadId, threadId, StringComparison.Ordinal))
                    return false;

                record = parsed;
                objectIndex = index;
                objectCount = count;
                rawJson = json;
                return true;
            }
            catch
            {
                return false;
            }
        }

        /// <summary>Loads and validates every member of a logical thread group in saved creation order.</summary>
        internal static bool TryLoadGroup(PartDocument doc, string threadId,
                                          out ThreadMetadataGroup group, out string error)
        {
            group = null;
            error = null;
            if (doc == null || string.IsNullOrWhiteSpace(threadId))
            {
                error = "Не задан документ детали или идентификатор резьбы.";
                return false;
            }

            try
            {
                ObjectCollection found = doc.AttributeManager.FindObjects(AttributeSetName, ThreadIdAttribute, threadId);
                if (found == null || found.Count == 0)
                {
                    error = "В документе не найдены объекты выбранной резьбы. Возможно, геометрия уже изменена или метаданные удалены.";
                    return false;
                }

                ThreadMetadataRecord referenceRecord = null;
                string referenceJson = null;
                List<object> members = null;
                bool[] indexes = null;
                foreach (object owner in found)
                {
                    ThreadMetadataRecord record;
                    int index, count;
                    string json;
                    if (!TryReadMember(owner, out record, out index, out count, out json))
                    {
                        error = "В группе резьбы обнаружен объект с повреждёнными или неполными метаданными.";
                        return false;
                    }
                    if (!string.Equals(record.ThreadId, threadId, StringComparison.Ordinal))
                    {
                        error = "Идентификатор одного из объектов не совпадает с выбранной резьбой.";
                        return false;
                    }
                    if (referenceRecord == null)
                    {
                        referenceRecord = record;
                        referenceJson = json;
                        members = new List<object>(new object[count]);
                        indexes = new bool[count];
                    }
                    else if (count != members.Count || !string.Equals(referenceJson, json, StringComparison.Ordinal))
                    {
                        error = "Метаданные группы расходятся между объектами резьбы; безопасное редактирование отменено.";
                        return false;
                    }

                    if (index < 0 || index >= members.Count || indexes[index])
                    {
                        error = "В группе резьбы есть повторяющийся или недопустимый индекс объекта.";
                        return false;
                    }
                    indexes[index] = true;
                    members[index] = owner;
                }

                if (referenceRecord == null || members == null || members.Count != referenceRecord.ObjectCount ||
                    found.Count != referenceRecord.ObjectCount)
                {
                    error = "Группа резьбы неполна: фактическое число объектов не совпадает с сохранённым.";
                    return false;
                }
                for (int i = 0; i < indexes.Length; i++)
                {
                    if (!indexes[i] || members[i] == null)
                    {
                        error = "Группа резьбы неполна: отсутствует объект с индексом " + i + ".";
                        return false;
                    }
                }

                group = new ThreadMetadataGroup { Record = referenceRecord, MembersByIndex = members };
                return true;
            }
            catch (Exception ex)
            {
                error = "Inventor не смог прочитать группу резьбы: " + ex.Message;
                return false;
            }
        }

        /// <summary>Loads all complete metadata groups in this part; any corrupt tagged group blocks replacement.</summary>
        internal static bool TryLoadAllGroups(PartDocument doc, out List<ThreadMetadataGroup> groups, out string error)
        {
            groups = new List<ThreadMetadataGroup>();
            error = null;
            if (doc == null)
            {
                error = "Не открыт документ детали.";
                return false;
            }

            try
            {
                ObjectCollection owners = doc.AttributeManager.FindObjects(AttributeSetName, ThreadIdAttribute, null);
                var seen = new HashSet<string>(StringComparer.Ordinal);
                if (owners == null) return true;
                foreach (object owner in owners)
                {
                    string id;
                    if (!TryGetThreadId(owner, out id) || string.IsNullOrWhiteSpace(id))
                    {
                        error = "Обнаружен объект Helivanta с пустым идентификатором группы. Сначала проверьте метаданные детали.";
                        return false;
                    }
                    if (!seen.Add(id)) continue;
                    ThreadMetadataGroup group;
                    string groupError;
                    if (!TryLoadGroup(doc, id, out group, out groupError))
                    {
                        error = "Не удалось проверить группу " + id + ": " + groupError;
                        return false;
                    }
                    groups.Add(group);
                }
                return true;
            }
            catch (Exception ex)
            {
                error = "Не удалось перечислить группы Helivanta в документе: " + ex.Message;
                return false;
            }
        }

        /// <summary>
        /// Resolves either an individual tagged feature or a selected Helivanta browser folder.
        /// A folder is accepted only when its descendant nodes resolve to exactly one ThreadId.
        /// </summary>
        internal static bool TryGetThreadIdFromSelection(PartDocument doc, object selected, out string threadId, out string error)
        {
            threadId = null;
            error = null;
            if (TryGetThreadId(selected, out threadId)) return true;

            BrowserNode node = ResolveBrowserNode(doc, selected);
            var ids = new List<string>();
            if (node != null) CollectThreadIdsFromBrowserNode(node, ids, 0);

            // Some Inventor builds expose a selected part-feature folder through SelectSet
            // differently from the BrowserNode. If that path yielded no ID, inspect the node
            // that is visibly selected in the model browser.
            if (ids.Count == 0)
            {
                BrowserNode selectedNode;
                string selectedNodeError;
                if (TryGetSingleSelectedBrowserNode(doc, out selectedNode, out selectedNodeError))
                    CollectThreadIdsFromBrowserNode(selectedNode, ids, 0);
            }

            if (ThreadEditSafetyPolicy.TryChooseSingleThreadId(ids, out threadId)) return true;
            error = ids.Distinct(StringComparer.Ordinal).Count(id => !string.IsNullOrWhiteSpace(id)) > 1
                ? "Выбранная папка содержит объекты более чем одной резьбы Helivanta. Выберите одну папку резьбы целиком."
                : "У выбранного объекта нет метаданных Helivanta. Выберите папку «Резьба — …» целиком либо отдельный объект внутри папки резьбы.";
            threadId = null;
            return false;
        }

        internal static bool TryGetSingleSelectedBrowserNode(PartDocument doc, out BrowserNode selectedNode, out string error)
        {
            selectedNode = null;
            error = null;
            if (doc == null) { error = "Не открыт документ детали."; return false; }
            try
            {
                BrowserPane pane = FindTreeBrowserPane(doc);
                if (pane == null || pane.TopNode == null)
                {
                    error = "Не удалось получить дерево модели Inventor.";
                    return false;
                }
                var selected = new List<BrowserNode>();
                CollectSelectedBrowserNodes(pane.TopNode, selected, 0);
                if (selected.Count != 1)
                {
                    error = selected.Count == 0
                        ? "В дереве модели не выбрана папка резьбы."
                        : "Выберите только одну папку резьбы.";
                    return false;
                }
                selectedNode = selected[0];
                return true;
            }
            catch (Exception ex)
            {
                error = "Не удалось прочитать выделение в дереве модели: " + ex.Message;
                return false;
            }
        }

        private static BrowserNode ResolveBrowserNode(PartDocument doc, object selected)
        {
            if (selected == null) return null;
            try { if (selected is BrowserNode node) return node; } catch { }
            try { if (selected is BrowserFolder folder) return folder.BrowserNode; } catch { }
            try
            {
                dynamic dynamicSelected = selected;
                object browserNode = dynamicSelected.BrowserNode;
                if (browserNode is BrowserNode node) return node;
            }
            catch { }
            try
            {
                BrowserPane pane = FindTreeBrowserPane(doc);
                if (pane != null) return pane.GetBrowserNodeFromObject(selected);
            }
            catch { }
            return null;
        }

        private static BrowserPane FindTreeBrowserPane(PartDocument doc)
        {
            if (doc == null) return null;
            try
            {
                BrowserPane active = doc.BrowserPanes.ActivePane;
                if (active != null && active.TreeBrowser) return active;
            }
            catch { }
            try
            {
                foreach (BrowserPane pane in doc.BrowserPanes)
                    if (pane != null && pane.TreeBrowser) return pane;
            }
            catch { }
            return null;
        }

        private static void CollectThreadIdsFromBrowserNode(BrowserNode node, List<string> ids, int depth)
        {
            if (node == null || ids == null || depth > 64 || ids.Count > 512) return;
            try
            {
                object native = node.NativeObject;
                string id;
                if (TryGetThreadId(native, out id)) ids.Add(id);
            }
            catch { }
            try
            {
                foreach (BrowserNode child in node.BrowserNodes)
                    CollectThreadIdsFromBrowserNode(child, ids, depth + 1);
            }
            catch { }
        }

        private static void CollectSelectedBrowserNodes(BrowserNode node, List<BrowserNode> selected, int depth)
        {
            if (node == null || selected == null || depth > 64 || selected.Count > 64) return;
            try { if (node.Selected) selected.Add(node); } catch { }
            try
            {
                foreach (BrowserNode child in node.BrowserNodes)
                    CollectSelectedBrowserNodes(child, selected, depth + 1);
            }
            catch { }
        }

        internal static bool TryGetThreadId(object owner, out string threadId)
        {
            threadId = null;
            if (owner == null) return false;
            try
            {
                AttributeSets sets = GetAttributeSets(owner);
                if (sets == null || !sets.NameIsUsed[AttributeSetName]) return false;
                AttributeSet set = sets[AttributeSetName];
                if (set == null || !set.NameIsUsed[ThreadIdAttribute]) return false;
                threadId = Convert.ToString(set[ThreadIdAttribute].Value);
                return !string.IsNullOrWhiteSpace(threadId);
            }
            catch { return false; }
        }

        private static AttributeSets GetAttributeSets(object owner)
        {
            // Generated object types vary (WorkPlane, PlanarSketch, CoilFeature, LoftFeature, etc.).
            // Autodesk exposes AttributeSets on each of these concrete objects. Resolve it through
            // late binding so this helper can handle the whole heterogeneous creation list.
            return (AttributeSets)((dynamic)owner).AttributeSets;
        }

        private static void TryRemoveSet(object owner)
        {
            try
            {
                AttributeSets sets = GetAttributeSets(owner);
                if (sets == null || !sets.NameIsUsed[AttributeSetName]) return;
                AttributeSet set = sets[AttributeSetName];
                if (set != null) set.Delete();
            }
            catch { }
        }

        private static double[] CopyVector(double[] vector)
        {
            if (vector == null || vector.Length < 3) return null;
            return new[] { vector[0], vector[1], vector[2] };
        }

        private static string GetProducerVersion()
        {
            try
            {
                Assembly assembly = typeof(ThreadMetadataStore).Assembly;
                AssemblyInformationalVersionAttribute info =
                    (AssemblyInformationalVersionAttribute)System.Attribute.GetCustomAttribute(
                        assembly, typeof(AssemblyInformationalVersionAttribute));
                if (info != null && !string.IsNullOrWhiteSpace(info.InformationalVersion))
                    return info.InformationalVersion;
                Version version = assembly.GetName().Version;
                return version == null ? "unknown" : version.ToString();
            }
            catch { return "unknown"; }
        }
    }
}
