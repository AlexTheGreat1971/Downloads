﻿using System;

namespace ThreadPro
{
    /// <summary>
    /// Validates ISO thread tolerance designations independently from B-Rep generation.
    /// This policy does not calculate ISO 965 limit dimensions and must not be interpreted
    /// as applying dimensional tolerance offsets to the generated thread geometry.
    /// </summary>
    public static class ThreadTolerancePolicy
    {
        public static bool TryNormalize(ThreadStandard standard, bool external, string designation, out string normalized)
        {
            normalized = string.Empty;
            if (string.IsNullOrWhiteSpace(designation)) return true;
            if (standard != ThreadStandard.ISO) return false;

            string candidate = designation.Trim();
            if (external && string.Equals(candidate, "6g", StringComparison.Ordinal))
            {
                normalized = "6g";
                return true;
            }
            if (!external && string.Equals(candidate, "6H", StringComparison.Ordinal))
            {
                normalized = "6H";
                return true;
            }
            return false;
        }

        public static string GetDescription(string designation)
        {
            if (string.Equals(designation, "6H", StringComparison.Ordinal))
                return "ISO 6H — класс обозначения внутренней резьбы";
            if (string.Equals(designation, "6g", StringComparison.Ordinal))
                return "ISO 6g — класс обозначения наружной резьбы";
            return "Класс допуска не задан";
        }

        public const string GeometryNotice = "Обозначение класса сохраняется в параметрах; расчёт предельных размеров ISO 965 и смещение геометрии по допуску пока не применяются.";
    }
}
