﻿using System;
using System.Drawing;
using System.Reflection;
using System.Windows.Forms;

namespace ThreadPro
{
    /// <summary>
    /// Branded confirmation shown before replacing a native cosmetic ThreadFeature when real
    /// downstream features exist. The safe/default result is No.
    /// </summary>
    internal sealed class NativeConversionWarningDialog : Form
    {
        private static Color Surface => HelivantaUiTheme.ModalSurface;
        private static Color Border => HelivantaUiTheme.ModalBorder;
        private static Color TextColor => HelivantaUiTheme.Text;
        private static Color Muted => HelivantaUiTheme.Muted;
        private static Color Accent => HelivantaUiTheme.Accent;
        private static Color Warning => HelivantaUiTheme.ModalHeader;
        private static Color HeaderText => HelivantaUiTheme.ModalHeaderText;
        private static Color ButtonSurface => HelivantaUiTheme.ModalPanel;

        private readonly PictureBox _wordmark;

        internal NativeConversionWarningDialog(IntPtr ownerHandle, int downstreamCount)
        {
            AutoScaleMode = AutoScaleMode.Dpi;
            Load += (sender, args) => HelivantaLocalization.Apply(this);
            Text = "Helivanta — подтверждение преобразования";
            FormBorderStyle = FormBorderStyle.None;
            StartPosition = FormStartPosition.Manual;
            ShowInTaskbar = false;
            ShowIcon = false;
            ControlBox = false;
            MinimizeBox = false;
            MaximizeBox = false;
            TopMost = false;
            KeyPreview = true;
            ClientSize = new Size(640, 320);
            BackColor = Surface;
            ForeColor = TextColor;
            Font = new Font("Segoe UI", 9f, FontStyle.Regular, GraphicsUnit.Point);

            var frame = new Panel
            {
                Dock = DockStyle.Fill,
                BackColor = Border,
                Padding = new Padding(1),
                Margin = Padding.Empty
            };
            Controls.Add(frame);
            var surface = new Panel
            {
                Dock = DockStyle.Fill,
                BackColor = Surface,
                Margin = Padding.Empty
            };
            frame.Controls.Add(surface);
            var accent = new Panel
            {
                Dock = DockStyle.Left,
                Width = 4,
                BackColor = Warning,
                Margin = Padding.Empty
            };
            surface.Controls.Add(accent);

            var headerBand = new Panel
            {
                Location = new Point(4, 0),
                Size = new Size(635, 66),
                Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right,
                BackColor = Warning,
                Margin = Padding.Empty
            };
            surface.Controls.Add(headerBand);

            _wordmark = new PictureBox
            {
                Location = new Point(16, 8),
                Size = new Size(184, 50),
                Anchor = AnchorStyles.Top | AnchorStyles.Left,
                SizeMode = PictureBoxSizeMode.Zoom,
                BackColor = Warning,
                Image = LoadWordmark()
            };
            headerBand.Controls.Add(_wordmark);

            var heading = new Label
            {
                Text = "Подтвердите преобразование резьбы",
                Location = new Point(204, 12),
                Size = new Size(410, 42),
                Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right,
                Font = new Font("Segoe UI Semibold", 12f, FontStyle.Bold, GraphicsUnit.Point),
                ForeColor = HeaderText,
                BackColor = Warning,
                TextAlign = ContentAlignment.MiddleLeft
            };
            headerBand.Controls.Add(heading);

            var explanation = new Label
            {
                Text = "Ниже выбранной штатной резьбы в истории построений обнаружено: " + downstreamCount + " последующих операций.\r\n\r\n" +
                    "Helivanta заменит косметическую резьбу Inventor физической геометрией. Нижележащие операции будут перестроены; если они зависят от исходной косметической резьбы или её граней, перестроение может завершиться ошибкой. Изменения выполняются одной транзакцией с попыткой отката.\r\n\r\n" +
                    "Рекомендуется работать с копией IPT.",
                Location = new Point(20, 80),
                Size = new Size(598, 142),
                AutoSize = true,
                MaximumSize = new Size(598, 0),
                Font = new Font("Segoe UI", 9.5f, FontStyle.Regular, GraphicsUnit.Point),
                ForeColor = Muted,
                BackColor = Surface,
                TextAlign = ContentAlignment.TopLeft
            };
            surface.Controls.Add(explanation);

            var continueButton = new Button
            {
                Text = "Продолжить",
                Location = new Point(398, 244),
                Size = new Size(108, 34),
                FlatStyle = FlatStyle.Flat,
                UseVisualStyleBackColor = false,
                BackColor = Accent,
                ForeColor = Color.White,
                Font = new Font("Segoe UI Semibold", 9f, FontStyle.Bold, GraphicsUnit.Point),
                DialogResult = DialogResult.Yes
            };
            continueButton.FlatAppearance.BorderColor = Accent;
            continueButton.FlatAppearance.BorderSize = 1;
            continueButton.AccessibleName = "Продолжить преобразование";
            continueButton.AccessibleDescription = "Подтвердить замену штатной косметической резьбы физической геометрией Helivanta, учитывая риск перестроения последующих операций.";
            surface.Controls.Add(continueButton);

            var cancelButton = new Button
            {
                Text = "Отмена",
                Location = new Point(516, 244),
                Size = new Size(102, 34),
                FlatStyle = FlatStyle.Flat,
                UseVisualStyleBackColor = false,
                BackColor = ButtonSurface,
                ForeColor = TextColor,
                Font = new Font("Segoe UI", 9f, FontStyle.Regular, GraphicsUnit.Point),
                DialogResult = DialogResult.No
            };
            cancelButton.FlatAppearance.BorderColor = Border;
            cancelButton.FlatAppearance.BorderSize = 1;
            cancelButton.AccessibleName = "Отмена преобразования";
            cancelButton.AccessibleDescription = "Отказаться от преобразования и оставить модель без изменений.";
            surface.Controls.Add(cancelButton);

            var tips = new ToolTip { ShowAlways = true, InitialDelay = 450, AutoPopDelay = 12000 };
            tips.SetToolTip(continueButton, HelivantaLocalization.Translate("Продолжить — Преобразовать"));
            tips.SetToolTip(cancelButton, HelivantaLocalization.Translate("Отмена — Не менять модель"));
            FormClosed += (s, e) => tips.Dispose();
            AcceptButton = cancelButton; // Enter is intentionally safe; user must choose Continue explicitly.
            CancelButton = cancelButton;
            Shown += (s, e) =>
            {
                // Re-measure after WinForms has applied the actual monitor DPI. The fixed-height
                // label previously clipped the final lines on some scaling/font combinations.
                int leftMargin = Math.Max(12, explanation.Left);
                int textWidth = Math.Max(240, surface.ClientSize.Width - leftMargin * 2);
                explanation.MaximumSize = new Size(textWidth, 0);
                explanation.Width = textWidth;
                explanation.PerformLayout();

                int buttonGap = Math.Max(14, Font.Height);
                int buttonY = explanation.Bottom + buttonGap;
                cancelButton.Top = buttonY;
                continueButton.Top = buttonY;
                cancelButton.Left = surface.ClientSize.Width - leftMargin - cancelButton.Width;
                continueButton.Left = cancelButton.Left - Math.Max(10, Font.Height / 2) - continueButton.Width;

                int bottomMargin = Math.Max(18, Font.Height);
                int requiredClientHeight = buttonY + Math.Max(cancelButton.Height, continueButton.Height) + bottomMargin;
                if (ClientSize.Height != requiredClientHeight)
                    ClientSize = new Size(ClientSize.Width, requiredClientHeight);

                NativeWindowPositioning.MoveToRight(Handle, ownerHandle);
                try { cancelButton.Focus(); } catch { }
            };
            FormClosing += (s, e) =>
            {
                if (DialogResult == DialogResult.None) DialogResult = DialogResult.No;
            };
        }

        private static Image LoadWordmark()
        {
            try { return HelivantaUiTheme.LoadWordmarkImage(false); }
            catch { return null; }
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                try { if (_wordmark != null && _wordmark.Image != null) _wordmark.Image.Dispose(); } catch { }
                try { if (_wordmark != null) _wordmark.Image = null; } catch { }
            }
            base.Dispose(disposing);
        }

        private sealed class StreamHolder : IDisposable
        {
            internal System.IO.Stream Stream;
            internal static StreamHolder Open(string resourceName)
            {
                return new StreamHolder { Stream = Assembly.GetExecutingAssembly().GetManifestResourceStream(resourceName) };
            }
            public void Dispose()
            {
                if (Stream != null) { Stream.Dispose(); Stream = null; }
            }
        }
    }
}
