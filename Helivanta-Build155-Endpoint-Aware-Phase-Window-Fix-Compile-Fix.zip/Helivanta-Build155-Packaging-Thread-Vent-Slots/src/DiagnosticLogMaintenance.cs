using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;

namespace ThreadPro
{
    /// <summary>
    /// Best-effort bounded retention for diagnostic logs. Never throws into an Inventor operation.
    /// Active logs are capped at 1 MiB, individual records at 512 KiB, four archives per log
    /// are retained, and archives older than 14 days are removed.
    /// </summary>
    internal static class DiagnosticLogMaintenance
    {
        private const long MaxActiveBytes = 1024L * 1024L;
        private const int MaxRecordBytes = 512 * 1024;
        private const int MaxArchivesPerLog = 4;
        private static readonly TimeSpan ArchiveRetention = TimeSpan.FromDays(14);
        private static readonly object LocksSync = new object();
        private static readonly Dictionary<string, object> PathLocks = new Dictionary<string, object>(StringComparer.OrdinalIgnoreCase);
        private static readonly string[] ActiveNames =
        {
            "build-diagnostics.log", "browser-tree-diagnostics.log", "transaction-lifecycle.log",
            "undo-boundary.log", "native-thread-conversion.log", "packaging-thread-diagnostics.log"
        };

        internal static void Append(string directory, string activeFileName, string text)
        {
            try
            {
                if (string.IsNullOrWhiteSpace(directory) || string.IsNullOrWhiteSpace(activeFileName)) return;
                Directory.CreateDirectory(directory);
                string path = Path.Combine(directory, activeFileName);
                object pathLock = GetPathLock(path);
                lock (pathLock)
                {
                    string safeText = BoundRecord(text ?? string.Empty);
                    MaintainOne(directory, path, Encoding.UTF8.GetByteCount(safeText));
                    File.AppendAllText(path, safeText, new UTF8Encoding(false));
                }
            }
            catch
            {
                // Logging and retention are always best-effort.
            }
        }

        internal static void CleanupDirectory(string directory)
        {
            try
            {
                if (string.IsNullOrWhiteSpace(directory)) return;
                Directory.CreateDirectory(directory);
                foreach (string name in ActiveNames)
                {
                    string path = Path.Combine(directory, name);
                    object pathLock = GetPathLock(path);
                    lock (pathLock) MaintainOne(directory, path, 0);
                }
            }
            catch { }
        }

        private static object GetPathLock(string path)
        {
            lock (LocksSync)
            {
                if (!PathLocks.TryGetValue(path, out object gate))
                {
                    gate = new object();
                    PathLocks[path] = gate;
                }
                return gate;
            }
        }

        private static string BoundRecord(string text)
        {
            if (Encoding.UTF8.GetByteCount(text) <= MaxRecordBytes) return text;
            const string marker = "[Helivanta log record truncated to 512 KiB; middle content omitted]" + "\r\n";
            int budget = MaxRecordBytes - Encoding.UTF8.GetByteCount(marker);
            int left = text.Length / 2;
            int right = text.Length - left;
            while (left > 0 && Encoding.UTF8.GetByteCount(text.Substring(0, left)) > budget / 2) left /= 2;
            while (right > 0 && Encoding.UTF8.GetByteCount(text.Substring(text.Length - right, right)) > budget / 2) right /= 2;
            string result = text.Substring(0, left) + marker + text.Substring(text.Length - right, right);
            while (Encoding.UTF8.GetByteCount(result) > MaxRecordBytes && (left > 0 || right > 0))
            {
                if (left >= right && left > 0) left--;
                else if (right > 0) right--;
                result = text.Substring(0, left) + marker + text.Substring(text.Length - right, right);
            }
            return result;
        }

        private static void MaintainOne(string directory, string activePath, int incomingBytes)
        {
            string fileName = Path.GetFileName(activePath);
            string baseName = Path.GetFileNameWithoutExtension(fileName);
            string archivePattern = baseName + "-*.log";
            PruneArchives(directory, archivePattern);

            try
            {
                long current = File.Exists(activePath) ? new FileInfo(activePath).Length : 0L;
                if (current > 0 && (current >= MaxActiveBytes || current + incomingBytes > MaxActiveBytes))
                {
                    string archivePath = Path.Combine(directory, baseName + "-" + DateTime.Now.ToString("yyyyMMdd-HHmmss-fff") + ".log");
                    int suffix = 1;
                    while (File.Exists(archivePath))
                    {
                        archivePath = Path.Combine(directory, baseName + "-" + DateTime.Now.ToString("yyyyMMdd-HHmmss-fff") + "-" + suffix + ".log");
                        suffix++;
                    }
                    File.Move(activePath, archivePath);
                    TrimOversizedFile(archivePath);
                    File.SetLastWriteTimeUtc(archivePath, DateTime.UtcNow);
                }
            }
            catch
            {
                // If a legacy active file is oversized but cannot be rotated, trim its oldest
                // contents as a last-resort cap; diagnostics must never block modeling.
                try { if (File.Exists(activePath)) TrimOversizedFile(activePath); } catch { }
            }

            PruneArchives(directory, archivePattern);
        }


        private static void TrimOversizedFile(string path)
        {
            try
            {
                var info = new FileInfo(path);
                if (!info.Exists || info.Length <= MaxActiveBytes) return;
                string text = File.ReadAllText(path, new UTF8Encoding(false, false));
                const string marker = "[Older log content trimmed to 1 MiB by Helivanta retention policy]\r\n";
                int budget = (int)MaxActiveBytes - Encoding.UTF8.GetByteCount(marker);
                int low = 0;
                int high = text.Length;
                while (low < high)
                {
                    int mid = low + (high - low + 1) / 2;
                    int start = Math.Max(0, text.Length - mid);
                    if (Encoding.UTF8.GetByteCount(text.Substring(start)) <= budget) low = mid;
                    else high = mid - 1;
                }
                string tail = low > 0 ? text.Substring(text.Length - low) : string.Empty;
                File.WriteAllText(path, marker + tail, new UTF8Encoding(false));
            }
            catch { }
        }

        private static void PruneArchives(string directory, string pattern)
        {
            try
            {
                DateTime cutoff = DateTime.UtcNow - ArchiveRetention;
                var archives = Directory.GetFiles(directory, pattern)
                    .Select(path => new FileInfo(path))
                    .OrderByDescending(info => info.LastWriteTimeUtc)
                    .ToList();
                foreach (FileInfo archive in archives)
                {
                    try { if (archive.LastWriteTimeUtc < cutoff) archive.Delete(); }
                    catch { }
                }
                archives = Directory.GetFiles(directory, pattern)
                    .Select(path => new FileInfo(path))
                    .OrderByDescending(info => info.LastWriteTimeUtc)
                    .ToList();
                foreach (FileInfo archive in archives.Skip(MaxArchivesPerLog))
                {
                    try { archive.Delete(); } catch { }
                }
            }
            catch { }
        }
    }
}
