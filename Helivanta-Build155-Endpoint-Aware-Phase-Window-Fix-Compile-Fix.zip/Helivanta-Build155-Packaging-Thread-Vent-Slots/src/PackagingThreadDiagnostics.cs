using System;
using System.Diagnostics;
using System.Globalization;
using System.IO;
using System.Text;
using System.Windows.Forms;
using DrawingColor = System.Drawing.Color;

namespace ThreadPro
{
    /// <summary>Diagnostics for experimental packaging-thread construction. Logging is best-effort and never masks the original failure.</summary>
    internal static class PackagingThreadDiagnostics
    {
        private const string LogFileName = "packaging-thread-diagnostics.log";

        internal static string LogPath
        {
            get
            {
                try
                {
                    return Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData),
                        "Helivanta", "Logs", LogFileName);
                }
                catch { return LogFileName; }
            }
        }

        internal static string CleanDocumentName(Inventor.Application app)
        {
            try
            {
                dynamic document = app == null ? null : app.ActiveDocument;
                string name = document == null ? "<no-document>" : Convert.ToString(document.DisplayName, CultureInfo.InvariantCulture);
                return string.IsNullOrWhiteSpace(name) ? "<unnamed-document>" : name.Replace("\r", " ").Replace("\n", " ");
            }
            catch { return "<document-name-unavailable>"; }
        }

        internal static void WriteEvent(string stage, string context, string detail)
        {
            try
            {
                var record = new StringBuilder();
                record.AppendFormat(CultureInfo.InvariantCulture,
                    "{0} pid={1} thread={2} component=PackagingThread stage={3}\r\ncontext: {4}\r\ndetail: {5}\r\n---\r\n",
                    DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss.fff", CultureInfo.InvariantCulture),
                    SafeProcessId(), System.Threading.Thread.CurrentThread.ManagedThreadId,
                    Clean(stage), Clean(context), Clean(detail));
                Append(record.ToString());
            }
            catch { }
        }

        internal static string WriteException(string stage, string context, Exception exception)
        {
            string path = LogPath;
            try
            {
                var record = new StringBuilder();
                record.AppendFormat(CultureInfo.InvariantCulture,
                    "{0} pid={1} thread={2} component=PackagingThread FAILURE stage={3} hresult=0x{4:X8}\r\ncontext: {5}\r\nexception-type: {6}\r\nexception-message: {7}\r\nexception-chain:\r\n{8}\r\nexception-details:\r\n{9}\r\n--- END FAILURE ---\r\n\r\n",
                    DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss.fff", CultureInfo.InvariantCulture),
                    SafeProcessId(), System.Threading.Thread.CurrentThread.ManagedThreadId,
                    Clean(stage), exception == null ? 0 : exception.HResult,
                    Clean(context), exception == null ? "<null>" : Clean(exception.GetType().FullName),
                    exception == null ? "<null>" : Clean(exception.Message),
                    FormatExceptionChain(exception), exception == null ? "<null>" : exception.ToString());
                Append(record.ToString());
            }
            catch { }
            return path;
        }

        internal static string BuildErrorReport(string stage, string context, Exception exception, string logPath)
        {
            var report = new StringBuilder();
            report.AppendLine("HELIVANTA — ОШИБКА ПОСТРОЕНИЯ УПАКОВОЧНОЙ РЕЗЬБЫ");
            report.AppendLine("Время: " + DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss.fff", CultureInfo.InvariantCulture));
            report.AppendLine("Этап: " + stage);
            report.AppendLine("HRESULT: 0x" + (exception == null ? 0 : exception.HResult).ToString("X8", CultureInfo.InvariantCulture));
            report.AppendLine("Контекст: " + (context ?? "<нет данных>"));
            report.AppendLine();
            report.AppendLine("ЦЕПОЧКА ИСКЛЮЧЕНИЙ (HRESULT КАЖДОГО ВНУТРЕННЕГО ИСКЛЮЧЕНИЯ):");
            report.AppendLine(FormatExceptionChain(exception));
            report.AppendLine();
            report.AppendLine("ПОЛНЫЙ СТЕК ИСКЛЮЧЕНИЯ:");
            report.AppendLine(exception == null ? "<исключение отсутствует>" : exception.ToString());
            report.AppendLine();
            report.AppendLine("Файл лога: " + (logPath ?? LogPath));
            report.AppendLine("Скопируйте этот текст целиком и приложите его к сообщению вместе с логом.");
            return report.ToString();
        }

        internal static void ShowErrorDialog(IWin32Window owner, string caption, string report, string logPath)
        {
            using (var form = new Form())
            {
                form.Text = caption + " — подробности ошибки";
                form.StartPosition = FormStartPosition.CenterParent;
                form.Size = new System.Drawing.Size(900, 590);
                form.MinimumSize = new System.Drawing.Size(700, 420);
                form.FormBorderStyle = FormBorderStyle.Sizable;
                form.MinimizeBox = false;
                form.MaximizeBox = true;
                form.ShowInTaskbar = false;
                form.BackColor = DrawingColor.FromArgb(38, 41, 46);
                form.ForeColor = DrawingColor.Gainsboro;
                form.Font = new System.Drawing.Font("Segoe UI", 9F);

                var layout = new TableLayoutPanel
                {
                    Dock = DockStyle.Fill,
                    ColumnCount = 1,
                    RowCount = 2,
                    Padding = new Padding(8),
                    BackColor = form.BackColor
                };
                layout.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100F));
                layout.RowStyles.Add(new RowStyle(SizeType.Percent, 100F));
                layout.RowStyles.Add(new RowStyle(SizeType.Absolute, 52F));
                var text = new TextBox
                {
                    Multiline = true,
                    ReadOnly = true,
                    WordWrap = false,
                    ScrollBars = ScrollBars.Both,
                    Dock = DockStyle.Fill,
                    Text = report ?? string.Empty,
                    BackColor = DrawingColor.FromArgb(27, 29, 33),
                    ForeColor = DrawingColor.Gainsboro,
                    Font = new System.Drawing.Font("Consolas", 9F),
                    BorderStyle = BorderStyle.FixedSingle,
                    Margin = new Padding(0, 0, 0, 6)
                };
                var buttons = new FlowLayoutPanel
                {
                    Dock = DockStyle.Fill,
                    FlowDirection = FlowDirection.RightToLeft,
                    Padding = new Padding(0, 4, 0, 0),
                    WrapContents = false,
                    BackColor = form.BackColor,
                    Margin = new Padding(0)
                };
                var close = new Button { Text = "Закрыть", AutoSize = true, DialogResult = DialogResult.Cancel };
                var openLog = new Button { Text = "Открыть лог", AutoSize = true };
                var copy = new Button { Text = "Копировать ошибку", AutoSize = true, BackColor = DrawingColor.FromArgb(226, 160, 48), ForeColor = DrawingColor.Black, FlatStyle = FlatStyle.Flat };
                var status = new Label { AutoSize = true, TextAlign = System.Drawing.ContentAlignment.MiddleLeft, Padding = new Padding(4, 8, 8, 0), ForeColor = DrawingColor.FromArgb(240, 180, 70) };

                copy.Click += (_, __) =>
                {
                    try { Clipboard.SetText(report ?? string.Empty); status.Text = "Текст скопирован"; }
                    catch (Exception copyException) { status.Text = "Не удалось скопировать: " + copyException.Message; }
                };
                openLog.Click += (_, __) =>
                {
                    try
                    {
                        string target = string.IsNullOrWhiteSpace(logPath) ? LogPath : logPath;
                        if (!File.Exists(target))
                        {
                            MessageBox.Show(form, "Файл лога ещё не создан или недоступен:\r\n" + target,
                                form.Text, MessageBoxButtons.OK, MessageBoxIcon.Warning);
                            return;
                        }
                        Process.Start(new ProcessStartInfo { FileName = target, UseShellExecute = true });
                    }
                    catch (Exception openException)
                    {
                        MessageBox.Show(form, "Не удалось открыть лог:\r\n" + openException.Message,
                            form.Text, MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    }
                };

                buttons.Controls.Add(close);
                buttons.Controls.Add(openLog);
                buttons.Controls.Add(copy);
                buttons.Controls.Add(status);
                layout.Controls.Add(text, 0, 0);
                layout.Controls.Add(buttons, 0, 1);
                form.Controls.Add(layout);
                form.CancelButton = close;
                form.AcceptButton = copy;
                form.ShowDialog(owner);
            }
        }

        private static string FormatExceptionChain(Exception exception)
        {
            if (exception == null) return "<null>";
            var result = new StringBuilder();
            Exception current = exception;
            int depth = 0;
            while (current != null && depth < 20)
            {
                result.AppendFormat(CultureInfo.InvariantCulture,
                    "[{0}] {1}; HRESULT=0x{2:X8}; Message={3}\r\n",
                    depth, current.GetType().FullName, current.HResult, Clean(current.Message));
                current = current.InnerException;
                depth++;
            }
            if (current != null) result.AppendLine("[truncated] More than 20 inner exceptions.");
            return result.ToString();
        }

        private static void Append(string text)
        {
            string directory = Path.GetDirectoryName(LogPath);
            DiagnosticLogMaintenance.Append(directory, LogFileName, text);
        }

        private static int SafeProcessId()
        {
            try { return Process.GetCurrentProcess().Id; }
            catch { return -1; }
        }

        private static string Clean(string value)
        {
            if (value == null) return "";
            return value.Replace("\r", "\\r").Replace("\n", "\\n").Replace("\t", "\\t");
        }
    }
}
