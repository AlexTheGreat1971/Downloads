﻿using System;
using System.Collections.Generic;

namespace ThreadPro
{
    internal enum ThreadEditMemberKind
    {
        Feature,
        Sketch,
        WorkFeature,
        Unsupported
    }

    internal enum HelivantaTransactionKind
    {
        Other,
        Build,
        Edit
    }

    /// <summary>Pure checks for persisted-group integrity and conservative replacement preconditions.</summary>
    internal static class ThreadEditSafetyPolicy
    {
        /// <summary>
        /// Classifies an Inventor transaction by its visible name. Edit transactions must carry
        /// a concrete ThreadId; ambiguous edit names fail closed and are treated as unrelated.
        /// </summary>
        internal static HelivantaTransactionKind ClassifyTransaction(
            string displayName, string buildPrefix, string editPrefix, out string threadId)
        {
            threadId = null;
            if (string.IsNullOrWhiteSpace(displayName) ||
                string.IsNullOrWhiteSpace(buildPrefix) || string.IsNullOrWhiteSpace(editPrefix))
                return HelivantaTransactionKind.Other;

            string editMarker = editPrefix + " ";
            if (displayName.StartsWith(editMarker, StringComparison.Ordinal))
            {
                string candidate = displayName.Substring(editMarker.Length).Trim();
                if (!string.IsNullOrWhiteSpace(candidate) && candidate.IndexOf(' ') < 0)
                {
                    threadId = candidate;
                    return HelivantaTransactionKind.Edit;
                }
                return HelivantaTransactionKind.Other;
            }

            if (string.Equals(displayName, buildPrefix, StringComparison.Ordinal) ||
                displayName.StartsWith(buildPrefix + " ", StringComparison.Ordinal))
                return HelivantaTransactionKind.Build;

            return HelivantaTransactionKind.Other;
        }

        internal static bool IsEditTransactionForThread(
            string displayName, string buildPrefix, string editPrefix, string currentThreadId)
        {
            string transactionThreadId;
            return !string.IsNullOrWhiteSpace(currentThreadId) &&
                ClassifyTransaction(displayName, buildPrefix, editPrefix, out transactionThreadId) == HelivantaTransactionKind.Edit &&
                string.Equals(transactionThreadId, currentThreadId, StringComparison.Ordinal);
        }

        /// <summary>
        /// An edit may change the thread standard/profile and pitch, but not its nominal diameter.
        /// ThreadBuilder can adapt the underlying cylinder with a join/cut ring during a normal
        /// build; doing that as a side effect of editing would silently change the part's stock.
        /// </summary>
        internal static bool IsNominalDiameterPreserved(double originalDiameterMm, double replacementDiameterMm,
                                                        double toleranceMm = 0.00049)
        {
            if (!IsFinite(originalDiameterMm) || !IsFinite(replacementDiameterMm) ||
                !IsFinite(toleranceMm) || originalDiameterMm <= 0.0 || replacementDiameterMm <= 0.0 || toleranceMm < 0.0)
                return false;
            return Math.Abs(originalDiameterMm - replacementDiameterMm) <= toleranceMm;
        }

        /// <summary>
        /// A rollback is only reported as verified when Abort succeeded and the whole metadata
        /// group reappears with its original record and exact member count.
        /// </summary>
        internal static bool IsRollbackVerified(bool abortSucceeded, bool originalGroupFound,
                                                bool recordsMatch, int originalMemberCount,
                                                int restoredMemberCount)
        {
            return abortSucceeded && originalGroupFound && recordsMatch && originalMemberCount > 0 &&
                   restoredMemberCount == originalMemberCount;
        }
        internal static bool HasCompleteIndices(int expectedCount, IEnumerable<int> indices)
        {
            if (expectedCount < 1 || indices == null) return false;
            var seen = new bool[expectedCount];
            int count = 0;
            foreach (int index in indices)
            {
                if (index < 0 || index >= expectedCount || seen[index]) return false;
                seen[index] = true;
                count++;
            }
            if (count != expectedCount) return false;
            for (int i = 0; i < seen.Length; i++)
                if (!seen[i]) return false;
            return true;
        }

        /// <summary>Classifies whether replacing a thread could affect operations after it.</summary>
        internal static bool RequiresDownstreamWarning(int lastGroupFeatureIndex, int featureCount)
        {
            return featureCount > 0 && lastGroupFeatureIndex >= 0 && lastGroupFeatureIndex < featureCount - 1;
        }

        /// <summary>Legacy predicate retained for tests that describe a thread at the history tail.</summary>
        internal static bool IsAtHistoryTail(int lastGroupFeatureIndex, int featureCount)
        {
            return featureCount > 0 && lastGroupFeatureIndex >= 0 && lastGroupFeatureIndex == featureCount - 1;
        }

        internal static bool IntervalsOverlap(double a0, double a1, double b0, double b1, double tolerance = 1e-4)
        {
            if (!IsFinite(a0) || !IsFinite(a1) || !IsFinite(b0) || !IsFinite(b1) ||
                !IsFinite(tolerance) || tolerance < 0.0) return true; // invalid intervals fail closed
            double aLo = Math.Min(a0, a1);
            double aHi = Math.Max(a0, a1);
            double bLo = Math.Min(b0, b1);
            double bHi = Math.Max(b0, b1);
            return Math.Min(aHi, bHi) - Math.Max(aLo, bLo) > tolerance;
        }

        internal static bool IsUniqueCandidateCount(int count) { return count == 1; }

        /// <summary>
        /// Builds a conservative DeleteObjects sequence: remove features in reverse creation order,
        /// then sketches, then work features. Each member is deleted individually by the caller.
        /// </summary>
        internal static bool TryBuildDeletionOrder(IList<ThreadEditMemberKind> kinds, out int[] order)
        {
            order = null;
            if (kinds == null || kinds.Count == 0) return false;
            for (int i = 0; i < kinds.Count; i++)
                if (kinds[i] == ThreadEditMemberKind.Unsupported) return false;

            var result = new List<int>(kinds.Count);
            ThreadEditMemberKind[] phases = {
                ThreadEditMemberKind.Feature,
                ThreadEditMemberKind.Sketch,
                ThreadEditMemberKind.WorkFeature
            };
            foreach (ThreadEditMemberKind phase in phases)
                for (int i = kinds.Count - 1; i >= 0; i--)
                    if (kinds[i] == phase) result.Add(i);

            if (result.Count != kinds.Count) return false;
            order = result.ToArray();
            return true;
        }

        /// <summary>Accept a folder selection only when all tagged descendants identify exactly one logical thread.</summary>
        internal static bool TryChooseSingleThreadId(IEnumerable<string> threadIds, out string threadId)
        {
            threadId = null;
            if (threadIds == null) return false;
            var distinct = new HashSet<string>(StringComparer.Ordinal);
            foreach (string candidate in threadIds)
            {
                if (!string.IsNullOrWhiteSpace(candidate)) distinct.Add(candidate);
                if (distinct.Count > 1) return false;
            }
            if (distinct.Count != 1) return false;
            foreach (string candidate in distinct) { threadId = candidate; break; }
            return !string.IsNullOrWhiteSpace(threadId);
        }

        private static bool IsFinite(double v) { return !double.IsNaN(v) && !double.IsInfinity(v); }
    }
}
