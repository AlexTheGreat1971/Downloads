﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Runtime.InteropServices;
using System.Text;
using Inventor;

namespace ThreadPro
{
    /// <summary>
    /// Read-only browser-tree diagnostics for Inventor folder/edit failures.
    /// This class must never update the model, change End-of-Part, or alter transactions.
    /// </summary>
    internal static class BrowserTreeDiagnostics
    {
        private static readonly object Sync = new object();
        private const int MaxDepth = 12;
        private const int MaxNodes = 2500;

        internal static void WriteEvent(string component, string stage, string detail)
        {
            try
            {
                var builder = new StringBuilder();
                builder.AppendFormat(CultureInfo.InvariantCulture,
                    "{0} pid={1} thread={2} component={3} stage={4} detail={5}{6}",
                    DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss.fff", CultureInfo.InvariantCulture),
                    SafeProcessId(), System.Threading.Thread.CurrentThread.ManagedThreadId,
                    Clean(component), Clean(stage), Clean(detail), System.Environment.NewLine);
                Append(builder.ToString());
            }
            catch { }
        }

        internal static void WriteSnapshot(string component, string stage, PartDocument document,
            BrowserPane pane, IList<object> trackedObjects, string detail)
        {
            try
            {
                var builder = new StringBuilder(8192);
                builder.AppendFormat(CultureInfo.InvariantCulture,
                    "{0} pid={1} thread={2} component={3} stage={4} document={5} detail={6}{7}",
                    DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss.fff", CultureInfo.InvariantCulture),
                    SafeProcessId(), System.Threading.Thread.CurrentThread.ManagedThreadId,
                    Clean(component), Clean(stage), DescribeDocument(document), Clean(detail), System.Environment.NewLine);

                BrowserNode top = null;
                try { if (pane != null) top = pane.TopNode; } catch { }
                builder.AppendFormat(CultureInfo.InvariantCulture, "TOPNODE available={0}; directChildren={1}{2}",
                    top != null, SafeChildCount(top), System.Environment.NewLine);

                if (trackedObjects != null)
                {
                    for (int i = 0; i < trackedObjects.Count; i++)
                    {
                        object tracked = trackedObjects[i];
                        builder.AppendFormat(CultureInfo.InvariantCulture, "TRACKED[{0}] {1}{2}",
                            i, DescribeObject(tracked), System.Environment.NewLine);
                        if (tracked == null || pane == null) continue;

                        BrowserNode mapped = null;
                        string lookupFailure = null;
                        try { mapped = pane.GetBrowserNodeFromObject(tracked); }
                        catch (Exception ex) { lookupFailure = ex.GetType().Name + ": " + ex.Message; }
                        builder.AppendFormat(CultureInfo.InvariantCulture,
                            "  MAP nodeFound={0}; mappedBrowserNodeComIdentity={1}; lookupFailure={2}{3}",
                            mapped != null, SafeComIdentity(mapped), Clean(lookupFailure), System.Environment.NewLine);
                        BrowserNode current = mapped;
                        for (int depth = 0; current != null && depth < 48; depth++)
                        {
                            builder.AppendFormat(CultureInfo.InvariantCulture, "  PARENT[{0}] {1}{2}",
                                depth, DescribeNode(current), System.Environment.NewLine);
                            try { current = current.Parent as BrowserNode; }
                            catch { current = null; }
                        }
                    }
                }

                if (top != null)
                {
                    int visited = 0;
                    AppendChildren(builder, top, "TopNode", 0, ref visited);
                    if (visited >= MaxNodes)
                        builder.AppendFormat(CultureInfo.InvariantCulture, "TREE truncated=true; maxNodes={0}{1}", MaxNodes, System.Environment.NewLine);
                }
                builder.Append("--- END SNAPSHOT ---").AppendLine().AppendLine();
                Append(builder.ToString());
            }
            catch (Exception ex)
            {
                WriteEvent(component, stage + ".snapshot-failed", ex.GetType().Name + ": " + ex.Message);
            }
        }

        private static void AppendChildren(StringBuilder builder, BrowserNode parent, string path, int depth, ref int visited)
        {
            if (parent == null || depth > MaxDepth || visited >= MaxNodes) return;
            try
            {
                int index = 0;
                foreach (BrowserNode child in parent.BrowserNodes)
                {
                    if (child == null) continue;
                    index++;
                    visited++;
                    string childPath = path + "/" + index;
                    builder.AppendFormat(CultureInfo.InvariantCulture, "TREE depth={0} path={1} {2}{3}",
                        depth + 1, childPath, DescribeNode(child), System.Environment.NewLine);
                    if (visited >= MaxNodes) return;
                    if (depth < MaxDepth) AppendChildren(builder, child, childPath, depth + 1, ref visited);
                }
            }
            catch (Exception ex)
            {
                builder.AppendFormat(CultureInfo.InvariantCulture, "TREE path={0} children-unavailable={1}{2}",
                    path, Clean(ex.GetType().Name + ": " + ex.Message), System.Environment.NewLine);
            }
        }

        private static string DescribeNode(BrowserNode node)
        {
            if (node == null) return "node=<null>";
            object native = null;
            try { native = node.NativeObject; } catch { }
            string type = native == null ? "<null>" : native.GetType().FullName;
            string apiType = SafeApiType(native);
            string name = SafeName(native);
            string comIdentity = SafeComIdentity(native);
            string browserNodeIdentity = SafeComIdentity(node);
            bool marker = (type ?? string.Empty).IndexOf("EndOfFeatures", StringComparison.OrdinalIgnoreCase) >= 0 ||
                          (type ?? string.Empty).IndexOf("EndOfPart", StringComparison.OrdinalIgnoreCase) >= 0 ||
                          (apiType ?? string.Empty).IndexOf("kEndOfFeaturesObject", StringComparison.OrdinalIgnoreCase) >= 0 ||
                          (apiType ?? string.Empty).IndexOf("EndOfFeatures", StringComparison.OrdinalIgnoreCase) >= 0 ||
                          (name ?? string.Empty).IndexOf("End of Part", StringComparison.OrdinalIgnoreCase) >= 0;
            string parentType = "<unknown>";
            try
            {
                BrowserNode parent = node.Parent as BrowserNode;
                parentType = parent == null ? "<non-browser-parent-or-root>" : DescribeNativeType(parent);
            }
            catch { }
            return "browserNodeComIdentity=" + Clean(browserNodeIdentity) +
                   "; nativeType=" + Clean(type) + "; nativeApiType=" + Clean(apiType) +
                   "; nativeName=" + Clean(name) + "; nativeComIdentity=" + Clean(comIdentity) +
                   "; endOfPartMarker=" + marker + "; parentType=" + Clean(parentType);
        }

        private static string DescribeNativeType(BrowserNode node)
        {
            try
            {
                object native = node.NativeObject;
                return native == null ? "<null>" : native.GetType().FullName;
            }
            catch { return "<unavailable>"; }
        }

        private static string DescribeObject(object value)
        {
            if (value == null) return "<null>";
            string description = "type=" + Clean(value.GetType().FullName) +
                "; name=" + Clean(SafeName(value)) + "; comIdentity=" + Clean(SafeComIdentity(value));
            try
            {
                string threadId;
                if (ThreadMetadataStore.TryGetThreadId(value, out threadId) && !string.IsNullOrWhiteSpace(threadId))
                    description += "; threadId=" + Clean(threadId);
            }
            catch { }
            return description;
        }

        private static string SafeComIdentity(object value)
        {
            if (value == null) return "<null>";
            IntPtr identity = IntPtr.Zero;
            try
            {
                identity = Marshal.GetIUnknownForObject(value);
                return "0x" + identity.ToInt64().ToString("X", CultureInfo.InvariantCulture);
            }
            catch (Exception ex)
            {
                return "<unavailable:" + ex.GetType().Name + ":" + Clean(ex.Message) + ">";
            }
            finally
            {
                if (identity != IntPtr.Zero)
                {
                    try { Marshal.Release(identity); } catch { }
                }
            }
        }


        private static string SafeApiType(object value)
        {
            if (value == null) return "<null>";
            try
            {
                dynamic dynamicValue = value;
                object objectType = dynamicValue.Type;
                return Convert.ToString(objectType, CultureInfo.InvariantCulture) ?? "";
            }
            catch (Exception ex)
            {
                return "<unavailable:" + ex.GetType().Name + ":" + Clean(ex.Message) + ">";
            }
        }

        private static string SafeName(object value)
        {
            if (value == null) return "";
            try
            {
                dynamic dynamicValue = value;
                object name = dynamicValue.Name;
                return Convert.ToString(name, CultureInfo.InvariantCulture) ?? "";
            }
            catch { return ""; }
        }

        private static string DescribeDocument(PartDocument document)
        {
            if (document == null) return "<unavailable>";
            try { return "\"" + Clean(document.DisplayName) + "\""; }
            catch { return "<display-name-unavailable>"; }
        }

        private static int SafeChildCount(BrowserNode node)
        {
            if (node == null) return 0;
            try { return node.BrowserNodes.Count; }
            catch { return -1; }
        }

        private static int SafeProcessId()
        {
            try { return System.Diagnostics.Process.GetCurrentProcess().Id; }
            catch { return -1; }
        }

        private static string Clean(string value)
        {
            if (value == null) return "";
            value = value.Replace("\r", "\\r").Replace("\n", "\\n").Replace("\t", "\\t");
            return value.Length > 6000 ? value.Substring(0, 6000) + "…" : value;
        }

        private static void Append(string text)
        {
            string directory = System.IO.Path.Combine(System.Environment.GetFolderPath(System.Environment.SpecialFolder.LocalApplicationData), "Helivanta", "Logs");
            System.IO.Directory.CreateDirectory(directory);
            lock (Sync) DiagnosticLogMaintenance.Append(directory, "browser-tree-diagnostics.log", text);
        }
    }
}
