﻿using System;

namespace ThreadPro
{
    /// <summary>Builds unambiguous, user-facing browser-folder names for the selected thread template.</summary>
    public static class ThreadFolderNamePolicy
    {
        public static string DirectionLabel(bool rightHand)
        {
            return rightHand ? "Правая (R)" : "Левая (L)";
        }

        public static string StandardLabel(ThreadStandard standard)
        {
            switch (standard)
            {
                case ThreadStandard.ISO: return "ISO";
                case ThreadStandard.BSW: return "BSW";
                case ThreadStandard.ANSI: return "ANSI/UN";
                case ThreadStandard.Tr: return "Tr";
                case ThreadStandard.S: return "S (DIN 513)";
                case ThreadStandard.Rd: return "Rd (DIN 405)";
                default: return "Неизвестный шаблон";
            }
        }

        private static string SizeForFolder(ThreadStandard standard, string sizeName)
        {
            string size = string.IsNullOrWhiteSpace(sizeName) ? "размер не указан" : sizeName.Trim();
            string prefix = null;
            switch (standard)
            {
                case ThreadStandard.Tr: prefix = "Tr "; break;
                case ThreadStandard.S: prefix = "S "; break;
                case ThreadStandard.Rd: prefix = "Rd "; break;
            }

            // The family label is already written explicitly by the folder builder. Remove a
            // duplicate family prefix from these three size-name formats but preserve all
            // other values as authored (ISO M..., BSW fractions, ANSI/UN fractions, custom pitch).
            if (!string.IsNullOrEmpty(prefix) && size.StartsWith(prefix, StringComparison.OrdinalIgnoreCase))
                size = size.Substring(prefix.Length).TrimStart();
            return size;
        }

        public static string ProfileLabel(ThreadStandard standard, bool mirror)
        {
            if (standard != ThreadStandard.S) return string.Empty;
            return mirror ? "Зеркальный профиль" : "Прямой профиль";
        }

        public static string AppendThreadOrientation(string baseName, bool rightHand, ThreadStandard standard, bool mirror)
        {
            string result = string.IsNullOrWhiteSpace(baseName) ? "Резьба" : baseName.TrimEnd();
            result += " · " + DirectionLabel(rightHand);

            string profile = ProfileLabel(standard, mirror);
            if (!string.IsNullOrEmpty(profile)) result += " · " + profile;
            return result;
        }

        public static string BuildThreadFolderName(string sizeName, int starts, bool rightHand,
                                                   ThreadStandard standard, bool mirror)
        {
            int count = Math.Max(1, starts);
            string startsWord = StartsWord(count);
            string baseName = "Резьба — " + StandardLabel(standard) + " · " +
                SizeForFolder(standard, sizeName) + " · " + count + " " + startsWord;
            return AppendThreadOrientation(baseName, rightHand, standard, mirror);
        }

        public static string BuildTaperedThreadFolderName(string taperStandard, string taperDesignation, int starts, bool rightHand)
        {
            return BuildTaperedThreadFolderName(taperStandard, null, taperDesignation, starts, rightHand);
        }

        public static string BuildTaperedThreadFolderName(string taperStandard, string displayDesignation,
            string tableDesignation, int starts, bool rightHand)
        {
            string family = string.IsNullOrWhiteSpace(taperStandard) ? "Коническая" : taperStandard.Trim();
            string designation = !string.IsNullOrWhiteSpace(displayDesignation) &&
                !string.Equals(displayDesignation.Trim(), "неизвестное", StringComparison.OrdinalIgnoreCase)
                ? displayDesignation.Trim()
                : (string.IsNullOrWhiteSpace(tableDesignation) ? "типоразмер не указан" : tableDesignation.Trim());
            int count = Math.Max(1, starts);
            bool designationContainsFamily = designation.IndexOf(family, StringComparison.OrdinalIgnoreCase) >= 0;
            string threadLabel = designationContainsFamily ? designation : family + " · " + designation;
            string baseName = "Резьба — " + threadLabel + " · " + count + " " + StartsWord(count);
            return baseName + " · " + DirectionLabel(rightHand);
        }

        public static string BuildRunoutFolderName(string sizeName, int starts, ThreadStandard standard)
        {
            int count = Math.Max(1, starts);
            return "Сбег — " + StandardLabel(standard) + " · " + SizeForFolder(standard, sizeName) +
                " · " + count + " " + StartsWord(count);
        }

        private static string StartsWord(int count)
        {
            int lastTwo = count % 100;
            int lastOne = count % 10;
            if (lastOne == 1 && lastTwo != 11) return "заход";
            if (lastOne >= 2 && lastOne <= 4 && (lastTwo < 12 || lastTwo > 14)) return "захода";
            return "заходов";
        }
    }
}
