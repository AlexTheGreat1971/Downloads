﻿using System;

namespace ThreadPro
{
    /// <summary>
    /// Keeps the technology/clearance ComboBox selection stable across native popup-close
    /// notifications, using the same commit resolution rules proven for the standard selector.
    /// </summary>
    internal static class ThreadTechnologySelectionPolicy
    {
        private static readonly decimal[] PresetClearances = { 0m, 0.1m, 0.15m, 0.3m };

        internal static int FindPresetIndex(double clearanceMm, double toleranceMm)
        {
            if (double.IsNaN(clearanceMm) || double.IsInfinity(clearanceMm)) return PresetClearances.Length;
            for (int i = 0; i < PresetClearances.Length; i++)
                if (Math.Abs((double)PresetClearances[i] - clearanceMm) <= Math.Max(0.0, toleranceMm)) return i;
            return PresetClearances.Length; // index 4 is “Другое”
        }

        internal static bool IsValidIndex(int selectedIndex, int itemCount)
        {
            return ThreadStandardSelectionPolicy.IsValidIndex(selectedIndex, itemCount);
        }

        internal static int ResolveStableIndex(int selectedIndex, int lastCommittedIndex, int itemCount)
        {
            return ThreadStandardSelectionPolicy.ResolveStableIndex(
                selectedIndex, lastCommittedIndex, itemCount);
        }

        internal static int ResolveCommittedIndex(
            int selectedIndex, int pendingIndex, int lastCommittedIndex, int itemCount)
        {
            return ThreadStandardSelectionPolicy.ResolveCommittedIndex(
                selectedIndex, pendingIndex, lastCommittedIndex, itemCount);
        }

        internal static int ResolveAfterDropdownClose(
            bool commitObserved, int pendingIndex, int selectedIndex,
            int lastCommittedIndex, int itemCount)
        {
            if (itemCount <= 0) return -1;

            // Technology selection must be conservative across dialog recreation/add-in
            // reloads. Without an observed user commit, a valid but stale native index must
            // not replace the last committed choice (e.g. FDM -> transient Metal after reopen).
            if (commitObserved && IsValidIndex(pendingIndex, itemCount)) return pendingIndex;
            if (IsValidIndex(lastCommittedIndex, itemCount)) return lastCommittedIndex;
            if (IsValidIndex(selectedIndex, itemCount)) return selectedIndex;
            return 0;
        }

        internal static string ResolveFieldDisplayText(string committedText, string nativeText, bool popupOpen)
        {
            return ThreadStandardSelectionPolicy.ResolveFieldDisplayText(committedText, nativeText, popupOpen);
        }

        internal static bool IsPresetIndex(int selectedIndex)
        {
            return selectedIndex >= 0 && selectedIndex < PresetClearances.Length;
        }

        internal static bool TryGetPresetClearance(int selectedIndex, out decimal clearanceMm)
        {
            switch (selectedIndex)
            {
                case 0: case 1: case 2: case 3:
                    clearanceMm = PresetClearances[selectedIndex];
                    return true;
                default: clearanceMm = 0m; return false;
            }
        }
    }
}
