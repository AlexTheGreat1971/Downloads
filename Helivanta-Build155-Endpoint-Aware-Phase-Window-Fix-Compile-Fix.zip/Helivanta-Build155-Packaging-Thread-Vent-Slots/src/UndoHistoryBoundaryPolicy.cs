﻿namespace ThreadPro
{
    /// <summary>
    /// Inventor exposes ClearAllTransactions as an application-wide operation. Never apply the
    /// document-open Undo boundary unless exactly one document remained open throughout the
    /// current open/new event sequence.
    /// </summary>
    internal static class UndoHistoryBoundaryPolicy
    {
        private const string UnidentifiedTransactionName = "Unidentified transaction";

        internal static bool ShouldClearAllTransactions(int openDocumentCount, bool observedNonSingleDocumentCount)
        {
            return openDocumentCount == 1 && !observedNonSingleDocumentCount;
        }

        /// <summary>
        /// Inventor's CurrentTransaction can return a permanent "Unidentified transaction"
        /// sentinel even when no identified transaction is in progress. ClearAllTransactions
        /// is documented to fail only when an identified transaction is in progress. Treat the
        /// exact sentinel as idle; fail closed for empty or any other name.
        /// </summary>
        internal static bool IsIdentifiedTransactionInProgress(string displayName)
        {
            return string.IsNullOrWhiteSpace(displayName) ||
                !string.Equals(displayName.Trim(), UnidentifiedTransactionName, System.StringComparison.OrdinalIgnoreCase);
        }
    }
}
