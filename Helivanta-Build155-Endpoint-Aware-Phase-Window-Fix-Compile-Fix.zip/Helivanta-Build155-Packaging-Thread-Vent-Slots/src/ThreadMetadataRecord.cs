﻿using System;

namespace ThreadPro
{
    /// <summary>
    /// Persistent, versioned snapshot for one logical Helivanta thread build.
    /// This file intentionally contains no Inventor COM dependencies so the data
    /// contract can be tested independently of the Inventor runtime.
    /// </summary>
    internal sealed class ThreadMetadataRecord
    {
        public ThreadMetadataRecord() { }

        public int SchemaVersion { get; set; } = 1;
        public string ThreadId { get; set; }
        public string ProducerVersion { get; set; }
        public int ObjectCount { get; set; }
        public ThreadParametersSnapshot Parameters { get; set; }
        public ThreadTargetSnapshot Target { get; set; }

        public bool IsValid()
        {
            if (SchemaVersion != 1 || string.IsNullOrWhiteSpace(ThreadId) ||
                ObjectCount < 1 || Parameters == null || Target == null)
                return false;

            if (Parameters.Standard < 0 || Parameters.Standard > 5 ||
                string.IsNullOrWhiteSpace(Parameters.SizeName) ||
                !IsFinitePositive(Parameters.PitchMm) ||
                Parameters.Starts < 1 || Parameters.Starts > 12 ||
                !IsFinitePositive(Parameters.NominalDiaMm) ||
                !IsFiniteNonNegative(Parameters.ClearanceMm) ||
                !IsFiniteNonNegative(Parameters.LengthMm) ||
                !IsFiniteNonNegative(Parameters.OffsetMm) ||
                !IsFiniteNonNegative(Parameters.RunSteps) ||
                !IsFiniteNonNegative(Parameters.ChamferMm) ||
                Parameters.ChamferMode < 0 || Parameters.ChamferMode > 3 ||
                Parameters.TaperGeometryMode < 0 || Parameters.TaperGeometryMode > 1)
                return false;

            if (Target.Center == null || Target.Center.Length != 3 ||
                Target.Axis == null || Target.Axis.Length != 3 ||
                string.IsNullOrWhiteSpace(Target.BodyName) ||
                !IsFinitePositive(Target.RadiusCm) || !IsFinitePositive(Target.LengthCm))
                return false;

            for (int i = 0; i < 3; i++)
            {
                if (!IsFinite(Target.Center[i]) || !IsFinite(Target.Axis[i])) return false;
            }

            double axisLength = Math.Sqrt(
                Target.Axis[0] * Target.Axis[0] +
                Target.Axis[1] * Target.Axis[1] +
                Target.Axis[2] * Target.Axis[2]);

            if (Math.Abs(axisLength - 1.0) > 1e-3) return false;
            if (Parameters.External != Target.IsExternal) return false;

            // Persisted parameters must still describe an axial interval that fits the
            // saved source cylinder. Match ThreadBuilder/preview tolerances so corrupt or
            // stale records fail closed before an edit transaction can begin.
            double offsetCm = Parameters.OffsetMm / 10.0;
            if (offsetCm >= Target.LengthCm - 1e-9) return false;
            if (Parameters.FullLength) return Target.LengthCm - offsetCm > 0.0;

            double lengthCm = Parameters.LengthMm / 10.0;
            if (lengthCm <= 0.0) return false;
            return offsetCm + lengthCm <= Target.LengthCm + 1e-6;
        }

        private static bool IsFinite(double value)
        {
            return !double.IsNaN(value) && !double.IsInfinity(value);
        }

        private static bool IsFinitePositive(double value)
        {
            return IsFinite(value) && value > 0.0;
        }

        private static bool IsFiniteNonNegative(double value)
        {
            return IsFinite(value) && value >= 0.0;
        }
    }

    internal sealed class ThreadParametersSnapshot
    {
        public ThreadParametersSnapshot() { }

        public int Standard { get; set; }
        public string SizeName { get; set; }
        public double PitchMm { get; set; }
        public double NominalDiaMm { get; set; }
        public int Starts { get; set; }
        public double ClearanceMm { get; set; }
        public bool External { get; set; }
        public bool Round { get; set; }
        public bool Smooth { get; set; }
        public bool SimplifiedRunout { get; set; }
        public double RunSteps { get; set; }
        public bool Mirror { get; set; }
        public bool SortThreadsIntoFolders { get; set; }
        public bool FullLength { get; set; }
        public double LengthMm { get; set; }
        public double OffsetMm { get; set; }
        public bool RunOut { get; set; }
        public bool RightHand { get; set; }
        public int ChamferMode { get; set; }
        public double ChamferMm { get; set; }
        public string ToleranceClass { get; set; }
        public bool Tapered { get; set; }
        // Additive field: absent in legacy JSON deserializes to 0 (StrictStandard), which matches the historic table-based taper calculation.
        public int TaperGeometryMode { get; set; }
        public string TaperStandard { get; set; }
        public string TaperDesignation { get; set; }
        public string TaperDisplayDesignation { get; set; }
        public double TaperRatio { get; set; }
        public double TaperReferenceDiameterMm { get; set; }
        public double TaperReferenceLengthMm { get; set; }
        public double TaperStartDiameterMm { get; set; }
        public double TaperEndDiameterMm { get; set; }
        public double TaperThreadDepthMm { get; set; }
    }

    internal sealed class ThreadTargetSnapshot
    {
        public ThreadTargetSnapshot() { }

        // Inventor database lengths are stored in centimetres, exactly as ThreadTarget does.
        public double[] Center { get; set; }
        public double[] Axis { get; set; }
        public double RadiusCm { get; set; }
        public double LengthCm { get; set; }
        public bool IsExternal { get; set; }
        public string BodyName { get; set; }
        public bool StartIsShoulder { get; set; }
        public bool EndIsShoulder { get; set; }
    }
}
