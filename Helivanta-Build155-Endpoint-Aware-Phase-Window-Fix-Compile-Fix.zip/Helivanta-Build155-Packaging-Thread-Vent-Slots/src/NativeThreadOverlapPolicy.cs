﻿using System;

namespace ThreadPro
{
    /// <summary>Fail-closed policy for overlap between Helivanta builds and native Inventor cosmetic threads.</summary>
    internal static class NativeThreadOverlapPolicy
    {
        internal static bool TryGetInterval(double[] center, double[] axis, double sourceLengthCm,
            bool fullLength, double lengthMm, double offsetMm,
            double[] referenceOrigin, double[] referenceAxis, out double start, out double end)
        {
            start = end = 0.0;
            if (!ValidVector(center) || !ValidVector(axis) || !ValidVector(referenceOrigin) || !ValidVector(referenceAxis) ||
                !Finite(sourceLengthCm) || sourceLengthCm <= 0.0 || !Finite(lengthMm) || !Finite(offsetMm) || offsetMm < 0.0)
                return false;

            double axisLength = Norm(axis);
            double referenceLength = Norm(referenceAxis);
            if (!Finite(axisLength) || !Finite(referenceLength) || axisLength < 1e-9 || referenceLength < 1e-9 ||
                Math.Abs(axisLength - 1.0) > 1e-3 || Math.Abs(referenceLength - 1.0) > 1e-3)
                return false;

            double offsetCm = offsetMm / 10.0;
            double lengthCm = fullLength ? sourceLengthCm - offsetCm : lengthMm / 10.0;
            if (!Finite(offsetCm) || !Finite(lengthCm) || lengthCm <= 0.0 ||
                offsetCm >= sourceLengthCm - 1e-9 || offsetCm + lengthCm > sourceLengthCm + 1e-6)
                return false;

            double dx = center[0] - referenceOrigin[0];
            double dy = center[1] - referenceOrigin[1];
            double dz = center[2] - referenceOrigin[2];
            double projectedOrigin = dx * referenceAxis[0] + dy * referenceAxis[1] + dz * referenceAxis[2];
            double direction = axis[0] * referenceAxis[0] + axis[1] * referenceAxis[1] + axis[2] * referenceAxis[2];
            if (!Finite(projectedOrigin) || !Finite(direction) || Math.Abs(direction) < 0.9999) return false;

            start = projectedOrigin + direction * offsetCm;
            end = projectedOrigin + direction * (offsetCm + lengthCm);
            return Finite(start) && Finite(end);
        }

        /// <summary>
        /// When Inventor cannot expose ThreadedFace, a native tapered ThreadFeature is known to
        /// live on a cone. It cannot use the same support surface as a proposed cylindrical face.
        /// Do not extend this relaxation to unknown/parallel ThreadInfo types.
        /// </summary>
        internal static bool CanClassifyTaperedThreadAsUnrelatedToCylinder(bool hasTaperedThreadInfo, bool proposedFaceIsCylinder)
        {
            return hasTaperedThreadInfo && proposedFaceIsCylinder;
        }

        /// <summary>Unknown interval on the same cylinder blocks; a different cylinder never blocks.</summary>
        internal static bool ShouldBlock(bool sameCylinder, bool intervalKnown,
            double proposedStart, double proposedEnd, double existingStart, double existingEnd)
        {
            if (!sameCylinder) return false;
            if (!intervalKnown) return true;
            return ThreadIntegrityPolicy.IntervalsOverlap(proposedStart, proposedEnd, existingStart, existingEnd);
        }

        private static bool ValidVector(double[] value)
        {
            return value != null && value.Length >= 3 && Finite(value[0]) && Finite(value[1]) && Finite(value[2]);
        }

        private static double Norm(double[] value)
        {
            return Math.Sqrt(value[0] * value[0] + value[1] * value[1] + value[2] * value[2]);
        }

        private static bool Finite(double value) { return !double.IsNaN(value) && !double.IsInfinity(value); }
    }
}
