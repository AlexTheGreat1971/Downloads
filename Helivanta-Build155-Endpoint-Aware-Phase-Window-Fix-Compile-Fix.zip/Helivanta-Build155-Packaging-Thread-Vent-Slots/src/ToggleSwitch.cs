using System;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Windows.Forms;

namespace ThreadPro
{
    /// <summary>
    /// Compact owner-drawn ON/OFF control. Uses CheckBox's native Checked/CheckedChanged,
    /// keyboard Space activation and accessibility semantics; only the presentation changes.
    /// </summary>
    internal sealed class ToggleSwitch : CheckBox
    {
        private bool _hovered;
        private bool _pressed;
        private readonly bool _switchOnLeft;

        internal ToggleSwitch(string text, bool checkedState, bool switchOnLeft = false)
        {
            _switchOnLeft = switchOnLeft;
            Text = text ?? string.Empty;
            Checked = checkedState;
            AutoSize = true;
            BackColor = HelivantaUiTheme.Panel;
            ForeColor = HelivantaUiTheme.Text;
            FlatStyle = FlatStyle.Flat;
            FlatAppearance.BorderSize = 0;
            UseVisualStyleBackColor = false;
            CheckAlign = ContentAlignment.MiddleLeft;
            SetStyle(ControlStyles.UserPaint | ControlStyles.AllPaintingInWmPaint |
                     ControlStyles.OptimizedDoubleBuffer | ControlStyles.ResizeRedraw |
                     ControlStyles.Opaque, true);
        }

        public override Size GetPreferredSize(Size proposedSize)
        {
            float scale = Math.Max(1f, DeviceDpi / 96f);
            Size textSize = TextRenderer.MeasureText(Text ?? string.Empty, Font,
                new Size(1400, 200), TextFormatFlags.NoPrefix | TextFormatFlags.SingleLine);
            int switchWidth = (int)Math.Round(34 * scale);
            int gap = (int)Math.Round(8 * scale);
            int height = Math.Max((int)Math.Round(23 * scale), textSize.Height + (int)Math.Round(3 * scale));
            return new Size(textSize.Width + switchWidth + gap + (int)Math.Round(2 * scale), height);
        }

        protected override void OnMouseEnter(EventArgs e)
        {
            _hovered = true;
            Invalidate();
            base.OnMouseEnter(e);
        }

        protected override void OnMouseLeave(EventArgs e)
        {
            _hovered = false;
            _pressed = false;
            Invalidate();
            base.OnMouseLeave(e);
        }

        protected override void OnMouseDown(MouseEventArgs e)
        {
            if (Enabled && e.Button == MouseButtons.Left) { _pressed = true; Invalidate(); }
            base.OnMouseDown(e);
        }

        protected override void OnMouseUp(MouseEventArgs e)
        {
            _pressed = false;
            Invalidate();
            base.OnMouseUp(e);
        }

        protected override void OnMouseCaptureChanged(EventArgs e)
        {
            if (!Capture) _pressed = false;
            Invalidate();
            base.OnMouseCaptureChanged(e);
        }

        protected override void OnGotFocus(EventArgs e)
        {
            Invalidate();
            base.OnGotFocus(e);
        }

        protected override void OnLostFocus(EventArgs e)
        {
            _pressed = false;
            Invalidate();
            base.OnLostFocus(e);
        }

        protected override void OnCheckedChanged(EventArgs e)
        {
            Invalidate();
            base.OnCheckedChanged(e);
        }

        protected override void OnEnabledChanged(EventArgs e)
        {
            if (!Enabled)
            {
                _hovered = false;
                _pressed = false;
            }
            base.OnEnabledChanged(e);
            Invalidate();
        }

        protected override void OnPaintBackground(PaintEventArgs e)
        {
            using (var brush = new SolidBrush(BackColor))
                e.Graphics.FillRectangle(brush, ClientRectangle);
        }

        protected override void OnPaint(PaintEventArgs e)
        {
            Graphics g = e.Graphics;
            g.SmoothingMode = SmoothingMode.AntiAlias;
            g.PixelOffsetMode = PixelOffsetMode.HighQuality;
            g.Clear(BackColor);

            float scale = Math.Max(1f, DeviceDpi / 96f);
            int trackWidth = Math.Max(31, (int)Math.Round(34 * scale));
            int trackHeight = Math.Max(17, (int)Math.Round(18 * scale));
            int y = Math.Max(0, (Height - trackHeight) / 2);
            int trackX = _switchOnLeft ? 1 : Math.Max(0, Width - trackWidth - 1);
            Rectangle track = new Rectangle(trackX, y, trackWidth, trackHeight);
            bool highContrast = SystemInformation.HighContrast;
            Color trackColor = highContrast
                ? (Checked ? SystemColors.Highlight : SystemColors.ControlDark)
                : (!Enabled ? HelivantaUiTheme.PanelSecondary
                    : _pressed ? (Checked ? ControlPaint.Dark(HelivantaUiTheme.Accent) : HelivantaUiTheme.Panel)
                    : Checked ? (_hovered ? HelivantaUiTheme.AccentHover : HelivantaUiTheme.Accent)
                    : (_hovered ? HelivantaUiTheme.AccentSoft : HelivantaUiTheme.Field));
            Color borderColor = highContrast ? SystemColors.WindowText : HelivantaUiTheme.ControlBorder;

            using (GraphicsPath path = CreatePill(track))
            using (var fill = new SolidBrush(trackColor))
            using (var border = new Pen(borderColor, Math.Max(1f, scale)))
            {
                g.FillPath(fill, path);
                g.DrawPath(border, path);
            }

            int thumbSize = Math.Max(9, trackHeight - Math.Max(4, (int)Math.Round(4 * scale)));
            int thumbY = y + (trackHeight - thumbSize) / 2;
            int inset = Math.Max(2, (int)Math.Round(2 * scale));
            int thumbX = Checked ? track.X + trackWidth - thumbSize - inset : track.X + inset;
            using (var thumb = new SolidBrush(!Enabled ? SystemColors.Control : Color.FromArgb(235, 244, 255)))
            using (var thumbOutline = new Pen(highContrast ? SystemColors.WindowText : Color.FromArgb(210, 225, 242), Math.Max(1f, scale)))
            {
                g.FillEllipse(thumb, thumbX, thumbY, thumbSize, thumbSize);
                g.DrawEllipse(thumbOutline, thumbX, thumbY, thumbSize, thumbSize);
            }

            int gap = (int)Math.Round(8 * scale);
            Rectangle textRect = _switchOnLeft
                ? new Rectangle(track.Right + gap, 0, Math.Max(0, Width - track.Right - gap), Height)
                : new Rectangle(0, 0, Math.Max(0, track.X - gap), Height);
            Color textColor = highContrast
                ? SystemColors.ControlText
                : (Enabled ? HelivantaUiTheme.Text : HelivantaUiTheme.Muted);
            TextRenderer.DrawText(g, Text ?? string.Empty, Font, textRect, textColor,
                TextFormatFlags.Left | TextFormatFlags.VerticalCenter | TextFormatFlags.NoPrefix |
                TextFormatFlags.EndEllipsis | TextFormatFlags.SingleLine);

            if (Focused && ShowFocusCues && Enabled)
            {
                Rectangle focus = Rectangle.Inflate(ClientRectangle, -1, -1);
                ControlPaint.DrawFocusRectangle(g, focus,
                    highContrast ? SystemColors.HighlightText : HelivantaUiTheme.Text, BackColor);
            }
        }

        private static GraphicsPath CreatePill(Rectangle rect)
        {
            var path = new GraphicsPath();
            float diameter = Math.Min(rect.Height, rect.Width);
            if (diameter <= 1f)
            {
                path.AddRectangle(rect);
                return path;
            }
            path.AddArc(rect.X, rect.Y, diameter, diameter, 90, 180);
            path.AddArc(rect.Right - diameter, rect.Y, diameter, diameter, 270, 180);
            path.CloseFigure();
            return path;
        }
    }
}
