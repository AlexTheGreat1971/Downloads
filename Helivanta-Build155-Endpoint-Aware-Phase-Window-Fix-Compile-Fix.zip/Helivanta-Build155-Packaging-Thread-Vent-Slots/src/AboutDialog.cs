﻿using System;
using System.Drawing;
using System.IO;
using System.Reflection;
using System.Windows.Forms;

namespace ThreadPro
{
    public sealed class AboutDialog : Form
    {
        public AboutDialog()
        {
            Text = HelivantaUserSettings.Current.Language == "en" ? "About Helivanta" : "О плагине";
            AutoScaleMode = AutoScaleMode.Dpi;
            Load += (sender, args) => HelivantaLocalization.Apply(this);
            FormBorderStyle = FormBorderStyle.FixedDialog;
            StartPosition = FormStartPosition.Manual;
            Opacity = 0.0;
            MaximizeBox = false; MinimizeBox = false; ShowInTaskbar = false;
            AutoSize = true; AutoSizeMode = AutoSizeMode.GrowAndShrink;
            Padding = new Padding(14);
            Font = new Font("Segoe UI", 9f);
            BackColor = HelivantaUiTheme.Surface;
            ForeColor = HelivantaUiTheme.Text;
            try { Icon = LoadEmbeddedIcon(); } catch { }

            var tl = new TableLayoutPanel
            {
                ColumnCount = 2,
                RowCount = 1,
                AutoSize = true,
                Dock = DockStyle.Fill,
                BackColor = BackColor,
                Margin = Padding.Empty,
                Padding = Padding.Empty
            };
            tl.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 320f));
            tl.ColumnStyles.Add(new ColumnStyle(SizeType.AutoSize));
            Controls.Add(tl);

            var icon = new PictureBox
            {
                Size = new Size(300, 300),
                SizeMode = PictureBoxSizeMode.Zoom,
                BackColor = Color.Transparent,
                Margin = new Padding(0, 0, 14, 0)
            };
            try { icon.Image = LoadEmbeddedPng(); } catch { }
            var logoZone = new Panel
            {
                Dock = DockStyle.Fill,
                MinimumSize = new Size(320, 300),
                BackColor = BackColor,
                Margin = Padding.Empty,
                Padding = Padding.Empty
            };
            logoZone.Paint += (sender, e) =>
            {
                if (SystemInformation.HighContrast) return;
                Color hatch = Color.FromArgb(
                    Math.Min(255, BackColor.R + 8),
                    Math.Min(255, BackColor.G + 9),
                    Math.Min(255, BackColor.B + 10));
                using (var pen = new Pen(hatch, 1f))
                {
                    // Same diagonal orientation as the section headers; keep the right text column smooth.
                    e.Graphics.SetClip(logoZone.ClientRectangle);
                    int h = logoZone.ClientSize.Height;
                    for (int c = -h; c < logoZone.ClientSize.Width + h; c += 9)
                        e.Graphics.DrawLine(pen, c, h, c + h, 0);
                }
            };
            icon.Location = new Point(0, 0);
            icon.Margin = Padding.Empty;
            logoZone.Controls.Add(icon);
            tl.Controls.Add(logoZone, 0, 0);

            var info = new TableLayoutPanel
            {
                ColumnCount = 1,
                AutoSize = true,
                Dock = DockStyle.Fill,
                BackColor = BackColor,
                Margin = Padding.Empty,
                Padding = Padding.Empty
            };
            tl.Controls.Add(info, 1, 0);

            Assembly assembly = Assembly.GetExecutingAssembly();
            Version v = assembly.GetName().Version;
            string versionText = v != null ? v.ToString(3) : "";
            AssemblyInformationalVersionAttribute informational =
                (AssemblyInformationalVersionAttribute)Attribute.GetCustomAttribute(assembly, typeof(AssemblyInformationalVersionAttribute));
            if (informational != null && !string.IsNullOrWhiteSpace(informational.InformationalVersion))
            {
                // The informational version is numeric starting with Build 44. Show it directly so About
                // agrees with the version displayed by the installer.
                string current = informational.InformationalVersion.Split('+')[0];
                int previewMarker = current.IndexOf("-preview.", StringComparison.OrdinalIgnoreCase);
                if (previewMarker >= 0)
                {
                    string baseVersion = current.Substring(0, previewMarker);
                    string previewLabel = current.Substring(previewMarker + 9)
                        .Replace("-alpha", " Alpha ")
                        .Replace("-fix", " Fix ")
                        .Replace('-', ' ');
                    versionText = baseVersion + " Preview " + previewLabel;
                }
                else versionText = current;
            }
            info.Controls.Add(new Label
            {
                Text = "Helivanta",
                Font = new Font("Segoe UI Semibold", 15f, FontStyle.Bold),
                ForeColor = HelivantaUiTheme.Text,
                AutoSize = true,
                Margin = new Padding(0, 0, 0, 2)
            });
            info.Controls.Add(new Label
            {
                Text = (HelivantaUserSettings.Current.Language == "en" ? "Physical Thread Design · version " : "Physical Thread Design · версия ") + versionText,
                ForeColor = HelivantaUiTheme.Muted,
                AutoSize = true,
                Margin = new Padding(0, 0, 0, 10)
            });
            info.Controls.Add(new Label
            {
                Text = Localize(
                    "Helivanta — плагин построения физических резьб. Полезен для аддитивных способов производства. " +
                    "Команды ленты: «Создать резьбу» и «Изменить резьбу». В дереве модели папки резьб показывают направление (L/R), а для стандарта S — ориентацию профиля. " +
                    "Технология и её зазор синхронизируются при первом выборе и при повторном открытии диалога. Для точного и ответственного проектирования пользуйтесь встроенными в Inventor опциями. " +
                    "Совместим с Inventor 2027.",
                    "Helivanta creates physical thread geometry and is useful for additive manufacturing. Ribbon commands: Create Thread and Edit Thread. Thread folders in the model browser show hand (L/R) and, for standard S, profile orientation. Technology and its process clearance are synchronized on the first selection and when the dialog is reopened. For critical engineering work, verify the result with Autodesk Inventor's built-in tools. Compatible with Inventor 2027."),
                AutoSize = true, MaximumSize = new Size(430, 0),
                ForeColor = HelivantaUiTheme.Text,
                Margin = new Padding(0, 0, 0, 10)
            });
            info.Controls.Add(new Label
            {
                Text = Localize("Поддерживаемые семейства резьбы", "Supported thread families"),
                Font = new Font("Segoe UI", 9f, FontStyle.Bold),
                ForeColor = HelivantaUiTheme.Text,
                AutoSize = true,
                Margin = new Padding(0, 0, 0, 4)
            });
            info.Controls.Add(new Label
            {
                Text = Localize(
                    "ISO — метрическая 60° (ISO 68-1, ISO 261)\r\n" +
                    "BSW — Витворта 55° (BS 84)\r\n" +
                    "ANSI — UN/UNC/UNF/UNEF 60° (ASME B1.1)\r\n" +
                    "Tr — трапецеидальная 30° (ISO 2901–2904, DIN 103)\r\n" +
                    "S — упорная 3°/30° (DIN 513)\r\n" +
                    "Rd — круглая 30° (DIN 405)\r\n" +
                    "Конические — NPT и JIS Taper (внутренние/наружные поддерживаемые типоразмеры)",
                    "ISO — metric 60° (ISO 68-1, ISO 261)\r\n" +
                    "BSW — Whitworth 55° (BS 84)\r\n" +
                    "ANSI — UN/UNC/UNF/UNEF 60° (ASME B1.1)\r\n" +
                    "Tr — trapezoidal 30° (ISO 2901–2904, DIN 103)\r\n" +
                    "S — buttress 3°/30° (DIN 513)\r\n" +
                    "Rd — round 30° (DIN 405)\r\n" +
                    "Tapered — NPT and JIS Taper (supported internal/external designations)"),
                AutoSize = true,
                MaximumSize = new Size(430, 0),
                ForeColor = HelivantaUiTheme.Text,
                Margin = new Padding(0, 0, 0, 8)
            });
            info.Controls.Add(new Label
            {
                Text = Localize("Возможности текущей версии", "Current version features"),
                Font = new Font("Segoe UI", 9f, FontStyle.Bold),
                ForeColor = HelivantaUiTheme.Text,
                AutoSize = true,
                Margin = new Padding(0, 0, 0, 4)
            });
            info.Controls.Add(new Label
            {
                Text = Localize(
                    "• Физическая геометрия резьбы, многозаходность, сбег, фаски и технологический зазор с пресетами для металла, смолы, SLS и FDM; выбранная технология и её зазор применяются с первого подтверждения.\r\n" +
                    "• Графитовые поля выбора и янтарные управляющие элементы, включая отдельные кнопки увеличения/уменьшения числовых значений.\r\n" +
                    "• Временный приблизительный предпросмотр без постоянных операций в дереве модели; настройки прозрачности и инженерная схема собраны в отдельном окне управления.\r\n" +
                    "• Редактирование поддерживаемых резьб Helivanta из дерева Inventor, включая запуск команды без предварительного выбора.\r\n" +
                    "• Конические резьбы NPT и JIS Taper: поддерживаемые внутренние и наружные варианты; строгий табличный режим и свободная геометрия конуса 1:16. Проверка толщины стенки может безопасно отклонить неподходящую геометрию.\r\n" +
                    "• Предпросмотр адаптируется к цилиндрическому и коническому режимам: размерная схема профиля, боковой вид конуса и таблица параметров.\r\n" +
                    "• Настройки Dark/Light, три акцента Amber/Blue/Gray и RU/EN; подписи команд и подсказки ленты обновляются при смене языка.\r\n" +
                    "• Секция «Цель и состояние» показывает этап, результат, параметры и предупреждения; диагностические журналы автоматически ограничиваются и очищаются по возрасту.\r\n" +
                    "• Отмена построений и согласование Undo/Redo Inventor.",
                    "• Physical thread geometry, multiple starts, runout, chamfers, and process clearance presets for metal, resin, SLS, and FDM; the selected technology and its clearance are applied after the first confirmation.\r\n" +
                    "• Graphite selection fields and accent-color controls, including separate buttons for increasing/decreasing numeric values.\r\n" +
                    "• Temporary approximate preview without persistent model-browser features; transparency controls and the engineering diagram are in a separate control window.\r\n" +
                    "• Edit supported Helivanta threads from the Inventor browser, including starting the command without a preselected feature.\r\n" +
                    "• NPT and JIS Taper threads: supported internal and external variants, strict table-driven mode, and free 1:16 taper geometry. The wall-thickness guard may reject unsuitable geometry.\r\n" +
                    "• Adaptive cylindrical/tapered preview with a dimensioned thread profile, cone side view, and parameter table.\r\n" +
                    "• Dark/Light themes, Amber/Blue/Gray accents, and RU/EN localization; ribbon captions and tooltips update when the language changes.\r\n" +
                    "• Target & Status shows operation stage, results, parameters, and safety warnings; diagnostic logs are size-limited and cleaned up by age.\r\n" +
                    "• Build undo and synchronization with Inventor Undo/Redo."),
                AutoSize = true, MaximumSize = new Size(430, 0),
                ForeColor = HelivantaUiTheme.Text,
                Margin = new Padding(0, 0, 0, 8)
            });
            info.Controls.Add(new Label
            {
                Text = Localize(
                    "Предпросмотр схематичен, а не является итоговой B-Rep-геометрией. Редактирование доступно для групп с сохранёнными метаданными и однозначной исходной поверхностью; если ниже есть зависимые операции, перед заменой появится предупреждение.",
                    "The preview is schematic and is not final B-rep geometry. Editing is available for groups with saved metadata and an unambiguous source surface; if downstream features exist, a warning is shown before replacement."),
                AutoSize = true, MaximumSize = new Size(430, 0),
                ForeColor = HelivantaUiTheme.Muted,
                Margin = new Padding(0, 0, 0, 10)
            });

            var ok = new Button
            {
                Text = "Закрыть", DialogResult = DialogResult.OK, AutoSize = true,
                MinimumSize = new Size(100, 28),
                Anchor = AnchorStyles.Right,
                BackColor = HelivantaUiTheme.Panel,
                ForeColor = HelivantaUiTheme.Text,
                FlatStyle = FlatStyle.Flat
            };
            ok.FlatAppearance.BorderColor = HelivantaUiTheme.ControlBorder;
            ok.FlatAppearance.BorderSize = 1;
            ok.AccessibleName = "Закрыть окно «О плагине»";
            ok.AccessibleDescription = "Закрыть сведения о версии и возможностях Helivanta.";
            var closeTip = new ToolTip { ShowAlways = true };
            closeTip.SetToolTip(ok, HelivantaLocalization.Translate("Закрыть — Закрыть окно"));
            FormClosed += (s, e) =>
            {
                closeTip.Dispose();
                try { icon.Image?.Dispose(); } catch { }
                icon.Image = null;
            };
            info.Controls.Add(ok);
            AcceptButton = ok; CancelButton = ok;
        }

        protected override void OnShown(EventArgs e)
        {
            base.OnShown(e);
            try
            {
                IntPtr reference = Owner != null ? Owner.Handle : IntPtr.Zero;
                NativeWindowPositioning.MoveToCenter(Handle, reference);
            }
            catch { }
            Opacity = 1.0;
        }

        private static Image LoadEmbeddedPng()
        {
            Image image = HelivantaUiTheme.LoadWordmarkImage(false);
            if (image == null) throw new FileNotFoundException("Embedded Helivanta wordmark for the active theme was not found.");
            return image;
        }

        private static string Localize(string russian, string english)
        {
            return HelivantaUserSettings.Current.Language == "en" ? english : russian;
        }

        private static Icon LoadEmbeddedIcon()
        {
            Assembly asm = Assembly.GetExecutingAssembly();
            using (Stream s = asm.GetManifestResourceStream("Helivanta.ico"))
            {
                if (s == null) throw new FileNotFoundException("Embedded Helivanta logo not found.");
                return new Icon(s);
            }
        }
    }
}
