using System;

namespace ThreadPro
{
    /// <summary>Pure vector math used to put multi-start profiles at distinct angular phases.</summary>
    internal static class PackagingThreadPhaseMath
    {
        /// <summary>
        /// Maps the requested thread hand directly to Inventor's ClockwiseRotation flag.
        /// The selected end controls only the axial build direction. It must not invert
        /// this flag: the runtime log showed RH from the high end and LH from the low end
        /// both resolving to false, producing right-handed helices in both cases.
        /// In this builder's profile/axis convention the observed RH mapping is false;
        /// LH is its inverse. Inventor's API defines clockwise sense, not RH/LH itself.
        /// </summary>
        internal static bool ResolveClockwiseRotation(bool rightHand)
        {
            // Calibrated against the user's runtime result: false produced the correct RH
            // geometry; the opposite value is required for LH, independent of selected end.
            return !rightHand;
        }

        internal static double[] RotateAroundAxis(double[] vector, double[] axis, double angleRadians)
        {
            if (vector == null || vector.Length != 3) throw new ArgumentException("Expected a 3D vector.", nameof(vector));
            if (axis == null || axis.Length != 3) throw new ArgumentException("Expected a 3D axis.", nameof(axis));
            if (double.IsNaN(angleRadians) || double.IsInfinity(angleRadians)) throw new ArgumentOutOfRangeException(nameof(angleRadians));
            double axisLength = Length(axis);
            double vectorLength = Length(vector);
            if (!Finite(axisLength) || axisLength < 1e-12) throw new ArgumentException("Rotation axis must be nonzero.", nameof(axis));
            if (!Finite(vectorLength) || vectorLength < 1e-12) throw new ArgumentException("Rotated vector must be nonzero.", nameof(vector));
            double[] u = { axis[0] / axisLength, axis[1] / axisLength, axis[2] / axisLength };
            double c = Math.Cos(angleRadians), s = Math.Sin(angleRadians);
            double dot = Dot(u, vector);
            double[] cross = Cross(u, vector);
            double[] result =
            {
                vector[0] * c + cross[0] * s + u[0] * dot * (1.0 - c),
                vector[1] * c + cross[1] * s + u[1] * dot * (1.0 - c),
                vector[2] * c + cross[2] * s + u[2] * dot * (1.0 - c)
            };
            double resultLength = Length(result);
            if (!Finite(resultLength) || resultLength < 1e-12) throw new InvalidOperationException("Rotation produced an invalid vector.");
            return new[] { result[0] / resultLength * vectorLength, result[1] / resultLength * vectorLength, result[2] / resultLength * vectorLength };
        }

        private static double Length(double[] v) => Math.Sqrt(Dot(v, v));
        private static double Dot(double[] a, double[] b) => a[0] * b[0] + a[1] * b[1] + a[2] * b[2];
        private static double[] Cross(double[] a, double[] b) => new[] { a[1] * b[2] - a[2] * b[1], a[2] * b[0] - a[0] * b[2], a[0] * b[1] - a[1] * b[0] };
        private static bool Finite(double v) => !double.IsNaN(v) && !double.IsInfinity(v);
    }
}
