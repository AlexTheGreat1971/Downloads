﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace ThreadPro
{
    /// <summary>Display-only localization for the searchable, inline Help pane in ThreadDialog.</summary>
    internal static class HelivantaInlineHelpLocalization
    {
        private sealed class Article
        {
            internal readonly string EnglishTitle;
            internal readonly string EnglishBody;
            internal Article(string title, string body) { EnglishTitle = title; EnglishBody = body; }
        }

        private static readonly Dictionary<string, Article> Articles = new Dictionary<string, Article>(StringComparer.Ordinal)
        {
            ["Быстрый старт"] = new Article("Quick start",
                "1. Open an IPT part in Autodesk Inventor 2027.\n2. Run Create Thread.\n3. Select a circular edge; multiple compatible edges can be selected.\n4. Configure thread type, hand, standard, and size.\n5. Check length, edge offset, and available options, then click Build.\n\nThe preview shows an approximate shape and does not replace final verification of the physical B-rep geometry."),
            ["Выбор рёбер"] = new Article("Edge selection",
                "Select the circular edge where the thread starts. Click a selected edge again to deselect it. Incompatible edges and regions that overlap an existing thread are rejected. You can inspect selected edges with Preview before building."),
            ["Цилиндрическая резьба"] = new Article("Cylindrical thread",
                "Choose an external or internal thread, right-hand or left-hand, and standard ISO, BSW, ANSI, Tr, S, or Rd. Select a designation or enter diameter and pitch manually. If the diameter has no exact table match, Custom is used instead of automatically increasing it to the nearest size."),
            ["Коническая резьба — режимы"] = new Article("Tapered thread — modes",
                "Enable “Tapered thread — prepare surface automatically” to show NPT/JIS Taper settings and the “Strictly follow tapered-thread standards” checkbox. Parameters that apply only to cylindrical construction are hidden in tapered mode; their previous values are restored when you switch back to cylindrical mode.\n\nStrict mode uses cone diameters from the Inventor table. Free mode preserves the diameter of the original cylindrical surface at the far end and calculates the diameter at the selected edge using a 1:16 taper; this result is not claimed to comply with a published standard. Free mode displays an additional explanation.\n\nProcess clearance remains zero for tapered threads. The minimum-wall-thickness guard may reject a build; do not bypass this restriction by changing parameters outside the provided settings."),
            ["Типоразмеры NPT и JIS Taper"] = new Article("NPT and JIS Taper designations",
                "Choose the taper standard and a designation from the list. Sizes and length are taken from the available Inventor table. If a size is displayed but construction is rejected, this is not necessarily a table-lookup failure: check the wall-thickness message and selected geometry. Table availability and successful creation of physical geometry are separate checks."),
            ["Размер и технологический зазор"] = new Article("Size and process clearance",
                "Designation provides standard combinations of nominal diameter and pitch. Process clearance is an additional total radial clearance for cylindrical threads, not an ISO 965 tolerance field. Presets: metal — 0 mm, resin — 0.10 mm, SLS — 0.15 mm, FDM — 0.30 mm; Other lets you enter a custom value. In tapered mode, clearance is zero and the cylindrical control is hidden."),
            ["Длина, отступ и сбег"] = new Article("Length, edge offset, and runout",
                "Thread length sets the axial build length. When Full surface length is enabled, the surface determines the length. Edge offset sets the distance to the beginning of the working region. Runout length, pitches sets how gradually the profile fades out; on a short surface, the actual length may be limited by a safety check."),
            ["Фаски и форма профиля"] = new Article("Chamfers and profile shape",
                "Chamfers can be enabled and configured in supported modes. If Inventor rejects a chamfer, retry without it or reduce its length. In tapered mode, only features supported by the active build path remain available; functions that apply only to cylindrical threads are hidden. Profile rounding is a cylindrical-thread feature and is not shown in tapered mode."),
            ["Предварительный просмотр"] = new Article("Preview",
                "Preview creates a temporary approximate mesh and contours. It does not create persistent features and does not modify the model browser. Enable it again after changing parameters. In cylindrical mode, the dimensioned profile and key parameters are shown side by side. In tapered mode, the cone side view is at the upper left, a vertical parameter table is at the right, and the thread profile uses the remaining area. The mesh is schematic and does not guarantee the exact shape of every flank, fillet, chamfer, or final runout."),
            ["Построение, отмена и сброс"] = new Article("Build, Undo, and Reset",
                "Build creates physical geometry. Wait for the operation to finish. Undo reverses the latest Helivanta build in the current session; Inventor Ctrl+Z/Ctrl+Y is also synchronized with occupied-region protection. Reset clears unconfirmed selections and restores default parameters. Exit closes the dialog; geometry already created remains in the document."),
            ["Редактирование и преобразование"] = new Article("Editing and conversion",
                "To edit a Helivanta thread, select its “Thread — …” folder in the model browser, an object inside it, or the Edit Thread command. Parameters are loaded from saved metadata. After a successful edit, the group keeps its original ID and other groups are not replaced. If downstream features depend on the thread, a warning is shown. Save a copy of the IPT before editing or converting a native cylindrical Inventor thread. Tapered/unknown native cosmetic-thread profiles are not currently supported by this conversion pipeline. If rollback after an error is not confirmed, do not save the document."),
            ["Диагностика и журналы"] = new Article("Diagnostics and logs",
                "The Target & Status section reports operation stage, outcome, key parameters, and warnings. Runtime Edit start/completion messages and their parameter details are localized in English too. Full logs are stored in %LOCALAPPDATA%\\Helivanta\\Logs. The active log and each archive are limited to about 1 MB; up to four archives are retained per log, and archives older than 14 days are deleted.\n\nIf an operation creates no result, check the selected surface, length, chamfers, and runout. Never bypass an insufficient-wall-thickness warning for tapered threads. After a geometry error, do not save the file unless restoration of the original model has been confirmed. For difficult cases, send the developer the log from the Logs folder and the exact reproduction steps."),
            ["Настройки, язык и предупреждения"] = new Article("Settings, language, and warnings",
                "Settings include Dark/Light theme, Amber/Blue/Gray accent, and Russian/English language. Choices are saved in the current user's profile. Changing language also updates Inventor ribbon command captions and tooltips. Target & Status messages report the start, completion, or cancellation of an operation. If a warning says the model was not changed, do not bypass the safety guard; review the reason and choose safe geometry. Numeric values in a warning describe the current part and parameters; they are not universal limits defined by a thread standard.")
        };

        internal static bool IsEnglish => string.Equals(HelivantaUserSettings.Current.Language, "en", StringComparison.OrdinalIgnoreCase);

        internal static string DisplayTitle(string sourceTitle)
        {
            if (string.IsNullOrEmpty(sourceTitle) || !IsEnglish) return sourceTitle ?? string.Empty;
            if (Articles.TryGetValue(sourceTitle, out Article article)) return article.EnglishTitle;
            switch (sourceTitle)
            {
                case "Ничего не найдено": return "No results found";
                case "Выберите раздел инструкции": return "Select a help topic";
                case "Раздел не найден": return "Topic not found";
                default: return HelivantaLocalization.Translate(sourceTitle);
            }
        }

        internal static string DisplayBody(string sourceTitle, string sourceBody)
        {
            if (string.IsNullOrEmpty(sourceBody) || !IsEnglish) return sourceBody ?? string.Empty;
            if (Articles.TryGetValue(sourceTitle ?? string.Empty, out Article article)) return article.EnglishBody;
            switch (sourceBody)
            {
                case "Попробуйте другой запрос.": return "Try a different search.";
                case "Выберите тему в списке слева.": return "Select a topic from the list on the left.";
                case "Выберите другую тему инструкции.": return "Choose another help topic.";
                default: return HelivantaLocalization.Translate(sourceBody);
            }
        }

        internal static string SourceTitle(string displayTitle)
        {
            if (string.IsNullOrEmpty(displayTitle)) return string.Empty;
            foreach (KeyValuePair<string, Article> pair in Articles)
                if (string.Equals(pair.Key, displayTitle, StringComparison.Ordinal) ||
                    (IsEnglish && string.Equals(pair.Value.EnglishTitle, displayTitle, StringComparison.Ordinal)))
                    return pair.Key;
            return displayTitle;
        }
    }
}
