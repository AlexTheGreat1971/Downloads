﻿using System;
using System.Collections.Generic;
using System.Globalization;
using Inventor;

namespace ThreadPro
{
    /// <summary>
    /// Experimental additive builder for semi-standard packaging threads.
    /// All public lengths are millimetres; Inventor database lengths are centimetres.
    /// Internal threads are positive inward-facing helical ribs, never cut grooves.
    /// </summary>
    internal static class PackagingThreadGeometryBuilder
    {
        internal const string PackagingTransactionNamePrefix = "Helivanta: упаковочная резьба (эксперимент)";
        internal static string LastCommittedTransactionName { get; private set; }

        internal static bool CanUndoLastBuild(Inventor.Application app, PartDocument expectedDocument, string expectedTransactionName)
        {
            if (app == null || expectedDocument == null || string.IsNullOrWhiteSpace(expectedTransactionName)) return false;
            try
            {
                // UndoTransaction is application-wide. Only allow it while the same document is active
                // and our exact transaction remains the newest committed one; never undo another action.
                if (!object.ReferenceEquals(app.ActiveDocument, expectedDocument)) return false;
                TransactionsEnumerator committed = app.TransactionManager.CommittedTransactions;
                if (committed == null || committed.Count <= 0) return false;
                Transaction last = null;
                foreach (Transaction candidate in committed) last = candidate;
                return last != null && string.Equals(last.DisplayName, expectedTransactionName, StringComparison.Ordinal);
            }
            catch { return false; }
        }

        internal static void UndoLastBuild(Inventor.Application app, PartDocument expectedDocument, string expectedTransactionName)
        {
            if (!CanUndoLastBuild(app, expectedDocument, expectedTransactionName))
                throw new InvalidOperationException("Последним действием в активной детали больше не является это построение Helivanta. Чтобы не отменить чужое действие, отмена заблокирована.");
            app.TransactionManager.UndoTransaction();
            PackagingThreadDiagnostics.WriteEvent("packaging-build-undone", PackagingThreadDiagnostics.CleanDocumentName(app),
                "Undid exact transaction: " + expectedTransactionName);
        }

        internal static string BuildExternal(Inventor.Application app, Edge selectedEdge,
            PackagingThreadGeometryPolicy.ResolvedParameters p, double axialLengthMm, bool rightHand)
        {
            // Backward-compatible entry point for existing callers/tests.
            return Build(app, selectedEdge, p, axialLengthMm, rightHand, false, false, false);
        }

        internal static string Build(Inventor.Application app, Edge selectedEdge,
            PackagingThreadGeometryPolicy.ResolvedParameters p, double axialLengthMm, bool rightHand,
            bool internalThread, bool smoothStart, bool smoothEnd)
        {
            return Build(app, selectedEdge, p, axialLengthMm, rightHand, internalThread, smoothStart, smoothEnd,
                false, PackagingThreadVentSlotPolicy.DefaultExternalSlotCount, PackagingThreadVentSlotPolicy.DefaultExternalSlotWidthDegrees);
        }

        internal static string Build(Inventor.Application app, Edge selectedEdge,
            PackagingThreadGeometryPolicy.ResolvedParameters p, double axialLengthMm, bool rightHand,
            bool internalThread, bool smoothStart, bool smoothEnd,
            bool ventSlotsEnabled, int ventSlotCount, double ventSlotWidthDegrees)
        {
            return Build(app, selectedEdge, p, axialLengthMm, rightHand, internalThread, smoothStart, smoothEnd,
                ventSlotsEnabled, ventSlotCount, ventSlotWidthDegrees, null);
        }

        internal static string Build(Inventor.Application app, Edge selectedEdge,
            PackagingThreadGeometryPolicy.ResolvedParameters p, double axialLengthMm, bool rightHand,
            bool internalThread, bool smoothStart, bool smoothEnd,
            bool ventSlotsEnabled, int ventSlotCount, double ventSlotWidthDegrees,
            Func<bool> cancellationRequested)
        {
            string diagnosticStage = "validate-input";
            string diagnosticContext = "selectedEdge=" + (selectedEdge == null ? "<null>" : "provided") +
                "; axialLength=" + axialLengthMm.ToString("0.###", CultureInfo.InvariantCulture) + " mm" +
                "; type=" + (internalThread ? "internal-positive-rib" : "external") +
                "; smoothStart=" + smoothStart + "; smoothEnd=" + smoothEnd +
                "; ventSlots=" + ventSlotsEnabled + "; ventSlotCount=" + ventSlotCount +
                "; ventSlotWidthDeg=" + ventSlotWidthDegrees.ToString("0.###", CultureInfo.InvariantCulture);
            if (p != null)
                diagnosticContext += string.Format(CultureInfo.InvariantCulture,
                    "; D={0:0.###} mm; P={1:0.###} mm; starts={2}; lead={3:0.###} mm; H={4:0.###} mm; embed={5:0.###} mm; wall={6:0.###} mm; RH={7}",
                    p.DiameterMm, p.PitchMm, p.Starts, p.LeadMm, p.HeightMm, p.EmbedMm, p.MeasuredWallMm, rightHand);
            if (app == null) throw new ArgumentNullException(nameof(app));
            if (selectedEdge == null) throw new InvalidOperationException("Выберите круговое ребро на торце цилиндра/отверстия.");
            if (p == null) throw new ArgumentNullException(nameof(p));
            if (axialLengthMm <= 0 || axialLengthMm > 1000 || double.IsNaN(axialLengthMm) || double.IsInfinity(axialLengthMm))
                throw new InvalidOperationException("Длина должна быть в диапазоне (0; 1000] мм.");

            diagnosticStage = "resolve-edge-cylinder";
            PackagingThreadDiagnostics.WriteEvent(diagnosticStage, diagnosticContext, "Resolving cylindrical face adjacent to selected circular edge.");
            Face face = FindCylindricalFace(selectedEdge);
            if (face == null)
                throw new InvalidOperationException("Выберите круговое ребро, смежное с цилиндрической гранью или стенкой отверстия.");
            bool detectedInternalThread = PackagingThreadGeometryPolicy.IsInternalFromFaceParamReversed(face.IsParamReversed);
            PackagingThreadDiagnostics.WriteEvent("resolve-thread-type", diagnosticContext,
                string.Format(CultureInfo.InvariantCulture,
                    "face.IsParamReversed={0}; autoDetectedType={1}; suppliedType={2}.",
                    face.IsParamReversed, detectedInternalThread ? "internal-positive-rib" : "external",
                    internalThread ? "internal-positive-rib" : "external"));
            if (detectedInternalThread != internalThread)
                throw new InvalidOperationException("Тип поверхности изменился между выбором и построением. Обновите выбор ребра и повторите операцию.");

            PackagingThreadVentSlotPolicy.Plan ventSlotPlan;
            string ventSlotError;
            if (!PackagingThreadVentSlotPolicy.TryResolve(ventSlotsEnabled, detectedInternalThread, ventSlotCount,
                ventSlotWidthDegrees, out ventSlotPlan, out ventSlotError))
                throw new InvalidOperationException("Неверные параметры вентиляционных пропилов: " + ventSlotError);

            diagnosticStage = "read-active-document";
            PartDocument doc = app.ActiveDocument as PartDocument;
            if (doc == null) throw new InvalidOperationException("Активный документ не является деталью.");
            PartComponentDefinition def = doc.ComponentDefinition;
            TransientGeometry tg = app.TransientGeometry;
            Cylinder cylinder = face.Geometry as Cylinder;
            if (cylinder == null) throw new InvalidOperationException("Не удалось получить аналитическую геометрию цилиндра.");

            diagnosticStage = "read-cylinder-geometry";
            double[] axis = Normalize(new[] { cylinder.AxisVector.X, cylinder.AxisVector.Y, cylinder.AxisVector.Z });
            double[] basePoint = { cylinder.BasePoint.X, cylinder.BasePoint.Y, cylinder.BasePoint.Z };
            double radiusCm = cylinder.Radius;
            if (radiusCm <= 0 || !Finite(radiusCm))
                throw new InvalidOperationException("Не удалось определить радиус цилиндра/отверстия.");

            // The cylindrical face's boundary vertices provide the axial limits in database cm.
            double minAxial = double.PositiveInfinity, maxAxial = double.NegativeInfinity;
            foreach (Vertex vertex in face.Vertices)
            {
                Point point = vertex.Point;
                double axial = Dot(new[] { point.X - basePoint[0], point.Y - basePoint[1], point.Z - basePoint[2] }, axis);
                minAxial = Math.Min(minAxial, axial);
                maxAxial = Math.Max(maxAxial, axial);
            }
            double spanCm = maxAxial - minAxial;
            if (!Finite(minAxial) || !Finite(maxAxial) || !Finite(spanCm) || spanCm < 0.2)
                throw new InvalidOperationException("Не удалось надёжно определить осевую длину цилиндрической грани.");

            diagnosticStage = "resolve-edge-axial-position";
            double edgeAxial = GetEdgeAxialCoordinate(selectedEdge, basePoint, axis);
            double distanceToLow = Math.Abs(edgeAxial - minAxial);
            double distanceToHigh = Math.Abs(edgeAxial - maxAxial);
            bool edgeIsLow = distanceToLow <= distanceToHigh;
            double edgeBoundaryDistance = Math.Min(distanceToLow, distanceToHigh);
            double edgeToleranceCm = Math.Max(0.002, spanCm * 1e-4); // at least 0.02 mm
            if (edgeBoundaryDistance > edgeToleranceCm)
                throw new InvalidOperationException("Выбранное ребро не совпадает с торцевой границей цилиндра. Выберите круговое ребро именно на торце.");

            diagnosticStage = "resolve-profile-and-length";
            double pitchCm = p.PitchMm / 10.0;
            double leadCm = p.LeadMm / 10.0;
            double requestedCm = axialLengthMm / 10.0;
            double profileWidthMm = PackagingThreadGeometryPolicy.ResolveProfileBaseWidthMm(p.PitchMm, p.HeightMm, p.EmbedMm);
            double profileWidthCm = profileWidthMm / 10.0;
            double embedCm = Math.Max(0.005, p.EmbedMm / 10.0);
            double heightCm = p.HeightMm / 10.0;
            double marginCm = Math.Max(pitchCm * 0.75, profileWidthCm * 0.60);
            double inwardSpanCm = edgeIsLow ? maxAxial - edgeAxial : edgeAxial - minAxial;
            double availableCm = inwardSpanCm - 2.0 * marginCm;
            if (!Finite(availableCm) || availableCm < leadCm * 0.75)
                throw new InvalidOperationException("Цилиндрическая грань слишком короткая для безопасного начала, конца и сбега резьбы.");

            double lengthCm = Math.Min(requestedCm, availableCm);
            if (!Finite(lengthCm) || lengthCm <= 0.0)
                throw new InvalidOperationException("Расчётная осевая длина резьбы не положительна.");

            PackagingThreadRunoutPolicy.Plan runoutPlan;
            string runoutError;
            if (!PackagingThreadRunoutPolicy.TryResolve(lengthCm * 10.0, p.PitchMm, p.LeadMm,
                p.HeightMm, p.EmbedMm, profileWidthMm, internalThread, smoothStart, smoothEnd, out runoutPlan, out runoutError))
                throw new InvalidOperationException("Не удалось разместить плавные сбеги: " + runoutError);

            double startRunoutCm = runoutPlan.StartLengthMm / 10.0;
            double endRunoutCm = runoutPlan.EndLengthMm / 10.0;
            double coreLengthCm = runoutPlan.CoreLengthMm / 10.0;
            double revolutions = coreLengthCm / leadCm;
            if (!Finite(revolutions) || revolutions < PackagingThreadRunoutPolicy.MinimumCoreLeadFraction - 1e-9)
                throw new InvalidOperationException("После выделения места под сбеги остаётся меньше четверти оборота основной резьбы.");
            PackagingThreadDiagnostics.WriteEvent("runout-policy-resolved", diagnosticContext,
                string.Format(CultureInfo.InvariantCulture,
                    "autoDetectedType={0}; targetRunoutTurnFraction={1:0.######}; effectiveRunoutTurnFraction={2:0.######}; lead={3:0.###} mm; startRunout={4:0.###} mm; endRunout={5:0.###} mm; coreLength={6:0.###} mm; coreTurns={7:0.######}.",
                    internalThread ? "internal-positive-rib" : "external", runoutPlan.TargetTurnFraction, runoutPlan.EffectiveTurnFraction, p.LeadMm,
                    runoutPlan.StartLengthMm, runoutPlan.EndLengthMm, coreLengthCm * 10.0, revolutions));

            double[] buildDirection = edgeIsLow ? axis : Scale(axis, -1.0);
            double startAxial = edgeIsLow ? edgeAxial + marginCm : edgeAxial - marginCm;
            double[] outerOrigin =
            {
                basePoint[0] + axis[0] * startAxial,
                basePoint[1] + axis[1] * startAxial,
                basePoint[2] + axis[2] * startAxial
            };
            double[] seed = Math.Abs(axis[2]) < 0.85 ? new[] { 0.0, 0.0, 1.0 } : new[] { 0.0, 1.0, 0.0 };
            double[] radial = Normalize(Cross(seed, axis));

            // A positive internal ridge overlaps the stock radially outward from the bore
            // surface and projects into the hole. The profile never uses a cut operation.
            if (p.IsInternalThread != detectedInternalThread)
                throw new InvalidOperationException("Автоопределённый тип поверхности не совпадает с типом в политике параметров.");
            double rootRadiusMm, crestRadiusMm;
            string radiusError;
            if (!PackagingThreadGeometryPolicy.TryResolveProfileRadiiMm(radiusCm * 10.0, p.HeightMm, p.EmbedMm,
                internalThread, out rootRadiusMm, out crestRadiusMm, out radiusError))
                throw new InvalidOperationException(radiusError);
            double rootRadiusCm = rootRadiusMm / 10.0;
            double crestRadiusCm = crestRadiusMm / 10.0;
            if (internalThread && embedCm > (p.MeasuredWallMm / 10.0) * 0.5 + 1e-9)
                throw new InvalidOperationException("Глубина соединения внутреннего валика превышает половину заданной толщины стенки.");

            Transaction transaction = null;
            var createdPlanes = new List<WorkPlane>();
            var createdSketches = new List<PlanarSketch>();
            var createdCoils = new List<CoilFeature>();
            var createdRunouts = new List<LoftFeature>();
            var createdVentSlots = new List<RevolveFeature>();
            var createdTerminalFaceCleanups = new List<DeleteFaceFeature>();
            string transactionDisplayName = PackagingTransactionNamePrefix + " " + Guid.NewGuid().ToString("N", CultureInfo.InvariantCulture).Substring(0, 10).ToUpperInvariant();
            SurfaceBody targetBody = face.SurfaceBody;
            if (targetBody == null) throw new InvalidOperationException("Не удалось определить тело, которому принадлежит выбранная цилиндрическая поверхность.");
            try
            {
                diagnosticStage = "start-transaction";
                PackagingThreadDiagnostics.WriteEvent("build-begin", diagnosticContext,
                    string.Format(CultureInfo.InvariantCulture,
                        "edgeIsLow={0}; edgeAxial={1:0.######} cm; minAxial={2:0.######} cm; maxAxial={3:0.######} cm; radius={4:0.######} cm; profileWidth={5:0.######} cm; totalLength={6:0.######} cm; startRunout={7:0.###} mm; endRunout={8:0.###} mm; coreLength={9:0.###} mm; coreRevolutions={10:0.######}; phaseCount={11}; internal={12}",
                        edgeIsLow, edgeAxial, minAxial, maxAxial, radiusCm, profileWidthCm, lengthCm,
                        runoutPlan.StartLengthMm, runoutPlan.EndLengthMm, runoutPlan.CoreLengthMm, revolutions, p.Starts, internalThread));
                double volumeBefore = def.MassProperties.Volume;
                int bodiesBefore = def.SurfaceBodies.Count;
                if (!Finite(volumeBefore) || volumeBefore <= 0 || bodiesBefore < 1)
                    throw new InvalidOperationException("До построения не удалось получить корректное исходное твёрдое тело.");

                transaction = app.TransactionManager.StartTransaction((_Document)doc, transactionDisplayName);
                ThrowIfCancellationRequested(cancellationRequested, "start-transaction", diagnosticContext);
                diagnosticStage = "prepare-starts";
                double halfWidth = profileWidthCm / 2.0;
                if (heightCm + embedCm > pitchCm * PackagingThreadGeometryPolicy.MaxProfileDepthPitchRatio + 1e-9)
                    throw new InvalidOperationException("Глубина профиля превышает безопасный предел относительно шага. Увеличьте шаг или уменьшите отношение высоты.");

                bool clockwiseRotation = PackagingThreadPhaseMath.ResolveClockwiseRotation(rightHand);
                double helixPhaseSign = rightHand ? 1.0 : -1.0;
                PackagingThreadDiagnostics.WriteEvent("resolve-handedness", diagnosticContext,
                    string.Format(CultureInfo.InvariantCulture,
                        "requestedHand={0}; edgeIsLow={1}; buildDirection=({2:0.######},{3:0.######},{4:0.######}); ClockwiseRotation={5}; helixPhaseSign={6}; internal={7}",
                        rightHand ? "RH" : "LH", edgeIsLow, buildDirection[0], buildDirection[1], buildDirection[2], clockwiseRotation, helixPhaseSign, internalThread));

                // First build the full-depth core. Its profile phase is advanced by the start
                // run-out length so it matches the terminal section of the start Loft exactly.
                for (int i = 0; i < p.Starts; i++)
                {
                    ThrowIfCancellationRequested(cancellationRequested, "before-core-coil-" + (i + 1).ToString(CultureInfo.InvariantCulture), diagnosticContext);
                    double basePhaseRad = PackagingThreadGeometryPolicy.GetStartPhaseDegrees(i, p.Starts) * Math.PI / 180.0;
                    double coreStartPhaseRad = basePhaseRad + helixPhaseSign * 2.0 * Math.PI * (startRunoutCm / leadCm);
                    double[] radialForStart = Normalize(PackagingThreadPhaseMath.RotateAroundAxis(radial, buildDirection, coreStartPhaseRad));
                    double[] coreOrigin = Add(outerOrigin, Scale(buildDirection, startRunoutCm));
                    int startNo = i + 1;
                    diagnosticStage = "start-" + startNo.ToString(CultureInfo.InvariantCulture) + "-create-plane";
                    PackagingThreadDiagnostics.WriteEvent(diagnosticStage, diagnosticContext,
                        string.Format(CultureInfo.InvariantCulture, "basePhase={0:0.###} deg; coreStartPhase={1:0.###} deg; startRunout={2:0.###} mm; internal={3}; ClockwiseRotation={4}",
                            PackagingThreadGeometryPolicy.GetStartPhaseDegrees(i, p.Starts), coreStartPhaseRad * 180.0 / Math.PI,
                            runoutPlan.StartLengthMm, internalThread, clockwiseRotation));
                    WorkPlane plane;
                    try
                    {
                        plane = def.WorkPlanes.AddFixed(
                            tg.CreatePoint(coreOrigin[0], coreOrigin[1], coreOrigin[2]),
                            tg.CreateUnitVector(radialForStart[0], radialForStart[1], radialForStart[2]),
                            tg.CreateUnitVector(buildDirection[0], buildDirection[1], buildDirection[2]), false);
                    }
                    catch (Exception planeException)
                    {
                        double axisDotRadial = Dot(buildDirection, radialForStart);
                        throw new InvalidOperationException(string.Format(CultureInfo.InvariantCulture,
                            "Не удалось создать плоскость основного участка захода {0}/{1}: фаза={2:0.#}°, dot(X,Y)={3:0.########}. Исходная ошибка: {4}",
                            startNo, p.Starts, PackagingThreadGeometryPolicy.GetStartPhaseDegrees(i, p.Starts), axisDotRadial, planeException.Message), planeException);
                    }
                    createdPlanes.Add(plane);
                    plane.Visible = false;
                    ThrowIfCancellationRequested(cancellationRequested, "after-core-plane-" + startNo.ToString(CultureInfo.InvariantCulture), diagnosticContext);

                    diagnosticStage = "start-" + startNo.ToString(CultureInfo.InvariantCulture) + "-create-sketch";
                    PlanarSketch sketch = def.Sketches.Add(plane);
                    createdSketches.Add(sketch);
                    sketch.Visible = false;
                    ThrowIfCancellationRequested(cancellationRequested, "after-core-sketch-" + startNo.ToString(CultureInfo.InvariantCulture), diagnosticContext);
                    Point2d S(double axialOffsetCm, double radiusCmAtPoint)
                    {
                        Point modelPoint = tg.CreatePoint(
                            coreOrigin[0] + buildDirection[0] * axialOffsetCm + radialForStart[0] * radiusCmAtPoint,
                            coreOrigin[1] + buildDirection[1] * axialOffsetCm + radialForStart[1] * radiusCmAtPoint,
                            coreOrigin[2] + buildDirection[2] * axialOffsetCm + radialForStart[2] * radiusCmAtPoint);
                        return sketch.ModelToSketchSpace(modelPoint);
                    }

                    SketchLine axisLine;
                    Profile profile;
                    diagnosticStage = "start-" + startNo.ToString(CultureInfo.InvariantCulture) + "-create-profile";
                    try
                    {
                        axisLine = sketch.SketchLines.AddByTwoPoints(S(-halfWidth, 0.0), S(coreLengthCm + halfWidth, 0.0));
                        if (axisLine == null) throw new InvalidOperationException("Inventor вернул пустую линию оси Coil.");
                        axisLine.Construction = true;
                        Point2d a = S(-halfWidth, rootRadiusCm);
                        Point2d b = S( halfWidth, rootRadiusCm);
                        Point2d c = S( halfWidth * PackagingThreadGeometryPolicy.CrestHalfWidthRatio, crestRadiusCm);
                        Point2d d = S(-halfWidth * PackagingThreadGeometryPolicy.CrestHalfWidthRatio, crestRadiusCm);
                        SketchLine l1 = sketch.SketchLines.AddByTwoPoints(a, b);
                        SketchLine l2 = sketch.SketchLines.AddByTwoPoints(l1.EndSketchPoint, c);
                        SketchLine l3 = sketch.SketchLines.AddByTwoPoints(l2.EndSketchPoint, d);
                        sketch.SketchLines.AddByTwoPoints(l3.EndSketchPoint, l1.StartSketchPoint);
                        profile = sketch.Profiles.AddForSolid();
                        if (profile == null) throw new InvalidOperationException("Inventor вернул пустой профиль.");
                        ThrowIfCancellationRequested(cancellationRequested, "after-core-profile-" + startNo.ToString(CultureInfo.InvariantCulture), diagnosticContext);
                    }
                    catch (OperationCanceledException) { throw; }
                    catch (Exception profileException)
                    {
                        throw new InvalidOperationException(string.Format(CultureInfo.InvariantCulture,
                            "Не удалось построить основной профиль захода {0}/{1} (internal={2}; длина ядра {3:0.###} мм; ширина {4:0.###} мм; корневой радиус {5:0.###} мм; радиус вершины {6:0.###} мм). Исходная ошибка: {7}",
                            startNo, p.Starts, internalThread, coreLengthCm * 10.0, profileWidthCm * 10.0,
                            rootRadiusCm * 10.0, crestRadiusCm * 10.0, profileException.Message), profileException);
                    }

                    diagnosticStage = "start-" + startNo.ToString(CultureInfo.InvariantCulture) + "-coil-operation";
                    PackagingThreadDiagnostics.WriteEvent(diagnosticStage, diagnosticContext,
                        string.Format(CultureInfo.InvariantCulture,
                            "basePhase={0:0.###} deg; coreStartPhase={1:0.###} deg; width={2:0.###} mm; H={3:0.###} mm; embed={4:0.###} mm; lead={5:0.###} mm; coreTurns={6:0.###}; internal={7}; ClockwiseRotation={8}",
                            basePhaseRad * 180.0 / Math.PI, coreStartPhaseRad * 180.0 / Math.PI,
                            profileWidthCm * 10.0, p.HeightMm, p.EmbedMm, p.LeadMm, revolutions, internalThread, clockwiseRotation));
                    ThrowIfCancellationRequested(cancellationRequested, "before-core-coil-operation-" + startNo.ToString(CultureInfo.InvariantCulture), diagnosticContext);
                    double volumeBeforeStart = def.MassProperties.Volume;
                    int bodiesBeforeStart = def.SurfaceBodies.Count;
                    CoilFeature coil;
                    try
                    {
                        coil = def.Features.CoilFeatures.AddByPitchAndRevolution(
                            profile, axisLine, leadCm, revolutions,
                            PartFeatureOperationEnum.kJoinOperation, false, clockwiseRotation, 0.0);
                    }
                    catch (Exception coilException)
                    {
                        throw new InvalidOperationException(string.Format(CultureInfo.InvariantCulture,
                            "Inventor отклонил Coil ядра захода {0}/{1} (фаза {2:0.#}°, шаг {3:0.###} мм, ход {4:0.###} мм, оборотов {5:0.###}, длина ядра {6:0.###} мм, ширина основания {7:0.###} мм, радиусы {8:0.###}/{9:0.###} мм, RH={10}, internal={11}, край={12}). Исходная ошибка: {13}",
                            startNo, p.Starts, basePhaseRad * 180.0 / Math.PI, p.PitchMm, p.LeadMm,
                            revolutions, coreLengthCm * 10.0, profileWidthCm * 10.0,
                            rootRadiusCm * 10.0, crestRadiusCm * 10.0, rightHand, internalThread,
                            edgeIsLow ? "low" : "high", coilException.Message), coilException);
                    }
                    if (coil == null) throw new InvalidOperationException("Inventor не вернул CoilFeature для захода " + startNo + ".");
                    createdCoils.Add(coil);
                    ThrowIfCancellationRequested(cancellationRequested, "after-core-coil-" + startNo.ToString(CultureInfo.InvariantCulture), diagnosticContext);
                    diagnosticStage = "start-" + startNo.ToString(CultureInfo.InvariantCulture) + "-assign-feature-name";
                    string featureName = PackagingThreadFeatureNamePolicy.CreateSafeUniqueName(
                        startNo, p.Starts, PackagingThreadGeometryPolicy.GetStartPhaseDegrees(i, p.Starts), Guid.NewGuid());
                    try
                    {
                        coil.Name = featureName;
                        PackagingThreadDiagnostics.WriteEvent(diagnosticStage + "-success", diagnosticContext, "Assigned unique Inventor-safe feature name: " + featureName);
                    }
                    catch (Exception nameException)
                    {
                        PackagingThreadDiagnostics.WriteEvent(diagnosticStage + "-nonfatal-failure", diagnosticContext,
                            string.Format(CultureInfo.InvariantCulture, "Coil geometry was created; feature renaming was skipped. attemptedName={0}; HRESULT=0x{1:X8}; exception={2}", featureName, nameException.HResult, nameException));
                    }

                    diagnosticStage = "start-" + startNo.ToString(CultureInfo.InvariantCulture) + "-verify-coil";
                    try
                    {
                        ThrowIfCancellationRequested(cancellationRequested, "before-core-update-" + startNo.ToString(CultureInfo.InvariantCulture), diagnosticContext);
                        doc.Update();
                        ThrowIfCancellationRequested(cancellationRequested, "after-core-update-" + startNo.ToString(CultureInfo.InvariantCulture), diagnosticContext);
                        if (coil.HealthStatus != HealthStatusEnum.kUpToDateHealth)
                            throw new InvalidOperationException("Coil создан с состоянием " + coil.HealthStatus + ".");
                        double volumeAfterStart = def.MassProperties.Volume;
                        int bodiesAfterStart = def.SurfaceBodies.Count;
                        double startVolumeTolerance = Math.Max(1e-8, Math.Abs(volumeBeforeStart) * 1e-10);
                        if (!Finite(volumeAfterStart) || volumeAfterStart - volumeBeforeStart <= startVolumeTolerance)
                            throw new InvalidOperationException("основной участок захода не добавил измеримого объёма");
                        if (bodiesAfterStart != bodiesBeforeStart)
                            throw new InvalidOperationException("основной участок захода создал отдельное тело вместо объединения с цилиндром");
                    }
                    catch (OperationCanceledException) { throw; }
                    catch (Exception verificationException)
                    {
                        throw new InvalidOperationException(string.Format(CultureInfo.InvariantCulture,
                            "Сбой при проверке основного Coil захода {0}/{1}: фаза={2:0.#}°, D={3:0.###} мм, P={4:0.###} мм, ход={5:0.###} мм, H={6:0.###} мм, врезание={7:0.###} мм, internal={8}, ядро={9:0.###} мм. Исходная ошибка: {10}",
                            startNo, p.Starts, basePhaseRad * 180.0 / Math.PI, p.DiameterMm, p.PitchMm, p.LeadMm,
                            p.HeightMm, p.EmbedMm, internalThread, coreLengthCm * 10.0, verificationException.Message), verificationException);
                    }
                    PackagingThreadDiagnostics.WriteEvent("start-" + startNo.ToString(CultureInfo.InvariantCulture) + "-verified", diagnosticContext,
                        "Core Coil updated; health/volume/body count checks passed.");
                    sketch.Visible = false;
                    plane.Visible = false;
                }

                // The end tapers are separate additive LoftFeatures. Every section has the
                // same four-vertex topology, rotates with the requested hand, and converges
                // smoothly to the cylindrical wall at the free end. Core and runouts meet at
                // identical stations and phases, so no axial/phase gap is introduced.
                for (int i = 0; i < p.Starts; i++)
                {
                    ThrowIfCancellationRequested(cancellationRequested, "before-runouts-" + (i + 1).ToString(CultureInfo.InvariantCulture), diagnosticContext);
                    double basePhaseRad = PackagingThreadGeometryPolicy.GetStartPhaseDegrees(i, p.Starts) * Math.PI / 180.0;
                    if (runoutPlan.HasStart)
                    {
                        ThrowIfCancellationRequested(cancellationRequested, "before-start-runout-" + (i + 1).ToString(CultureInfo.InvariantCulture), diagnosticContext);
                        diagnosticStage = "start-" + (i + 1).ToString(CultureInfo.InvariantCulture) + "-runout-loft";
                        AddRunoutLoft(app, doc, def, tg, outerOrigin, radial, buildDirection,
                            radiusCm, rootRadiusCm, crestRadiusCm, halfWidth,
                            PackagingThreadGeometryPolicy.CrestHalfWidthRatio, leadCm, lengthCm,
                            startRunoutCm, basePhaseRad, helixPhaseSign, true, internalThread,
                            i + 1, p.Starts, diagnosticContext, createdPlanes, createdSketches, createdRunouts, cancellationRequested);
                        ThrowIfCancellationRequested(cancellationRequested, "after-start-runout-" + (i + 1).ToString(CultureInfo.InvariantCulture), diagnosticContext);
                    }
                    if (runoutPlan.HasEnd)
                    {
                        ThrowIfCancellationRequested(cancellationRequested, "before-end-runout-" + (i + 1).ToString(CultureInfo.InvariantCulture), diagnosticContext);
                        diagnosticStage = "end-" + (i + 1).ToString(CultureInfo.InvariantCulture) + "-runout-loft";
                        AddRunoutLoft(app, doc, def, tg, outerOrigin, radial, buildDirection,
                            radiusCm, rootRadiusCm, crestRadiusCm, halfWidth,
                            PackagingThreadGeometryPolicy.CrestHalfWidthRatio, leadCm, lengthCm,
                            endRunoutCm, basePhaseRad, helixPhaseSign, false, internalThread,
                            i + 1, p.Starts, diagnosticContext, createdPlanes, createdSketches, createdRunouts, cancellationRequested);
                        ThrowIfCancellationRequested(cancellationRequested, "after-end-runout-" + (i + 1).ToString(CultureInfo.InvariantCulture), diagnosticContext);
                    }
                }

                if (ventSlotPlan.Enabled)
                {
                    diagnosticStage = "vent-slot-batch";
                    double ventSlotStartOverrunMm = PackagingThreadVentSlotPolicy.GetStartOverrunMm(marginCm * 10.0);
                    double remainingCylinderAfterThreadMm = Math.Max(0.0, (inwardSpanCm - marginCm - lengthCm) * 10.0);
                    double ventSlotEndOverrunMm = PackagingThreadVentSlotPolicy.GetEndOverrunMm(p.LeadMm, remainingCylinderAfterThreadMm);
                    PackagingThreadDiagnostics.WriteEvent("vent-slot-overrun-resolved", diagnosticContext,
                        string.Format(CultureInfo.InvariantCulture,
                            "startOverrun={0:0.###} mm; selected-edge inset={1:0.###} mm; edge safety={2:0.###} mm; preferred end overrun={3:0.###} mm; remaining cylinder after thread={4:0.###} mm; actual end overrun={5:0.###} mm.",
                            ventSlotStartOverrunMm, marginCm * 10.0, PackagingThreadVentSlotPolicy.EdgeSafetyOverrunMm,
                            PackagingThreadVentSlotPolicy.GetAxialOverrunMm(p.LeadMm), remainingCylinderAfterThreadMm, ventSlotEndOverrunMm));
                    AddVentSlots(app, doc, def, tg, targetBody, outerOrigin, radial, buildDirection,
                        radiusCm, crestRadiusCm, lengthCm, ventSlotStartOverrunMm, ventSlotEndOverrunMm,
                        internalThread, ventSlotPlan, diagnosticContext, createdPlanes, createdSketches, createdVentSlots,
                        cancellationRequested);
                    ThrowIfCancellationRequested(cancellationRequested, "before-terminal-fragment-cleanup", diagnosticContext);
                    AddTerminalFragmentCleanups(app, doc, def, targetBody, outerOrigin, radial, buildDirection,
                        lengthCm, halfWidth, profileWidthCm * 10.0, leadCm * 10.0,
                        ventSlotStartOverrunMm / 10.0, ventSlotEndOverrunMm / 10.0,
                        helixPhaseSign, p.Starts, ventSlotPlan, diagnosticContext,
                        createdTerminalFaceCleanups, cancellationRequested);
                    ThrowIfCancellationRequested(cancellationRequested, "after-terminal-fragment-cleanup", diagnosticContext);
                }

                ThrowIfCancellationRequested(cancellationRequested, "before-final-update", diagnosticContext);
                diagnosticStage = "verify-final-model";
                doc.Update();
                double volumeAfter = def.MassProperties.Volume;
                int bodiesAfter = def.SurfaceBodies.Count;
                double volumeTolerance = Math.Max(1e-8, Math.Abs(volumeBefore) * 1e-10);
                if (!Finite(volumeAfter) || volumeAfter - volumeBefore <= volumeTolerance)
                    throw new InvalidOperationException("Coil/Loft не добавили измеримый объём к исходному телу. Операция отменена.");
                if (bodiesAfter != bodiesBefore)
                    throw new InvalidOperationException("После построения изменилось число тел (до=" + bodiesBefore + ", после=" + bodiesAfter + "). Валик/сбег не сросся с исходной деталью; операция отменена.");

                ThrowIfCancellationRequested(cancellationRequested, "before-transaction-commit", diagnosticContext);
                diagnosticStage = "commit-transaction";
                PackagingThreadDiagnostics.WriteEvent(diagnosticStage, diagnosticContext,
                    string.Format(CultureInfo.InvariantCulture, "Final volume/body checks passed; coreCoils={0}; runoutLofts={1}; ventSlotCuts={2}; terminalFaceHealFeatures={3}; legacySectorCleanup=disabled; ventSlotCount={4}; ventSlotWidthDeg={5:0.###}; startRunout={6:0.###} mm; endRunout={7:0.###} mm; internalPositiveRib={8}; transaction={9}.",
                        createdCoils.Count, createdRunouts.Count, createdVentSlots.Count, createdTerminalFaceCleanups.Count,
                        ventSlotPlan.SlotCount, ventSlotPlan.WidthDegrees, runoutPlan.StartLengthMm, runoutPlan.EndLengthMm, internalThread, transactionDisplayName));
                transaction.End();
                transaction = null;
                LastCommittedTransactionName = transactionDisplayName;
                string kindDescription = internalThread ? "внутренняя (положительный валик внутрь отверстия)" : "наружная";
                return string.Format(CultureInfo.InvariantCulture,
                    "Создана экспериментальная {0} {1}-заходная резьба: D={2:0.###} мм; шаг P={3:0.###} мм; ход L={4:0.###} мм; основная длина={5:0.###} мм; сбег в начале={6:0.###} мм; сбег в конце={7:0.###} мм; высота={8:0.###} мм; направление={9}; фазы заходов: {10}. {11}",
                    kindDescription, p.Starts, p.DiameterMm, p.PitchMm, p.LeadMm, coreLengthCm * 10.0,
                    runoutPlan.StartLengthMm, runoutPlan.EndLengthMm, p.HeightMm, rightHand ? "правая" : "левая",
                    string.Join(", ", EnumerableRange(p.Starts).ConvertAll(i => PackagingThreadGeometryPolicy.GetStartPhaseDegrees(i, p.Starts).ToString("0.#", CultureInfo.InvariantCulture) + "°")),
                    ventSlotPlan.Enabled ? string.Format(CultureInfo.InvariantCulture, "Вентиляционные пропилы: {0} шт. по {1:0.###}°; очистка хвостов Delete Face + Heal: {2} успешных операций; секторные вырезы отключены.", createdVentSlots.Count, ventSlotPlan.WidthDegrees, createdTerminalFaceCleanups.Count) : "Вентиляционные пропилы отключены.");
            }
            catch (Exception ex)
            {
                if (ex is OperationCanceledException)
                    PackagingThreadDiagnostics.WriteEvent("build-cancelled", diagnosticContext,
                        "Cancellation was honored at stage " + diagnosticStage + "; aborting the feature transaction. " + ex.Message);
                else
                    PackagingThreadDiagnostics.WriteException("builder/" + diagnosticStage, diagnosticContext, ex);
                try { if (transaction != null) transaction.Abort(); } catch (Exception abortException)
                {
                    PackagingThreadDiagnostics.WriteException("builder/transaction-abort", diagnosticContext, abortException);
                }
                throw;
            }
        }

        private static void ThrowIfCancellationRequested(Func<bool> cancellationRequested, string stage, string diagnosticContext)
        {
            if (cancellationRequested == null || !cancellationRequested()) return;
            PackagingThreadDiagnostics.WriteEvent("build-cancel-requested", diagnosticContext,
                "Cancellation honored at checkpoint: " + stage + "; the whole transaction will be aborted.");
            throw new OperationCanceledException("Построение отменено пользователем на этапе: " + stage + ". Все изменения этой операции будут отменены.");
        }

        private static void AddVentSlots(
            Inventor.Application app, PartDocument doc, PartComponentDefinition def, TransientGeometry tg,
            SurfaceBody targetBody, double[] outerOrigin, double[] baseRadial, double[] buildDirection,
            double stockRadiusCm, double crestRadiusCm, double totalLengthCm,
            double startOverrunMm, double endOverrunMm,
            bool internalThread, PackagingThreadVentSlotPolicy.Plan plan, string diagnosticContext,
            IList<WorkPlane> createdPlanes, IList<PlanarSketch> createdSketches, IList<RevolveFeature> createdVentSlots,
            Func<bool> cancellationRequested)
        {
            if (plan == null || !plan.Enabled) return;
            if (targetBody == null) throw new InvalidOperationException("Для вентиляционных пропилов не определено исходное твёрдое тело.");

            double radialOvercutCm = PackagingThreadVentSlotPolicy.RadialOvercutMm / 10.0;
            if (!Finite(startOverrunMm) || startOverrunMm <= 0.0 || !Finite(endOverrunMm) || endOverrunMm <= 0.0)
                throw new InvalidOperationException("Осевой запас резака должен быть положительным и конечным.");
            double startOverrunCm = startOverrunMm / 10.0;
            double endOverrunCm = endOverrunMm / 10.0;
            // Cut only the raised rib: outside the original cylinder for external threads,
            // and inside the bore only for internal positive ribs. The stock cylinder itself
            // is the stopping boundary; the tiny overcut affects only the free side of the ridge.
            double radialMin = internalThread ? crestRadiusCm - radialOvercutCm : stockRadiusCm;
            double radialMax = internalThread ? stockRadiusCm : crestRadiusCm + radialOvercutCm;
            if (!Finite(radialMin) || !Finite(radialMax) || radialMin <= 0.0 || radialMax <= radialMin)
                throw new InvalidOperationException("Неверный радиальный диапазон инструмента вентиляционного пропила.");

            double slotAngleRad = plan.WidthDegrees * Math.PI / 180.0;
            if (!Finite(slotAngleRad) || slotAngleRad <= 0.0 || slotAngleRad >= 2.0 * Math.PI / plan.SlotCount + 1e-9)
                throw new InvalidOperationException("Ширина вентиляционного пропила пересекается с соседним пропилом.");

            PackagingThreadDiagnostics.WriteEvent("vent-slots-begin", diagnosticContext,
                string.Format(CultureInfo.InvariantCulture,
                    "count={0}; width={1:0.###} deg; spacing={2:0.###} deg; sweepRadians={3:0.########}; internal={4}; radialRange={5:0.######}..{6:0.######} cm; axialRange={7:0.######}..{8:0.######} cm; radialOvercut={9:0.###} mm; startOverrun={10:0.###} mm; endOverrun={11:0.###} mm.",
                    plan.SlotCount, plan.WidthDegrees, plan.SpacingDegrees, slotAngleRad, internalThread,
                    radialMin, radialMax, -startOverrunCm, totalLengthCm + endOverrunCm,
                    PackagingThreadVentSlotPolicy.RadialOvercutMm, startOverrunMm, endOverrunMm));

            for (int index = 0; index < plan.SlotCount; index++)
            {
                ThrowIfCancellationRequested(cancellationRequested, "before-vent-slot-" + (index + 1).ToString(CultureInfo.InvariantCulture), diagnosticContext);
                int slotNumber = index + 1;
                string stage = "vent-slot-" + slotNumber.ToString("00", CultureInfo.InvariantCulture);
                double startAngleDegrees = plan.GetStartAngleDegrees(index);
                double startAngleRadians = startAngleDegrees * Math.PI / 180.0;
                // AddByAngle revolves toward the plane normal. With X=radial and Y=axis,
                // the positive side corresponds to decreasing the right-hand angular parameter,
                // so starting at centre+half width centers each cut on i*360/count.
                double[] slotRadial = Normalize(PackagingThreadPhaseMath.RotateAroundAxis(baseRadial, buildDirection, startAngleRadians));
                double volumeBefore = def.MassProperties.Volume;
                int bodiesBefore = def.SurfaceBodies.Count;
                try
                {
                    PackagingThreadDiagnostics.WriteEvent(stage + "-create-plane", diagnosticContext,
                        string.Format(CultureInfo.InvariantCulture,
                            "slot={0}/{1}; startAngle={2:0.###} deg; centreAngle={3:0.###} deg; width={4:0.###} deg; internal={5}.",
                            slotNumber, plan.SlotCount, startAngleDegrees, index * plan.SpacingDegrees, plan.WidthDegrees, internalThread));
                    WorkPlane plane = def.WorkPlanes.AddFixed(
                        tg.CreatePoint(outerOrigin[0], outerOrigin[1], outerOrigin[2]),
                        tg.CreateUnitVector(slotRadial[0], slotRadial[1], slotRadial[2]),
                        tg.CreateUnitVector(buildDirection[0], buildDirection[1], buildDirection[2]), false);
                    if (plane == null) throw new InvalidOperationException("Inventor не создал рабочую плоскость пропила.");
                    plane.Visible = false;
                    createdPlanes.Add(plane);
                    ThrowIfCancellationRequested(cancellationRequested, stage + "-after-plane", diagnosticContext);
                    PlanarSketch sketch = def.Sketches.Add(plane);
                    if (sketch == null) throw new InvalidOperationException("Inventor не создал эскиз пропила.");
                    sketch.Visible = false;
                    createdSketches.Add(sketch);
                    ThrowIfCancellationRequested(cancellationRequested, stage + "-after-sketch", diagnosticContext);

                    Point2d S(double stationCm, double radiusCm)
                    {
                        Point modelPoint = tg.CreatePoint(
                            outerOrigin[0] + buildDirection[0] * stationCm + slotRadial[0] * radiusCm,
                            outerOrigin[1] + buildDirection[1] * stationCm + slotRadial[1] * radiusCm,
                            outerOrigin[2] + buildDirection[2] * stationCm + slotRadial[2] * radiusCm);
                        return sketch.ModelToSketchSpace(modelPoint);
                    }

                    SketchLine axisLine = sketch.SketchLines.AddByTwoPoints(
                        S(-startOverrunCm, 0.0), S(totalLengthCm + endOverrunCm, 0.0));
                    if (axisLine == null) throw new InvalidOperationException("Inventor не создал ось вращения вентиляционного пропила.");
                    axisLine.Construction = true;
                    Point2d a = S(-startOverrunCm, radialMin);
                    Point2d b = S(totalLengthCm + endOverrunCm, radialMin);
                    Point2d c = S(totalLengthCm + endOverrunCm, radialMax);
                    Point2d d = S(-startOverrunCm, radialMax);
                    SketchLine l1 = sketch.SketchLines.AddByTwoPoints(a, b);
                    SketchLine l2 = sketch.SketchLines.AddByTwoPoints(l1.EndSketchPoint, c);
                    SketchLine l3 = sketch.SketchLines.AddByTwoPoints(l2.EndSketchPoint, d);
                    sketch.SketchLines.AddByTwoPoints(l3.EndSketchPoint, l1.StartSketchPoint);
                    Profile profile = sketch.Profiles.AddForSolid();
                    if (profile == null) throw new InvalidOperationException("Inventor вернул пустой профиль прямоугольного вентиляционного пропила.");
                    ThrowIfCancellationRequested(cancellationRequested, stage + "-after-profile", diagnosticContext);

                    PackagingThreadDiagnostics.WriteEvent(stage + "-cut-operation", diagnosticContext,
                        string.Format(CultureInfo.InvariantCulture,
                            "sweep=AddByAngle({0:0.########} rad); operation=kCutOperation; radialMin={1:0.######} cm; radialMax={2:0.######} cm.",
                            slotAngleRad, radialMin, radialMax));
                    RevolveFeature cut = def.Features.RevolveFeatures.AddByAngle(
                        profile, axisLine, slotAngleRad,
                        PartFeatureExtentDirectionEnum.kPositiveExtentDirection,
                        PartFeatureOperationEnum.kCutOperation);
                    if (cut == null) throw new InvalidOperationException("Inventor не вернул RevolveFeature для вентиляционного пропила.");
                    createdVentSlots.Add(cut);
                    ThrowIfCancellationRequested(cancellationRequested, "after-vent-slot-cut-" + slotNumber.ToString(CultureInfo.InvariantCulture), diagnosticContext);
                    ThrowIfCancellationRequested(cancellationRequested, "before-set-affected-body-" + slotNumber.ToString(CultureInfo.InvariantCulture), diagnosticContext);
                    ObjectCollection affected = app.TransientObjects.CreateObjectCollection();
                    affected.Add(targetBody);
                    cut.SetAffectedBodies(affected);
                    ThrowIfCancellationRequested(cancellationRequested, "after-set-affected-body-" + slotNumber.ToString(CultureInfo.InvariantCulture), diagnosticContext);
                    string safeName = "HVPkgV_" + Guid.NewGuid().ToString("N", CultureInfo.InvariantCulture).Substring(0, 10).ToUpperInvariant() +
                        "_SLOT" + slotNumber.ToString("00", CultureInfo.InvariantCulture) + "OF" + plan.SlotCount.ToString("00", CultureInfo.InvariantCulture);
                    try { cut.Name = safeName; } catch (Exception nameEx)
                    {
                        PackagingThreadDiagnostics.WriteEvent(stage + "-name-skipped", diagnosticContext,
                            "Cut was created but feature naming failed: HRESULT=0x" + nameEx.HResult.ToString("X8", CultureInfo.InvariantCulture) + "; " + nameEx.Message);
                    }
                    ThrowIfCancellationRequested(cancellationRequested, "before-update-vent-slot-" + slotNumber.ToString(CultureInfo.InvariantCulture), diagnosticContext);
                    doc.Update();
                    ThrowIfCancellationRequested(cancellationRequested, "after-update-vent-slot-" + slotNumber.ToString(CultureInfo.InvariantCulture), diagnosticContext);
                    if (cut.HealthStatus != HealthStatusEnum.kUpToDateHealth)
                        throw new InvalidOperationException("Пропил создан с состоянием " + cut.HealthStatus + ".");
                    double volumeAfter = def.MassProperties.Volume;
                    int bodiesAfter = def.SurfaceBodies.Count;
                    double tolerance = Math.Max(1e-8, Math.Abs(volumeBefore) * 1e-10);
                    if (!Finite(volumeAfter) || volumeBefore - volumeAfter <= tolerance)
                        throw new InvalidOperationException("Пропил не удалил измеримый объём резьбового валика. Проверьте ориентацию плоскости и выбранный цилиндр.");
                    if (bodiesAfter != bodiesBefore)
                        throw new InvalidOperationException("Пропил изменил число твёрдых тел: до=" + bodiesBefore + ", после=" + bodiesAfter + ".");
                    PackagingThreadDiagnostics.WriteEvent(stage + "-verified", diagnosticContext,
                        string.Format(CultureInfo.InvariantCulture,
                            "Vent slot cut verified; name={0}; angle={1:0.###} deg; width={2:0.###} deg; volumeRemoved={3:0.##########} cm^3; bodies={4}; internal={5}.",
                            safeName, startAngleDegrees, plan.WidthDegrees, volumeBefore - volumeAfter, bodiesAfter, internalThread));
                }
                catch (OperationCanceledException) { throw; }
                catch (Exception ex)
                {
                    var detailed = new InvalidOperationException(string.Format(CultureInfo.InvariantCulture,
                        "Не удалось создать вентиляционный пропил {0}/{1}: ширина={2:0.###}°, начальный угол={3:0.###}°, radialRange={4:0.###}..{5:0.###} мм, internal={6}. Причина: {7}",
                        slotNumber, plan.SlotCount, plan.WidthDegrees, startAngleDegrees,
                        radialMin * 10.0, radialMax * 10.0, internalThread, ex.Message), ex);
                    PackagingThreadDiagnostics.WriteException("builder/" + stage, diagnosticContext, detailed);
                    throw detailed;
                }
            }
        }

        private static void AddTerminalFragmentCleanups(
            Inventor.Application app, PartDocument doc, PartComponentDefinition def,
            SurfaceBody targetBody, double[] outerOrigin, double[] baseRadial, double[] buildDirection,
            double totalLengthCm, double halfWidthCm, double profileWidthMm,
            double leadMm, double startOverrunCm, double endOverrunCm, double helixPhaseSign,
            int starts, PackagingThreadVentSlotPolicy.Plan slotPlan, string diagnosticContext,
            IList<DeleteFaceFeature> createdCleanupFaces, Func<bool> cancellationRequested)
        {
            if (slotPlan == null || !slotPlan.Enabled) return;

            for (int startIndex = 0; startIndex < starts; startIndex++)
            {
                double basePhaseDegrees = PackagingThreadGeometryPolicy.GetStartPhaseDegrees(startIndex, starts);
                double endPhaseDegrees = PackagingThreadVentFragmentPolicy.Normalize(
                    basePhaseDegrees + helixPhaseSign * 360.0 * totalLengthCm / (leadMm / 10.0));
                for (int endIndex = 0; endIndex < 2; endIndex++)
                {
                    ThrowIfCancellationRequested(cancellationRequested,
                        "before-terminal-fragment-plan-start-" + (startIndex + 1).ToString(CultureInfo.InvariantCulture) + "-end-" + endIndex.ToString(CultureInfo.InvariantCulture), diagnosticContext);
                    bool atStart = endIndex == 0;
                    double phase = atStart ? basePhaseDegrees : endPhaseDegrees;
                    // On a start, the helix travels into the part following its hand sign. At the far
                    // end, move back along the helix to find the preceding slot boundary.
                    bool towardIncreasing = atStart ? helixPhaseSign > 0.0 : helixPhaseSign < 0.0;
                    PackagingThreadVentFragmentPolicy.Plan plan;
                    string planError;
                    if (!PackagingThreadVentFragmentPolicy.TryResolve(phase, towardIncreasing,
                        slotPlan.SlotCount, slotPlan.WidthDegrees, starts, leadMm, profileWidthMm,
                        out plan, out planError))
                        throw new InvalidOperationException("Не удалось оценить концевой фрагмент захода " + (startIndex + 1) + ": " + planError);

                    string label = (atStart ? "start" : "end") + "-" + (startIndex + 1).ToString(CultureInfo.InvariantCulture) + "-terminal-fragment";
                    PackagingThreadDiagnostics.WriteEvent(label + "-plan", diagnosticContext,
                        string.Format(CultureInfo.InvariantCulture,
                            "phase={0:0.###} deg; nearestBoundary={1:0.###} deg; previousDirectionHint={2}; clearGap={3:0.###} deg; sectorPitch={4:0.###} deg; fragment={5:0.###} deg ({6:0.###}% of clear gap; {7:0.###}% of sector pitch); cleanupThreshold={8:0.###} deg; axialTravel={9:0.###} mm; shouldTrim={10}; reason={11}",
                            plan.EndpointPhaseDegrees, plan.SlotBoundaryDegrees, towardIncreasing, plan.GapAngleDegrees,
                            plan.SectorAngleDegrees, plan.FragmentAngleDegrees, plan.FractionOfGap * 100.0,
                            plan.FractionOfSector * 100.0, plan.EffectiveThresholdDegrees, plan.AxialTravelMm, plan.ShouldTrim, plan.Reason));
                    if (!plan.ShouldTrim) continue;

                    // Match the three narrow helical top faces the user selects manually, then use
                    // Inventor Delete Face with Heal=true. Do not fall back to a fragile sector cut:
                    // an ambiguous probe is logged and skipped rather than creating another bad feature.
                    if (TryDeleteTerminalFacesWithHeal(app, doc, def, targetBody, outerOrigin, baseRadial,
                        buildDirection, totalLengthCm, startOverrunCm, endOverrunCm, halfWidthCm,
                        helixPhaseSign, leadMm, plan, atStart,
                        label, diagnosticContext, createdCleanupFaces, cancellationRequested))
                        continue;
                    PackagingThreadDiagnostics.WriteEvent(label + "-cleanup-skipped", diagnosticContext,
                        "Delete Face + Heal was not applied safely. Legacy sector-cut fallback is disabled; the tiny residual may remain. See the preceding delete-face diagnostic for candidate counts/reason.");
                    continue;


                }
            }
        }

        private static bool TryDeleteTerminalFacesWithHeal(
            Inventor.Application app, PartDocument doc, PartComponentDefinition def, SurfaceBody targetBody,
            double[] origin, double[] baseRadial, double[] axis, double totalLengthCm,
            double startOverrunCm, double endOverrunCm, double halfWidthCm,
            double helixPhaseSign, double leadMm,
            PackagingThreadVentFragmentPolicy.Plan plan, bool atStart, string label, string diagnosticContext,
            IList<DeleteFaceFeature> createdCleanupFaces, Func<bool> cancellationRequested)
        {
            // Inventor's Delete Face API takes a FaceCollection and a Heal flag. The user reports
            // selecting the three narrow top faces of each short tail. The local window and surface
            // type filter distinguish them from planar vent-slot end walls in the supplied case.
            // The target is identified from the measured local axial window, phase-corrected angular
            // window and observed helical-top surface type; do not reject these faces by nominal crest radius.
            FaceCollection candidates = app.TransientObjects.CreateFaceCollection();
            var candidateDetails = new List<string>();
            var nearbySectorDetails = new List<string>();
            double axialTravelCm = plan.AxialTravelMm / 10.0;
            double axialMin = atStart ? -startOverrunCm - 0.02 : totalLengthCm - axialTravelCm - halfWidthCm - 0.02;
            double axialMax = atStart ? axialTravelCm + halfWidthCm + 0.02 : totalLengthCm + endOverrunCm + 0.02;
            double sweepStart = NormalizeDegrees(plan.SweepStartDegrees);
            double sweepWidth = Math.Max(0.5, plan.SweepWidthDegrees);
            double angularPad = Math.Max(2.0, Math.Min(8.0, sweepWidth * 0.25));
            int scannedFaces = 0, axialCandidates = 0, angularSectorCandidates = 0, topSurfaceCandidates = 0;
            // These values are also needed by the summary/verification events after the scan loop,
            // so declare them in the enclosing method scope rather than inside the per-face try block.
            bool useForwardPhaseWindow = PackagingThreadVentFragmentPolicy.UseForwardFacePhaseWindow(
                atStart, helixPhaseSign);
            double facePhaseCorrectionSign = PackagingThreadVentFragmentPolicy.GetFacePhaseCorrectionSign(
                atStart, helixPhaseSign);

            for (int i = 1; i <= targetBody.Faces.Count; i++)
            {
                ThrowIfCancellationRequested(cancellationRequested, label + "-scan-face-" + i.ToString(CultureInfo.InvariantCulture), diagnosticContext);
                Face candidate;
                try { candidate = targetBody.Faces[i]; } catch { continue; }
                if (candidate == null) continue;
                scannedFaces++;
                try
                {
                    Point q = candidate.PointOnFace;
                    double dx = q.X - origin[0], dy = q.Y - origin[1], dz = q.Z - origin[2];
                    double station = dx * axis[0] + dy * axis[1] + dz * axis[2];
                    if (station < axialMin || station > axialMax) continue;
                    axialCandidates++;
                    double rx = dx - station * axis[0], ry = dy - station * axis[1], rz = dz - station * axis[2];
                    double pointRadius = Math.Sqrt(rx * rx + ry * ry + rz * rz);
                    if (pointRadius < 1e-7) continue;
                    rx /= pointRadius; ry /= pointRadius; rz /= pointRadius;
                    double dot = baseRadial[0] * rx + baseRadial[1] * ry + baseRadial[2] * rz;
                    double cx = baseRadial[1] * rz - baseRadial[2] * ry;
                    double cy = baseRadial[2] * rx - baseRadial[0] * rz;
                    double cz = baseRadial[0] * ry - baseRadial[1] * rx;
                    double signed = cx * axis[0] + cy * axis[1] + cz * axis[2];
                    double angle = NormalizeDegrees(Math.Atan2(signed, dot) * 180.0 / Math.PI);
                    // PointOnFace is generally not located at the axial endpoint. On a helix,
                    // its azimuth changes with axial station, so comparing its raw angle with
                    // an endpoint-sector angle biases the start and end differently. Remove the
                    // expected helical phase accumulated between this station and the endpoint
                    // before testing the local fragment window.
                    double endpointStationCm = atStart ? 0.0 : totalLengthCm;
                    // The prior phase-corrected build cleaned RH/end and LH/start, but missed
                    // RH/start and LH/end. For the missing pair, the phase correction sign and
                    // angular-window orientation must be mirrored together; flipping only the
                    // sign regressed all four combinations. This affects face selection only.
                    double endpointPhaseAngle = PackagingThreadVentFragmentPolicy.CorrectAngleToEndpoint(
                        angle, station, endpointStationCm, leadMm, facePhaseCorrectionSign);
                    double offset = useForwardPhaseWindow
                        ? NormalizeDegrees(endpointPhaseAngle - sweepStart)
                        : NormalizeDegrees(sweepStart - endpointPhaseAngle);
                    bool inSector = offset <= sweepWidth + angularPad || offset >= 360.0 - angularPad;
                    if (!inSector)
                    {
                        if (nearbySectorDetails.Count < 12 && candidate.SurfaceType == SurfaceTypeEnum.kBSplineSurface)
                            nearbySectorDetails.Add(string.Format(CultureInfo.InvariantCulture,
                                "face#{0}: station={1:0.###}mm, radius={2:0.###}mm, rawAngle={3:0.###}deg, endpointPhase={4:0.###}deg, correctionSign={5}, surface={6} (outside phase-corrected fragment sector)",
                                i, station * 10.0, pointRadius * 10.0, angle, endpointPhaseAngle, facePhaseCorrectionSign, candidate.SurfaceType));
                        continue;
                    }
                    angularSectorCandidates++;

                    // The runtime log for the known short tail showed five faces in the local
                    // axial/angular window: two kPlaneSurface slot/end walls and exactly three
                    // kBSplineSurface faces. Those three spline faces are the narrow helical top
                    // faces the user selects manually. They lie near the stock radius (~11.0 mm),
                    // not at the nominal crest radius (~11.55 mm), so a crest-radius test excludes
                    // the intended faces. Here the plan has already established fragment < 25% of
                    // the free slot sector; use surface topology plus the local window to select the
                    // three faces, and log the full vertex radial span for review.
                    if (candidate.SurfaceType != SurfaceTypeEnum.kBSplineSurface)
                    {
                        if (nearbySectorDetails.Count < 12)
                            nearbySectorDetails.Add(string.Format(CultureInfo.InvariantCulture,
                                "face#{0}: station={1:0.###}mm, radius={2:0.###}mm, rawAngle={3:0.###}deg, endpointPhase={4:0.###}deg, correctionSign={5}, surface={6} (not selected: not a spline top face)",
                                i, station * 10.0, pointRadius * 10.0, angle, endpointPhaseAngle, facePhaseCorrectionSign, candidate.SurfaceType));
                        continue;
                    }

                    double minVertexRadius = double.PositiveInfinity;
                    double maxVertexRadius = double.NaN;
                    int vertexCount = 0;
                    try
                    {
                        foreach (Vertex vertex in candidate.Vertices)
                        {
                            if (vertex == null || vertex.Point == null) continue;
                            double vx = vertex.Point.X - origin[0];
                            double vy = vertex.Point.Y - origin[1];
                            double vz = vertex.Point.Z - origin[2];
                            double axial = vx * axis[0] + vy * axis[1] + vz * axis[2];
                            double vrx = vx - axial * axis[0];
                            double vry = vy - axial * axis[1];
                            double vrz = vz - axial * axis[2];
                            double vertexRadius = Math.Sqrt(vrx * vrx + vry * vry + vrz * vrz);
                            if (!Finite(vertexRadius)) continue;
                            maxVertexRadius = double.IsNaN(maxVertexRadius) ? vertexRadius : Math.Max(maxVertexRadius, vertexRadius);
                            minVertexRadius = Math.Min(minVertexRadius, vertexRadius);
                            vertexCount++;
                        }
                    }
                    catch { /* Keep the face eligible, but preserve that its vertex diagnostic is unavailable. */ }

                    topSurfaceCandidates++;
                    candidates.Add(candidate);
                    candidateDetails.Add(string.Format(CultureInfo.InvariantCulture,
                        "face#{0}: station={1:0.###}mm, pointRadius={2:0.###}mm, vertexRadius={3}..{4}mm, rawAngle={5:0.###}deg, endpointPhase={6:0.###}deg, correctionSign={7}, vertices={8}, surface={9}",
                        i, station * 10.0, pointRadius * 10.0,
                        vertexCount > 0 && !double.IsNaN(maxVertexRadius) ? (minVertexRadius * 10.0).ToString("0.###", CultureInfo.InvariantCulture) : "n/a",
                        vertexCount > 0 && !double.IsNaN(maxVertexRadius) ? (maxVertexRadius * 10.0).ToString("0.###", CultureInfo.InvariantCulture) : "n/a",
                        angle, endpointPhaseAngle, facePhaseCorrectionSign, vertexCount, candidate.SurfaceType));
                }
                catch { /* Non-evaluable faces are not eligible for automatic deletion. */ }
            }

            if (candidates.Count != 3)
            {
                PackagingThreadDiagnostics.WriteEvent(label + "-delete-face-ambiguous", diagnosticContext,
                    string.Format(CultureInfo.InvariantCulture,
                        "Heal deletion not attempted: scannedFaces={0}; axialCandidates={1}; phaseCorrectedSectorCandidates={2}; splineTopSurfaceCandidates={3}; finalCandidates={4}; required=3; axialRange={5:0.###}..{6:0.###}mm; correctedSector={7:0.###}+{8:0.###}deg; faceWindow={11}; correctionSign={12}; accepted=[{9}]; nearbyFaces=[{10}]. PointOnFace phase is mapped to the endpoint, and both correction sign and window orientation depend on hand plus endpoint. No crest-radius filter is applied because target top faces lie near stock radius.",
                        scannedFaces, axialCandidates, angularSectorCandidates, topSurfaceCandidates, candidates.Count,
                        axialMin * 10.0, axialMax * 10.0, sweepStart, sweepWidth,
                        string.Join(" | ", candidateDetails), string.Join(" | ", nearbySectorDetails),
                        useForwardPhaseWindow ? "forward" : "reverse", facePhaseCorrectionSign));

                return false;
            }

            ThrowIfCancellationRequested(cancellationRequested, label + "-before-delete-face-heal", diagnosticContext);
            double volumeBefore = def.MassProperties.Volume;
            int bodyCountBefore = def.SurfaceBodies.Count;
            DeleteFaceFeature feature = null;
            try
            {
                feature = def.Features.DeleteFaceFeatures.Add(candidates, true);
                if (feature == null) throw new InvalidOperationException("Inventor did not return DeleteFaceFeature.");
                doc.Update();
                ThrowIfCancellationRequested(cancellationRequested, label + "-after-delete-face-heal", diagnosticContext);
                if (feature.HealthStatus != HealthStatusEnum.kUpToDateHealth)
                    throw new InvalidOperationException("Delete Face + Heal health=" + feature.HealthStatus + ".");
                double volumeAfter = def.MassProperties.Volume;
                int bodyCountAfter = def.SurfaceBodies.Count;
                if (!Finite(volumeAfter) || Math.Abs(volumeBefore - volumeAfter) < Math.Max(1e-8, Math.Abs(volumeBefore) * 1e-10))
                    throw new InvalidOperationException("Delete Face + Heal did not produce a measurable geometry change.");
                if (bodyCountAfter != bodyCountBefore)
                    throw new InvalidOperationException("Delete Face + Heal changed solid-body count from " + bodyCountBefore + " to " + bodyCountAfter + ".");
                createdCleanupFaces?.Add(feature);
                PackagingThreadDiagnostics.WriteEvent(label + "-delete-face-heal-verified", diagnosticContext,
                    "Delete Face + Heal succeeded for the 3 crest/top faces; volumeDelta=" +
                    (volumeBefore - volumeAfter).ToString("0.##########", CultureInfo.InvariantCulture) +
                    " cm^3; faceWindow=" + (useForwardPhaseWindow ? "forward" : "reverse") +
                    "; correctionSign=" + facePhaseCorrectionSign.ToString("0.###", CultureInfo.InvariantCulture) +
                    "; faces=[" + string.Join(" | ", candidateDetails) + "].");
                return true;
            }
            catch (OperationCanceledException) { throw; }
            catch (Exception ex)
            {
                PackagingThreadDiagnostics.WriteException("builder/" + label + "-delete-face-heal", diagnosticContext, ex);
                if (feature != null)
                {
                    try { feature.Delete(); doc.Update(); }
                    catch (Exception cleanupEx)
                    {
                        throw new InvalidOperationException("Delete Face + Heal failed and its feature could not be rolled back safely: " + cleanupEx.Message, ex);
                    }
                }
                return false;
            }
        }

        private static double NormalizeDegrees(double value)
        {
            value %= 360.0;
            if (value < 0.0) value += 360.0;
            return value;
        }

        private static LoftFeature AddRunoutLoft(
            Inventor.Application app, PartDocument doc, PartComponentDefinition def, TransientGeometry tg,
            double[] outerOrigin, double[] baseRadial, double[] buildDirection,
            double stockRadiusCm, double fullRootRadiusCm, double fullCrestRadiusCm,
            double halfWidthCm, double crestHalfWidthRatio, double leadCm, double totalLengthCm,
            double runoutLengthCm, double basePhaseRad, double helixPhaseSign, bool runoutAtStart,
            bool internalThread, int startIndex, int startCount, string diagnosticContext,
            IList<WorkPlane> createdPlanes, IList<PlanarSketch> createdSketches, IList<LoftFeature> createdRunouts,
            Func<bool> cancellationRequested)
        {
            string label = (runoutAtStart ? "start" : "end") + "-" + startIndex.ToString(CultureInfo.InvariantCulture) + "-runout";
            PackagingThreadDiagnostics.WriteEvent(label + "-begin", diagnosticContext,
                string.Format(CultureInfo.InvariantCulture,
                    "length={0:0.###} mm; sections={1}; startPhase={2:0.###} deg; handSign={3}; internalPositiveRib={4}",
                    runoutLengthCm * 10.0, PackagingThreadRunoutPolicy.GetSectionCount(runoutLengthCm * 10.0, leadCm * 10.0),
                    basePhaseRad * 180.0 / Math.PI, helixPhaseSign, internalThread));

            double totalLength = totalLengthCm;
            double stationFrom = runoutAtStart ? 0.0 : totalLength - runoutLengthCm;
            int sectionCount = PackagingThreadRunoutPolicy.GetSectionCount(runoutLengthCm * 10.0, leadCm * 10.0);
            ObjectCollection sections = app.TransientObjects.CreateObjectCollection();
            for (int sectionIndex = 0; sectionIndex < sectionCount; sectionIndex++)
            {
                ThrowIfCancellationRequested(cancellationRequested, label + "-section-" + (sectionIndex + 1).ToString(CultureInfo.InvariantCulture), diagnosticContext);
                double t = sectionIndex / (double)(sectionCount - 1);
                double stationOffsetCm = stationFrom + runoutLengthCm * t;
                double crestFactor = PackagingThreadRunoutPolicy.GetCrestFactor(t, runoutAtStart);
                double rootFactor = PackagingThreadRunoutPolicy.GetRootFactor(t, runoutAtStart, Math.Abs(fullRootRadiusCm - stockRadiusCm) * 10.0);
                double rootRadiusAtSection = stockRadiusCm + (fullRootRadiusCm - stockRadiusCm) * rootFactor;
                double crestRadiusAtSection = stockRadiusCm + (fullCrestRadiusCm - stockRadiusCm) * crestFactor;
                if (!Finite(rootRadiusAtSection) || !Finite(crestRadiusAtSection) ||
                    rootRadiusAtSection <= 0.0 || crestRadiusAtSection <= 0.0 ||
                    (internalThread ? rootRadiusAtSection <= crestRadiusAtSection : rootRadiusAtSection >= crestRadiusAtSection))
                    throw new InvalidOperationException("Недопустимый профиль сечения сбега " + (sectionIndex + 1) + "/" + sectionCount + ".");

                double phase = basePhaseRad + helixPhaseSign * 2.0 * Math.PI * (stationOffsetCm / leadCm);
                double[] stationRadial = Normalize(PackagingThreadPhaseMath.RotateAroundAxis(baseRadial, buildDirection, phase));
                double[] stationOrigin = Add(outerOrigin, Scale(buildDirection, stationOffsetCm));
                WorkPlane plane = def.WorkPlanes.AddFixed(
                    tg.CreatePoint(stationOrigin[0], stationOrigin[1], stationOrigin[2]),
                    tg.CreateUnitVector(stationRadial[0], stationRadial[1], stationRadial[2]),
                    tg.CreateUnitVector(buildDirection[0], buildDirection[1], buildDirection[2]), false);
                plane.Visible = false;
                createdPlanes.Add(plane);
                PlanarSketch sketch = def.Sketches.Add(plane);
                sketch.Visible = false;
                createdSketches.Add(sketch);

                Point2d S(double axialOffsetCm, double radiusCmAtPoint)
                {
                    Point modelPoint = tg.CreatePoint(
                        stationOrigin[0] + buildDirection[0] * axialOffsetCm + stationRadial[0] * radiusCmAtPoint,
                        stationOrigin[1] + buildDirection[1] * axialOffsetCm + stationRadial[1] * radiusCmAtPoint,
                        stationOrigin[2] + buildDirection[2] * axialOffsetCm + stationRadial[2] * radiusCmAtPoint);
                    return sketch.ModelToSketchSpace(modelPoint);
                }
                Point2d a = S(-halfWidthCm, rootRadiusAtSection);
                Point2d b = S( halfWidthCm, rootRadiusAtSection);
                Point2d c = S( halfWidthCm * crestHalfWidthRatio, crestRadiusAtSection);
                Point2d d = S(-halfWidthCm * crestHalfWidthRatio, crestRadiusAtSection);
                SketchLine l1 = sketch.SketchLines.AddByTwoPoints(a, b);
                SketchLine l2 = sketch.SketchLines.AddByTwoPoints(l1.EndSketchPoint, c);
                SketchLine l3 = sketch.SketchLines.AddByTwoPoints(l2.EndSketchPoint, d);
                sketch.SketchLines.AddByTwoPoints(l3.EndSketchPoint, l1.StartSketchPoint);
                Profile profile = sketch.Profiles.AddForSolid();
                if (profile == null) throw new InvalidOperationException("Inventor вернул пустой профиль сечения сбега " + (sectionIndex + 1) + ".");
                sections.Add(profile);
                ThrowIfCancellationRequested(cancellationRequested, label + "-after-section-" + (sectionIndex + 1).ToString(CultureInfo.InvariantCulture), diagnosticContext);
                PackagingThreadDiagnostics.WriteEvent(label + "-section", diagnosticContext,
                    string.Format(CultureInfo.InvariantCulture,
                        "section={0}/{1}; t={2:0.###}; station={3:0.###} mm; crestFactor={4:0.####}; rootFactor={5:0.####}; phase={6:0.###} deg",
                        sectionIndex + 1, sectionCount, t, stationOffsetCm * 10.0, crestFactor, rootFactor, phase * 180.0 / Math.PI));
            }

            ThrowIfCancellationRequested(cancellationRequested, label + "-before-loft-operation", diagnosticContext);
            double volumeBefore = def.MassProperties.Volume;
            int bodiesBefore = def.SurfaceBodies.Count;
            LoftDefinition definition = def.Features.LoftFeatures.CreateLoftDefinition(
                sections, PartFeatureOperationEnum.kJoinOperation);
            LoftFeature loft = def.Features.LoftFeatures.Add(definition);
            if (loft == null) throw new InvalidOperationException("Inventor не вернул LoftFeature для сбега " + label + ".");
            createdRunouts.Add(loft);
            ThrowIfCancellationRequested(cancellationRequested, label + "-after-loft", diagnosticContext);
            string name = PackagingThreadFeatureNamePolicy.CreateSafeUniqueName(
                startIndex, startCount, PackagingThreadGeometryPolicy.GetStartPhaseDegrees(startIndex - 1, startCount), Guid.NewGuid());
            try { loft.Name = name + (runoutAtStart ? "_RunIn" : "_RunOut"); } catch { }
            ThrowIfCancellationRequested(cancellationRequested, label + "-before-update", diagnosticContext);
            doc.Update();
            ThrowIfCancellationRequested(cancellationRequested, label + "-after-update", diagnosticContext);
            if (loft.HealthStatus != HealthStatusEnum.kUpToDateHealth)
                throw new InvalidOperationException("Loft сбега " + label + " создан с состоянием " + loft.HealthStatus + ".");
            double volumeAfter = def.MassProperties.Volume;
            int bodiesAfter = def.SurfaceBodies.Count;
            double tolerance = Math.Max(1e-8, Math.Abs(volumeBefore) * 1e-10);
            if (!Finite(volumeAfter) || volumeAfter - volumeBefore <= tolerance)
                throw new InvalidOperationException("Loft сбега " + label + " не добавил измеримый объём.");
            if (bodiesAfter != bodiesBefore)
                throw new InvalidOperationException("Loft сбега " + label + " создал отдельное тело вместо соединения с резьбой/деталью.");
            PackagingThreadDiagnostics.WriteEvent(label + "-verified", diagnosticContext,
                string.Format(CultureInfo.InvariantCulture,
                    "Loft Join verified; featureName={0}; sectionCount={1}; volumeDelta={2:0.##########} cm^3; bodyCount={3}; terminalCrestFactor={4:0.###}; internalPositiveRib={5}.",
                    name, sectionCount, volumeAfter - volumeBefore, bodiesAfter, PackagingThreadRunoutPolicy.TerminalCrestFactor, internalThread));
            return loft;
        }

        private static List<int> EnumerableRange(int count)
        {
            var values = new List<int>(count);
            for (int i = 0; i < count; i++) values.Add(i);
            return values;
        }

        private static double[] Add(double[] a, double[] b) => new[] { a[0] + b[0], a[1] + b[1], a[2] + b[2] };
        private static double[] Scale(double[] vector, double factor) => new[] { vector[0] * factor, vector[1] * factor, vector[2] * factor };

        private static Face FindCylindricalFace(Edge edge)
        {
            if (edge == null) return null;
            double edgeRadiusCm;
            try
            {
                dynamic curve = edge.Geometry;
                edgeRadiusCm = Convert.ToDouble(curve.Radius, CultureInfo.InvariantCulture);
            }
            catch { return null; }
            if (!Finite(edgeRadiusCm) || edgeRadiusCm <= 0.0) return null;

            Face bestFace = null;
            double bestRadiusDifference = double.PositiveInfinity;
            try
            {
                foreach (Face candidate in edge.Faces)
                {
                    if (candidate == null || candidate.SurfaceType != SurfaceTypeEnum.kCylinderSurface) continue;
                    Cylinder candidateCylinder = candidate.Geometry as Cylinder;
                    if (candidateCylinder == null) continue;
                    double difference = Math.Abs(candidateCylinder.Radius - edgeRadiusCm);
                    if (difference < bestRadiusDifference)
                    {
                        bestRadiusDifference = difference;
                        bestFace = candidate;
                    }
                }
            }
            catch { return null; }
            double toleranceCm = Math.Max(0.001, edgeRadiusCm * 1e-5);
            return bestFace != null && bestRadiusDifference <= toleranceCm ? bestFace : null;
        }

        private static double GetEdgeAxialCoordinate(Edge edge, double[] basePoint, double[] axis)
        {
            try
            {
                dynamic curve = edge.Geometry;
                Point center = curve.Center;
                double axial = Dot(new[] { center.X - basePoint[0], center.Y - basePoint[1], center.Z - basePoint[2] }, axis);
                if (Finite(axial)) return axial;
            }
            catch { }
            throw new InvalidOperationException("Не удалось определить положение выбранного ребра вдоль оси цилиндра.");
        }

        private static double[] Normalize(double[] v)
        {
            double n = Math.Sqrt(Dot(v, v));
            if (!Finite(n) || n < 1e-12) throw new InvalidOperationException("Невозможно определить направление оси/радиуса.");
            return new[] { v[0] / n, v[1] / n, v[2] / n };
        }
        private static double Dot(double[] a, double[] b) => a[0] * b[0] + a[1] * b[1] + a[2] * b[2];
        private static double[] Cross(double[] a, double[] b) => new[] { a[1] * b[2] - a[2] * b[1], a[2] * b[0] - a[0] * b[2], a[0] * b[1] - a[1] * b[0] };
        private static bool Finite(double v) => !double.IsNaN(v) && !double.IsInfinity(v);
    }
}
