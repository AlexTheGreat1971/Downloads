﻿using System;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Runtime.InteropServices;
using System.Windows.Forms;
using Inventor;

namespace ThreadPro
{
    internal sealed class WindowWrapper : System.Windows.Forms.IWin32Window
    {
        public WindowWrapper(IntPtr handle) { Handle = handle; }
        public IntPtr Handle { get; private set; }
    }

    // Converts System.Drawing images into IPictureDisp for Inventor button icons.
    internal sealed class PictureConverter : System.Windows.Forms.AxHost
    {
        private PictureConverter() : base("59EE46BA-677D-4D20-BF10-8D8EB5F67A9C") { }
        public static object ToPicture(Image img) { return GetIPictureDispFromPicture(img); }
    }

    [ComVisible(true)]
    [Guid("7A3C1E52-9B4D-4F6A-8C21-5D0E7B9A1F34")]
    public class ThreadProAddIn : ApplicationAddInServer
    {
        public const string ClientIdStr = "{7A3C1E52-9B4D-4F6A-8C21-5D0E7B9A1F34}";
        private const string CmdName = "Helivanta.Cmd.Build";
        private const string EditCmdName = "Helivanta.Cmd.EditThread";
        private const string PackagingCmdName = "Helivanta.Cmd.PackagingThread";

        private Inventor.Application _app;
        private Inventor.ApplicationEvents _applicationEvents;
        private Inventor.TransactionEvents _transactionEvents;
        private System.Windows.Forms.Timer _undoHistoryBoundaryTimer;
        private int _undoHistoryBoundaryRetries;
        private string _undoHistoryBoundaryTrigger;
        private bool _undoHistoryBoundarySequencePending;
        private bool _undoHistoryBoundaryObservedNonSingleDocumentCount;
        private ButtonDefinition _btn;
        private ButtonDefinition _editBtn;
        private ButtonDefinition _packagingBtn;

        private string _ribbonLanguage;

        public void Activate(ApplicationAddInSite addInSiteObject, bool firstTime)
        {
            _app = addInSiteObject.Application;
            try { AttachUndoHistoryBoundaryEvents(); }
            catch (Exception ex) { WriteUndoHistoryBoundaryLog("attach-failed: " + ex.Message); }

            HelivantaUserSettings.SettingsSaved -= OnUserSettingsSaved;
            HelivantaUserSettings.SettingsSaved += OnUserSettingsSaved;
            try
            {
                BuildRibbonUi();
                _ribbonLanguage = HelivantaUserSettings.Current.Language ?? "ru";
            }
            catch (Exception ex)
            {
                System.Windows.Forms.MessageBox.Show(HelivantaLocalization.Translate("Helivanta: не удалось создать кнопку.") + "\n" + ex.Message, "Helivanta");
            }
        }

        private void BuildRibbonUi()
        {
            // The existing command definitions may be reused by Inventor across add-in reloads.
            // Detach this instance's sinks before a language change recreates them.
            try { if (_btn != null) _btn.OnExecute -= new ButtonDefinitionSink_OnExecuteEventHandler(OnExecute); } catch { }
            try { if (_editBtn != null) _editBtn.OnExecute -= new ButtonDefinitionSink_OnExecuteEventHandler(OnExecuteEdit); } catch { }
            try { if (_packagingBtn != null) _packagingBtn.OnExecute -= new ButtonDefinitionSink_OnExecuteEventHandler(OnExecutePackagingThread); } catch { }
            Ribbon ribbon = _app.UserInterfaceManager.Ribbons["Part"];
            RibbonTab tab = null;
            try { tab = ribbon.RibbonTabs["Helivanta.Tab"]; } catch { tab = null; }

            // Remove our old panel first. Inventor keeps add-in ControlDefinitions alive
            // across unload/reload cycles, and their DisplayName is read-only in the API.
            // Rebuilding our own panel releases command-control references so an old
            // definition can safely be replaced when a visible caption changes.
            if (tab != null)
            {
                try { tab.RibbonPanels["Helivanta.Panel.Main"].Delete(); } catch { }
            }

            ControlDefinitions defs = _app.CommandManager.ControlDefinitions;
            _btn = null;
            try { _btn = (ButtonDefinition)defs[CmdName]; } catch { _btn = null; }
            if (_btn != null && !string.Equals(_btn.DisplayName, HelivantaLocalization.Translate("Создать резьбу"), StringComparison.Ordinal))
            {
                try { _btn.Delete(); _btn = null; }
                catch (Exception ex)
                {
                    throw new InvalidOperationException(
                        "Не удалось обновить сохранённую команду «Создать резьбу». Закройте старую панель Helivanta и повторите запуск.", ex);
                }
            }

            if (_btn == null)
            {
                object small = PictureConverter.ToPicture(MakeIcon(16));
                object large = PictureConverter.ToPicture(MakeIcon(32));
                dynamic d = defs;   // late-bound: icon parameter type differs between interop builds
                _btn = d.AddButtonDefinition(
                    HelivantaLocalization.Translate("Создать резьбу"), CmdName,
                    CommandTypesEnum.kNonShapeEditCmdType, ClientIdStr,
                    HelivantaLocalization.Translate("Helivanta: создание физической резьбы (ISO / BSW / ANSI / Tr / S / Rd)"),
                    HelivantaLocalization.Translate("Создать физическую резьбу: выбрать тип, стандарт, размер, технологию и параметры построения"),
                    small, large, ButtonDisplayEnum.kDisplayTextInLearningMode);
            }
            _btn.DescriptionText = HelivantaLocalization.Translate("Helivanta: создание физической резьбы (ISO / BSW / ANSI / Tr / S / Rd)");
            _btn.ToolTipText = HelivantaLocalization.Translate("Создать резьбу — Построить");
            try { _btn.OnExecute -= new ButtonDefinitionSink_OnExecuteEventHandler(OnExecute); } catch { }
            _btn.OnExecute += new ButtonDefinitionSink_OnExecuteEventHandler(OnExecute);

            _editBtn = null;
            try { _editBtn = (ButtonDefinition)defs[EditCmdName]; } catch { _editBtn = null; }
            if (_editBtn != null && !string.Equals(_editBtn.DisplayName, HelivantaLocalization.Translate("Изменить резьбу"), StringComparison.Ordinal))
            {
                try { _editBtn.Delete(); _editBtn = null; }
                catch (Exception ex)
                {
                    throw new InvalidOperationException(
                        "Не удалось обновить сохранённую команду «Изменить резьбу». Закройте старую панель Helivanta и повторите запуск.", ex);
                }
            }

            if (_editBtn == null)
            {
                object smallEdit = PictureConverter.ToPicture(MakeIcon(16));
                object largeEdit = PictureConverter.ToPicture(MakeIcon(32));
                dynamic d = defs;
                _editBtn = d.AddButtonDefinition(
                    HelivantaLocalization.Translate("Изменить резьбу"), EditCmdName,
                    CommandTypesEnum.kNonShapeEditCmdType, ClientIdStr,
                    HelivantaLocalization.Translate("Helivanta: редактирование резьбы Helivanta или штатной операции «Резьба Inventor»"),
                    HelivantaLocalization.Translate("Выберите папку/объект резьбы Helivanta либо штатную операцию «Резьба Inventor» в дереве модели"),
                    smallEdit, largeEdit, ButtonDisplayEnum.kDisplayTextInLearningMode);
            }
            _editBtn.DescriptionText = HelivantaLocalization.Translate("Helivanta: редактирование резьбы Helivanta или штатной операции «Резьба Inventor»");
            _editBtn.ToolTipText = HelivantaLocalization.Translate("Изменить резьбу — Изменить параметры");
            try { _editBtn.OnExecute -= new ButtonDefinitionSink_OnExecuteEventHandler(OnExecuteEdit); } catch { }
            _editBtn.OnExecute += new ButtonDefinitionSink_OnExecuteEventHandler(OnExecuteEdit);

            _packagingBtn = null;
            try { _packagingBtn = (ButtonDefinition)defs[PackagingCmdName]; } catch { _packagingBtn = null; }
            if (_packagingBtn != null && !string.Equals(_packagingBtn.DisplayName, HelivantaLocalization.Translate("Упаковочная резьба (эксперимент)"), StringComparison.Ordinal))
            {
                try { _packagingBtn.Delete(); _packagingBtn = null; } catch { }
            }
            if (_packagingBtn == null)
            {
                object smallPackaging = PictureConverter.ToPicture(MakeIcon(16));
                object largePackaging = PictureConverter.ToPicture(MakeIcon(32));
                dynamic d = defs;
                _packagingBtn = d.AddButtonDefinition(
                    HelivantaLocalization.Translate("Упаковочная резьба (эксперимент)"), PackagingCmdName,
                    CommandTypesEnum.kNonShapeEditCmdType, ClientIdStr,
                    HelivantaLocalization.Translate("Экспериментальная полу-стандартная упаковочная резьба; геометрический построитель пока не подключён"),
                    HelivantaLocalization.Translate("Выберите цилиндрическую грань и проверьте параметры упаковочной резьбы"),
                    smallPackaging, largePackaging, ButtonDisplayEnum.kDisplayTextInLearningMode);
            }
            try { _packagingBtn.OnExecute -= new ButtonDefinitionSink_OnExecuteEventHandler(OnExecutePackagingThread); } catch { }
            _packagingBtn.OnExecute += new ButtonDefinitionSink_OnExecuteEventHandler(OnExecutePackagingThread);

            // remove UI left by older versions (named "ThreadPro")
            try { ribbon.RibbonTabs["id_TabTools"].RibbonPanels["ThreadPro.Panel"].Delete(); } catch { }
            try { ribbon.RibbonTabs["ThreadPro.Tab"].Delete(); } catch { }

            tab = null;
            try { tab = ribbon.RibbonTabs["Helivanta.Tab"]; } catch { tab = null; }
            if (tab == null)
            {
                try { tab = ribbon.RibbonTabs.Add("Helivanta", "Helivanta.Tab", ClientIdStr, "id_TabModel", false); }
                catch { tab = ribbon.RibbonTabs.Add("Helivanta", "Helivanta.Tab", ClientIdStr); }
            }
            RibbonPanel panel = null;
            try { panel = tab.RibbonPanels["Helivanta.Panel.Main"]; } catch { panel = null; }
            if (panel == null)
                panel = tab.RibbonPanels.Add(HelivantaLocalization.Translate("Физическая резьба"), "Helivanta.Panel.Main", ClientIdStr, "", false);
            try { panel.CommandControls.AddButton(_btn, true, true, "", false); } catch { }
            try { panel.CommandControls.AddButton(_editBtn, true, true, "", false); } catch { }
            try { panel.CommandControls.AddButton(_packagingBtn, true, true, "", false); } catch { }
        }

        private void OnUserSettingsSaved(object sender, EventArgs e)
        {
            if (_app == null) return;
            string language = HelivantaUserSettings.Current.Language ?? "ru";
            if (string.Equals(language, _ribbonLanguage, StringComparison.OrdinalIgnoreCase)) return;
            try
            {
                BuildRibbonUi();
                _ribbonLanguage = language;
            }
            catch (Exception ex)
            {
                System.Windows.Forms.MessageBox.Show(
                    HelivantaLocalization.Translate("Не удалось обновить язык команд ленты.") + "\n" + ex.Message,
                    "Helivanta");
            }
        }

        public void Deactivate()
        {
            HelivantaUserSettings.SettingsSaved -= OnUserSettingsSaved;
            _ribbonLanguage = null;
            TransactionLifecycleDiagnostics.Write("ThreadProAddIn", "Deactivate.begin", _app);
            DetachUndoHistoryBoundaryEvents();
            CloseEditSelectionPrompt();
            if (_dlg != null)
            {
                ThreadDialog closingDialog = _dlg;
                try { closingDialog.Close(); } catch { }
                try { if (!closingDialog.IsDisposed) closingDialog.Dispose(); } catch { }
                _dlg = null;
            }
            if (_btn != null)
            {
                try { _btn.OnExecute -= new ButtonDefinitionSink_OnExecuteEventHandler(OnExecute); } catch { }
                _btn = null;
            }
            if (_editBtn != null)
            {
                try { _editBtn.OnExecute -= new ButtonDefinitionSink_OnExecuteEventHandler(OnExecuteEdit); } catch { }
                _editBtn = null;
            }
            if (_packagingBtn != null)
            {
                try { _packagingBtn.OnExecute -= new ButtonDefinitionSink_OnExecuteEventHandler(OnExecutePackagingThread); } catch { }
                _packagingBtn = null;
            }
            _app = null;
            GC.Collect();
            GC.WaitForPendingFinalizers();
        }

        public void ExecuteCommand(int commandID) { }
        public object Automation { get { return null; } }

        private void AttachUndoHistoryBoundaryEvents()
        {
            if (_app == null) return;
            _applicationEvents = _app.ApplicationEvents;
            _applicationEvents.OnOpenDocument += new ApplicationEventsSink_OnOpenDocumentEventHandler(OnOpenDocumentForUndoBoundary);
            _applicationEvents.OnNewDocument += new ApplicationEventsSink_OnNewDocumentEventHandler(OnNewDocumentForUndoBoundary);

            try { _transactionEvents = _app.TransactionManager.TransactionEvents; }
            catch (Exception ex)
            {
                _transactionEvents = null;
                TransactionLifecycleDiagnostics.Write("ThreadProAddIn", "TransactionEvents.get-failed", _app,
                    null, null, false, ex.ToString());
            }
            if (_transactionEvents != null)
            {
                try { _transactionEvents.OnUndo += AddInTransactionEvents_OnUndo; }
                catch (Exception ex) { TransactionLifecycleDiagnostics.Write("ThreadProAddIn", "TransactionEvents.OnUndo.attach-failed", _app, null, null, false, ex.ToString()); }
                try { _transactionEvents.OnRedo += AddInTransactionEvents_OnRedo; }
                catch (Exception ex) { TransactionLifecycleDiagnostics.Write("ThreadProAddIn", "TransactionEvents.OnRedo.attach-failed", _app, null, null, false, ex.ToString()); }
                try { _transactionEvents.OnCommit += AddInTransactionEvents_OnCommit; }
                catch (Exception ex) { TransactionLifecycleDiagnostics.Write("ThreadProAddIn", "TransactionEvents.OnCommit.attach-failed", _app, null, null, false, ex.ToString()); }
                try { _transactionEvents.OnAbort += AddInTransactionEvents_OnAbort; }
                catch (Exception ex) { TransactionLifecycleDiagnostics.Write("ThreadProAddIn", "TransactionEvents.OnAbort.attach-failed", _app, null, null, false, ex.ToString()); }
                try { _transactionEvents.OnDelete += AddInTransactionEvents_OnDelete; }
                catch (Exception ex) { TransactionLifecycleDiagnostics.Write("ThreadProAddIn", "TransactionEvents.OnDelete.attach-failed", _app, null, null, false, ex.ToString()); }
                TransactionLifecycleDiagnostics.Write("ThreadProAddIn", "TransactionEvents.attach-attempted", _app);
            }

            _undoHistoryBoundaryTimer = new System.Windows.Forms.Timer { Interval = 220 };
            _undoHistoryBoundaryTimer.Tick += UndoHistoryBoundaryTimer_Tick;
        }

        private void DetachUndoHistoryBoundaryEvents()
        {
            try
            {
                if (_applicationEvents != null)
                {
                    _applicationEvents.OnOpenDocument -= new ApplicationEventsSink_OnOpenDocumentEventHandler(OnOpenDocumentForUndoBoundary);
                    _applicationEvents.OnNewDocument -= new ApplicationEventsSink_OnNewDocumentEventHandler(OnNewDocumentForUndoBoundary);
                }
            }
            catch { }
            if (_transactionEvents != null)
            {
                try { _transactionEvents.OnUndo -= AddInTransactionEvents_OnUndo; } catch { }
                try { _transactionEvents.OnRedo -= AddInTransactionEvents_OnRedo; } catch { }
                try { _transactionEvents.OnCommit -= AddInTransactionEvents_OnCommit; } catch { }
                try { _transactionEvents.OnAbort -= AddInTransactionEvents_OnAbort; } catch { }
                try { _transactionEvents.OnDelete -= AddInTransactionEvents_OnDelete; } catch { }
            }
            _transactionEvents = null;
            try
            {
                if (_undoHistoryBoundaryTimer != null)
                {
                    _undoHistoryBoundaryTimer.Stop();
                    _undoHistoryBoundaryTimer.Tick -= UndoHistoryBoundaryTimer_Tick;
                    _undoHistoryBoundaryTimer.Dispose();
                }
            }
            catch { }
            _undoHistoryBoundaryTimer = null;
            _applicationEvents = null;
            _undoHistoryBoundarySequencePending = false;
            _undoHistoryBoundaryObservedNonSingleDocumentCount = false;
            _undoHistoryBoundaryRetries = 0;
            _undoHistoryBoundaryTrigger = null;
        }

        private void OnOpenDocumentForUndoBoundary(Inventor._Document documentObject, string fullDocumentName,
            Inventor.EventTimingEnum beforeOrAfter, Inventor.NameValueMap context,
            out Inventor.HandlingCodeEnum handlingCode)
        {
            handlingCode = Inventor.HandlingCodeEnum.kEventNotHandled;
            TransactionLifecycleDiagnostics.Write("ThreadProAddIn", "ApplicationEvents.OnOpenDocument." + beforeOrAfter,
                _app, documentObject, null, false, "fullDocumentName=" + (fullDocumentName ?? string.Empty));
            if (beforeOrAfter != Inventor.EventTimingEnum.kAfter) return;
            ScheduleUndoHistoryBoundary("open: " + (fullDocumentName ?? string.Empty));
        }

        private void OnNewDocumentForUndoBoundary(Inventor._Document documentObject,
            Inventor.EventTimingEnum beforeOrAfter, Inventor.NameValueMap context,
            out Inventor.HandlingCodeEnum handlingCode)
        {
            handlingCode = Inventor.HandlingCodeEnum.kEventNotHandled;
            TransactionLifecycleDiagnostics.Write("ThreadProAddIn", "ApplicationEvents.OnNewDocument." + beforeOrAfter,
                _app, documentObject, null, false);
            if (beforeOrAfter != Inventor.EventTimingEnum.kAfter) return;
            string name = string.Empty;
            try { if (documentObject != null) name = documentObject.DisplayName; } catch { }
            ScheduleUndoHistoryBoundary("new: " + name);
        }

        private void ScheduleUndoHistoryBoundary(string trigger)
        {
            try
            {
                if (_app == null || _undoHistoryBoundaryTimer == null) return;

                // Opening an assembly can raise several open-document events for referenced files.
                // Remember any non-single-document state seen anywhere in this coalesced sequence;
                // a later count of one must not retroactively make that sequence safe to clear.
                if (!_undoHistoryBoundarySequencePending)
                {
                    _undoHistoryBoundarySequencePending = true;
                    _undoHistoryBoundaryObservedNonSingleDocumentCount = false;
                    _undoHistoryBoundaryRetries = 0;
                }

                int countAtEvent = _app.Documents.Count;
                if (countAtEvent != 1)
                    _undoHistoryBoundaryObservedNonSingleDocumentCount = true;

                _undoHistoryBoundaryTrigger = trigger ?? string.Empty;
                TransactionLifecycleDiagnostics.Write("ThreadProAddIn", "UndoBoundary.schedule", _app,
                    null, null, false,
                    "trigger=" + _undoHistoryBoundaryTrigger + "; openDocuments=" + countAtEvent +
                    "; observedNonSingleCount=" + _undoHistoryBoundaryObservedNonSingleDocumentCount +
                    "; retries=" + _undoHistoryBoundaryRetries);
                _undoHistoryBoundaryTimer.Interval = 220;
                _undoHistoryBoundaryTimer.Stop();
                _undoHistoryBoundaryTimer.Start();
            }
            catch (Exception ex)
            {
                WriteUndoHistoryBoundaryLog("schedule-failed: " + ex.Message);
                FinishUndoHistoryBoundarySequence();
            }
        }

        private void UndoHistoryBoundaryTimer_Tick(object sender, EventArgs e)
        {
            try { if (_undoHistoryBoundaryTimer != null) _undoHistoryBoundaryTimer.Stop(); } catch { }
            if (_app == null) return;

            TransactionLifecycleDiagnostics.Write("ThreadProAddIn", "UndoBoundary.timer-tick", _app,
                null, null, false,
                "trigger=" + _undoHistoryBoundaryTrigger + "; retries=" + _undoHistoryBoundaryRetries +
                "; observedNonSingleCount=" + _undoHistoryBoundaryObservedNonSingleDocumentCount);
            int documentCount;
            try { documentCount = _app.Documents.Count; }
            catch (Exception ex)
            {
                WriteUndoHistoryBoundaryLog("check-document-count-failed: " + ex.Message);
                FinishUndoHistoryBoundarySequence();
                return;
            }

            if (!UndoHistoryBoundaryPolicy.ShouldClearAllTransactions(
                    documentCount, _undoHistoryBoundaryObservedNonSingleDocumentCount))
            {
                // Inventor's ClearAllTransactions clears both Undo and Redo for the whole app.
                // Preserve history if the current count is not one OR if a multi-document state
                // was observed earlier in the same open/new sequence.
                WriteUndoHistoryBoundaryLog("skipped; openDocuments=" + documentCount +
                    "; observedNonSingleCount=" + _undoHistoryBoundaryObservedNonSingleDocumentCount +
                    "; trigger=" + _undoHistoryBoundaryTrigger);
                FinishUndoHistoryBoundarySequence();
                return;
            }

            try
            {
                // Inventor may return a non-null sentinel called "Unidentified transaction"
                // when no identified transaction is active. It must not block the boundary forever.
                // Any named, unreadable, or otherwise unexpected transaction is treated as active.
                Inventor.Transaction currentTransaction = _app.TransactionManager.CurrentTransaction;
                string currentTransactionName = currentTransaction == null ? null : currentTransaction.DisplayName;
                TransactionLifecycleDiagnostics.Write("ThreadProAddIn", "UndoBoundary.transaction-state", _app,
                    null, currentTransaction, false,
                    "displayName=" + (currentTransactionName ?? "<null>") +
                    "; identifiedActive=" + (currentTransaction != null && UndoHistoryBoundaryPolicy.IsIdentifiedTransactionInProgress(currentTransactionName)));
                if (currentTransaction != null && UndoHistoryBoundaryPolicy.IsIdentifiedTransactionInProgress(currentTransactionName))
                {
                    RetryOrLogUndoHistoryBoundary("identified-transaction-still-active: " + (currentTransactionName ?? "<empty-name>"));
                    return;
                }

                // Check the condition again immediately before the app-wide destructive call.
                documentCount = _app.Documents.Count;
                if (!UndoHistoryBoundaryPolicy.ShouldClearAllTransactions(
                        documentCount, _undoHistoryBoundaryObservedNonSingleDocumentCount))
                {
                    WriteUndoHistoryBoundaryLog("skipped-before-clear; openDocuments=" + documentCount +
                        "; observedNonSingleCount=" + _undoHistoryBoundaryObservedNonSingleDocumentCount +
                        "; trigger=" + _undoHistoryBoundaryTrigger);
                    FinishUndoHistoryBoundarySequence();
                    return;
                }

                TransactionLifecycleDiagnostics.Write("ThreadProAddIn", "UndoBoundary.ClearAllTransactions.before", _app,
                    null, null, false, "openDocuments=" + documentCount + "; trigger=" + _undoHistoryBoundaryTrigger);
                _app.TransactionManager.ClearAllTransactions();
                TransactionLifecycleDiagnostics.Write("ThreadProAddIn", "UndoBoundary.ClearAllTransactions.after", _app,
                    null, null, false, "openDocuments=" + documentCount + "; trigger=" + _undoHistoryBoundaryTrigger);
                WriteUndoHistoryBoundaryLog("cleared; openDocuments=1; observedNonSingleCount=false; currentTransaction=" +
                    (currentTransactionName ?? "none") + "; trigger=" + _undoHistoryBoundaryTrigger);
                FinishUndoHistoryBoundarySequence();
            }
            catch (Exception ex)
            {
                RetryOrLogUndoHistoryBoundary("clear-failed: " + ex.Message);
            }
        }

        private void RetryOrLogUndoHistoryBoundary(string reason)
        {
            if (_undoHistoryBoundaryTimer != null && _undoHistoryBoundaryRetries < 6)
            {
                TransactionLifecycleDiagnostics.Write("ThreadProAddIn", "UndoBoundary.retry-scheduled", _app,
                    null, null, false, "reason=" + reason + "; retriesBeforeIncrement=" + _undoHistoryBoundaryRetries +
                    "; trigger=" + _undoHistoryBoundaryTrigger);
                _undoHistoryBoundaryRetries++;
                _undoHistoryBoundaryTimer.Interval = 220;
                _undoHistoryBoundaryTimer.Start();
                return;
            }
            TransactionLifecycleDiagnostics.Write("ThreadProAddIn", "UndoBoundary.final-failure", _app,
                null, null, false, "failed-after-retries=" + _undoHistoryBoundaryRetries +
                "; reason=" + reason + "; trigger=" + _undoHistoryBoundaryTrigger);
            WriteUndoHistoryBoundaryLog("failed-after-retries=" + _undoHistoryBoundaryRetries + "; reason=" + reason + "; trigger=" + _undoHistoryBoundaryTrigger);
            FinishUndoHistoryBoundarySequence();
        }

        private void FinishUndoHistoryBoundarySequence()
        {
            try { if (_undoHistoryBoundaryTimer != null) _undoHistoryBoundaryTimer.Stop(); } catch { }
            _undoHistoryBoundarySequencePending = false;
            _undoHistoryBoundaryObservedNonSingleDocumentCount = false;
            _undoHistoryBoundaryRetries = 0;
            _undoHistoryBoundaryTrigger = null;
        }

        private void AddInTransactionEvents_OnUndo(Inventor.Transaction TransactionObject,
            Inventor.NameValueMap Context, Inventor.EventTimingEnum BeforeOrAfter,
            out Inventor.HandlingCodeEnum HandlingCode)
        {
            HandlingCode = Inventor.HandlingCodeEnum.kEventNotHandled;
            TransactionLifecycleDiagnostics.Write("ThreadProAddIn.TransactionEvents",
                "OnUndo." + BeforeOrAfter, _app, null, TransactionObject,
                BeforeOrAfter == Inventor.EventTimingEnum.kAfter,
                "context=" + (Context == null ? "null" : "present"));
        }

        private void AddInTransactionEvents_OnRedo(Inventor.Transaction TransactionObject,
            Inventor.NameValueMap Context, Inventor.EventTimingEnum BeforeOrAfter,
            out Inventor.HandlingCodeEnum HandlingCode)
        {
            HandlingCode = Inventor.HandlingCodeEnum.kEventNotHandled;
            TransactionLifecycleDiagnostics.Write("ThreadProAddIn.TransactionEvents",
                "OnRedo." + BeforeOrAfter, _app, null, TransactionObject,
                BeforeOrAfter == Inventor.EventTimingEnum.kAfter,
                "context=" + (Context == null ? "null" : "present"));
        }

        private void AddInTransactionEvents_OnCommit(Inventor.Transaction TransactionObject,
            Inventor.NameValueMap Context, Inventor.EventTimingEnum BeforeOrAfter,
            out Inventor.HandlingCodeEnum HandlingCode)
        {
            HandlingCode = Inventor.HandlingCodeEnum.kEventNotHandled;
            TransactionLifecycleDiagnostics.Write("ThreadProAddIn.TransactionEvents",
                "OnCommit." + BeforeOrAfter, _app, null, TransactionObject,
                false,
                "context=" + (Context == null ? "null" : "present"));
        }

        private void AddInTransactionEvents_OnAbort(Inventor.Transaction TransactionObject,
            Inventor.NameValueMap Context, Inventor.EventTimingEnum BeforeOrAfter)
        {
            // Inventor documents that the Transaction object is only fully functional before Abort;
            // the after-event still records the current transaction state and model body count.
            Inventor.Transaction transactionForLog = BeforeOrAfter == Inventor.EventTimingEnum.kBefore
                ? TransactionObject : null;
            TransactionLifecycleDiagnostics.Write("ThreadProAddIn.TransactionEvents",
                "OnAbort." + BeforeOrAfter, _app, null, transactionForLog,
                BeforeOrAfter == Inventor.EventTimingEnum.kAfter,
                "context=" + (Context == null ? "null" : "present") +
                "; post-abort TransactionObject not queried=" + (BeforeOrAfter == Inventor.EventTimingEnum.kAfter));
        }

        private void AddInTransactionEvents_OnDelete(Inventor.Transaction TransactionObject,
            Inventor.NameValueMap Context, Inventor.EventTimingEnum BeforeOrAfter)
        {
            // OnDelete is delivered after the transaction leaves the stack; Autodesk documents the
            // Transaction object as no longer functional, so do not query its properties.
            TransactionLifecycleDiagnostics.Write("ThreadProAddIn.TransactionEvents",
                "OnDelete." + BeforeOrAfter, _app, null, null, false,
                "deleted transaction object intentionally not queried; context=" +
                (Context == null ? "null" : "present"));
        }

        private static void WriteUndoHistoryBoundaryLog(string message)
        {
            try
            {
                string directory = System.IO.Path.Combine(
                    System.Environment.GetFolderPath(System.Environment.SpecialFolder.LocalApplicationData),
                    "Helivanta", "Logs");
                System.IO.Directory.CreateDirectory(directory);
                DiagnosticLogMaintenance.Append(directory, "undo-boundary.log",
                    System.DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss.fff") + " " + message + System.Environment.NewLine);
            }
            catch { }
        }

        private static Bitmap MakeIcon(int size)
        {
            foreach (string name in Assembly.GetExecutingAssembly().GetManifestResourceNames())
            {
                if (!name.EndsWith("Helivanta-ThreadIcon.png", StringComparison.OrdinalIgnoreCase)) continue;
                using (Stream s = Assembly.GetExecutingAssembly().GetManifestResourceStream(name))
                using (Image source = Image.FromStream(s))
                {
                    var bmp = new Bitmap(size, size);
                    using (var g = Graphics.FromImage(bmp))
                    {
                        g.SmoothingMode = System.Drawing.Drawing2D.SmoothingMode.HighQuality;
                        g.InterpolationMode = System.Drawing.Drawing2D.InterpolationMode.HighQualityBicubic;
                        g.PixelOffsetMode = System.Drawing.Drawing2D.PixelOffsetMode.HighQuality;
                        g.Clear(System.Drawing.Color.Transparent);
                        g.DrawImage(source, new Rectangle(0, 0, size, size));
                    }
                    return bmp;
                }
            }
            return new Bitmap(size, size);
        }

        private ThreadDialog _dlg;
        private EditSelectionPrompt _editSelectionPrompt;
        private bool _openingDialog;

        private void QueueInventorForegroundRestoreAfterDialogClose()
        {
            if (_app == null) return;
            IntPtr inventorHandle;
            try { inventorHandle = new IntPtr(_app.MainFrameHWND); }
            catch { return; }
            if (inventorHandle == IntPtr.Zero) return;

            // Request Inventor immediately, then verify/retry after the owner-window transition.
            // This avoids a visible flash of the previously focused app without asking Windows
            // to restore/minimize/resize the Inventor frame.
            bool immediateFocused = false;
            try { immediateFocused = NativeWindowPositioning.ActivateOwnerAfterClose(inventorHandle); }
            catch { }
            try
            {
                TransactionLifecycleDiagnostics.Write("ThreadProAddIn", "inventor-foreground-immediate-after-close",
                    _app, null, null, false,
                    "ownerHwnd=" + inventorHandle + "; activationVerified=" + immediateFocused);
            }
            catch { }

            var timer = new System.Windows.Forms.Timer { Interval = 140 };
            int attempts = 0;
            timer.Tick += (s, e) =>
            {
                if (_dlg != null && !_dlg.IsDisposed)
                {
                    try { timer.Stop(); } catch { }
                    try { timer.Dispose(); } catch { }
                    return;
                }

                attempts++;
                bool focused = false;
                try
                {
                    if (_app != null) focused = NativeWindowPositioning.ActivateOwnerAfterClose(inventorHandle);
                }
                catch { }

                if (focused || attempts >= 4 || _app == null)
                {
                    try { timer.Stop(); } catch { }
                    try { timer.Dispose(); } catch { }
                    try
                    {
                        TransactionLifecycleDiagnostics.Write("ThreadProAddIn", "inventor-foreground-after-close",
                            _app, null, null, false,
                            "ownerHwnd=" + inventorHandle + "; activationVerified=" + focused + "; attempts=" + attempts);
                    }
                    catch { }
                }
            };
            timer.Start();
        }

        // The dialog is modeless so Inventor geometry remains selectable while it is open.
        // Show a lightweight splash before any dialog construction/layout work, otherwise on
        // slower machines the ribbon click appears to do nothing for several seconds.
        private void OnExecute(NameValueMap context)
        {
            if (_dlg != null && !_dlg.IsDisposed)
            {
                try { _dlg.Activate(); } catch { }
                return;
            }
            if (_openingDialog) return;

            _openingDialog = true;
            LoadingSplash splash = null;
            try
            {
                var mainFrameHandle = new IntPtr(_app.MainFrameHWND);
                var owner = new WindowWrapper(mainFrameHandle);

                splash = new LoadingSplash(mainFrameHandle);
                // Create and natively position the HWND before showing it, so no initial
                // WinForms/DPI-scaled (0,0) placement is ever painted on the left.
                splash.Opacity = 0.0;
                _ = splash.Handle;
                splash.EnsureRightPosition(mainFrameHandle);
                splash.Show(owner);
                splash.EnsureRightPosition(mainFrameHandle);
                splash.Opacity = 1.0;
                splash.Refresh();
                // Force the first paint before constructing the full dialog. The handler is
                // re-entry guarded by _openingDialog because DoEvents pumps the UI message queue.
                System.Windows.Forms.Application.DoEvents();
                splash?.EnsureRightPosition(mainFrameHandle);

                if (!(_app.ActiveDocument is PartDocument))
                {
                    CloseSplashSafely(splash);
                    splash = null;
                    System.Windows.Forms.MessageBox.Show(
                        HelivantaLocalization.Translate("Откройте деталь (.ipt) — физическая резьба строится в среде детали."), "Helivanta");
                    return;
                }

                _dlg = new ThreadDialog(_app);
                _dlg.EditSelectionRequested += BeginEditSelectionFromDialog;
                _dlg.FormClosed += (s, e) =>
                {
                    _dlg = null;
                    QueueInventorForegroundRestoreAfterDialogClose();
                };
                // Establish final DPI-aware dimensions and native right-edge coordinates before
                // the dialog is shown. ThreadDialog keeps itself transparent through the last
                // layout pass and is revealed only after another native alignment.
                _dlg.PrepareInitialPosition();
                _dlg.Show(owner);

                CloseSplashSafely(splash);
                splash = null;
            }
            catch (Exception ex)
            {
                CloseSplashSafely(splash);
                splash = null;
                System.Windows.Forms.MessageBox.Show("Helivanta: " + ex.Message, "Helivanta");
            }
            finally
            {
                CloseSplashSafely(splash);
                _openingDialog = false;
            }
        }

        private void OnExecutePackagingThread(NameValueMap context)
        {
            if (!(_app.ActiveDocument is PartDocument))
            {
                MessageBox.Show("Откройте деталь (.ipt) и выберите одну цилиндрическую грань перед запуском команды.", "Helivanta — упаковочная резьба");
                return;
            }
            // Modeless is intentional: Inventor must remain interactive so the user can
            // select a circular edge while this parameter dialog stays open.
            var existing = System.Windows.Forms.Application.OpenForms
                .OfType<PackagingThreadDialog>()
                .FirstOrDefault(f => !f.IsDisposed);
            if (existing != null)
            {
                existing.Activate();
                return;
            }

            var dialog = new PackagingThreadDialog(_app);
            dialog.FormClosed += (_, __) => dialog.Dispose();
            dialog.Show(new WindowWrapper(new IntPtr(_app.MainFrameHWND)));
        }

        private void OnExecuteEdit(NameValueMap context)
        {
            if (_editSelectionPrompt != null && !_editSelectionPrompt.IsDisposed)
            {
                try { _editSelectionPrompt.Activate(); } catch { }
                return;
            }

            if (!(_app.ActiveDocument is PartDocument))
            {
                MessageBox.Show("Откройте деталь (.ipt), чтобы редактировать резьбу Helivanta или штатную резьбу Inventor.", "Helivanta — редактирование");
                return;
            }

            object selected = TryGetSelectedThreadObject();
            if (selected == null)
            {
                // A dialog's circular-edge interaction must release Inventor's input before
                // the modeless browser-selection prompt can receive tree selections.
                if (_dlg != null && !_dlg.IsDisposed) _dlg.PauseSelectionForEditPick();
                // Modeless by design: the user must still be able to click the Inventor model
                // browser while this prompt remains visible. It closes itself only after a
                // valid Helivanta thread/folder is selected and hands off to the normal flow.
                ShowEditSelectionPrompt();
                return;
            }

            OpenEditForSelection(selected);
        }

        private void BeginEditSelectionFromDialog()
        {
            if (_dlg == null || _dlg.IsDisposed) return;
            if (!(_app.ActiveDocument is PartDocument))
            {
                MessageBox.Show("Откройте деталь (.ipt), чтобы выбрать резьбу для редактирования.", "Helivanta — редактирование");
                _dlg.ResumeSelectionAfterEditPickCancelled();
                return;
            }
            if (_editSelectionPrompt != null && !_editSelectionPrompt.IsDisposed)
            {
                try { _editSelectionPrompt.Activate(); } catch { }
                return;
            }
            ShowEditSelectionPrompt();
        }

        private object TryGetSelectedThreadObject()
        {
            PartDocument doc = _app == null ? null : _app.ActiveDocument as PartDocument;
            if (doc == null) return null;

            object selected = null;
            try
            {
                if (doc.SelectSet != null && doc.SelectSet.Count == 1)
                    selected = doc.SelectSet[1];
            }
            catch { selected = null; }

            string id;
            string error;
            if (selected != null && ThreadMetadataStore.TryGetThreadIdFromSelection(doc, selected, out id, out error))
                return selected;

            // Native Autodesk Thread features do not carry Helivanta AttributeSets. Resolve them
            // separately so a selected ThreadFeature can be sent to the normal Helivanta
            // dialog and converted to physical geometry through ThreadBuilder.
            ThreadFeature nativeThread;
            if (selected != null && NativeThreadConversionService.TryResolveFeature(doc, selected, out nativeThread))
                return selected;

            // Inventor's SelectSet may expose a proxy for a selected browser folder or feature.
            // Prefer the visible BrowserNode when selection is only represented in the browser.
            try
            {
                BrowserNode node;
                if (ThreadMetadataStore.TryGetSingleSelectedBrowserNode(doc, out node, out error))
                {
                    if (ThreadMetadataStore.TryGetThreadIdFromSelection(doc, node, out id, out error))
                        return node;
                    if (NativeThreadConversionService.TryResolveFeature(doc, node, out nativeThread))
                        return node;
                }
            }
            catch { }

            return null;
        }

        private void ShowEditSelectionPrompt()
        {
            if (_editSelectionPrompt != null && !_editSelectionPrompt.IsDisposed)
            {
                try { _editSelectionPrompt.Activate(); } catch { }
                return;
            }

            IntPtr mainFrameHandle = new IntPtr(_app.MainFrameHWND);
            bool nextNativeOnly = _dlg != null && !_dlg.IsDisposed && _dlg.IsAwaitingNextNativeConversionSelection;
            object selectionToIgnore = nextNativeOnly ? TryGetSelectedThreadObject() : null;
            _editSelectionPrompt = new EditSelectionPrompt(
                mainFrameHandle,
                TryGetSelectedThreadObject,
                selected =>
                {
                    CloseEditSelectionPrompt();
                    OpenEditForSelection(selected);
                },
                () =>
                {
                    CloseEditSelectionPrompt();
                    if (_dlg != null && !_dlg.IsDisposed) _dlg.ResumeSelectionAfterEditPickCancelled();
                },
                nextNativeOnly,
                selectionToIgnore);
            try
            {
                _ = _editSelectionPrompt.Handle;
                NativeWindowPositioning.MoveToRight(_editSelectionPrompt.Handle, mainFrameHandle);
                _editSelectionPrompt.Show(new WindowWrapper(mainFrameHandle));
                NativeWindowPositioning.MoveToRight(_editSelectionPrompt.Handle, mainFrameHandle);
                _editSelectionPrompt.Activate();
            }
            catch (Exception ex)
            {
                CloseEditSelectionPrompt();
                if (_dlg != null && !_dlg.IsDisposed) _dlg.ResumeSelectionAfterEditPickCancelled();
                MessageBox.Show("Не удалось открыть окно выбора резьбы. " + ex.Message, "Helivanta — редактирование");
            }
        }

        private void CloseEditSelectionPrompt()
        {
            EditSelectionPrompt prompt = _editSelectionPrompt;
            _editSelectionPrompt = null;
            if (prompt == null) return;
            try { if (!prompt.IsDisposed) prompt.Close(); } catch { }
            try { prompt.Dispose(); } catch { }
        }

        private void OpenEditForSelection(object selected)
        {
            if (selected == null || _openingDialog) return;
            _openingDialog = true;
            LoadingSplash editSplash = null;
            bool splashTransferredToDialog = false;
            try
            {
                // Reuse the established branded progress window after a valid thread has been
                // chosen. This keeps the normal edit launch sequence identical either way.
                IntPtr mainFrameHandle = new IntPtr(_app.MainFrameHWND);
                editSplash = new LoadingSplash(mainFrameHandle);
                editSplash.SetStatus("Проверяем резьбу");
                var splashOwner = new WindowWrapper(mainFrameHandle);
                editSplash.Show(splashOwner);
                editSplash.EnsureRightPosition(mainFrameHandle);
                System.Windows.Forms.Application.DoEvents();

                ThreadFeature nativeThreadFeature;
                if (NativeThreadConversionService.TryResolveFeature(_app.ActiveDocument as PartDocument, selected, out nativeThreadFeature))
                {
                    NativeThreadConversionPlan conversionPlan;
                    string nativeError;
                    if (!NativeThreadConversionService.TryPrepare(_app, nativeThreadFeature, out conversionPlan, out nativeError))
                    {
                        MessageBox.Show(nativeError ?? "Выбранную штатную резьбу Inventor нельзя преобразовать в физическую резьбу Helivanta.",
                            "Helivanta — преобразование резьбы Inventor", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                        if (_dlg != null && !_dlg.IsDisposed) _dlg.ResumeSelectionAfterEditPickCancelled();
                        return;
                    }

                    int downstreamCount;
                    if (!NativeThreadConversionService.TryGetDownstreamOperationCount(
                        _app.ActiveDocument as PartDocument, nativeThreadFeature, out downstreamCount, out nativeError))
                    {
                        MessageBox.Show(nativeError ?? "Не удалось проверить последующие операции.",
                            "Helivanta — преобразование резьбы Inventor", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                        if (_dlg != null && !_dlg.IsDisposed) _dlg.ResumeSelectionAfterEditPickCancelled();
                        return;
                    }
                    if (downstreamCount > 0)
                    {
                        using (var warningDialog = new NativeConversionWarningDialog(mainFrameHandle, downstreamCount))
                        {
                            if (warningDialog.ShowDialog(new WindowWrapper(mainFrameHandle)) != DialogResult.Yes)
                            {
                                if (_dlg != null && !_dlg.IsDisposed) _dlg.ResumeSelectionAfterEditPickCancelled();
                                return;
                            }
                        }
                    }

                    if (_dlg != null && !_dlg.IsDisposed)
                    {
                        if (!_dlg.TryBeginNativeConversion(conversionPlan, out nativeError))
                        {
                            CloseSplashSafely(editSplash);
                            editSplash = null;
                            MessageBox.Show(nativeError ?? "Не удалось открыть диалог преобразования.",
                                "Helivanta — преобразование резьбы Inventor", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                            _dlg.ResumeSelectionAfterEditPickCancelled();
                            return;
                        }
                        // Keep the branded progress splash visible while the existing main dialog
                        // switches modes; close it only after activation has completed.
                        try { _dlg.Activate(); } catch { }
                        CloseSplashSafely(editSplash);
                        editSplash = null;
                        return;
                    }

                    var conversionOwner = new WindowWrapper(mainFrameHandle);
                    ThreadDialog conversionDialog = new ThreadDialog(_app);
                    if (!conversionDialog.TryBeginNativeConversion(conversionPlan, out nativeError))
                    {
                        try { conversionDialog.Close(); } catch { }
                        try { conversionDialog.Dispose(); } catch { }
                        CloseSplashSafely(editSplash);
                        editSplash = null;
                        MessageBox.Show(nativeError ?? "Не удалось открыть диалог преобразования.",
                            "Helivanta — преобразование резьбы Inventor", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                        return;
                    }
                    LoadingSplash splashWaitingForDialog = editSplash;
                    conversionDialog.InitialPresentationCompleted += (s, e) => CloseSplashSafely(splashWaitingForDialog);
                    conversionDialog.FormClosed += (s, e) =>
                    {
                        CloseSplashSafely(splashWaitingForDialog);
                        _dlg = null;
                        QueueInventorForegroundRestoreAfterDialogClose();
                    };
                    _dlg = conversionDialog;
                    _dlg.EditSelectionRequested += BeginEditSelectionFromDialog;
                    _dlg.PrepareInitialPosition();
                    splashTransferredToDialog = true;
                    try { _dlg.Show(conversionOwner); }
                    catch { splashTransferredToDialog = false; throw; }
                    return;
                }

                // During sequential native conversion, only another native Inventor ThreadFeature
                // is a valid next target. Do not accidentally switch the same dialog to editing a
                // Helivanta group or resume ordinary edge selection after the user clicked Next.
                if (_dlg != null && !_dlg.IsDisposed && _dlg.IsAwaitingNextNativeConversionSelection)
                {
                    CloseSplashSafely(editSplash);
                    editSplash = null;
                    _dlg.RejectNextNativeConversionSelection(
                        "Выберите именно штатную операцию «Резьба Inventor» в дереве построений. Объекты Helivanta, грани и рёбра не подходят для последовательного преобразования.");
                    MessageBox.Show("Для следующего шага выберите другую штатную операцию «Резьба Inventor» в левом дереве построений. Уже выполненные преобразования сохранены.",
                        "Helivanta — следующая резьба", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    return;
                }

                if (_dlg != null && !_dlg.IsDisposed)
                {
                    string error;
                    if (!_dlg.TryBeginEdit(selected, out error))
                    {
                        MessageBox.Show(error ?? "Нельзя редактировать выбранную резьбу.", "Helivanta — редактирование");
                        _dlg.ResumeSelectionAfterEditPickCancelled();
                        return;
                    }
                    try { _dlg.Activate(); } catch { }
                    return;
                }

                var owner = new WindowWrapper(mainFrameHandle);
                ThreadDialog dialog = new ThreadDialog(_app);
                string beginError;
                if (!dialog.TryBeginEdit(selected, out beginError))
                {
                    try { dialog.Close(); } catch { }
                    try { dialog.Dispose(); } catch { }
                    MessageBox.Show(beginError ?? "Нельзя редактировать выбранную резьбу.", "Helivanta — редактирование");
                    return;
                }
                _dlg = dialog;
                _dlg.EditSelectionRequested += BeginEditSelectionFromDialog;
                _dlg.FormClosed += (s, e) =>
                {
                    _dlg = null;
                    QueueInventorForegroundRestoreAfterDialogClose();
                };
                _dlg.PrepareInitialPosition();
                _dlg.Show(owner);
            }
            catch (Exception ex)
            {
                splashTransferredToDialog = false;
                MessageBox.Show("Helivanta: не удалось открыть режим редактирования. " + ex.Message, "Helivanta — редактирование");
            }
            finally
            {
                if (!splashTransferredToDialog) CloseSplashSafely(editSplash);
                _openingDialog = false;
            }
        }

        /// <summary>
        /// Non-modal prompt for the no-selection entry path. Inventor must remain interactive
        /// so a browser folder/member can be selected while the prompt polls for a valid target.
        /// </summary>
        private sealed class EditSelectionPrompt : System.Windows.Forms.Form
        {
            private readonly Func<object> _getSelection;
            private readonly Action<object> _selectionFound;
            private readonly Action _cancelled;
            private readonly object _selectionToIgnore;
            private readonly System.Windows.Forms.Timer _timer;
            private System.Windows.Forms.PictureBox _wordmark;
            private readonly bool _nextNativeOnly;
            private bool _handoffStarted;
            private bool _allowClose;
            private bool _cancelCallbackSent;

            private static Image LoadSelectionWordmark()
            {
                // Use the shared official wordmark loader so this prompt follows the selected theme.
                try { return HelivantaUiTheme.LoadWordmarkImage(true); }
                catch { return null; }
            }

            internal EditSelectionPrompt(IntPtr ownerHandle, Func<object> getSelection, Action<object> selectionFound,
                Action cancelled, bool nextNativeOnly, object selectionToIgnore)
            {
                _getSelection = getSelection;
                _selectionFound = selectionFound;
                _cancelled = cancelled;
                _selectionToIgnore = selectionToIgnore;
                // Preserve the mode in which this prompt was created. During sequential native
                // conversion this flag prevents the previous Browser selection from being reused.
                _nextNativeOnly = nextNativeOnly;
                Text = HelivantaLocalization.Translate(nextNativeOnly ? "Helivanta — следующая штатная резьба" : "Helivanta — выбор резьбы для редактирования");
                FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
                StartPosition = FormStartPosition.Manual;
                AutoScaleDimensions = new System.Drawing.SizeF(96F, 96F);
                AutoScaleMode = System.Windows.Forms.AutoScaleMode.Dpi;
                ClientSize = new System.Drawing.Size(520, 204);
                ControlBox = false; // The user returns through the themed «Отмена» action.
                MaximizeBox = false;
                MinimizeBox = false;
                ShowInTaskbar = false;
                BackColor = HelivantaUiTheme.Surface;
                ForeColor = HelivantaUiTheme.Text;

                _wordmark = new System.Windows.Forms.PictureBox
                {
                    Location = new System.Drawing.Point(16, 10),
                    Size = new System.Drawing.Size(188, 52),
                    SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom,
                    BackColor = System.Drawing.Color.Transparent,
                    Image = LoadSelectionWordmark()
                };
                var heading = new System.Windows.Forms.Label
                {
                    Text = HelivantaLocalization.Translate(nextNativeOnly ? "Выберите следующую резьбу Inventor" : "Выберите резьбу в дереве построений"),
                    Location = new System.Drawing.Point(216, 16),
                    Size = new System.Drawing.Size(286, 30),
                    Font = new System.Drawing.Font("Segoe UI Semibold", 10.5f, System.Drawing.FontStyle.Bold),
                    ForeColor = HelivantaUiTheme.Text,
                    TextAlign = System.Drawing.ContentAlignment.MiddleLeft
                };
                var explanation = new System.Windows.Forms.Label
                {
                    Text = HelivantaLocalization.Translate(nextNativeOnly
                        ? "В дереве построений выберите следующую штатную операцию «Резьба Inventor». Не выбирайте уже преобразованную резьбу или папку Helivanta, грань либо ребро в окне модели. Предыдущие преобразования уже сохранены."
                        : "В дереве построений выберите резьбу/папку Helivanta для изменения или штатную операцию «Резьба Inventor» для преобразования. Не выбирайте грань или ребро в окне модели. Преобразование начнётся после подтверждения в основном окне."),
                    Location = new System.Drawing.Point(16, 66),
                    Size = new System.Drawing.Size(486, 70),
                    ForeColor = HelivantaUiTheme.Muted,
                    TextAlign = System.Drawing.ContentAlignment.TopLeft
                };
                var status = new System.Windows.Forms.Label
                {
                    Text = HelivantaLocalization.Translate(nextNativeOnly ? "Ожидаем следующую штатную резьбу Inventor…" : "Ожидаем выбор в дереве Inventor…"),
                    Location = new System.Drawing.Point(16, 150),
                    Size = new System.Drawing.Size(382, 25),
                    ForeColor = HelivantaUiTheme.Success,
                    TextAlign = System.Drawing.ContentAlignment.MiddleLeft
                };
                var cancelButton = new System.Windows.Forms.Button
                {
                    Text = HelivantaLocalization.Translate("Отмена"),
                    Location = new System.Drawing.Point(410, 148),
                    Size = new System.Drawing.Size(92, 29),
                    FlatStyle = System.Windows.Forms.FlatStyle.Flat,
                    UseVisualStyleBackColor = false,
                    BackColor = HelivantaUiTheme.Accent,
                    ForeColor = System.Drawing.Color.White,
                    Font = new System.Drawing.Font("Segoe UI", 8.5f, System.Drawing.FontStyle.Regular),
                    TextAlign = System.Drawing.ContentAlignment.MiddleCenter
                };
                cancelButton.FlatAppearance.BorderColor = HelivantaUiTheme.ControlBorder;
                cancelButton.FlatAppearance.BorderSize = 1;
                cancelButton.AccessibleName = HelivantaLocalization.Translate("Отмена — вернуться к текущему режиму");
                cancelButton.AccessibleDescription = HelivantaLocalization.Translate(nextNativeOnly
                    ? "Отменить выбор следующей штатной резьбы. Ранее выполненные преобразования останутся в модели."
                    : "Отменить выбор существующей резьбы и вернуться к текущему диалогу Helivanta без изменения модели.");
                cancelButton.Click += (s, e) => CancelPrompt();

                var frame = new System.Windows.Forms.Panel
                {
                    Dock = System.Windows.Forms.DockStyle.Fill,
                    BackColor = HelivantaUiTheme.Border,
                    Padding = new System.Windows.Forms.Padding(1),
                    Margin = System.Windows.Forms.Padding.Empty
                };
                var surface = new System.Windows.Forms.Panel
                {
                    Dock = System.Windows.Forms.DockStyle.Fill,
                    BackColor = HelivantaUiTheme.Surface,
                    Margin = System.Windows.Forms.Padding.Empty
                };
                frame.Controls.Add(surface);
                Controls.Add(frame);
                var accent = new System.Windows.Forms.Panel
                { Location = new System.Drawing.Point(0, 0), Size = new System.Drawing.Size(4, 202),
                  BackColor = HelivantaUiTheme.Accent, Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left };
                surface.Controls.Add(accent);
                surface.Controls.Add(_wordmark);
                surface.Controls.Add(heading);
                surface.Controls.Add(explanation);
                surface.Controls.Add(status);
                surface.Controls.Add(cancelButton);
                bool localizingPromptStatus = false;
                status.TextChanged += (s, e) =>
                {
                    if (!localizingPromptStatus && string.Equals(HelivantaUserSettings.Current.Language, "en", StringComparison.OrdinalIgnoreCase))
                    {
                        string localized = HelivantaLocalization.Translate(status.Text ?? string.Empty);
                        if (!string.Equals(localized, status.Text, StringComparison.Ordinal))
                        {
                            localizingPromptStatus = true;
                            try { status.Text = localized; }
                            finally { localizingPromptStatus = false; }
                        }
                    }
                    FitPromptLayout(heading, explanation, status, cancelButton);
                };

                // Measure the full explanatory copy at the actual font and available text width.
                // The prompt grows downwards instead of clipping the last line at the former fixed 70 px.
                int explanationWidth = Math.Max(200, 486);
                System.Drawing.Size measuredExplanation = System.Windows.Forms.TextRenderer.MeasureText(
                    explanation.Text,
                    explanation.Font,
                    new System.Drawing.Size(explanationWidth, 8192),
                    System.Windows.Forms.TextFormatFlags.WordBreak |
                    System.Windows.Forms.TextFormatFlags.TextBoxControl |
                    System.Windows.Forms.TextFormatFlags.NoPadding);
                explanation.Height = Math.Max(70, measuredExplanation.Height + 10);
                int actionTop = explanation.Bottom + 12;
                status.Location = new System.Drawing.Point(16, actionTop);
                cancelButton.Location = new System.Drawing.Point(410, actionTop - 2);
                int measuredClientHeight = actionTop + cancelButton.Height + 16;
                ClientSize = new System.Drawing.Size(520, Math.Max(204, measuredClientHeight));
                var promptTip = new System.Windows.Forms.ToolTip { ShowAlways = true, InitialDelay = 450, AutoPopDelay = 12000 };
                promptTip.SetToolTip(cancelButton, HelivantaLocalization.Translate("Отмена — Вернуться"));
                KeyPreview = true;
                KeyDown += (s, e) => { if (e.KeyCode == Keys.Escape) { e.Handled = true; CancelPrompt(); } };
                FormClosed += (s, e) => promptTip.Dispose();
                FormClosing += (s, e) =>
                {
                    if (_allowClose || _handoffStarted) return;
                    e.Cancel = true;
                    CancelPrompt();
                };

                _timer = new System.Windows.Forms.Timer { Interval = 500 };
                _timer.Tick += (s, e) =>
                {
                    if (_handoffStarted || IsDisposed || _getSelection == null) return;
                    object selected = null;
                    try { selected = _getSelection(); } catch { }
                    if (selected == null) return;
                    if (_nextNativeOnly && _selectionToIgnore != null &&
                        NativeThreadConversionService.SameSelectionIdentity(selected, _selectionToIgnore)) return;
                    _handoffStarted = true;
                    _timer.Stop();
                    try { if (_selectionFound != null) _selectionFound(selected); }
                    catch (Exception ex)
                    {
                        _handoffStarted = false;
                        if (!IsDisposed)
                        {
                            status.ForeColor = System.Drawing.Color.FromArgb(255, 125, 125);
                            status.Text = "Не удалось открыть резьбу: " + ex.Message;
                            _timer.Start();
                        }
                    }
                };
                Shown += (s, e) =>
                {
                    FitPromptLayout(heading, explanation, status, cancelButton);
                    NativeWindowPositioning.MoveToRight(Handle, ownerHandle);
                    _timer.Start();
                };
                // When the prompt is dragged between monitors Windows may rescale its controls
                // after the initial Shown event. Re-measure actual text at the new DPI so status
                // lines and the final explanation line never fall below the client area.
                DpiChanged += (s, e) =>
                {
                    if (IsDisposed || !IsHandleCreated) return;
                    try { BeginInvoke((Action)(() => FitPromptLayout(heading, explanation, status, cancelButton))); }
                    catch { FitPromptLayout(heading, explanation, status, cancelButton); }
                };
            }

            private void FitPromptLayout(System.Windows.Forms.Label heading, System.Windows.Forms.Label explanation,
                System.Windows.Forms.Label status, System.Windows.Forms.Button cancelButton)
            {
                if (heading == null || explanation == null || status == null || cancelButton == null || IsDisposed) return;
                float scale = Math.Max(1f, DeviceDpi / 96f);
                int padding = Math.Max(8, (int)Math.Round(10 * scale));
                int gap = Math.Max(8, (int)Math.Round(12 * scale));
                int minTop = (int)Math.Round(66 * scale);

                System.Drawing.Size headingMeasured = System.Windows.Forms.TextRenderer.MeasureText(
                    heading.Text, heading.Font,
                    new System.Drawing.Size(Math.Max(1, heading.Width), 8192),
                    System.Windows.Forms.TextFormatFlags.WordBreak |
                    System.Windows.Forms.TextFormatFlags.TextBoxControl |
                    System.Windows.Forms.TextFormatFlags.NoPadding);
                heading.Height = Math.Max(heading.Height, headingMeasured.Height + Math.Max(4, (int)Math.Round(4 * scale)));

                explanation.Top = Math.Max(minTop, heading.Bottom + gap / 2);
                System.Drawing.Size explanationMeasured = System.Windows.Forms.TextRenderer.MeasureText(
                    explanation.Text, explanation.Font,
                    new System.Drawing.Size(Math.Max(1, explanation.Width), 8192),
                    System.Windows.Forms.TextFormatFlags.WordBreak |
                    System.Windows.Forms.TextFormatFlags.TextBoxControl |
                    System.Windows.Forms.TextFormatFlags.NoPadding);
                explanation.Height = Math.Max(explanation.Height, explanationMeasured.Height + padding);

                int actionTop = explanation.Bottom + gap;
                System.Drawing.Size statusMeasured = System.Windows.Forms.TextRenderer.MeasureText(
                    status.Text, status.Font,
                    new System.Drawing.Size(Math.Max(1, status.Width), 8192),
                    System.Windows.Forms.TextFormatFlags.WordBreak |
                    System.Windows.Forms.TextFormatFlags.TextBoxControl |
                    System.Windows.Forms.TextFormatFlags.NoPadding);
                status.Height = Math.Max(status.Height, statusMeasured.Height + Math.Max(2, (int)Math.Round(2 * scale)));
                status.Top = actionTop;
                cancelButton.Top = actionTop - Math.Max(1, (int)Math.Round(2 * scale));
                int contentBottom = Math.Max(status.Bottom, cancelButton.Bottom) + Math.Max(10, (int)Math.Round(16 * scale));
                int minimumHeight = (int)Math.Round(204 * scale);
                ClientSize = new System.Drawing.Size(ClientSize.Width, Math.Max(minimumHeight, contentBottom));
            }

            private void CancelPrompt()
            {
                if (_allowClose || _handoffStarted) return;
                _allowClose = true;
                try { _timer.Stop(); } catch { }
                if (!_cancelCallbackSent)
                {
                    _cancelCallbackSent = true;
                    try { if (_cancelled != null) _cancelled(); } catch { }
                }
                try { if (!IsDisposed) Close(); } catch { }
            }

            protected override void Dispose(bool disposing)
            {
                if (disposing)
                {
                    try { _timer.Stop(); } catch { }
                    try { _timer.Dispose(); } catch { }
                    try
                    {
                        if (_wordmark != null && _wordmark.Image != null)
                        {
                            _wordmark.Image.Dispose();
                            _wordmark.Image = null;
                        }
                    }
                    catch { }
                }
                base.Dispose(disposing);
            }
        }

        private static void CloseSplashSafely(LoadingSplash splash)
        {
            if (splash == null) return;
            try { if (!splash.IsDisposed) splash.Close(); } catch { }
            try { splash.Dispose(); } catch { }
        }
    }
}
