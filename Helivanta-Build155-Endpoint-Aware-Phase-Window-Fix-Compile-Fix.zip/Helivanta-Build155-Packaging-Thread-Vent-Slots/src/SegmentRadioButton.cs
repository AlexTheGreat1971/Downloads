using System;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Linq;
using System.Windows.Forms;

namespace ThreadPro
{
    /// <summary>
    /// Owner-drawn segment for mutually-exclusive choices. It deliberately derives from
    /// RadioButton so Checked/CheckedChanged, keyboard navigation, accessibility and group
    /// semantics continue to be handled by WinForms.
    /// </summary>
    internal sealed class SegmentRadioButton : RadioButton
    {
        private readonly string _groupKey;
        private bool _hovered;
        private bool _pressed;

        internal SegmentRadioButton(string groupKey)
        {
            _groupKey = groupKey ?? string.Empty;
            SetStyle(ControlStyles.UserPaint | ControlStyles.AllPaintingInWmPaint |
                     ControlStyles.OptimizedDoubleBuffer | ControlStyles.ResizeRedraw |
                     ControlStyles.Opaque, true);
            BackColor = HelivantaUiTheme.Panel;
            ForeColor = HelivantaUiTheme.Text;
            AutoSize = false;
            FlatStyle = FlatStyle.Flat;
            FlatAppearance.BorderSize = 0;
            UseVisualStyleBackColor = false;
            TextAlign = ContentAlignment.MiddleCenter;
            TabStop = true;
        }

        public override Size GetPreferredSize(Size proposedSize)
        {
            Size measured = TextRenderer.MeasureText(Text ?? string.Empty, Font,
                new Size(800, 100), TextFormatFlags.NoPrefix | TextFormatFlags.SingleLine);
            float scale = Math.Max(1f, DeviceDpi / 96f);
            return new Size(measured.Width + (int)Math.Round(22 * scale),
                Math.Max((int)Math.Round(28 * scale), measured.Height + (int)Math.Round(8 * scale)));
        }

        protected override void OnMouseEnter(EventArgs e)
        {
            _hovered = true;
            Invalidate();
            base.OnMouseEnter(e);
        }

        protected override void OnMouseLeave(EventArgs e)
        {
            _hovered = false;
            _pressed = false;
            Invalidate();
            base.OnMouseLeave(e);
        }

        protected override void OnMouseDown(MouseEventArgs e)
        {
            if (Enabled && e.Button == MouseButtons.Left) { _pressed = true; Invalidate(); }
            base.OnMouseDown(e);
        }

        protected override void OnMouseUp(MouseEventArgs e)
        {
            _pressed = false;
            Invalidate();
            base.OnMouseUp(e);
        }

        protected override void OnMouseCaptureChanged(EventArgs e)
        {
            if (!Capture) _pressed = false;
            Invalidate();
            base.OnMouseCaptureChanged(e);
        }

        protected override void OnGotFocus(EventArgs e)
        {
            Invalidate();
            base.OnGotFocus(e);
        }

        protected override void OnLostFocus(EventArgs e)
        {
            _pressed = false;
            Invalidate();
            base.OnLostFocus(e);
        }

        protected override void OnCheckedChanged(EventArgs e)
        {
            Invalidate();
            base.OnCheckedChanged(e);
        }

        protected override void OnEnabledChanged(EventArgs e)
        {
            if (!Enabled)
            {
                _hovered = false;
                _pressed = false;
            }
            base.OnEnabledChanged(e);
            Invalidate();
        }

        protected override void OnPaintBackground(PaintEventArgs e)
        {
            Color background = Parent != null ? Parent.BackColor : HelivantaUiTheme.Panel;
            using (var brush = new SolidBrush(background))
                e.Graphics.FillRectangle(brush, ClientRectangle);
        }

        protected override void OnPaint(PaintEventArgs e)
        {
            Graphics g = e.Graphics;
            g.SmoothingMode = SmoothingMode.AntiAlias;
            g.PixelOffsetMode = PixelOffsetMode.HighQuality;
            g.Clear(Parent != null ? Parent.BackColor : HelivantaUiTheme.Panel);

            bool first, last;
            GetGroupEdges(out first, out last);
            float scale = Math.Max(1f, DeviceDpi / 96f);
            int radius = Math.Min((int)Math.Round(6 * scale), Math.Max(3, Height / 3));
            Rectangle rect = new Rectangle(0, 0, Math.Max(1, Width - 1), Math.Max(1, Height - 1));

            bool highContrast = SystemInformation.HighContrast;
            Color fill = highContrast
                ? (Checked ? SystemColors.Highlight : SystemColors.Control)
                : (!Enabled ? HelivantaUiTheme.PanelSecondary
                    : _pressed ? (Checked ? ControlPaint.Dark(HelivantaUiTheme.Accent) : HelivantaUiTheme.Panel)
                    : Checked ? (_hovered ? HelivantaUiTheme.AccentHover : HelivantaUiTheme.Accent)
                    : _hovered ? HelivantaUiTheme.AccentSoft : HelivantaUiTheme.Field);
            Color border = highContrast ? SystemColors.WindowText : HelivantaUiTheme.ControlBorder;
            Color text = highContrast ? (Checked ? SystemColors.HighlightText : SystemColors.ControlText)
                : (!Enabled ? HelivantaUiTheme.Muted : HelivantaUiTheme.Text);

            using (GraphicsPath path = CreateSegmentPath(rect, radius, first, last))
            using (var brush = new SolidBrush(fill))
            using (var pen = new Pen(border, Math.Max(1f, scale)))
            {
                g.FillPath(brush, path);
                g.DrawPath(pen, path);
            }

            TextRenderer.DrawText(g, Text ?? string.Empty, Font,
                new Rectangle(4, 1, Math.Max(0, Width - 8), Math.Max(0, Height - 2)),
                text, TextFormatFlags.HorizontalCenter | TextFormatFlags.VerticalCenter |
                      TextFormatFlags.NoPrefix | TextFormatFlags.EndEllipsis | TextFormatFlags.SingleLine);

            if (Focused && ShowFocusCues && Enabled)
            {
                Rectangle focus = Rectangle.Inflate(rect, -4, -4);
                ControlPaint.DrawFocusRectangle(g, focus,
                    highContrast ? SystemColors.HighlightText : HelivantaUiTheme.Text, fill);
            }
        }

        private void GetGroupEdges(out bool first, out bool last)
        {
            first = true;
            last = true;
            if (Parent == null || string.IsNullOrEmpty(_groupKey)) return;
            var group = Parent.Controls.OfType<SegmentRadioButton>()
                .Where(c => string.Equals(c._groupKey, _groupKey, StringComparison.Ordinal))
                .OrderBy(c => c.Left).ThenBy(c => c.Top).ToList();
            int index = group.IndexOf(this);
            if (index >= 0)
            {
                first = index == 0;
                last = index == group.Count - 1;
            }
        }

        private static GraphicsPath CreateSegmentPath(Rectangle r, int radius, bool roundLeft, bool roundRight)
        {
            var path = new GraphicsPath();
            float x = r.X, y = r.Y, right = r.Right, bottom = r.Bottom;
            float d = Math.Min(radius * 2f, Math.Min(r.Width, r.Height));
            if (d < 2f)
            {
                path.AddRectangle(r);
                return path;
            }

            path.StartFigure();
            path.AddLine(x + (roundLeft ? d / 2f : 0f), y, right - (roundRight ? d / 2f : 0f), y);
            if (roundRight) path.AddArc(right - d, y, d, d, 270, 90); else path.AddLine(right, y, right, y);
            path.AddLine(right, y + (roundRight ? d / 2f : 0f), right, bottom - (roundRight ? d / 2f : 0f));
            if (roundRight) path.AddArc(right - d, bottom - d, d, d, 0, 90); else path.AddLine(right, bottom, right, bottom);
            path.AddLine(right - (roundRight ? d / 2f : 0f), bottom, x + (roundLeft ? d / 2f : 0f), bottom);
            if (roundLeft) path.AddArc(x, bottom - d, d, d, 90, 90); else path.AddLine(x, bottom, x, bottom);
            path.AddLine(x, bottom - (roundLeft ? d / 2f : 0f), x, y + (roundLeft ? d / 2f : 0f));
            if (roundLeft) path.AddArc(x, y, d, d, 180, 90); else path.AddLine(x, y, x, y);
            path.CloseFigure();
            return path;
        }
    }
}
