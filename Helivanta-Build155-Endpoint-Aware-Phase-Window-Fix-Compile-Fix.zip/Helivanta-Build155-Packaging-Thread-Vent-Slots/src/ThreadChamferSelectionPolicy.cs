﻿namespace ThreadPro
{
    /// <summary>
    /// Keeps the chamfer-location ComboBox's committed selection authoritative across
    /// transient owner-drawn/native popup-close notifications, matching the hardened
    /// standard-selector lifecycle.
    /// </summary>
    internal static class ThreadChamferSelectionPolicy
    {
        internal static bool IsValidIndex(int selectedIndex, int itemCount)
        {
            return ThreadStandardSelectionPolicy.IsValidIndex(selectedIndex, itemCount);
        }

        internal static int ResolveStableIndex(int selectedIndex, int lastCommittedIndex, int itemCount)
        {
            return ThreadStandardSelectionPolicy.ResolveStableIndex(
                selectedIndex, lastCommittedIndex, itemCount);
        }

        internal static int ResolveCommittedIndex(
            int selectedIndex, int pendingIndex, int lastCommittedIndex, int itemCount)
        {
            return ThreadStandardSelectionPolicy.ResolveCommittedIndex(
                selectedIndex, pendingIndex, lastCommittedIndex, itemCount);
        }

        internal static int ResolveAfterDropdownClose(
            bool commitObserved, int pendingIndex, int selectedIndex,
            int lastCommittedIndex, int itemCount)
        {
            return ThreadStandardSelectionPolicy.ResolveAfterDropdownClose(
                commitObserved, pendingIndex, selectedIndex, lastCommittedIndex, itemCount);
        }

        internal static string ResolveFieldDisplayText(string committedText, string nativeText, bool popupOpen)
        {
            return ThreadStandardSelectionPolicy.ResolveFieldDisplayText(
                committedText, nativeText, popupOpen);
        }

        /// <summary>
        /// Maps the stable zero-based location choice to the persisted chamfer mode.
        /// Mode 0 means chamfers are disabled; enabled modes are 1..3.
        /// </summary>
        internal static int ResolveChamferMode(
            bool enabled, int selectedIndex, int lastCommittedIndex, int itemCount)
        {
            if (!enabled) return 0;
            // Once a valid choice was committed, it outranks a stale-but-valid native index
            // too (not just a transient -1). This is the exact popup-close regression guard.
            int index = IsValidIndex(lastCommittedIndex, itemCount)
                ? lastCommittedIndex
                : ResolveStableIndex(selectedIndex, lastCommittedIndex, itemCount);
            return IsValidIndex(index, itemCount) ? index + 1 : 0;
        }
    }
}