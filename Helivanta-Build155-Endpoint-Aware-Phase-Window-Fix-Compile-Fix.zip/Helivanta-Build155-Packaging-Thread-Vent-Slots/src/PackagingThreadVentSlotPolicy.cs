﻿using System;

namespace ThreadPro
{
    /// <summary>
    /// Pure policy for optional longitudinal ventilation slots through the raised thread ridge.
    /// Public width is an angular width in degrees. PCO1881's neck drawing supports 4 external
    /// positions and a 28-degree half-angle callout (56-degree total reference sector). The
    /// narrower 14-degree default is a practical, user-adjustable modelling value. Eight internal
    /// positions and the default width are provisional choices, not PCO1881 requirements.
    /// </summary>
    internal static class PackagingThreadVentSlotPolicy
    {
        internal const int MinimumSlotCount = 1;
        internal const int MaximumSlotCount = 20;
        internal const double DefaultExternalSlotWidthDegrees = 14.0;
        internal const double DefaultInternalSlotWidthDegrees = 14.0;
        internal const int DefaultExternalSlotCount = 4;
        internal const int DefaultInternalSlotCount = 8;
        internal const double MinimumSlotWidthDegrees = 0.5;
        internal const double MaximumSlotWidthDegrees = 120.0;
        internal const double RadialOvercutMm = 0.02;
        internal const double MinimumAxialOverrunMm = 1.0;
        internal const double EdgeSafetyOverrunMm = 0.25;

        /// <summary>Preferred cutter travel after the final ridge; may be limited by the cylinder boundary.</summary>
        internal static double GetAxialOverrunMm(double leadMm)
        {
            if (!Finite(leadMm) || leadMm <= 0.0)
                throw new ArgumentOutOfRangeException(nameof(leadMm), "Lead must be finite and positive.");
            return Math.Max(MinimumAxialOverrunMm, leadMm);
        }

        /// <summary>
        /// The outerOrigin used by the helix is inset from the selected circular edge.
        /// This puts the cutter's beginning a small distance before the physical edge itself.
        /// </summary>
        internal static double GetStartOverrunMm(double threadStartInsetMm)
        {
            if (!Finite(threadStartInsetMm) || threadStartInsetMm < 0.0)
                throw new ArgumentOutOfRangeException(nameof(threadStartInsetMm), "Thread-start inset must be finite and non-negative.");
            return threadStartInsetMm + EdgeSafetyOverrunMm;
        }

        /// <summary>
        /// Prefer max(1 mm, lead) after the last thread ridge where there is room. Near a shoulder,
        /// cap the travel at 0.25 mm past the far boundary of the selected cylindrical face.
        /// </summary>
        internal static double GetEndOverrunMm(double leadMm, double availableAfterThreadMm)
        {
            double preferred = GetAxialOverrunMm(leadMm);
            if (!Finite(availableAfterThreadMm) || availableAfterThreadMm < 0.0)
                throw new ArgumentOutOfRangeException(nameof(availableAfterThreadMm), "Remaining cylindrical-face span must be finite and non-negative.");
            return Math.Min(preferred, availableAfterThreadMm + EdgeSafetyOverrunMm);
        }

        internal sealed class Plan
        {
            public bool Enabled { get; internal set; }
            public bool IsInternalThread { get; internal set; }
            public int SlotCount { get; internal set; }
            public double WidthDegrees { get; internal set; }
            public double SpacingDegrees { get; internal set; }

            /// <summary>
            /// The slot starts at the centre angle plus half the requested width. The Revolve is
            /// directed toward the sketch's positive normal, which sweeps back toward the centre.
            /// </summary>
            internal double GetStartAngleDegrees(int zeroBasedIndex)
            {
                if (!Enabled) throw new InvalidOperationException("Vent slots are disabled.");
                if (zeroBasedIndex < 0 || zeroBasedIndex >= SlotCount) throw new ArgumentOutOfRangeException(nameof(zeroBasedIndex));
                return zeroBasedIndex * SpacingDegrees + WidthDegrees / 2.0;
            }
        }

        internal static int GetDefaultCount(bool internalThread) => internalThread ? DefaultInternalSlotCount : DefaultExternalSlotCount;

        internal static double GetDefaultWidthDegrees(bool internalThread) => internalThread ? DefaultInternalSlotWidthDegrees : DefaultExternalSlotWidthDegrees;

        internal static bool TryResolve(bool enabled, bool internalThread, int slotCount, double widthDegrees,
            out Plan plan, out string error)
        {
            plan = null;
            error = null;
            if (!enabled)
            {
                plan = new Plan { Enabled = false, IsInternalThread = internalThread, SlotCount = 0, WidthDegrees = 0.0, SpacingDegrees = 0.0 };
                return true;
            }
            if (slotCount < MinimumSlotCount || slotCount > MaximumSlotCount)
                return Reject("Число вентиляционных пропилов должно быть от 1 до 20.", out error);
            if (!Finite(widthDegrees) || widthDegrees < MinimumSlotWidthDegrees || widthDegrees > MaximumSlotWidthDegrees)
                return Reject("Угловая ширина пропила должна быть в диапазоне 0,5–120°.", out error);
            double spacing = 360.0 / slotCount;
            if (widthDegrees >= spacing - 1e-9)
                return Reject(string.Format(System.Globalization.CultureInfo.InvariantCulture,
                    "Ширина одного пропила {0:0.###}° должна быть меньше углового интервала {1:0.###}° при числе пропилов {2}.",
                    widthDegrees, spacing, slotCount), out error);
            plan = new Plan
            {
                Enabled = true,
                IsInternalThread = internalThread,
                SlotCount = slotCount,
                WidthDegrees = widthDegrees,
                SpacingDegrees = spacing
            };
            return true;
        }

        private static bool Reject(string message, out string error)
        {
            error = message;
            return false;
        }

        private static bool Finite(double value) => !double.IsNaN(value) && !double.IsInfinity(value);
    }
}
