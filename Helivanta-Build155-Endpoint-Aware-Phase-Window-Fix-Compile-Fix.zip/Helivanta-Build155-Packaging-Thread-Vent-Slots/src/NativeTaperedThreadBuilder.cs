﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Runtime.InteropServices;
using Inventor;

namespace ThreadPro
{
    /// <summary>
    /// End-to-end native tapered-thread workflow:
    /// selected cylindrical circular edge -> standards-ratio conical host -> native ThreadFeature.
    /// The caller owns one Inventor transaction around both geometry operations.
    /// </summary>
    internal static class NativeTaperedThreadBuilder
    {
        internal static ThreadFeature LastCreatedFeature { get; private set; }
        /// <summary>Ordered host + thread objects, all tagged together so edit/undo can remove the host cone too.</summary>
        internal static List<object> LastCreatedObjects { get; private set; } = new List<object>();

        private sealed class PreparedHost
        {
            internal Face ConeFace;
            internal Edge StartEdge;
            internal List<RevolveFeature> Revolves = new List<RevolveFeature>();
            internal List<PlanarSketch> Sketches = new List<PlanarSketch>();
            internal List<WorkPlane> WorkPlanes = new List<WorkPlane>();
            internal double StartDiameterMm;
            internal double EndDiameterMm;
            internal double HostLengthCm;
        }

        private sealed class PreparedGroove
        {
            internal WorkPlane WorkPlane;
            internal PlanarSketch Sketch;
            internal CoilFeature Coil;
            internal List<object> RunoutObjects = new List<object>();
            internal string RunoutSummary = string.Empty;
        }

        internal static void ValidateSourceTarget(ThreadTarget target, ThreadParams p)
        {
            if (target == null || p == null) throw new ArgumentNullException();
            if (target.IsConical || target.SelectedFace == null ||
                target.SelectedFace.SurfaceType != SurfaceTypeEnum.kCylinderSurface || target.SelectedEdge == null)
                throw new InvalidOperationException(
                    "Для наружной конической резьбы выберите круговое ребро на свободном малом конце; для внутренней — круговое ребро на широком входе отверстия. Helivanta сама подготовит конус 1:16; готовая коническая грань как исходная заготовка пока не поддерживается.");
            if (target.Body == null || !target.Body.IsSolid)
                throw new InvalidOperationException("Автоматическая подготовка конической резьбы разрешена только на замкнутом твёрдом теле.");
            if (target.Center == null || target.Center.Length < 3 || target.U == null || target.U.Length < 3 ||
                !Finite(target.RadiusCm) || target.RadiusCm <= 0.0 || !Finite(target.LengthCm) || target.LengthCm <= 0.0)
                throw new InvalidOperationException("Не удалось надёжно определить ось, радиус и длину выбранной цилиндрической поверхности.");
            if (target.IsExternal != p.External)
                throw new InvalidOperationException("Тип резьбы не совпадает с выбранной поверхностью (наружная/внутренняя).");
            double ratio;
            if (!TaperedThreadGeometryPolicy.TryGetDiameterRatio(p.TaperStandard, out ratio))
                throw new InvalidOperationException("Для автоматического построения поддерживаются только таблицы NPT и JIS Taper Inventor с конусностью 1:16.");
            if (string.IsNullOrWhiteSpace(p.TaperDesignation))
                throw new InvalidOperationException("Выберите полное обозначение конической резьбы из установленной таблицы Inventor.");
            if (p.Starts != 1)
                throw new InvalidOperationException("Для конической резьбы NPT/JIS используется однозаходное обозначение из таблицы. Установите число заходов 1.");
            double hostLengthCm;
            string lengthError;
            if (!TaperedThreadGeometryPolicy.TryGetHostLengthCm(p.FullLength, target.LengthCm,
                p.LengthMm, p.OffsetMm, out hostLengthCm, out lengthError))
                throw new InvalidOperationException(lengthError);
            // The target cylinder is stock, not the final thread diameter. The actual start/end
            // diameters are read from Inventor's selected thread designation in Build(), before
            // opening a geometry operation. Therefore do not derive the standard cone from the
            // picked stock radius here.
        }

        /// <summary>
        /// Resolves table dimensions for a schematic, non-transacting tapered preview. This method
        /// reads ThreadTableQuery only; it must not open a transaction or alter the source model.
        /// </summary>
        internal static bool TryPreparePreviewParameters(Inventor.Application app, ThreadTarget source,
            ThreadParams p, out string error)
        {
            error = null;
            try
            {
                ValidateSourceTarget(source, p);
                if (app == null) throw new ArgumentNullException("app");
                double ratio;
                if (!TaperedThreadGeometryPolicy.TryGetDiameterRatio(p.TaperStandard, out ratio))
                    throw new InvalidOperationException("Неизвестная конусность выбранного стандарта.");
                double hostLengthCm;
                string lengthError;
                if (!TaperedThreadGeometryPolicy.TryGetHostLengthCm(p.FullLength, source.LengthCm,
                    p.LengthMm, p.OffsetMm, out hostLengthCm, out lengthError))
                    throw new InvalidOperationException(lengthError);
                ThreadInfo info = ResolveThreadInfo(app, p);
                double startRadiusCm, endRadiusCm;
                string geometryError;
                if (!TryResolveTaperRadii(info, p.External, p.TaperGeometryMode, source.RadiusCm,
                    hostLengthCm, p.OffsetMm, ratio, out startRadiusCm, out endRadiusCm, out geometryError))
                    throw new InvalidOperationException(geometryError);
                double pitchMm, depthMm;
                if (!TryGetNativePitchAndDepthMm(info, out pitchMm, out depthMm, out geometryError))
                    throw new InvalidOperationException(geometryError);

                p.PitchMm = pitchMm;
                p.TaperThreadDepthMm = depthMm;
                p.TaperRatio = ratio;
                p.TaperStartDiameterMm = startRadiusCm * 20.0;
                p.TaperEndDiameterMm = endRadiusCm * 20.0;
                p.TaperReferenceDiameterMm = p.TaperStartDiameterMm;
                p.TaperReferenceLengthMm = hostLengthCm * 10.0;
                p.NominalDiaMm = p.TaperStartDiameterMm;
                // Standard tapered clearance remains zero. Real smooth Loft run-out is now
                // supported on the conical B-rep path; the radio option selects section density.
                // Tool overrun, profile rounding and chamfer are still disabled for the taper path.
                p.ClearanceMm = 0.0;
                p.RunOut = false;
                p.Round = false;
                return true;
            }
            catch (Exception ex)
            {
                error = ex.Message;
                return false;
            }
        }

        internal static void ValidateWallThicknessOrThrow(Inventor.Application app, ThreadTarget source, ThreadParams p)
        {
            ValidateSourceTarget(source, p);
            if (app == null) throw new ArgumentNullException("app");
            double ratio;
            if (!TaperedThreadGeometryPolicy.TryGetDiameterRatio(p.TaperStandard, out ratio))
                throw new InvalidOperationException("Неизвестная конусность выбранного стандарта.");
            double hostLengthCm;
            string lengthError;
            if (!TaperedThreadGeometryPolicy.TryGetHostLengthCm(p.FullLength, source.LengthCm,
                p.LengthMm, p.OffsetMm, out hostLengthCm, out lengthError))
                throw new InvalidOperationException(lengthError);
            ThreadInfo info = ResolveThreadInfo(app, p);
            double startRadiusCm, endRadiusCm;
            string diameterError;
            if (!TryResolveTaperRadii(info, p.External, p.TaperGeometryMode, source.RadiusCm,
                hostLengthCm, p.OffsetMm, ratio, out startRadiusCm, out endRadiusCm, out diameterError))
                throw new InvalidOperationException(diameterError);
            double pitchMm, depthMm;
            string profileError;
            if (!TryGetNativePitchAndDepthMm(info, out pitchMm, out depthMm, out profileError))
                throw new InvalidOperationException(profileError);
            string chamferError;
            double chamferStartCm = p.OffsetMm / 10.0;
            bool chamferStartShoulder = source.StartIsShoulder && chamferStartCm <= 1e-6;
            bool chamferEndShoulder = source.EndIsShoulder && p.FullLength;
            if (!TaperedThreadGeometryPolicy.TryValidateChamfer(p.ChamferMode, p.ChamferMm,
                chamferStartCm, hostLengthCm, startRadiusCm, endRadiusCm, p.External,
                chamferStartShoulder, chamferEndShoulder, out chamferError))
                throw new InvalidOperationException(chamferError + " Модель не изменена.");
            ThreadWallThicknessGuard.ValidateTaperedOrThrow(app, source, p,
                hostLengthCm, startRadiusCm, endRadiusCm, pitchMm, depthMm);
        }

        internal static int Build(Inventor.Application app, ThreadTarget source, ThreadParams p)
        {
            if (app == null || source == null || p == null) throw new ArgumentNullException();
            LastCreatedFeature = null;
            LastCreatedObjects = new List<object>();
            ValidateSourceTarget(source, p);
            if (!p.TaperGeometryChangeConfirmed)
                throw new InvalidOperationException("Коническая резьба изменяет твёрдую геометрию: подготовит конус и вырежет физические витки. Сначала покажите предупреждение и получите явное подтверждение пользователя. Деталь не изменена.");

            PartDocument doc = app.ActiveDocument as PartDocument;
            if (doc == null) throw new InvalidOperationException("Активный документ должен быть деталью Inventor (.ipt).");
            string activeName = null;
            try { activeName = doc.InternalName; } catch { }
            if (!string.IsNullOrEmpty(source.SourceDocumentInternalName) &&
                !string.Equals(source.SourceDocumentInternalName, activeName, StringComparison.OrdinalIgnoreCase))
                throw new InvalidOperationException("Выбранное ребро принадлежит другой детали. Повторно выберите его в активном документе.");

            double diameterRatio;
            if (!TaperedThreadGeometryPolicy.TryGetDiameterRatio(p.TaperStandard, out diameterRatio))
                throw new InvalidOperationException("Неизвестная конусность для выбранного стандарта.");

            PartComponentDefinition def = doc.ComponentDefinition;
            ThreadFeatures threadFeatures = def.Features.ThreadFeatures;
            ThreadInfo info = ResolveThreadInfo(app, p);
            string nativeDisplayDesignation = SafeDesignation((dynamic)info);
            p.TaperDisplayDesignation = !string.IsNullOrWhiteSpace(nativeDisplayDesignation) &&
                !string.Equals(nativeDisplayDesignation, "неизвестное", StringComparison.OrdinalIgnoreCase)
                ? nativeDisplayDesignation : p.TaperDesignation;

            double hostLengthCm;
            string lengthError;
            if (!TaperedThreadGeometryPolicy.TryGetHostLengthCm(p.FullLength, source.LengthCm,
                p.LengthMm, p.OffsetMm, out hostLengthCm, out lengthError))
                throw new InvalidOperationException(lengthError);
            double desiredStartRadiusCm, endRadiusCm;
            string diameterError;
            if (!TryResolveTaperRadii(info, p.External, p.TaperGeometryMode, source.RadiusCm,
                hostLengthCm, p.OffsetMm, diameterRatio, out desiredStartRadiusCm, out endRadiusCm, out diameterError))
                throw new InvalidOperationException(diameterError);

            double tablePitchMm, tableDepthMm;
            string profileError;
            if (!TryGetNativePitchAndDepthMm(info, out tablePitchMm, out tableDepthMm, out profileError))
                throw new InvalidOperationException(profileError + " Геометрия не изменена.");
            double threadAngleDegrees;
            if (!TaperedThreadGeometryPolicy.TryGetThreadAngleDegrees(p.TaperStandard, out threadAngleDegrees))
                throw new InvalidOperationException("Для физического профиля не определён угол резьбы стандарта «" + p.TaperStandard + "». Геометрия не изменена.");
            double grooveTopWidthMm, grooveRootWidthMm;
            if (!TaperedThreadGeometryPolicy.TryGetPhysicalGrooveDimensionsMm(tablePitchMm, tableDepthMm,
                threadAngleDegrees, out grooveTopWidthMm, out grooveRootWidthMm, out profileError))
                throw new InvalidOperationException(profileError + " Геометрия не изменена.");

            // Strict mode uses the selected Inventor table end diameter. Free mode preserves
            // the selected stock cylinder at the far end and derives the selected-edge diameter.
            // Both modes use the standard 1:16 taper and zero technological clearance.

            // The source diameter is stock, not a hard constraint. If it crosses the target cone,
            // CreateConicalHost performs separate Cut and Join revolutions at the analytic crossing
            // station. The dialog has already shown the stock and target diameters and obtained consent.
            p.PitchMm = tablePitchMm;
            p.TaperThreadDepthMm = tableDepthMm;

            PreparedHost host = CreateConicalHost(app, doc, source, p, hostLengthCm,
                desiredStartRadiusCm, endRadiusCm);
            if (host == null || host.ConeFace == null || host.StartEdge == null || host.Revolves == null || host.Revolves.Count == 0)
                throw new InvalidOperationException("Helivanta не смогла восстановить созданную коническую грань и её начальное круговое ребро. Изменения будут отменены.");

            // Group every segment used to prepare the cone. Crossing stock needs both a Cut and a
            // Join revolution; edit/delete must remove both, as well as their sketches/work planes.
            foreach (WorkPlane generatedPlane in host.WorkPlanes) LastCreatedObjects.Add(generatedPlane);
            foreach (PlanarSketch generatedSketch in host.Sketches) LastCreatedObjects.Add(generatedSketch);
            foreach (RevolveFeature generatedRevolve in host.Revolves) LastCreatedObjects.Add(generatedRevolve);

            // The prepared conical face has its standard-derived large-end circle at the original
            // edge station. Offset remains measured from that station and is applied exactly once.
            object depth = p.FullLength ? null : (object)(p.LengthMm.ToString(CultureInfo.InvariantCulture) + " mm");
            object offset = p.OffsetMm.ToString(CultureInfo.InvariantCulture) + " mm";
            ThreadFeature feature;
            try
            {
                // The generated cone has its own geometric axis orientation; do not reuse the
                // source cylinder's DirectionReversed flag. Determine direction from the new face
                // axis so the native callout advances from the picked start edge toward the far end.
                bool nativeDirectionReversed = GetDirectionReversedForFace(host.ConeFace, source.U);
                feature = threadFeatures.Add(host.ConeFace, host.StartEdge, info,
                    nativeDirectionReversed, p.FullLength, depth, offset);
                if (feature == null) throw new InvalidOperationException("Inventor не вернул ThreadFeature.");
                // Keep the native ThreadFeature for standard/callout metadata, but hide its
                // cosmetic 3D threads: the following CoilFeature creates real helical B-rep grooves.
                feature.DisplayInModel = false;
                doc.Update();
                if (feature.HealthStatus != HealthStatusEnum.kUpToDateHealth)
                    throw new InvalidOperationException("Inventor создал нативное обозначение резьбы, но состояние операции не UpToDate: " + feature.HealthStatus + ". Вся операция будет отменена.");
            }
            catch (Exception ex)
            {
                throw new InvalidOperationException("Не удалось создать нативную коническую резьбу на подготовленной поверхности. Проверены стандарт, обозначение, длина и выбранный диаметр; исходная деталь будет восстановлена откатом. Причина Inventor: " + ex.Message, ex);
            }

            LastCreatedFeature = feature;
            LastCreatedObjects.Add(feature);

            PreparedGroove physicalGroove;
            try
            {
                physicalGroove = CreatePhysicalThreadGroove(app, doc, source, p, host,
                    desiredStartRadiusCm, hostLengthCm, diameterRatio, threadAngleDegrees,
                    grooveTopWidthMm, grooveRootWidthMm, tableDepthMm);
            }
            catch (Exception ex)
            {
                throw new InvalidOperationException("Нативное обозначение было создано, но физическая винтовая канавка не построилась. Операция целиком будет отменена, чтобы не оставить одну косметическую резьбу. Причина Inventor: " + ex.Message, ex);
            }
            LastCreatedObjects.Add(physicalGroove.WorkPlane);
            LastCreatedObjects.Add(physicalGroove.Sketch);
            LastCreatedObjects.Add(physicalGroove.Coil);
            if (physicalGroove.RunoutObjects != null)
                foreach (object runoutObject in physicalGroove.RunoutObjects)
                    if (runoutObject != null) LastCreatedObjects.Add(runoutObject);
            if (!string.IsNullOrWhiteSpace(physicalGroove.RunoutSummary))
                TransactionLifecycleDiagnostics.Write("NativeTaperedThreadBuilder", "physical-taper-runout-summary", app, doc, null, false,
                    physicalGroove.RunoutSummary);

            // Metadata follows the actual source edge and standard rather than the unrelated parallel-thread controls.
            p.TaperRatio = diameterRatio;
            p.TaperReferenceDiameterMm = host.StartDiameterMm;
            p.TaperReferenceLengthMm = hostLengthCm * 10.0;
            p.TaperStartDiameterMm = host.StartDiameterMm;
            p.TaperEndDiameterMm = host.EndDiameterMm;
            p.SizeName = p.TaperDesignation;
            p.NominalDiaMm = host.StartDiameterMm;
            p.Starts = 1;
            // Preserve the selected smooth/simple run-out settings in metadata. The run-out Loft
            // features above are real Cut operations and part of the same named thread group.
            p.RunOut = false;
            p.Round = false;
            p.Mirror = false;
            p.ClearanceMm = 0.0;
            p.ToleranceClass = string.Empty;
            return 1;
        }

        private static bool TryGetNativePitchAndDepthMm(ThreadInfo info,
            out double pitchMm, out double depthMm, out string error)
        {
            pitchMm = depthMm = 0.0;
            error = null;
            try
            {
                dynamic native = info;
                bool metric = Convert.ToBoolean(native.Metric, CultureInfo.InvariantCulture);
                double pitchValue = 0.0;
                double threadHeight = 0.0;
                string threadsPerInch = string.Empty;
                try { pitchValue = Convert.ToDouble(native.Pitch, CultureInfo.InvariantCulture); } catch { }
                try { threadsPerInch = Convert.ToString(native.ThreadsPerInch, CultureInfo.InvariantCulture) ?? string.Empty; } catch { }
                try { threadHeight = Convert.ToDouble(native.ThreadHeight, CultureInfo.InvariantCulture); } catch { }
                return TaperedThreadGeometryPolicy.TryResolvePitchAndDepthMm(metric, pitchValue,
                    threadsPerInch, threadHeight, out pitchMm, out depthMm, out error);
            }
            catch (Exception ex)
            {
                error = "Не удалось прочитать Pitch/ThreadsPerInch и ThreadHeight из таблицы Inventor: " + ex.Message;
                return false;
            }
        }

        private static PreparedGroove CreatePhysicalThreadGroove(Inventor.Application app, PartDocument doc,
            ThreadTarget source, ThreadParams p, PreparedHost host, double desiredStartRadiusCm,
            double hostLengthCm, double diameterRatio, double threadAngleDegrees,
            double topWidthMm, double rootWidthMm, double threadDepthMm)
        {
            if (app == null || doc == null || source == null || p == null || host == null || source.Body == null)
                throw new ArgumentNullException();

            double offsetCm = p.OffsetMm / 10.0;
            double pitchCm = p.PitchMm / 10.0;
            double depthCm = threadDepthMm / 10.0;
            double topHalfCm = topWidthMm / 20.0;
            double rootHalfCm = rootWidthMm / 20.0;
            double extensionCm = pitchCm * 0.04;

            // Keep the cutter profile inside the intended axial envelope at shoulders. The final
            // full-depth core is shortened by the requested real run-out Loft(s), not by changing
            // the standard pitch/depth or the prepared taper.
            double physicalStartStationCm = offsetCm;
            if (source.StartIsShoulder && physicalStartStationCm < topHalfCm * 1.05)
                physicalStartStationCm = topHalfCm * 1.05;
            double physicalEndStationCm = hostLengthCm;
            if (source.EndIsShoulder && hostLengthCm >= source.LengthCm - 1e-6)
                physicalEndStationCm -= topHalfCm * 1.05;

            bool smoothStart = p.Smooth && p.OffsetMm > 1e-6 && !source.StartIsShoulder;
            bool smoothEnd = p.Smooth && (!p.FullLength || source.EndIsShoulder) &&
                (!p.FullLength || hostLengthCm >= source.LengthCm - 1e-6);
            double coreStartStationCm, coreEndStationCm, runLengthCm;
            string runoutPlanError;
            if (!TaperedThreadGeometryPolicy.TryGetRunoutStationsCm(
                physicalStartStationCm, physicalEndStationCm, pitchCm, p.RunSteps,
                smoothStart, smoothEnd, out coreStartStationCm, out coreEndStationCm,
                out runLengthCm, out runoutPlanError))
                throw new InvalidOperationException(runoutPlanError);
            double threadLengthCm = coreEndStationCm - coreStartStationCm;
            if (!Finite(threadLengthCm) || threadLengthCm <= pitchCm * 0.5 ||
                !Finite(pitchCm) || pitchCm <= 0.0 || !Finite(depthCm) || depthCm <= 0.0 || rootHalfCm <= 0.0)
                throw new InvalidOperationException("Недостаточная длина или некорректные размеры физической винтовой канавки после учёта плеча и сбега.");

            double taperRadialSign = p.External ? 1.0 : -1.0;
            double radialSign = p.External ? -1.0 : 1.0;
            Func<double, double> ConeRadiusAt = stationCm =>
                desiredStartRadiusCm + taperRadialSign * stationCm * diameterRatio / 2.0;
            double startRadiusAtThreadCm = ConeRadiusAt(coreStartStationCm);
            if (!Finite(startRadiusAtThreadCm) || startRadiusAtThreadCm <= depthCm * 1.05)
                throw new InvalidOperationException("Расчётный радиус начала физического витка слишком мал относительно глубины профиля.");

            double[] u = Normalize(source.U);
            double[] helper = Math.Abs(u[0]) < 0.9 ? new[] { 1.0, 0.0, 0.0 } : new[] { 0.0, 1.0, 0.0 };
            double[] r = Normalize(Cross(u, Cross(helper, u)));
            double[] q = Normalize(Cross(u, r));
            double[] origin = new[]
            {
                source.Center[0] + u[0] * coreStartStationCm,
                source.Center[1] + u[1] * coreStartStationCm,
                source.Center[2] + u[2] * coreStartStationCm
            };
            TransientGeometry tg = app.TransientGeometry;
            PartComponentDefinition def = doc.ComponentDefinition;
            WorkPlane wp = null;
            PlanarSketch sketch = null;
            CoilFeature coil = null;
            var runoutObjects = new List<object>();
            var runoutNotes = new List<string>();
            try
            {
                // Cut the end chamfer into the prepared cone before creating the helical groove and
                // its run-out lofts. Applying a Revolve cut after those intersecting cuts can leave
                // narrow sliver faces at the first/last thread; later groove operations should trim
                // into the already-chamfered stock instead.
                if (p.ChamferMode == 1 || p.ChamferMode == 3)
                    AddTaperedChamferCut("Фаска конической резьбы у начала", true);
                if (p.ChamferMode == 2 || p.ChamferMode == 3)
                    AddTaperedChamferCut("Фаска конической резьбы у конца", false);

                wp = def.WorkPlanes.AddFixed(
                    tg.CreatePoint(origin[0], origin[1], origin[2]),
                    tg.CreateUnitVector(r[0], r[1], r[2]),
                    tg.CreateUnitVector(u[0], u[1], u[2]), false);
                wp.Visible = false;
                try { wp.Name = "Helivanta — плоскость физической конической резьбы"; } catch { }

                sketch = def.Sketches.Add(wp);
                try { sketch.Name = "Helivanta — профиль физической канавки " + threadAngleDegrees.ToString("0.#", CultureInfo.InvariantCulture) + "°"; } catch { }

                Point2d S(double axialCm, double depthOffsetCm)
                {
                    double radius = startRadiusAtThreadCm + radialSign * depthOffsetCm;
                    Inventor.Point modelPoint = tg.CreatePoint(
                        origin[0] + u[0] * axialCm + r[0] * radius,
                        origin[1] + u[1] * axialCm + r[1] * radius,
                        origin[2] + u[2] * axialCm + r[2] * radius);
                    return sketch.ModelToSketchSpace(modelPoint);
                }

                Point2d AxisPoint(double axialCm)
                {
                    Inventor.Point modelPoint = tg.CreatePoint(
                        origin[0] + u[0] * axialCm,
                        origin[1] + u[1] * axialCm,
                        origin[2] + u[2] * axialCm);
                    return sketch.ModelToSketchSpace(modelPoint);
                }
                SketchLine axisLine = sketch.SketchLines.AddByTwoPoints(AxisPoint(0.0), AxisPoint(threadLengthCm));
                axisLine.Construction = true;
                var points = new List<Point2d>
                {
                    S(-topHalfCm, -extensionCm),
                    S( topHalfCm, -extensionCm),
                    S( topHalfCm, 0.0),
                    S( rootHalfCm, depthCm),
                    S(-rootHalfCm, depthCm),
                    S(-topHalfCm, 0.0)
                };
                // Profiles.AddForSolid requires shared SketchPoint topology at every join.
                object firstStart = null;
                object previousEnd = null;
                for (int i = 0; i < points.Count; i++)
                {
                    object startObject = i == 0 ? (object)points[i] : previousEnd;
                    object endObject = i == points.Count - 1 && firstStart != null
                        ? firstStart : (object)points[(i + 1) % points.Count];
                    SketchLine segment = sketch.SketchLines.AddByTwoPoints(startObject, endObject);
                    if (segment == null)
                        throw new InvalidOperationException("Inventor не создал сегмент " + (i + 1) + " из " + points.Count + " в профиле физической канавки.");
                    if (i == 0) firstStart = segment.StartSketchPoint;
                    previousEnd = segment.EndSketchPoint;
                }

                Profile profile;
                try { profile = sketch.Profiles.AddForSolid(); }
                catch (Exception profileEx)
                {
                    throw new InvalidOperationException(string.Format(CultureInfo.InvariantCulture,
                        "Inventor отверг профиль физической канавки до вызова CoilFeature. Ожидался замкнутый шестисегментный профиль; P={0:0.###} мм, H={1:0.###} мм, верхняя ширина={2:0.###} мм, ширина впадины={3:0.###} мм, длина полного витка={4:0.###} мм. Ошибка профиля: {5}",
                        p.PitchMm, threadDepthMm, topWidthMm, rootWidthMm, threadLengthCm * 10.0, profileEx.Message), profileEx);
                }
                if (profile == null) throw new InvalidOperationException("Inventor вернул пустой Profile для физической конической канавки.");

                doc.Update();
                double volumeBeforeCoil = doc.ComponentDefinition.MassProperties.Volume;
                int bodyCountBeforeCoil = doc.ComponentDefinition.SurfaceBodies.Count;
                if (!Finite(volumeBeforeCoil) || volumeBeforeCoil <= 0.0 || bodyCountBeforeCoil < 1)
                    throw new InvalidOperationException("Не удалось получить достоверный объём исходного тела перед CoilFeature.");

                double revolutions = threadLengthCm / pitchCm;
                double coilTaperAngle;
                if (!TaperedThreadGeometryPolicy.TryGetCoilTaperAngleRadians(diameterRatio, p.External, out coilTaperAngle))
                    throw new InvalidOperationException("Не удалось определить знак конусности физической спирали.");
                TransactionLifecycleDiagnostics.Write("NativeTaperedThreadBuilder", "physical-coil-parameters", app, doc, null, false,
                    string.Format(CultureInfo.InvariantCulture,
                        "standard={0}; designation={1}; external={2}; rightHand={3}; coilTaperRadians={4:0.########}; pitchCm={5:0.########}; revolutions={6:0.######}; coreLengthCm={7:0.######}; physicalStartCm={8:0.######}; physicalEndCm={9:0.######}; coreStartCm={10:0.######}; coreEndCm={11:0.######}; startRadiusCm={12:0.######}; depthMm={13:0.######}; topWidthMm={14:0.######}; rootWidthMm={15:0.######}; smoothStart={16}; smoothEnd={17}; runoutLengthCm={18:0.######}; runoutMode=smooth",
                        p.TaperStandard, p.TaperDesignation, p.External, p.RightHand, coilTaperAngle,
                        pitchCm, revolutions, threadLengthCm, physicalStartStationCm, physicalEndStationCm,
                        coreStartStationCm, coreEndStationCm, startRadiusAtThreadCm, threadDepthMm, topWidthMm,
                        rootWidthMm, smoothStart, smoothEnd, runLengthCm));
                try
                {
                    coil = def.Features.CoilFeatures.AddByPitchAndRevolution(
                        profile, axisLine, pitchCm, revolutions,
                        PartFeatureOperationEnum.kCutOperation,
                        false, !p.RightHand, coilTaperAngle);
                }
                catch (Exception coilEx)
                {
                    throw new InvalidOperationException(string.Format(CultureInfo.InvariantCulture,
                        "Профиль принят Inventor, но CoilFeature отклонён. P={0:0.###} мм ({1:0.######} см), обороты={2:0.###}, длина={3:0.###} мм, угол конусности={4:0.######} рад, наружная={5}, правая={6}. Причина: {7}",
                        p.PitchMm, pitchCm, revolutions, threadLengthCm * 10.0, coilTaperAngle,
                        p.External, p.RightHand, coilEx.Message), coilEx);
                }
                if (coil == null) throw new InvalidOperationException("Inventor не вернул физический CoilFeature.");
                ObjectCollection affected = app.TransientObjects.CreateObjectCollection();
                affected.Add(source.Body);
                coil.SetAffectedBodies(affected);
                try { coil.Name = "Helivanta — физическая коническая резьба " + p.TaperDesignation; } catch { }
                sketch.Visible = false;
                wp.Visible = false;
                doc.Update();
                if (coil.HealthStatus != HealthStatusEnum.kUpToDateHealth)
                    throw new InvalidOperationException("Физический CoilFeature создан, но состояние не UpToDate: " + coil.HealthStatus + ".");
                double volumeAfterCoil = doc.ComponentDefinition.MassProperties.Volume;
                int bodyCountAfterCoil = doc.ComponentDefinition.SurfaceBodies.Count;
                double volumeTolerance = Math.Max(1e-8, Math.Abs(volumeBeforeCoil) * 1e-10);
                double meanRadiusAtEndCm = startRadiusAtThreadCm + taperRadialSign * threadLengthCm * diameterRatio / 2.0;
                double meanRadiusCm = (startRadiusAtThreadCm + meanRadiusAtEndCm) / 2.0;
                double coilPathLengthCm = Math.Sqrt(threadLengthCm * threadLengthCm +
                    Math.Pow(2.0 * Math.PI * Math.Max(0.0, meanRadiusCm) * revolutions, 2.0));
                double grooveSectionAreaCm2 = (threadDepthMm * (topWidthMm + rootWidthMm) / 2.0) / 100.0;
                double estimatedCutterVolumeCm3 = grooveSectionAreaCm2 * coilPathLengthCm;
                double requiredVolumeReductionCm3 = Math.Max(volumeTolerance, estimatedCutterVolumeCm3 * 0.05);
                if (!Finite(volumeAfterCoil) || !Finite(estimatedCutterVolumeCm3) || estimatedCutterVolumeCm3 <= 0.0 ||
                    volumeBeforeCoil - volumeAfterCoil <= requiredVolumeReductionCm3)
                    throw new InvalidOperationException(string.Format(CultureInfo.InvariantCulture,
                        "CoilFeature создан, но фактическое удаление материала недостаточно для настоящей канавки. Объём до={0:0.#########} см³, после={1:0.#########} см³, удалено={2:0.#########} см³, ожидаемый объём инструмента≈{3:0.#########} см³, минимальное удаление={4:0.#########} см³. Операция будет отменена, чтобы не оставить пружинообразную спираль.",
                        volumeBeforeCoil, volumeAfterCoil, volumeBeforeCoil - volumeAfterCoil,
                        estimatedCutterVolumeCm3, requiredVolumeReductionCm3));
                if (bodyCountAfterCoil != bodyCountBeforeCoil)
                    throw new InvalidOperationException("Физическая винтовая канавка изменила число твёрдых тел (до=" + bodyCountBeforeCoil + ", после=" + bodyCountAfterCoil + "). Вероятно, резьба прорезала стенку или создала отдельное тело; операция будет отменена.");

                bool DeleteRunoutTemporaryObjects(List<object> items)
                {
                    if (items == null) return true;
                    bool deletedAll = true;
                    for (int di = items.Count - 1; di >= 0; di--)
                    {
                        object item = items[di];
                        if (item == null) continue;
                        try { ((dynamic)item).Delete(); }
                        catch { deletedAll = false; }
                    }
                    try { doc.Update(); }
                    catch { deletedAll = false; }
                    return deletedAll;
                }

                void AddSegmentedRunoutFallback(string featureName, bool startRunout, double zFrom, double zTo,
                    double fadeLengthCm, Exception loftFailure)
                {
                    double height = zTo - zFrom;
                    if (!Finite(height) || height <= 1e-5 || !Finite(fadeLengthCm) || fadeLengthCm <= 1e-6)
                        throw new InvalidOperationException("Резервный сегментный сбег имеет некорректный осевой интервал.", loftFailure);

                    int fallbackSegments;
                    string segmentPolicyError;
                    if (!TaperedThreadGeometryPolicy.TryGetFallbackRunoutSegmentCount(
                        height, pitchCm, out fallbackSegments, out segmentPolicyError))
                        throw new InvalidOperationException(segmentPolicyError, loftFailure);
                    const double terminalDepthFactor = 0.005;
                    double anchorDepthCm = -Math.Max(extensionCm * 1.5, 1e-4);
                    double[] axialOffsets = { -topHalfCm, topHalfCm, topHalfCm, rootHalfCm, -rootHalfCm, -topHalfCm };
                    double[] depths = { -extensionCm, -extensionCm, 0.0, depthCm, depthCm, 0.0 };
                    var fallbackObjects = new List<object>();
                    double volumeBeforeAll = doc.ComponentDefinition.MassProperties.Volume;

                    for (int seg = 0; seg < fallbackSegments; seg++)
                    {
                        double za = zFrom + height * seg / fallbackSegments;
                        double zb = zFrom + height * (seg + 1) / fallbackSegments;
                        double segHeight = zb - za;
                        double sampleStation = (za + zb) * 0.5;
                        double fadeT = startRunout
                            ? (sampleStation - physicalStartStationCm) / fadeLengthCm
                            : (sampleStation - coreEndStationCm) / fadeLengthCm;
                        fadeT = Math.Max(0.0, Math.Min(1.0, fadeT));
                        double eased = fadeT * fadeT * (3.0 - 2.0 * fadeT);
                        double depthFactor = startRunout
                            ? terminalDepthFactor + (1.0 - terminalDepthFactor) * eased
                            : 1.0 - (1.0 - terminalDepthFactor) * eased;

                        double phase = (p.RightHand ? 1.0 : -1.0) * 2.0 * Math.PI * ((za - coreStartStationCm) / pitchCm);
                        double cp = Math.Cos(phase), sp = Math.Sin(phase);
                        double[] radial = Normalize(new[]
                        {
                            r[0] * cp + q[0] * sp,
                            r[1] * cp + q[1] * sp,
                            r[2] * cp + q[2] * sp
                        });
                        Inventor.Point axisPoint = tg.CreatePoint(
                            source.Center[0] + u[0] * za,
                            source.Center[1] + u[1] * za,
                            source.Center[2] + u[2] * za);
                        WorkPlane segmentPlane = def.WorkPlanes.AddFixed(axisPoint,
                            tg.CreateUnitVector(radial[0], radial[1], radial[2]),
                            tg.CreateUnitVector(u[0], u[1], u[2]), false);
                        segmentPlane.Visible = false;
                        try { segmentPlane.Name = featureName + " — резервная плоскость " + (seg + 1); } catch { }
                        fallbackObjects.Add(segmentPlane);

                        PlanarSketch segmentSketch = def.Sketches.Add(segmentPlane);
                        try { segmentSketch.Name = featureName + " — резервный профиль " + (seg + 1) + "/" + fallbackSegments; } catch { }
                        fallbackObjects.Add(segmentSketch);
                        double baseRadiusCm = ConeRadiusAt(za);
                        if (!Finite(baseRadiusCm) || baseRadiusCm <= depthCm * 1.01)
                            throw new InvalidOperationException("Некорректный локальный радиус в резервном сегменте " + (seg + 1) + ".", loftFailure);

                        var vertices = new List<Point2d>(axialOffsets.Length);
                        for (int vi = 0; vi < axialOffsets.Length; vi++)
                        {
                            double adjustedDepth = anchorDepthCm + (depths[vi] - anchorDepthCm) * depthFactor;
                            double radius = baseRadiusCm + radialSign * adjustedDepth;
                            if (!Finite(radius) || radius <= 1e-5)
                                throw new InvalidOperationException("Резервный профиль сбега пересекает ось вращения.", loftFailure);
                            vertices.Add(tg.CreatePoint2d(radius, axialOffsets[vi]));
                        }
                        object firstPoint = null, previousPoint = null;
                        for (int vi = 0; vi < vertices.Count; vi++)
                        {
                            object pointA = vi == 0 ? (object)vertices[vi] : previousPoint;
                            object pointB = vi == vertices.Count - 1 ? firstPoint : (object)vertices[vi + 1];
                            SketchLine edge = segmentSketch.SketchLines.AddByTwoPoints(pointA, pointB);
                            if (edge == null) throw new InvalidOperationException("Не создано ребро резервного профиля сбега.", loftFailure);
                            if (vi == 0) firstPoint = edge.StartSketchPoint;
                            previousPoint = edge.EndSketchPoint;
                        }
                        SketchLine axisLine = segmentSketch.SketchLines.AddByTwoPoints(
                            segmentSketch.ModelToSketchSpace(axisPoint),
                            segmentSketch.ModelToSketchSpace(tg.CreatePoint(
                                source.Center[0] + u[0] * zb,
                                source.Center[1] + u[1] * zb,
                                source.Center[2] + u[2] * zb)));
                        axisLine.Construction = true;
                        Profile profile = segmentSketch.Profiles.AddForSolid();
                        if (profile == null) throw new InvalidOperationException("Inventor вернул пустой профиль резервного сегмента.", loftFailure);

                        double volumeBefore = doc.ComponentDefinition.MassProperties.Volume;
                        int bodyCountBefore = doc.ComponentDefinition.SurfaceBodies.Count;
                        double revolutions = segHeight / pitchCm;
                        CoilFeature segmentCoil = def.Features.CoilFeatures.AddByPitchAndRevolution(
                            profile, axisLine, pitchCm, revolutions,
                            PartFeatureOperationEnum.kCutOperation, false, !p.RightHand, coilTaperAngle);
                        if (segmentCoil == null) throw new InvalidOperationException("Inventor не вернул CoilFeature резервного сбега.", loftFailure);
                        ObjectCollection affected = app.TransientObjects.CreateObjectCollection();
                        affected.Add(source.Body);
                        segmentCoil.SetAffectedBodies(affected);
                        try { segmentCoil.Name = "Helivanta — " + featureName + " · сегмент " + (seg + 1) + "/" + fallbackSegments; } catch { }
                        segmentSketch.Visible = false;
                        segmentPlane.Visible = false;
                        fallbackObjects.Add(segmentCoil);
                        doc.Update();
                        if (segmentCoil.HealthStatus != HealthStatusEnum.kUpToDateHealth)
                            throw new InvalidOperationException("Резервный Coil сегмента " + (seg + 1) + " не UpToDate: " + segmentCoil.HealthStatus + ".", loftFailure);
                        double volumeAfter = doc.ComponentDefinition.MassProperties.Volume;
                        int bodyCountAfter = doc.ComponentDefinition.SurfaceBodies.Count;
                        double volumeTolerance = Math.Max(1e-8, Math.Abs(volumeBefore) * 1e-11);
                        if (!Finite(volumeAfter) || volumeBefore - volumeAfter <= volumeTolerance)
                            throw new InvalidOperationException("Резервный Coil сегмента " + (seg + 1) + " не удалил измеримый объём материала.", loftFailure);
                        if (bodyCountAfter != bodyCountBefore)
                            throw new InvalidOperationException("Резервный Coil сегмента " + (seg + 1) + " изменил число твёрдых тел.", loftFailure);
                    }

                    runoutObjects.AddRange(fallbackObjects);
                    double volumeAfterAll = doc.ComponentDefinition.MassProperties.Volume;
                    runoutNotes.Add(string.Format(CultureInfo.InvariantCulture,
                        "{0}: резервный конический сегментный Coil после отказа Loft; сегментов {1}; диапазон {2:0.###}–{3:0.###} мм; удалено объёма {4:0.########} см³",
                        featureName, fallbackSegments, zFrom * 10.0, zTo * 10.0, volumeBeforeAll - volumeAfterAll));
                    string fallbackWarning = "Конический Loft сбега не принят Inventor (" + loftFailure.Message + "); использован резервный сегментный Coil (" + fallbackSegments + " сегментов). Визуальную плавность окончания необходимо проверить.";
                    ThreadBuilder.LastWarning = string.IsNullOrWhiteSpace(ThreadBuilder.LastWarning)
                        ? fallbackWarning : ThreadBuilder.LastWarning + System.Environment.NewLine + fallbackWarning;
                    TransactionLifecycleDiagnostics.Write("NativeTaperedThreadBuilder", "taper-runout-segmented-fallback", app, doc,
                        null, false, fallbackWarning + "; volumeBefore=" + volumeBeforeAll.ToString("0.########", CultureInfo.InvariantCulture) +
                        "; volumeAfter=" + volumeAfterAll.ToString("0.########", CultureInfo.InvariantCulture));
                }

                void AddRunoutLoft(string featureName, bool startRunout)
                {
                    // Overlap the fully-cut ends by a small axial amount so Inventor does not have
                    // to boolean two merely tangent cut volumes. The overlap is all at full depth;
                    // only the interval after/before the core boundary receives the depth fade.
                    double overlapCm = Math.Min(pitchCm * 0.08, runLengthCm * 0.15);
                    double zFrom = startRunout ? physicalStartStationCm : coreEndStationCm - overlapCm;
                    double zTo = startRunout ? coreStartStationCm + overlapCm : physicalEndStationCm;
                    double height = zTo - zFrom;
                    if (!Finite(height) || height <= 1e-5)
                        throw new InvalidOperationException("Недостаточная длина для построения " + featureName + ".");
                    double fadeLengthCm = startRunout
                        ? coreStartStationCm - physicalStartStationCm
                        : physicalEndStationCm - coreEndStationCm;
                    if (!Finite(fadeLengthCm) || fadeLengthCm <= 1e-6)
                        throw new InvalidOperationException("Не удалось определить длину перехода профиля для " + featureName + ".");

                    // Estimate angular sampling from the same chord-sagitta principle used by the
                    // cylindrical run-out path. The only supported mode uses 14..18 sections/turn;
                    // larger local radii request denser sampling, while the hard ceiling protects
                    // Inventor's Loft solver from the earlier high-complexity case.
                    double runoutOverhangCm = Math.Max(extensionCm * 1.5, 1e-4);
                    double localRadiusCm = Math.Min(ConeRadiusAt(zFrom), ConeRadiusAt(zTo));
                    int sectionsPerTurn;
                    string sectionDensityError;
                    if (!TaperedThreadGeometryPolicy.TryGetRunoutSectionsPerTurn(
                        localRadiusCm, runoutOverhangCm,
                        out sectionsPerTurn, out sectionDensityError))
                        throw new InvalidOperationException(sectionDensityError);
                    int sectionCount = Math.Max(7, Math.Min(257,
                        (int)Math.Ceiling((height / pitchCm) * sectionsPerTurn) + 1));
                    const double terminalDepthFactor = 0.005;
                    double anchorDepthCm = -Math.Max(extensionCm * 1.5, 1e-4);
                    var temporary = new List<object>();
                    ObjectCollection loftSections = app.TransientObjects.CreateObjectCollection();
                    double volumeBeforeLoft = doc.ComponentDefinition.MassProperties.Volume;
                    int bodyCountBeforeLoft = doc.ComponentDefinition.SurfaceBodies.Count;
                    if (!Finite(volumeBeforeLoft) || volumeBeforeLoft <= 0.0)
                        throw new InvalidOperationException("Не удалось измерить объём перед " + featureName + ".");

                    try
                    {
                        for (int sectionIndex = 0; sectionIndex < sectionCount; sectionIndex++)
                        {
                            double sectionT = sectionIndex / (double)(sectionCount - 1);
                            double stationCm = zFrom + height * sectionT;
                            double fadeT = startRunout
                                ? (stationCm - physicalStartStationCm) / fadeLengthCm
                                : (stationCm - coreEndStationCm) / fadeLengthCm;
                            fadeT = Math.Max(0.0, Math.Min(1.0, fadeT));
                            double eased = fadeT * fadeT * (3.0 - 2.0 * fadeT);
                            double depthFactor = startRunout
                                ? terminalDepthFactor + (1.0 - terminalDepthFactor) * eased
                                : 1.0 - (1.0 - terminalDepthFactor) * eased;

                            double phase = (p.RightHand ? 1.0 : -1.0) * 2.0 * Math.PI *
                                ((stationCm - coreStartStationCm) / pitchCm);
                            double cp = Math.Cos(phase), sp = Math.Sin(phase);
                            double[] radial = Normalize(new[]
                            {
                                r[0] * cp + q[0] * sp,
                                r[1] * cp + q[1] * sp,
                                r[2] * cp + q[2] * sp
                            });
                            Inventor.Point axisPoint = tg.CreatePoint(
                                source.Center[0] + u[0] * stationCm,
                                source.Center[1] + u[1] * stationCm,
                                source.Center[2] + u[2] * stationCm);
                            WorkPlane runoutPlane = def.WorkPlanes.AddFixed(axisPoint,
                                tg.CreateUnitVector(radial[0], radial[1], radial[2]),
                                tg.CreateUnitVector(u[0], u[1], u[2]), false);
                            runoutPlane.Visible = false;
                            try { runoutPlane.Name = featureName + " — плоскость " + (sectionIndex + 1); } catch { }
                            temporary.Add(runoutPlane);

                            PlanarSketch runoutSketch = def.Sketches.Add(runoutPlane);
                            try { runoutSketch.Name = featureName + " — сечение " + (sectionIndex + 1) + "/" + sectionCount; } catch { }
                            temporary.Add(runoutSketch);
                            double baseRadiusCm = ConeRadiusAt(stationCm);
                            if (!Finite(baseRadiusCm) || baseRadiusCm <= depthCm * 1.01)
                                throw new InvalidOperationException("Недопустимый локальный радиус в сечении " + (sectionIndex + 1) + " сбега.");

                            double[] axialOffsets = { -topHalfCm, topHalfCm, topHalfCm, rootHalfCm, -rootHalfCm, -topHalfCm };
                            double[] depths = { -extensionCm, -extensionCm, 0.0, depthCm, depthCm, 0.0 };
                            var sectionPoints = new List<Point2d>(axialOffsets.Length);
                            for (int vertexIndex = 0; vertexIndex < axialOffsets.Length; vertexIndex++)
                            {
                                double depthAtVertex = anchorDepthCm + (depths[vertexIndex] - anchorDepthCm) * depthFactor;
                                double radiusAtVertex = baseRadiusCm + radialSign * depthAtVertex;
                                if (!Finite(radiusAtVertex) || radiusAtVertex <= 1e-5)
                                    throw new InvalidOperationException("Сечение сбега пересекает ось вращения; операция будет отменена.");
                                // Local sketch coordinates: X = radial distance, Y = axial offset.
                                sectionPoints.Add(tg.CreatePoint2d(radiusAtVertex, axialOffsets[vertexIndex]));
                            }
                            object first = null, previous = null;
                            for (int vertexIndex = 0; vertexIndex < sectionPoints.Count; vertexIndex++)
                            {
                                object startPoint = vertexIndex == 0 ? (object)sectionPoints[vertexIndex] : previous;
                                object endPoint = vertexIndex == sectionPoints.Count - 1
                                    ? first : (object)sectionPoints[(vertexIndex + 1) % sectionPoints.Count];
                                SketchLine line = runoutSketch.SketchLines.AddByTwoPoints(startPoint, endPoint);
                                if (line == null) throw new InvalidOperationException("Inventor не создал ребро профиля сечения сбега.");
                                if (vertexIndex == 0) first = line.StartSketchPoint;
                                previous = line.EndSketchPoint;
                            }
                            Profile sectionProfile = runoutSketch.Profiles.AddForSolid();
                            if (sectionProfile == null) throw new InvalidOperationException("Inventor вернул пустой профиль для сечения сбега.");
                            loftSections.Add(sectionProfile);
                        }

                        LoftDefinition definition = def.Features.LoftFeatures.CreateLoftDefinition(
                            loftSections, PartFeatureOperationEnum.kCutOperation);
                        LoftFeature loft = def.Features.LoftFeatures.Add(definition);
                        if (loft == null) throw new InvalidOperationException("Inventor не вернул LoftFeature для " + featureName + ".");
                        temporary.Add(loft);
                        ObjectCollection loftAffectedBodies = app.TransientObjects.CreateObjectCollection();
                        loftAffectedBodies.Add(source.Body);
                        loft.SetAffectedBodies(loftAffectedBodies);
                        try { loft.Name = "Helivanta — " + featureName; } catch { }
                        foreach (object item in temporary)
                        {
                            if (item is WorkPlane) ((WorkPlane)item).Visible = false;
                            if (item is PlanarSketch) ((PlanarSketch)item).Visible = false;
                        }
                        doc.Update();
                        if (loft.HealthStatus != HealthStatusEnum.kUpToDateHealth)
                            throw new InvalidOperationException(featureName + " создан, но состояние LoftFeature не UpToDate: " + loft.HealthStatus + ".");
                        double volumeAfterLoft = doc.ComponentDefinition.MassProperties.Volume;
                        int bodyCountAfterLoft = doc.ComponentDefinition.SurfaceBodies.Count;
                        double loftTolerance = Math.Max(1e-8, Math.Abs(volumeBeforeLoft) * 1e-11);
                        if (!Finite(volumeAfterLoft) || volumeBeforeLoft - volumeAfterLoft <= loftTolerance)
                            throw new InvalidOperationException(string.Format(CultureInfo.InvariantCulture,
                                "{0} создан, но не удалил измеримый объём материала (до={1:0.#########} см³; после={2:0.#########} см³). Сбег не будет считаться успешным; транзакция откатится.",
                                featureName, volumeBeforeLoft, volumeAfterLoft));
                        if (bodyCountAfterLoft != bodyCountBeforeLoft)
                            throw new InvalidOperationException(featureName + " изменил число твёрдых тел (до=" + bodyCountBeforeLoft + ", после=" + bodyCountAfterLoft + "). Транзакция будет отменена.");
                        runoutObjects.AddRange(temporary);
                        runoutNotes.Add(string.Format(CultureInfo.InvariantCulture,
                            "{0}: режим плавный; диапазон {1:0.###}–{2:0.###} мм; переход {3:0.###} мм; секций {4}; удалено объёма {5:0.########} см³",
                            featureName, zFrom * 10.0, zTo * 10.0, fadeLengthCm * 10.0,
                            sectionCount, volumeBeforeLoft - volumeAfterLoft));
                    }
                    catch (Exception loftException)
                    {
                        // Remove the rejected Loft profiles before trying a conical Coil fallback.
                        // The fallback is part of the same Inventor transaction and is accepted only
                        // if every segment is healthy, removes material, and preserves body count.
                        if (!DeleteRunoutTemporaryObjects(temporary))
                            throw new InvalidOperationException("Inventor отклонил Loft и не позволил безопасно удалить все временные сечения; резервный сбег не запускается, транзакция должна быть отменена.", loftException);
                        AddSegmentedRunoutFallback(featureName, startRunout, zFrom, zTo, fadeLengthCm, loftException);
                    }
                }

                void AddTaperedChamferCut(string featureName, bool atStart)
                {
                    double chamferLengthCm = p.ChamferMm / 10.0;
                    double z0 = atStart ? physicalStartStationCm : physicalEndStationCm - chamferLengthCm;
                    double z1 = atStart ? physicalStartStationCm + chamferLengthCm : physicalEndStationCm;
                    if (!Finite(chamferLengthCm) || chamferLengthCm <= 0.0 ||
                        z0 < physicalStartStationCm - 1e-7 || z1 > physicalEndStationCm + 1e-7 || z1 <= z0)
                        throw new InvalidOperationException("Фаска выходит за фактический интервал конической резьбы.");

                    // Extend the cutter just beyond the stock boundary, rather than starting
                    // entirely inside the material. A material-side-only profile can be tangent
                    // to the cone at the exact edge and leave a microscopic annular skin. For an
                    // external thread the free space is outside (larger radius); for an internal
                    // thread it is inside the bore (smaller radius). The cut still extends into
                    // material by the chamfer triangle below.
                    double boundaryOverlapCm = 0.002; // 0.02 mm in Inventor centimetres
                    double voidSideSign = p.External ? 1.0 : -1.0;
                    double baseR0 = ConeRadiusAt(z0) + voidSideSign * boundaryOverlapCm;
                    double baseR1 = ConeRadiusAt(z1) + voidSideSign * boundaryOverlapCm;
                    double chamferSign = p.External ? -1.0 : 1.0;
                    double chamferRadius = (atStart ? baseR0 : baseR1) + chamferSign * chamferLengthCm;
                    if (!Finite(baseR0) || !Finite(baseR1) || !Finite(chamferRadius) ||
                        baseR0 <= 1e-5 || baseR1 <= 1e-5 || chamferRadius <= 1e-5)
                        throw new InvalidOperationException("Фаска пересекает ось или имеет некорректный локальный радиус.");

                    WorkPlane chamferPlane = null;
                    PlanarSketch chamferSketch = null;
                    RevolveFeature chamferFeature = null;
                    try
                    {
                        chamferPlane = def.WorkPlanes.AddFixed(
                            tg.CreatePoint(source.Center[0], source.Center[1], source.Center[2]),
                            tg.CreateUnitVector(r[0], r[1], r[2]),
                            tg.CreateUnitVector(u[0], u[1], u[2]), false);
                        chamferPlane.Visible = false;
                        try { chamferPlane.Name = featureName + " — плоскость"; } catch { }
                        chamferSketch = def.Sketches.Add(chamferPlane);
                        try { chamferSketch.Name = featureName + " — профиль"; } catch { }
                        Point2d ChamferPoint(double station, double radius)
                        {
                            Inventor.Point world = tg.CreatePoint(
                                source.Center[0] + u[0] * station + r[0] * radius,
                                source.Center[1] + u[1] * station + r[1] * radius,
                                source.Center[2] + u[2] * station + r[2] * radius);
                            return chamferSketch.ModelToSketchSpace(world);
                        }
                        SketchLine axisLine = chamferSketch.SketchLines.AddByTwoPoints(
                            ChamferPoint(z0, 0.0), ChamferPoint(z1, 0.0));
                        if (axisLine == null) throw new InvalidOperationException("Не создана ось вращения фаски.");
                        axisLine.Construction = true;
                        Point2d[] corners = atStart
                            ? new[] { ChamferPoint(z0, baseR0), ChamferPoint(z1, baseR1), ChamferPoint(z0, chamferRadius) }
                            : new[] { ChamferPoint(z0, baseR0), ChamferPoint(z1, baseR1), ChamferPoint(z1, chamferRadius) };
                        SketchLine first = chamferSketch.SketchLines.AddByTwoPoints(corners[0], corners[1]);
                        if (first == null) throw new InvalidOperationException("Inventor не создал первое ребро профиля фаски.");
                        SketchLine second = chamferSketch.SketchLines.AddByTwoPoints(first.EndSketchPoint, corners[2]);
                        if (second == null) throw new InvalidOperationException("Inventor не создал второе ребро профиля фаски.");
                        SketchLine third = chamferSketch.SketchLines.AddByTwoPoints(second.EndSketchPoint, first.StartSketchPoint);
                        if (third == null) throw new InvalidOperationException("Inventor не замкнул профиль фаски.");
                        Profile chamferProfile = chamferSketch.Profiles.AddForSolid();
                        if (chamferProfile == null) throw new InvalidOperationException("Inventor вернул пустой профиль фаски.");
                        double volumeBefore = doc.ComponentDefinition.MassProperties.Volume;
                        int bodyCountBefore = doc.ComponentDefinition.SurfaceBodies.Count;
                        if (!Finite(volumeBefore) || volumeBefore <= 0.0 || bodyCountBefore < 1)
                            throw new InvalidOperationException("Не удалось измерить тело перед фаской.");
                        chamferFeature = def.Features.RevolveFeatures.AddFull(
                            chamferProfile, axisLine, PartFeatureOperationEnum.kCutOperation);
                        if (chamferFeature == null) throw new InvalidOperationException("Inventor не вернул RevolveFeature фаски.");
                        ObjectCollection affected = app.TransientObjects.CreateObjectCollection();
                        affected.Add(source.Body);
                        chamferFeature.SetAffectedBodies(affected);
                        try { chamferFeature.Name = "Helivanta — " + featureName; } catch { }
                        chamferSketch.Visible = false;
                        chamferPlane.Visible = false;
                        doc.Update();
                        if (chamferFeature.HealthStatus != HealthStatusEnum.kUpToDateHealth)
                            throw new InvalidOperationException(featureName + " не имеет состояния UpToDate: " + chamferFeature.HealthStatus + ".");
                        double volumeAfter = doc.ComponentDefinition.MassProperties.Volume;
                        int bodyCountAfter = doc.ComponentDefinition.SurfaceBodies.Count;
                        double tolerance = Math.Max(1e-8, Math.Abs(volumeBefore) * 1e-11);
                        if (!Finite(volumeAfter) || volumeBefore - volumeAfter <= tolerance)
                            throw new InvalidOperationException(featureName + " не удалил измеримый объём материала.");
                        if (bodyCountAfter != bodyCountBefore)
                            throw new InvalidOperationException(featureName + " изменил количество твёрдых тел.");
                        runoutObjects.Add(chamferPlane);
                        runoutObjects.Add(chamferSketch);
                        runoutObjects.Add(chamferFeature);
                        runoutNotes.Add(string.Format(CultureInfo.InvariantCulture,
                            "{0}: диапазон {1:0.###}–{2:0.###} мм, размер {3:0.###} мм; удалено {4:0.########} см³",
                            featureName, z0 * 10.0, z1 * 10.0, p.ChamferMm, volumeBefore - volumeAfter));
                        TransactionLifecycleDiagnostics.Write("NativeTaperedThreadBuilder", "taper-chamfer-cut-created", app, doc,
                            null, false, string.Format(CultureInfo.InvariantCulture,
                                "feature={0}; mode={1}; external={2}; stationStartCm={3:0.########}; stationEndCm={4:0.########}; chamferMm={5:0.######}; boundaryOverlapCm={9:0.########}; volumeBefore={6:0.########}; volumeAfter={7:0.########}; health={8}",
                                featureName, p.ChamferMode, p.External, z0, z1, p.ChamferMm, volumeBefore, volumeAfter, chamferFeature.HealthStatus, boundaryOverlapCm));
                    }
                    catch (Exception chamferException)
                    {
                        throw new InvalidOperationException("Не удалось создать коническую фаску «" + featureName + "». Вся транзакция будет отменена. Причина: " + chamferException.Message, chamferException);
                    }
                }

                if (smoothStart) AddRunoutLoft("Сбег конической резьбы у начала", true);
                if (smoothEnd) AddRunoutLoft("Сбег конической резьбы у конца", false);

                return new PreparedGroove
                {
                    WorkPlane = wp,
                    Sketch = sketch,
                    Coil = coil,
                    RunoutObjects = runoutObjects,
                    RunoutSummary = string.Join("; ", runoutNotes)
                };
            }
            catch (Exception ex)
            {
                throw new InvalidOperationException("Не удалось создать физическую спиральную канавку на конической поверхности: " + ex.Message, ex);
            }
        }

        private static ThreadInfo ResolveThreadInfo(Inventor.Application app, ThreadParams p)
        {
            ThreadInfo info = null;
            try
            {
                dynamic query = app.GeneralOptions.ThreadTableQuery;
                string queryType = TaperThreadTableResolver.ResolveQueryType((object)query,
                    p.TaperStandard, p.External, out string typeResolutionDiagnostic);
                TransactionLifecycleDiagnostics.Write("NativeTaperedThreadBuilder", "thread-table-type-resolved", app,
                    app.ActiveDocument as PartDocument, null, false, typeResolutionDiagnostic ?? string.Empty);
                object createdInfo = query.CreateThreadInfo(!p.External, p.RightHand, queryType, p.TaperDesignation);
                info = createdInfo as ThreadInfo;
                if (info == null && createdInfo != null) info = (ThreadInfo)createdInfo;
            }
            catch (Exception ex)
            {
                throw new InvalidOperationException("Inventor не нашёл обозначение «" + p.TaperDesignation + "» в таблице «" + p.TaperStandard + ". Проверьте установленную Thread.xls. Деталь не изменена.", ex);
            }
            if (info == null) throw new InvalidOperationException("Inventor не вернул ThreadInfo для выбранного конического стандарта.");
            if (info is StandardThreadInfo)
                throw new InvalidOperationException("Обозначение «" + p.TaperDesignation + "» в таблице «" + p.TaperStandard + "» не является коническим.");
            try
            {
                dynamic taperedInfo = info;
                bool nativeInternal = Convert.ToBoolean(taperedInfo.Internal, CultureInfo.InvariantCulture);
                bool nativeRightHanded = Convert.ToBoolean(taperedInfo.RightHanded, CultureInfo.InvariantCulture);
                if (nativeInternal != !p.External || nativeRightHanded != p.RightHand)
                    throw new InvalidOperationException("Таблица Inventor вернула резьбу с несовпадающими внутренним/наружным типом или направлением.");
            }
            catch (InvalidOperationException) { throw; }
            catch (Exception ex)
            {
                throw new InvalidOperationException("Не удалось подтвердить направление и тип нативного обозначения резьбы из таблицы Inventor.", ex);
            }
            return info;
        }

        private static bool TryResolveTaperRadii(ThreadInfo info, bool external,
            TaperGeometryModeKind mode, double stockEndRadiusCm, double hostLengthCm,
            double offsetMm, double diameterRatio, out double startRadiusCm, out double endRadiusCm,
            out string error)
        {
            startRadiusCm = 0.0;
            endRadiusCm = 0.0;
            error = null;
            if (mode == TaperGeometryModeKind.FreeGeometry)
            {
                endRadiusCm = stockEndRadiusCm;
                if (!TaperedThreadGeometryPolicy.TryGetStartRadiusFromEndCm(external,
                    endRadiusCm, hostLengthCm, diameterRatio, out startRadiusCm))
                {
                    error = "Свободный режим не может сохранить диаметр исходной поверхности при заданной длине и конусности 1:16.";
                    return false;
                }
                return true;
            }
            if (mode != TaperGeometryModeKind.StrictStandard)
            {
                error = "Неизвестный режим геометрии конической резьбы.";
                return false;
            }
            if (!TryGetStandardStartRadiusCm(info, external, hostLengthCm, offsetMm,
                diameterRatio, out startRadiusCm, out error)) return false;
            if (!TaperedThreadGeometryPolicy.TryGetEndRadiusCm(startRadiusCm, hostLengthCm,
                diameterRatio, external, out endRadiusCm))
            {
                error = "Табличные диаметры не образуют допустимый конус для выбранной длины.";
                return false;
            }
            return true;
        }

        /// <summary>
        /// Reads the selected thread table's standard diameter. Inventor reports these values in
        /// mm for Metric=true and inches otherwise. External threads start at their small end and
        /// grow toward NominalExternalDiameter; for internal threads BasicMinorDiameter is the small
        /// end, so the selected mouth diameter is expanded across the host length.
        /// </summary>
        private static bool TryGetStandardStartRadiusCm(ThreadInfo info, bool external,
            double hostLengthCm, double offsetMm, double diameterRatio, out double startRadiusCm, out string error)
        {
            startRadiusCm = 0.0;
            error = null;
            if (info == null)
            {
                error = "Inventor не вернул данные выбранного конического стандарта.";
                return false;
            }

            try
            {
                dynamic native = info;
                bool metric = Convert.ToBoolean(native.Metric, CultureInfo.InvariantCulture);
                double outsidePipeDiameter = double.NaN;
                double nominalExternalDiameter = double.NaN;
                double basicMinorDiameter = double.NaN;
                object tableValue;
                double parsedValue;
                try { tableValue = native.OutsidePipeDiameter; if (TryPositiveNumber(tableValue, out parsedValue)) outsidePipeDiameter = parsedValue; } catch { }
                try { tableValue = native.NominalExternalDiameter; if (TryPositiveNumber(tableValue, out parsedValue)) nominalExternalDiameter = parsedValue; } catch { }
                try { tableValue = native.BasicMinorDiameter; if (TryPositiveNumber(tableValue, out parsedValue)) basicMinorDiameter = parsedValue; } catch { }
                if (!TaperedThreadGeometryPolicy.TryGetStandardStartRadiusCm(external, metric,
                    outsidePipeDiameter, nominalExternalDiameter, basicMinorDiameter,
                    hostLengthCm, offsetMm, diameterRatio, out startRadiusCm))
                {
                    error = external
                        ? "В таблице Inventor нет корректного OutsidePipeDiameter/NominalExternalDiameter для «" + SafeDesignation(native) + "». Выберите другое табличное обозначение."
                        : "В таблице Inventor нет корректного BasicMinorDiameter (диаметр малого конца) для внутреннего обозначения «" + SafeDesignation(native) + "». Без этого диаметра безопасная автоподготовка невозможна.";
                    return false;
                }
                return true;
            }
            catch (Exception ex)
            {
                error = "Не удалось прочитать стандартный диаметр из TaperedThreadInfo Inventor: " + ex.Message;
                return false;
            }
        }

        private static bool TryPositiveNumber(object value, out double number)
        {
            number = 0.0;
            if (value == null || value == DBNull.Value) return false;
            try { number = Convert.ToDouble(value, CultureInfo.InvariantCulture); }
            catch { return false; }
            return Finite(number) && number > 0.0;
        }

        private static string SafeDesignation(dynamic native)
        {
            try { return Convert.ToString(native.ThreadDesignation, CultureInfo.InvariantCulture) ?? "неизвестное"; }
            catch { return "неизвестное"; }
        }

        internal static bool TryBuildGeometryChangeSummary(Inventor.Application app, ThreadTarget source,
            ThreadParams p, out string summary, out string error)
        {
            summary = null;
            error = null;
            try
            {
                ValidateSourceTarget(source, p);
                PartDocument doc = app == null ? null : app.ActiveDocument as PartDocument;
                if (doc == null) throw new InvalidOperationException("Активный документ должен быть деталью Inventor (.ipt).");
                string activeName = null;
                try { activeName = doc.InternalName; } catch { }
                if (!string.IsNullOrEmpty(source.SourceDocumentInternalName) &&
                    !string.Equals(source.SourceDocumentInternalName, activeName, StringComparison.OrdinalIgnoreCase))
                    throw new InvalidOperationException("Выбранное ребро принадлежит другой детали. Повторно выберите его в активном документе.");

                double ratio;
                if (!TaperedThreadGeometryPolicy.TryGetDiameterRatio(p.TaperStandard, out ratio))
                    throw new InvalidOperationException("Неизвестная конусность выбранного стандарта.");
                double hostLengthCm;
                string lengthError;
                if (!TaperedThreadGeometryPolicy.TryGetHostLengthCm(p.FullLength, source.LengthCm,
                    p.LengthMm, p.OffsetMm, out hostLengthCm, out lengthError))
                    throw new InvalidOperationException(lengthError);
                ThreadInfo info = ResolveThreadInfo(app, p);
                double startRadius, endRadius, pitchMm, depthMm;
                string errorText;
                if (!TryResolveTaperRadii(info, p.External, p.TaperGeometryMode, source.RadiusCm,
                    hostLengthCm, p.OffsetMm, ratio, out startRadius, out endRadius, out errorText))
                    throw new InvalidOperationException(errorText);
                if (!TryGetNativePitchAndDepthMm(info, out pitchMm, out depthMm, out errorText))
                    throw new InvalidOperationException(errorText);

                p.PitchMm = pitchMm;
                p.TaperThreadDepthMm = depthMm;
                p.TaperRatio = ratio;
                p.TaperStartDiameterMm = startRadius * 20.0;
                p.TaperEndDiameterMm = endRadius * 20.0;
                p.TaperReferenceDiameterMm = p.TaperStartDiameterMm;
                p.TaperReferenceLengthMm = hostLengthCm * 10.0;

                double stockDiameter = source.RadiusCm * 20.0;
                double startDiameter = startRadius * 20.0;
                double endDiameter = endRadius * 20.0;
                double maxDelta = Math.Max(Math.Abs(startDiameter - stockDiameter), Math.Abs(endDiameter - stockDiameter));
                string direction = p.External
                    ? "наружный конус: меньший диаметр у выбранного входного ребра, увеличение к плечу"
                    : "внутренний конус: широкий вход у выбранного ребра, уменьшение диаметра внутрь";
                string materialText = p.TaperGeometryMode == TaperGeometryModeKind.StrictStandard
                    ? "поверхность будет приведена к табличным диаметрам конуса, затем будут вырезаны физические винтовые канавки"
                    : "дальний диаметр исходной поверхности будет сохранён, входной диаметр вычислен по 1:16; результат считается нестандартным";
                summary = string.Format(CultureInfo.InvariantCulture,
                    "Helivanta изменит геометрию выбранного тела.\n\n" +
                    "Стандарт/типоразмер: {0} {1}; режим геометрии: {2}; направление: {3}.\n" +
                    "Исходный диаметр у ребра: Ø{4:0.###} мм.\n" +
                    "Диаметр конуса: Ø{5:0.###} мм у выбранного ребра → Ø{6:0.###} мм на дальнем конце; длина подготовки: {7:0.###} мм; отступ резьбы: {8:0.###} мм.\n" +
                    "Табличный шаг: {9:0.###} мм; высота профиля: {10:0.###} мм.\n" +
                    "{11}. Максимальное отличие исходного диаметра от целевого на концах — {12:0.###} мм.\n\n" +
                    "Будут добавляться или сниматься кольцевые объёмы; если исходный цилиндр пересекает расчётный конус, Helivanta выполнит отдельные Cut/Join участки. В конце будет вырезана физическая винтовая канавка. Зависимые последующие операции Inventor могут перестроиться или запросить исправление. Все действия выполняются в одной транзакции с откатом при ошибке.\n\nПродолжить?",
                    p.TaperStandard, p.TaperDesignation,
                    p.TaperGeometryMode == TaperGeometryModeKind.StrictStandard ? "строго по табличным диаметрам" : "свободный (нестандартный)",
                    p.RightHand ? "правая" : "левая", stockDiameter, startDiameter, endDiameter, hostLengthCm * 10.0, p.OffsetMm,
                    pitchMm, depthMm, direction + "; " + materialText, maxDelta);
                return true;
            }
            catch (Exception ex)
            {
                error = ex.Message;
                return false;
            }
        }

        /// <summary>
        /// Builds the explicit geometry-change prompt for Edit mode using the saved source-cylinder
        /// snapshot. The current live cylinder is temporarily replaced by the conical host, so a
        /// live Edge/Face cannot be required before ThreadEditService starts its transaction.
        /// This method is read-only and must run before the old feature group is deleted.
        /// </summary>
        internal static bool TryBuildGeometryChangeSummaryFromSnapshot(Inventor.Application app,
            ThreadTargetSnapshot source, ThreadParametersSnapshot originalParameters, ThreadParams p,
            out string summary, out string error)
        {
            summary = null;
            error = null;
            try
            {
                if (app == null || source == null || p == null)
                    throw new ArgumentNullException();
                PartDocument doc = app.ActiveDocument as PartDocument;
                if (doc == null) throw new InvalidOperationException("Активный документ должен быть деталью Inventor (.ipt).");
                if (!Finite(source.RadiusCm) || source.RadiusCm <= 0.0 ||
                    !Finite(source.LengthCm) || source.LengthCm <= 0.0 ||
                    source.Center == null || source.Center.Length != 3 || source.Axis == null || source.Axis.Length != 3)
                    throw new InvalidOperationException("Сохранённый снимок исходной поверхности неполон; изменение геометрии нельзя подтвердить безопасно.");
                double axisLength = Math.Sqrt(source.Axis[0] * source.Axis[0] + source.Axis[1] * source.Axis[1] + source.Axis[2] * source.Axis[2]);
                if (!Finite(axisLength) || Math.Abs(axisLength - 1.0) > 1e-3)
                    throw new InvalidOperationException("Ось сохранённой исходной поверхности некорректна; изменение геометрии нельзя подтвердить безопасно.");
                if (source.IsExternal != p.External)
                    throw new InvalidOperationException("Нельзя изменить тип резьбы с наружного на внутренний или наоборот в рамках одной операции правки.");
                double ratio;
                if (!TaperedThreadGeometryPolicy.TryGetDiameterRatio(p.TaperStandard, out ratio))
                    throw new InvalidOperationException("Неизвестная конусность выбранного стандарта.");
                double hostLengthCm;
                string lengthError;
                if (!TaperedThreadGeometryPolicy.TryGetHostLengthCm(p.FullLength, source.LengthCm,
                    p.LengthMm, p.OffsetMm, out hostLengthCm, out lengthError))
                    throw new InvalidOperationException(lengthError);
                ThreadInfo info = ResolveThreadInfo(app, p);
                double startRadiusCm, endRadiusCm, pitchMm, depthMm;
                string tableError;
                if (!TryResolveTaperRadii(info, p.External, p.TaperGeometryMode, source.RadiusCm,
                    hostLengthCm, p.OffsetMm, ratio, out startRadiusCm, out endRadiusCm, out tableError))
                    throw new InvalidOperationException(tableError);
                if (!TryGetNativePitchAndDepthMm(info, out pitchMm, out depthMm, out tableError))
                    throw new InvalidOperationException(tableError);
                double stockDiameterMm = source.RadiusCm * 20.0;
                double startDiameterMm = startRadiusCm * 20.0;
                double endDiameterMm = endRadiusCm * 20.0;
                double maxDeltaMm = Math.Max(Math.Abs(startDiameterMm - stockDiameterMm), Math.Abs(endDiameterMm - stockDiameterMm));
                string oldLength = originalParameters == null ? "неизвестно" :
                    (originalParameters.FullLength ? "вся поверхность" : originalParameters.LengthMm.ToString("0.###", CultureInfo.InvariantCulture) + " мм");
                string newLength = p.FullLength ? "вся поверхность (нестандартная длина)" : p.LengthMm.ToString("0.###", CultureInfo.InvariantCulture) + " мм";
                string mode = p.External
                    ? "наружный конус: меньший диаметр у входного ребра, увеличение к плечу"
                    : "внутренний конус: широкий вход, уменьшение диаметра внутрь";
                summary = string.Format(CultureInfo.InvariantCulture,
                    "Режим правки изменит существующую группу Helivanta и геометрию исходного тела.\n\n" +
                    "Обозначение: {0} {1}; режим геометрии: {2}; направление: {3}.\n" +
                    "Длина: {4} → {5}; отступ: {6:0.###} мм.\n" +
                    "Исходный диаметр сохранённой поверхности: Ø{7:0.###} мм.\n" +
                    "Целевой конус: Ø{8:0.###} мм у входного ребра → Ø{9:0.###} мм на дальнем конце; участок подготовки {10:0.###} мм.\n" +
                    "Табличный шаг: {11:0.###} мм; высота профиля: {12:0.###} мм.\n" +
                    "Тип: {13}. Максимальное изменение диаметра на концах: {14:0.###} мм.\n\n" +
                    "Старая группа будет удалена и заменена внутри одной Inventor-транзакции. Если любой этап подготовки конуса, Coil или сбега завершится ошибкой, операция должна быть отменена целиком. После замены зависимые последующие операции могут потребовать исправления.\n\nПодтвердить изменение геометрии?",
                    p.TaperStandard, p.TaperDesignation,
                    p.TaperGeometryMode == TaperGeometryModeKind.StrictStandard ? "строго по табличным диаметрам" : "свободный (нестандартный)",
                    p.RightHand ? "правая" : "левая", oldLength, newLength, p.OffsetMm,
                    stockDiameterMm, startDiameterMm, endDiameterMm, hostLengthCm * 10.0,
                    pitchMm, depthMm, mode, maxDeltaMm);
                return true;
            }
            catch (Exception ex)
            {
                error = ex.Message;
                return false;
            }
        }

        private static PreparedHost CreateConicalHost(Inventor.Application app, PartDocument doc,
            ThreadTarget source, ThreadParams p, double hostLengthCm, double desiredStartRadiusCm, double endRadiusCm)
        {
            if (source.Body == null) throw new InvalidOperationException("Не определено твёрдое тело для подготовки конической поверхности.");
            PartComponentDefinition def = doc.ComponentDefinition;
            TransientGeometry tg = app.TransientGeometry;
            double[] u = Normalize(source.U);
            double[] helper = Math.Abs(u[0]) < 0.9 ? new[] { 1.0, 0.0, 0.0 } : new[] { 0.0, 1.0, 0.0 };
            double[] r = Normalize(Cross(u, Cross(helper, u)));
            double[] origin = new[] { source.Center[0], source.Center[1], source.Center[2] };
            var workPlanes = new List<WorkPlane>();
            var sketches = new List<PlanarSketch>();
            var revolves = new List<RevolveFeature>();
            try
            {
                bool crosses;
                double crossingStationCm;
                string crossingError;
                if (!TaperedThreadGeometryPolicy.TryGetStockCrossingStationCm(source.RadiusCm,
                    desiredStartRadiusCm, endRadiusCm, hostLengthCm,
                    out crosses, out crossingStationCm, out crossingError))
                    throw new InvalidOperationException(crossingError);

                if (!crosses)
                {
                    bool join;
                    string operationError;
                    if (!TaperedThreadGeometryPolicy.TryChooseJoinOperation(p.External, source.RadiusCm,
                        desiredStartRadiusCm, endRadiusCm, out join, out operationError))
                        throw new InvalidOperationException(operationError);
                    AddConicalRevolveSegment(app, doc, source, p, tg, u, r, origin,
                        0.0, hostLengthCm, desiredStartRadiusCm, endRadiusCm, join,
                        workPlanes, sketches, revolves, "полный");
                }
                else
                {
                    // The constant-radius starting stock crosses the target taper. Apply the Cut
                    // section first, then Join (or vice versa) on the other side of the exact crossing.
                    // Each section has a zero-thickness triangular end at the crossing station and
                    // shares the original cylindrical face with the body, keeping the result connected.
                    double crossingRadius = source.RadiusCm;
                    bool joinFirst = TaperedThreadGeometryPolicy.RequiresJoinForRadialChange(
                        p.External, source.RadiusCm, desiredStartRadiusCm);
                    bool joinSecond = TaperedThreadGeometryPolicy.RequiresJoinForRadialChange(
                        p.External, source.RadiusCm, endRadiusCm);
                    if (joinFirst == joinSecond)
                        throw new InvalidOperationException("Расчёт точки пересечения не разделил операции Cut и Join. Модель не изменена.");

                    AddConicalRevolveSegment(app, doc, source, p, tg, u, r, origin,
                        0.0, crossingStationCm, desiredStartRadiusCm, crossingRadius, joinFirst,
                        workPlanes, sketches, revolves, "до пересечения");
                    doc.Update();
                    AddConicalRevolveSegment(app, doc, source, p, tg, u, r, origin,
                        crossingStationCm, hostLengthCm, crossingRadius, endRadiusCm, joinSecond,
                        workPlanes, sketches, revolves, "после пересечения");
                }

                doc.Update();
                Face coneFace;
                Edge startEdge;
                string segmentSummary = DescribeRevolveSegments(revolves);
                TransactionLifecycleDiagnostics.Write("NativeTaperedThreadBuilder", "cone-segments-ready", app, doc, null, false,
                    string.Format(CultureInfo.InvariantCulture,
                        "standard={0}; designation={1}; external={2}; rightHand={3}; hostLengthCm={4:0.######}; expectedStartDiameterMm={5:0.######}; expectedEndDiameterMm={6:0.######}; sourceRadiusCm={7:0.######}; axis=({8:0.######},{9:0.######},{10:0.######}); segments={11}",
                        p.TaperStandard, p.TaperDesignation, p.External, p.RightHand, hostLengthCm,
                        desiredStartRadiusCm * 20.0, endRadiusCm * 20.0, source.RadiusCm,
                        u[0], u[1], u[2], segmentSummary));
                if (!TryFindGeneratedCone(app, doc, revolves[revolves.Count - 1], source, p,
                    hostLengthCm, desiredStartRadiusCm, endRadiusCm, out coneFace, out startEdge))
                    throw new InvalidOperationException("После подготовки сегментов Revolve не найдена однозначная коническая грань с ожидаемыми диаметрами начала и конца. Детали поиска записаны в transaction-lifecycle.log; вся транзакция будет отменена.");

                return new PreparedHost
                {
                    ConeFace = coneFace,
                    StartEdge = startEdge,
                    Revolves = revolves,
                    Sketches = sketches,
                    WorkPlanes = workPlanes,
                    HostLengthCm = hostLengthCm,
                    StartDiameterMm = desiredStartRadiusCm * 20.0,
                    EndDiameterMm = endRadiusCm * 20.0
                };
            }
            catch (Exception ex)
            {
                throw new InvalidOperationException("Не удалось подготовить коническую поверхность от выбранного ребра. Helivanta попробовала построить корректный конус участками Cut/Join, если исходная заготовка пересекает его профиль. " + ex.Message, ex);
            }
        }

        private static void AddConicalRevolveSegment(Inventor.Application app, PartDocument doc,
            ThreadTarget source, ThreadParams p, TransientGeometry tg, double[] u, double[] r,
            double[] origin, double x0, double x1, double targetRadius0, double targetRadius1,
            bool join, List<WorkPlane> workPlanes, List<PlanarSketch> sketches,
            List<RevolveFeature> revolves, string segmentLabel)
        {
            if (x1 - x0 <= 1e-6) throw new InvalidOperationException("Слишком короткий участок подготовки конической поверхности: " + segmentLabel + ".");
            WorkPlane wp = null;
            PlanarSketch sketch = null;
            RevolveFeature revolve = null;
            try
            {
                wp = doc.ComponentDefinition.WorkPlanes.AddFixed(
                    tg.CreatePoint(origin[0], origin[1], origin[2]),
                    tg.CreateUnitVector(r[0], r[1], r[2]),
                    tg.CreateUnitVector(u[0], u[1], u[2]), false);
                wp.Visible = false;
                try { wp.Name = "Helivanta — плоскость подготовки конуса (" + segmentLabel + ")"; } catch { }

                sketch = doc.ComponentDefinition.Sketches.Add(wp);
                try { sketch.Name = "Helivanta — профиль конуса 1:16 (" + segmentLabel + ")"; } catch { }
                Point2d S(double axialCm, double radiusCm)
                {
                    Inventor.Point modelPoint = tg.CreatePoint(
                        origin[0] + u[0] * axialCm + r[0] * radiusCm,
                        origin[1] + u[1] * axialCm + r[1] * radiusCm,
                        origin[2] + u[2] * axialCm + r[2] * radiusCm);
                    return sketch.ModelToSketchSpace(modelPoint);
                }

                SketchLine axisLine = sketch.SketchLines.AddByTwoPoints(S(x0, 0.0), S(x1, 0.0));
                axisLine.Construction = true;
                double stockRadius = source.RadiusCm;
                const double radiusToleranceCm = 1e-7;
                // Build the closed annular cross-section between the target cone and the constant
                // source cylinder. At a crossing endpoint the quad degenerates cleanly to a triangle.
                var section = new List<Tuple<double, double>>
                {
                    Tuple.Create(x0, Math.Min(stockRadius, targetRadius0)),
                    Tuple.Create(x1, Math.Min(stockRadius, targetRadius1)),
                    Tuple.Create(x1, Math.Max(stockRadius, targetRadius1)),
                    Tuple.Create(x0, Math.Max(stockRadius, targetRadius0))
                };
                var clean = new List<Tuple<double, double>>();
                foreach (Tuple<double, double> point in section)
                {
                    if (clean.Count == 0 || DistanceSquared(clean[clean.Count - 1], point) > radiusToleranceCm * radiusToleranceCm)
                        clean.Add(point);
                }
                if (clean.Count > 1 && DistanceSquared(clean[0], clean[clean.Count - 1]) <= radiusToleranceCm * radiusToleranceCm)
                    clean.RemoveAt(clean.Count - 1);
                if (clean.Count < 3) throw new InvalidOperationException("Профиль кольцевого участка выродился: " + segmentLabel + ".");

                SketchLine first = sketch.SketchLines.AddByTwoPoints(S(clean[0].Item1, clean[0].Item2),
                    S(clean[1].Item1, clean[1].Item2));
                SketchLine previous = first;
                for (int i = 2; i < clean.Count; i++)
                    previous = sketch.SketchLines.AddByTwoPoints(previous.EndSketchPoint,
                        S(clean[i].Item1, clean[i].Item2));
                sketch.SketchLines.AddByTwoPoints(previous.EndSketchPoint, first.StartSketchPoint);

                Profile profile = sketch.Profiles.AddForSolid();
                PartFeatureOperationEnum operation = join
                    ? PartFeatureOperationEnum.kJoinOperation
                    : PartFeatureOperationEnum.kCutOperation;
                revolve = doc.ComponentDefinition.Features.RevolveFeatures.AddFull(profile, axisLine, operation);
                ObjectCollection affected = app.TransientObjects.CreateObjectCollection();
                affected.Add(source.Body);
                revolve.SetAffectedBodies(affected);
                try { revolve.Name = "Helivanta — подготовка конуса 1:16 " + (join ? "Join" : "Cut") + " (" + segmentLabel + ")"; } catch { }
                sketch.Visible = false;
                wp.Visible = false;
                doc.Update();
                if (revolve.HealthStatus != HealthStatusEnum.kUpToDateHealth)
                    throw new InvalidOperationException("Revolve " + segmentLabel + " не имеет состояния UpToDate: " + revolve.HealthStatus + ".");

                workPlanes.Add(wp);
                sketches.Add(sketch);
                revolves.Add(revolve);
                TransactionLifecycleDiagnostics.Write("NativeTaperedThreadBuilder", "cone-revolve-segment-created", app, doc, null, false,
                    string.Format(CultureInfo.InvariantCulture,
                        "segment={0}; operation={1}; standard={2}; designation={3}; external={4}; rightHand={5}; stationStartCm={6:0.######}; stationEndCm={7:0.######}; startDiameterMm={8:0.######}; endDiameterMm={9:0.######}; health={10}; axis=({11:0.######},{12:0.######},{13:0.######})",
                        segmentLabel, join ? "Join" : "Cut", p.TaperStandard, p.TaperDesignation, p.External, p.RightHand,
                        x0, x1, targetRadius0 * 20.0, targetRadius1 * 20.0, revolve.HealthStatus,
                        u[0], u[1], u[2]));
            }
            catch (Exception ex)
            {
                throw new InvalidOperationException("Не удалось создать участок конуса " + segmentLabel + " операцией " + (join ? "Join" : "Cut") + ": " + ex.Message, ex);
            }
        }

        private static bool GetDirectionReversedForFace(Face face, double[] desiredAxis)
        {
            if (face == null || desiredAxis == null || desiredAxis.Length < 3)
                throw new InvalidOperationException("Невозможно определить направление нативной резьбы: нет конической грани или оси.");
            Cone cone;
            try { cone = face.Geometry as Cone; } catch { cone = null; }
            if (cone == null)
                throw new InvalidOperationException("Грань подготовки не предоставляет геометрию Cone для определения направления резьбы.");
            double[] faceAxis = Normalize(new[] { cone.AxisVector.X, cone.AxisVector.Y, cone.AxisVector.Z });
            double[] targetAxis = Normalize(new[] { desiredAxis[0], desiredAxis[1], desiredAxis[2] });
            double dot = Dot(faceAxis, targetAxis);
            if (!Finite(dot) || Math.Abs(dot) < 0.9995)
                throw new InvalidOperationException("Ось созданного конуса не совпадает с направлением от выбранного ребра к дальнему торцу.");
            return dot < 0.0;
        }

        private static bool TryFindGeneratedCone(Inventor.Application app, PartDocument doc, RevolveFeature revolve,
            ThreadTarget source, ThreadParams parameters, double hostLengthCm,
            double desiredStartRadiusCm, double endRadiusCm, out Face coneFace, out Edge startEdge)
        {
            coneFace = null;
            startEdge = null;
            var candidates = new List<Face>();
            string faceScanError = null;
            // Only accept a cone face belonging to the original solid. A face from another/overlapping
            // body can make ThreadFeature succeed cosmetically while leaving the original cylinder intact.
            try
            {
                foreach (Face face in source.Body.Faces)
                    if (face.SurfaceType == SurfaceTypeEnum.kConeSurface) candidates.Add(face);
            }
            catch (Exception ex)
            {
                faceScanError = ex.GetType().Name + ": " + ex.Message;
            }

            string candidateDetails = DescribeConeCandidates(candidates, source, hostLengthCm,
                desiredStartRadiusCm, endRadiusCm);
            if (!string.IsNullOrWhiteSpace(faceScanError))
                candidateDetails = "face-scan-error=" + faceScanError + "; " + candidateDetails;
            bool found = TrySelectConeCandidate(candidates, source, hostLengthCm,
                desiredStartRadiusCm, endRadiusCm, out coneFace, out startEdge);
            TransactionLifecycleDiagnostics.Write("NativeTaperedThreadBuilder", found ? "cone-face-selected" : "cone-face-not-found",
                app, doc, null, false,
                string.Format(CultureInfo.InvariantCulture,
                    "selected={0}; standard={1}; designation={2}; external={3}; rightHand={4}; requestedStartDiameterMm={5:0.######}; requestedEndDiameterMm={6:0.######}; hostLengthCm={7:0.######}; candidateCount={8}; lastRevolve={9}; candidates=[{10}]",
                    found, parameters == null ? "" : parameters.TaperStandard,
                    parameters == null ? "" : parameters.TaperDesignation,
                    parameters != null && parameters.External, parameters != null && parameters.RightHand,
                    desiredStartRadiusCm * 20.0, endRadiusCm * 20.0, hostLengthCm, candidates.Count,
                    SafeRevolveName(revolve), candidateDetails));
            return found;
        }

        private static string DescribeRevolveSegments(IList<RevolveFeature> revolves)
        {
            if (revolves == null || revolves.Count == 0) return "none";
            var descriptions = new List<string>();
            foreach (RevolveFeature item in revolves)
                descriptions.Add(SafeRevolveName(item));
            return string.Join(" | ", descriptions);
        }

        private static string SafeRevolveName(RevolveFeature feature)
        {
            if (feature == null) return "null";
            try { return feature.Name + " [" + feature.HealthStatus + "]"; }
            catch { return "Revolve[name-unavailable]"; }
        }

        private static string DescribeConeCandidates(IList<Face> candidates, ThreadTarget source,
            double hostLengthCm, double expectedStartRadiusCm, double expectedEndRadiusCm)
        {
            var descriptions = new List<string>();
            if (candidates == null) return "candidate-list-null";
            int index = 0;
            foreach (Face face in candidates)
            {
                index++;
                try
                {
                    Cone cone = face.Geometry as Cone;
                    if (cone == null)
                    {
                        descriptions.Add("#" + index + ": geometry-not-Cone");
                        continue;
                    }
                    double[] faceAxis = Normalize(new[] { cone.AxisVector.X, cone.AxisVector.Y, cone.AxisVector.Z });
                    double axisDot = Math.Abs(Dot(faceAxis, source.U));
                    double[] basePoint = { cone.BasePoint.X, cone.BasePoint.Y, cone.BasePoint.Z };
                    double[] delta = Sub(basePoint, source.Center);
                    double station = Dot(delta, source.U);
                    double[] perpendicular = { delta[0] - source.U[0] * station, delta[1] - source.U[1] * station, delta[2] - source.U[2] * station };
                    double axisOffsetCm = Math.Sqrt(Dot(perpendicular, perpendicular));
                    var edges = new List<string>();
                    foreach (Edge edge in face.Edges)
                    {
                        double[] center = EdgeCenter(edge);
                        double radius = EdgeRadius(edge);
                        if (center == null || radius <= 0.0) continue;
                        double edgeStation = Dot(Sub(center, source.Center), source.U);
                        double startStationError = Math.Abs(edgeStation);
                        double endStationError = Math.Abs(edgeStation - hostLengthCm);
                        double startRadiusError = Math.Abs(radius - expectedStartRadiusCm);
                        double endRadiusError = Math.Abs(radius - expectedEndRadiusCm);
                        edges.Add(string.Format(CultureInfo.InvariantCulture,
                            "s={0:0.######}cm,r={1:0.######}cm,D={2:0.######}mm,startErr=(s:{3:0.######}cm,r:{4:0.######}cm),endErr=(s:{5:0.######}cm,r:{6:0.######}cm)",
                            edgeStation, radius, radius * 20.0, startStationError, startRadiusError,
                            endStationError, endRadiusError));
                    }
                    descriptions.Add(string.Format(CultureInfo.InvariantCulture,
                        "#{0}:axisDot={1:0.######};baseStation={2:0.######}cm;axisOffset={3:0.######}cm;expected=(start:{4:0.######}cm/{5:0.######}mm,end:{6:0.######}cm/{7:0.######}mm);edges=[{8}]",
                        index, axisDot, station, axisOffsetCm, expectedStartRadiusCm, expectedStartRadiusCm * 20.0,
                        expectedEndRadiusCm, expectedEndRadiusCm * 20.0, string.Join(",", edges)));
                }
                catch (Exception ex)
                {
                    descriptions.Add("#" + index + ":read-error=" + ex.GetType().Name + ":" + ex.Message);
                }
            }
            return descriptions.Count == 0 ? "no-cone-faces" : string.Join(" | ", descriptions);
        }

        private static bool TrySelectConeCandidate(List<Face> candidates, ThreadTarget source, double hostLengthCm,
            double desiredStartRadiusCm, double endRadiusCm, out Face coneFace, out Edge startEdge)
        {
            coneFace = null;
            startEdge = null;
            var matches = new List<Tuple<Face, Edge>>();
            foreach (Face face in candidates)
            {
                if (face == null || face.SurfaceType != SurfaceTypeEnum.kConeSurface) continue;
                Cone cone;
                try { cone = face.Geometry as Cone; } catch { cone = null; }
                if (cone == null) continue;
                try
                {
                    double[] axis = Normalize(new[] { cone.AxisVector.X, cone.AxisVector.Y, cone.AxisVector.Z });
                    double axisDot = Math.Abs(Dot(axis, source.U));
                    if (axisDot < 0.9995) continue;
                    double[] basePoint = { cone.BasePoint.X, cone.BasePoint.Y, cone.BasePoint.Z };
                    double[] delta = Sub(basePoint, source.Center);
                    double along = Dot(delta, source.U);
                    double rx = delta[0] - source.U[0] * along;
                    double ry = delta[1] - source.U[1] * along;
                    double rz = delta[2] - source.U[2] * along;
                    if (Math.Sqrt(rx * rx + ry * ry + rz * rz) > 0.005) continue;
                }
                catch { continue; }

                Edge start = null;
                bool hasFarEdge = false;
                try
                {
                    foreach (Edge edge in face.Edges)
                    {
                        double[] center = EdgeCenter(edge);
                        double radius = EdgeRadius(edge);
                        if (center == null || radius <= 0.0) continue;
                        double station = Dot(Sub(center, source.Center), source.U);
                        if (Math.Abs(station) <= 0.005 && Math.Abs(radius - desiredStartRadiusCm) <= 0.005)
                            start = edge;
                        if (Math.Abs(station - hostLengthCm) <= 0.005 && Math.Abs(radius - endRadiusCm) <= 0.005)
                            hasFarEdge = true;
                    }
                }
                catch { continue; }
                if (start != null && hasFarEdge) matches.Add(Tuple.Create(face, start));
            }
            if (matches.Count != 1) return false;
            coneFace = matches[0].Item1;
            startEdge = matches[0].Item2;
            return true;
        }

        private static double[] EdgeCenter(Edge edge)
        {
            try
            {
                if (edge.GeometryType == CurveTypeEnum.kCircleCurve)
                {
                    Circle circle = (Circle)edge.Geometry;
                    return new[] { circle.Center.X, circle.Center.Y, circle.Center.Z };
                }
                if (edge.GeometryType == CurveTypeEnum.kCircularArcCurve)
                {
                    Arc3d arc = (Arc3d)edge.Geometry;
                    return new[] { arc.Center.X, arc.Center.Y, arc.Center.Z };
                }
            }
            catch { }
            return null;
        }

        private static double EdgeRadius(Edge edge)
        {
            try
            {
                if (edge.GeometryType == CurveTypeEnum.kCircleCurve) return ((Circle)edge.Geometry).Radius;
                if (edge.GeometryType == CurveTypeEnum.kCircularArcCurve) return ((Arc3d)edge.Geometry).Radius;
            }
            catch { }
            return 0.0;
        }

        private static double DistanceSquared(Tuple<double, double> a, Tuple<double, double> b)
        {
            double x = a.Item1 - b.Item1;
            double y = a.Item2 - b.Item2;
            return x * x + y * y;
        }

        private static double[] Normalize(double[] vector)
        {
            double length = Math.Sqrt(Dot(vector, vector));
            if (!Finite(length) || length <= 1e-12) throw new InvalidOperationException("Не удалось нормализовать осевой вектор.");
            return new[] { vector[0] / length, vector[1] / length, vector[2] / length };
        }

        private static double Dot(double[] a, double[] b) => a[0] * b[0] + a[1] * b[1] + a[2] * b[2];
        private static double[] Sub(double[] a, double[] b) => new[] { a[0] - b[0], a[1] - b[1], a[2] - b[2] };
        private static double[] Cross(double[] a, double[] b) => new[]
        {
            a[1] * b[2] - a[2] * b[1],
            a[2] * b[0] - a[0] * b[2],
            a[0] * b[1] - a[1] * b[0]
        };
        private static bool Finite(double value) => !double.IsNaN(value) && !double.IsInfinity(value);
    }
}
