﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Diagnostics;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Runtime.InteropServices;
using System.Windows.Forms;

namespace ThreadPro
{
    public sealed class ThreadDialog : Form
    {
        internal event Action EditSelectionRequested;
        private readonly Inventor.Application _app;
        public ThreadTarget Target;
        private EdgeSelector _sel;
        private bool _editMode;
        private bool _nativeConversionMode;
        private bool _nativeConversionCompleted;
        private bool _nativeConversionAwaitingNextSelection;
        private NativeThreadConversionPlan _nativeConversionPlan;
        private string _nativeConversionThreadId;
        private double _editNominalDiaMm;

        /// <summary>
        /// True only while a successfully converted native thread is waiting for the user
        /// to select the next native Inventor ThreadFeature. Used by the add-in picker to
        /// reject Helivanta groups/other browser objects in the sequential conversion flow.
        /// </summary>
        internal bool IsAwaitingNextNativeConversionSelection
        {
            get { return _nativeConversionMode && _nativeConversionCompleted && _nativeConversionAwaitingNextSelection; }
        }

        private bool NominalDiameterIsLockedForCurrentMode
        {
            get { return _editMode || _nativeConversionMode; }
        }
        private int _lastValidStandardIndex;
        private bool _preserveCommittedStandardUntilDropdownReopened;
        private bool _standardApplyPending;
        private int _pendingStandardIndex = -1;
        private bool _standardCommitObserved;
        // Technology selection has an explicit commit/preset lifecycle. The combo uses native
        // selection rendering (like cbStd) to prevent owner-drawn popup-close rollback; these
        // committed indices remain a defensive guard for transient notifications and presets.
        private int _lastCommittedMaterialIndex;
        private bool _preserveCommittedMaterialUntilDropdownReopened;
        private bool _materialApplyPending;
        private int _pendingMaterialIndex = -1;
        private bool _materialCommitObserved;
        // Chamfer location is an owner-drawn ComboBox too. Keep its committed index separate
        // from SelectedIndex because Inventor/WinForms may transiently report -1 or the old row
        // while the native popup closes.
        private int _lastCommittedChamferIndex = -1;
        private bool _preserveCommittedChamferUntilDropdownReopened;
        private bool _chamferApplyPending;
        private int _pendingChamferIndex = -1;
        private bool _chamferCommitObserved;
        private string _editThreadId;

        private static readonly CultureInfo Inv = CultureInfo.InvariantCulture;
        private bool _loading;
        private bool _localizingStatusText;
        private bool _inchDia, _inchPitch;
        private readonly List<ThreadSize> _all = new List<ThreadSize>();

        private ComboBox cbStd, cbSize, cbDia, cbPitch, cbMat, cbCham, cbTolerance, cbTaperStandard, cbTaperDesignation;
        private NumericUpDown nStarts, nClear, nLen, nOff, nCham, nRun;
        private CheckBox chFull, chRun, chRound, chMirror, chCham, chSortFolders, chTapered, chTaperStrictStandard;
        private SegmentRadioButton rbChamStart, rbChamEnd, rbChamBoth;
        private GlowSlider _startsSlider, _lengthSlider, _offsetSlider;
        private TableLayoutPanel _buildGrid;
        private sealed class TaperRowStyleSnapshot
        {
            public SizeType SizeType { get; set; }
            public float Height { get; set; }
        }
        private readonly Dictionary<int, TaperRowStyleSnapshot> _preTaperBuildRowStyles = new Dictionary<int, TaperRowStyleSnapshot>();
        private readonly Dictionary<Control, bool> _preTaperVisibleStates = new Dictionary<Control, bool>();
        private bool _taperModeTransitionInProgress;
        private string _lastTaperAutoSelectionKey = string.Empty;
        private System.Windows.Forms.Timer _taperAutoSelectTimer;
        private List<string> _taperAutoSelectDesignations;
        private List<Tuple<string, double>> _taperAutoSelectCandidates;
        private object _taperAutoSelectQuery;
        private int _taperAutoSelectIndex;
        private string _taperAutoSelectType;
        private string _taperAutoSelectTableType;
        private string _taperAutoSelectKey;
        private double _taperAutoSelectTargetDiameterMm;
        private double _taperAutoSelectRatio;
        private bool _taperAutoSelectExternal;
        private bool _taperAutoSelectRight;
        private NumericUpDown nTaperRatio;
        private Label lTaperGeometryModeNote;
        private bool _preTaperChamferChecked, _preTaperRunOutChecked, _preTaperRoundChecked;
        private int _preTaperChamferIndex = -1;
        private decimal _preTaperChamferMm = 1m;
        private Dictionary<Control, bool> _preTaperEnabledStates;
        private decimal _startsBeforeTaperMode = 1m;
        private decimal _clearanceBeforeTaperMode;
        private bool _fullLengthBeforeTaperMode = true;
        private bool _refreshingTaperDesignations;
        private bool _settingTaperTableLength;
        private bool _taperLengthOverrideNoticeShown;
        private string _lastTaperInfoDesignation;
        private string _lastTaperInfoStandard;
        private double _lastTaperPitchMm;
        private double _lastTaperDepthMm;
        private RadioButton rbR, rbL, rbExt, rbInt;
        private TextBox lTarget, lInfo, lStatus, lWarn;
        private Label lDia, lPitch;
        private RadioButton rbMmD, rbInD, rbMmP, rbInP;
        private Button bBuild, bClose, bAbout, bHelp, bSettings, bResume, bReset, bUndo, bPreview, bCreateNew, bEditExisting, bIntegrityCheck;
        private ThreadPreviewOverlay _threadPreview;
        // Last successful, non-transacting native-table resolution used by the engineering diagram.
        // This snapshot is presentation-only and is shown only while its input key still matches.
        private bool _diagramTaperCacheValid;
        private string _diagramTaperCacheKey = string.Empty;
        private double _diagramTaperCachePitchMm, _diagramTaperCacheDepthMm;
        private double _diagramTaperCacheStartDiameterMm, _diagramTaperCacheEndDiameterMm;
        private double _diagramTaperCacheHostLengthMm, _diagramTaperCacheRatio;
        private ToolTip _previewToolTip;
        private System.Windows.Forms.Timer _previewDocumentTimer;
        private System.Windows.Forms.Timer _previewRefreshTimer;
        private bool _previewRequested;
        private bool _previewRefreshInProgress;
        private TableLayoutPanel _selectionActionPanel;
        private TableLayoutPanel _modeActionButtons;
        // Preview controls live in a separate fixed-size palette so they never participate
        // in the main dialog's responsive layout or content-height calculation.
        private PreviewControlsDialog _previewControlsDialog;
        private int _previewTransparencyPercent = HelivantaUserSettings.Current.PreviewOpacity;
        private int _previewLineThicknessPercent = HelivantaUserSettings.Current.PreviewLineScale;

        private TableLayoutPanel root;
        private Panel bodyViewport;
        private TableLayoutPanel bodyStack;
        private Panel _inlineHelpPanel;
        private TextBox _inlineHelpSearch;
        private ListBox _inlineHelpSections;
        private Label _inlineHelpTopicHeading;
        private Button _inlineHelpBackButton;
        private Label _inlineHelpArticleTitle;
        private BufferedHelpArticleViewer _inlineHelpArticle;
        private readonly List<KeyValuePair<string, string>> _inlineHelpTopics = new List<KeyValuePair<string, string>>();
        private bool _localizingTargetStatusText;
        private bool _inlineHelpMode;
        private bool _filteringInlineHelp;
        private string _displayedInlineHelpTopic = string.Empty;
        private string _displayedInlineHelpText = string.Empty;
        private string _inlineHelpRenderedLanguage = string.Empty;
        private TableLayoutPanel informationSection;
        private TableLayoutPanel _threadSizeSection;
        private Panel _informationMessagesViewport;
        private FlowLayoutPanel _informationMessagesFlow;
        private FlowLayoutPanel footerButtons;
        private FlowLayoutPanel chamferOptions;
        private FlowLayoutPanel _previewLegend;
        private bool _layouting;
        private bool _initialLayoutSettled;
        private bool _initialPresentationPending = true;
        private bool _initialPresentationCompletionNotified;
        internal event EventHandler InitialPresentationCompleted;
        private int _sessionBuilds;
        // Selection snapshots for each successful build, newest last. Used to restore the
        // just-undone build's edges without changing the user's current dialog parameters.
        private readonly List<List<ThreadTarget>> _buildSelections = new List<List<ThreadTarget>>();
        private readonly List<List<BuiltThreadZone>> _buildZones = new List<List<BuiltThreadZone>>();
        // Keep our in-memory overlap guard synchronized with Inventor's native Undo/Redo stack.
        private readonly List<List<ThreadTarget>> _redoBuildSelections = new List<List<ThreadTarget>>();
        private readonly List<List<BuiltThreadZone>> _redoBuildZones = new List<List<BuiltThreadZone>>();
        private Inventor.TransactionEvents _transactionEvents;
        private bool _pluginUndoInProgress;
        private HelivantaTransactionKind _nativeUndoKind;
        private string _nativeUndoThreadId;
        private HelivantaTransactionKind _nativeRedoKind;
        private string _nativeRedoThreadId;
        private readonly System.Windows.Forms.Timer _resizeTimer;
        private bool _buildInProgress;
        private bool _inSizing;
        private bool _closing;
        private int _lastSectionWidth = -1;
        private int _sectionCounter;
        private string _lastBuildInfo = "Готово к построению. После нажатия «Построить» здесь будет показан результат или подробная ошибка Inventor.";
        private string _lastBuildWarning = "";

        // Build115 keeps Build114's accepted card composition but restores Build113's
        // lighter graphite/blue palette so the main dialog sits comfortably beside Inventor.
        // Set HELIVANTA_USE_LEGACY_UI=1 before launching Inventor to restore Build113 layout.
        // This switch affects only visual arrangement; geometry and behavior do not depend on it.
        private static readonly bool UseNewLayout = !string.Equals(
            Environment.GetEnvironmentVariable("HELIVANTA_USE_LEGACY_UI"), "1", StringComparison.OrdinalIgnoreCase);

        // Keep the Build113 palette tokens for the main dialog. Modal/preview/help palettes remain shared.
        private static Color UiSurface => HelivantaUiTheme.Surface;
        private static Color UiPanel => HelivantaUiTheme.Panel;
        private static Color UiPanel2 => HelivantaUiTheme.PanelSecondary;
        private static Color UiHeader => HelivantaUiTheme.Header;
        private static Color UiField => HelivantaUiTheme.Field;
        private static Color UiText => HelivantaUiTheme.Text;
        private static Color UiMuted => HelivantaUiTheme.Muted;
        private static Color UiBorder => HelivantaUiTheme.Border;
        private static Color UiAccent => HelivantaUiTheme.Accent;
        private static Color UiAccentHover => HelivantaUiTheme.AccentHover;
        private static readonly Color UiHelpAmber = Color.FromArgb(235, 170, 57);
        private static readonly Color UiHelpAmberText = Color.FromArgb(28, 34, 42);
        private static Color UiAccentSoft => HelivantaUiTheme.AccentSoft;
        private static Color UiSuccess => HelivantaUiTheme.Success;
        private static Color UiWarning => HelivantaUiTheme.Warning;
        private static Color UiError => HelivantaUiTheme.Error;
        private static Color UiControlBorder => HelivantaUiTheme.ControlBorder;
        private static Color UiModalSurface => HelivantaUiTheme.ModalSurface;
        private static Color UiModalPanel => HelivantaUiTheme.ModalPanel;
        private static Color UiModalBorder => HelivantaUiTheme.ModalBorder;
        private static Color UiModalHeader => HelivantaUiTheme.ModalHeader;
        private static Color UiModalHeaderText => HelivantaUiTheme.ModalHeaderText;

        private const int LogicalWidth = 544; // 15% narrower than 640 logical px
        private const int ScreenEdgeMargin = 8;

        // Explicit scaling is used only for a few size constraints that WinForms does not
        // consistently rescale after construction. DeviceDpi is inherited from Form and is
        // available on the .NET 10 WinForms target; the former Build86 candidate called this
        // helper without defining it, which caused CS0103 at the taper-options notice.
        private const uint RDW_INVALIDATE = 0x0001;
        private const uint RDW_ERASE = 0x0004;
        private const uint RDW_ALLCHILDREN = 0x0080;
        private const uint RDW_UPDATENOW = 0x0100;
        private const uint RDW_FRAME = 0x0400;

        [DllImport("user32.dll", SetLastError = true)]
        private static extern bool RedrawWindowNative(IntPtr hWnd, IntPtr lprcUpdate, IntPtr hrgnUpdate, uint flags);

        private void RedrawNativeControlTreeAfterTaperTransition()
        {
            if (!IsHandleCreated || IsDisposed) return;
            const uint flags = RDW_INVALIDATE | RDW_ERASE | RDW_ALLCHILDREN | RDW_UPDATENOW | RDW_FRAME;
            try
            {
                // Native ComboBox and NumericUpDown buttons have non-client paint parts.
                // A regular Control.Invalidate(true) does not reliably invalidate those parts
                // after their parent rows collapse. RedrawWindow asks Windows to erase and repaint
                // the final, settled control tree exactly once, including child HWND frames.
                RedrawWindowNative(Handle, IntPtr.Zero, IntPtr.Zero, flags);
            }
            catch
            {
                try { Invalidate(true); Update(); } catch { }
            }
        }

        private int Dpi(int logicalPixels)
        {
            float scale = Math.Max(1f, DeviceDpi / 96f);
            return (int)Math.Round(logicalPixels * scale);
        }

        public ThreadDialog(Inventor.Application app)
        {
            _app = app;
            AttachTransactionEvents();

            // Prune expired/extra rotated diagnostics whenever the dialog opens, even if
            // the user does not create a thread during this session.
            try
            {
                string logDirectory = Path.Combine(
                    Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData),
                    "Helivanta", "Logs");
                DiagnosticLogMaintenance.CleanupDirectory(logDirectory);
            }
            catch { }

            AutoScaleMode = AutoScaleMode.Dpi;
            Text = HelivantaLocalization.Translate("Helivanta — физическая резьба");
            FormBorderStyle = FormBorderStyle.Sizable;
            StartPosition = FormStartPosition.Manual;
            // Keep the form invisible for its first layout pass. Shown moves it to the
            // final right-side position before making it visible, avoiding the (0,0) flash.
            Opacity = 0.0;
            MaximizeBox = false;
            MinimizeBox = false;
            ShowInTaskbar = false;
            AutoSize = false;
            Font = new Font("Segoe UI", 9f, FontStyle.Regular, GraphicsUnit.Point);
            BackColor = UiSurface;
            ForeColor = UiText;
            Load += (sender, args) => HelivantaLocalization.Apply(this);
            SetStyle(ControlStyles.OptimizedDoubleBuffer | ControlStyles.AllPaintingInWmPaint | ControlStyles.ResizeRedraw, true);
            DoubleBuffered = true;
            UpdateStyles();

            _resizeTimer = new System.Windows.Forms.Timer { Interval = 70 };
            _resizeTimer.Tick += (s, e) =>
            {
                _resizeTimer.Stop();
                if (!_inSizing && !IsDisposed) RefreshVerticalLayout();
            };

            try { Icon = LoadEmbeddedIcon(); } catch { }

            root = new BufferedTableLayoutPanel
            {
                Dock = DockStyle.Fill,
                ColumnCount = 1,
                RowCount = 3,
                BackColor = UiSurface,
                Padding = UseNewLayout ? new Padding(Dpi(8), Dpi(7), Dpi(8), Dpi(7)) : new Padding(7, 6, 7, 6),
                Margin = Padding.Empty
            };
            root.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100f));
            root.RowStyles.Add(new RowStyle(SizeType.AutoSize));
            root.RowStyles.Add(new RowStyle(SizeType.Percent, 100f));
            root.RowStyles.Add(new RowStyle(SizeType.AutoSize));
            Controls.Add(root);

            // Product header: keep the accepted Build114 card layout but use the official
            // Helivanta wordmark asset, not a substitute text-only H tile.
            // A separate host owns the rule below the header. Painting the rule in the
            // TableLayoutPanel itself allowed the transparent subtitle label to repaint over it.
            var headerHost = new Panel
            {
                Dock = DockStyle.Fill,
                Height = Dpi(UseNewLayout ? 53 : 48) + Math.Max(1, Dpi(1)),
                BackColor = UiSurface,
                Margin = new Padding(0, 0, 0, Dpi(UseNewLayout ? 9 : 7)),
                Padding = Padding.Empty,
                MinimumSize = new Size(0, Dpi(UseNewLayout ? 53 : 48) + Math.Max(1, Dpi(1)))
            };
            var header = new BufferedTableLayoutPanel
            {
                Dock = DockStyle.Top,
                ColumnCount = UseNewLayout ? 4 : 3,
                RowCount = 2,
                Height = Dpi(UseNewLayout ? 53 : 48),
                BackColor = UiSurface,
                Margin = Padding.Empty,
                Padding = Padding.Empty
            };
            header.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, Dpi(4)));
            if (UseNewLayout)
            {
                // The logo occupies the exact geometric center of the full header.
                // Equal flexible columns flank it; the action buttons are right-aligned
                // inside the right column so their width does not shift the logo off-center.
                header.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 50f));
                header.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, Dpi(174)));
                header.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 50f));
            }
            else
            {
                header.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100f));
                header.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, Dpi(142)));
            }
            header.RowStyles.Add(new RowStyle(SizeType.Absolute, Dpi(UseNewLayout ? 27 : 25)));
            header.RowStyles.Add(new RowStyle(SizeType.Absolute, Dpi(UseNewLayout ? 21 : 21)));

            var headerAccent = new Panel
            {
                Dock = DockStyle.Fill,
                BackColor = UiAccent,
                Margin = new Padding(0, Dpi(3), Dpi(UseNewLayout ? 6 : 8), Dpi(3))
            };
            header.Controls.Add(headerAccent, 0, 0);
            header.SetRowSpan(headerAccent, 2);

            int titleColumn = 1;
            var headTitle = new Label
            {
                Text = UseNewLayout ? "Физическая резьба" : "HELIVANTA  /  Физическая резьба",
                Dock = DockStyle.Fill,
                Font = new Font("Segoe UI Semibold", UseNewLayout ? 11.5f : 11f, FontStyle.Bold),
                ForeColor = UiText,
                Margin = new Padding(Dpi(5), 0, 0, 0),
                TextAlign = ContentAlignment.MiddleLeft,
                AutoEllipsis = true
            };
            var headSub = new Label
            {
                Text = "КОНСТРУКТОР ГЕОМЕТРИИ",
                Dock = DockStyle.Fill,
                Font = new Font("Segoe UI", 7.5f, FontStyle.Bold),
                ForeColor = UiMuted,
                Margin = new Padding(Dpi(5), 0, 0, 0),
                Padding = new Padding(0, 0, 0, Dpi(2)), // lift subtitle slightly; keep descenders inside the row
                TextAlign = ContentAlignment.MiddleLeft,
                AutoEllipsis = true
            };
            header.Controls.Add(headTitle, titleColumn, 0);
            header.Controls.Add(headSub, titleColumn, 1);

            // Use the original approved Helivanta wordmark asset. The experimental hand-drawn
            // vector reconstruction was removed after visual review did not match the official mark.
            var headWordmark = new PictureBox
            {
                Dock = DockStyle.Fill,
                SizeMode = PictureBoxSizeMode.Zoom,
                BackColor = Color.Transparent,
                Margin = new Padding(0, Dpi(1), 0, Dpi(1)),
                TabStop = false,
                Name = "headWordmark",
                AccessibleName = "Официальный логотип Helivanta"
            };
            try { headWordmark.Image = LoadEmbeddedWordmark(); } catch { }
            if (UseNewLayout)
            {
                header.Controls.Add(headWordmark, 2, 0);
                header.SetRowSpan(headWordmark, 2);
                // Help and About remain in the compact right-hand area; only their position changes.
                bHelp = MakeHelpButton();
                bAbout = MakeAboutButton();
                bSettings = MakeSettingsButton();
                foreach (Button headerButton in new Button[] { bHelp, bAbout, bSettings })
                {
                    headerButton.Size = new Size(Dpi(42), Dpi(42));
                    headerButton.Margin = new Padding(0, Dpi(1), 0, 0);
                    headerButton.Anchor = AnchorStyles.None;
                }
                var headerActions = new Panel
                {
                    Dock = DockStyle.Fill,
                    BackColor = UiSurface,
                    Margin = Padding.Empty,
                    Padding = Padding.Empty
                };
                var headerActionFlow = new FlowLayoutPanel
                {
                    Dock = DockStyle.Right,
                    AutoSize = true,
                    AutoSizeMode = AutoSizeMode.GrowAndShrink,
                    FlowDirection = FlowDirection.LeftToRight,
                    WrapContents = false,
                    BackColor = UiSurface,
                    Margin = Padding.Empty,
                    Padding = Padding.Empty
                };
                headerActionFlow.Controls.Add(bHelp);
                headerActionFlow.Controls.Add(bAbout);
                headerActionFlow.Controls.Add(bSettings);
                headerActions.Controls.Add(headerActionFlow);
                header.Controls.Add(headerActions, 3, 0);
                header.SetRowSpan(headerActions, 2);
            }
            else
            {
                header.Controls.Add(headWordmark, 2, 0);
                header.SetRowSpan(headWordmark, 2);
            }
            headerHost.Controls.Add(header);
            // Paint the bottom rule on the host itself, in the host's final client coordinates.
            // This avoids a one-pixel gap caused by rounded DPI heights and dock-order interactions.
            headerHost.Paint += (sender, args) =>
            {
                int lineWidth = Math.Max(1, (int)Math.Round(DeviceDpi / 96.0));
                float y = headerHost.ClientSize.Height - lineWidth / 2f;
                using (var linePen = new Pen(UiBorder, lineWidth))
                    args.Graphics.DrawLine(linePen, 0f, y, Math.Max(0, headerHost.ClientSize.Width - 1), y);
            };
            headerHost.Resize += (sender, args) => headerHost.Invalidate();
            root.Controls.Add(headerHost, 0, 0);

            bodyViewport = new Panel
            {
                Dock = DockStyle.Fill,
                AutoScroll = true,
                BackColor = UiSurface,
                Margin = Padding.Empty,
                Padding = new Padding(0),
                BorderStyle = BorderStyle.None
            };

            bodyStack = new BufferedTableLayoutPanel
            {
                ColumnCount = 1,
                RowCount = 0,
                AutoSize = true,
                AutoSizeMode = AutoSizeMode.GrowAndShrink,
                Dock = DockStyle.Top,
                BackColor = UiSurface,
                Margin = Padding.Empty,
                Padding = Padding.Empty
            };
            bodyStack.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100f));
            bodyViewport.Controls.Add(bodyStack);
            root.Controls.Add(bodyViewport, 0, 1);

            // --- Information section (selection + live information, stays first) ---
            // One dynamic block combines edge selection, calculated information, statuses and warnings.
            informationSection = NewSection(UseNewLayout ? "ЦЕЛЬ И СОСТОЯНИЕ" : "Информация");
            var informationGrid = GetSectionGrid(informationSection);

            lTarget = NewInfoLabel("Выберите круговые рёбра одного диаметра. Повторный щелчок снимает выбор.");
            lInfo = NewInfoLabel("");
            lInfo.Visible = false;
            lStatus = NewInfoLabel("Выбирайте рёбра в окне модели Inventor.");
            lWarn = NewInfoLabel("");
            lWarn.Visible = false;
            lWarn.ForeColor = UiMuted;
            HookTargetStatusLocalization(lTarget);
            HookTargetStatusLocalization(lStatus);
            HookTargetStatusLocalization(lInfo);
            HookTargetStatusLocalization(lWarn);
            // The initial Text values were assigned before handlers were attached.
            lTarget.Text = HelivantaLocalization.Translate(lTarget.Text);
            lStatus.Text = HelivantaLocalization.Translate(lStatus.Text);

            // The message viewport has a fixed logical height. Its contents may grow freely,
            // but message text must never resize this viewport or the parent form.
            informationGrid.SuspendLayout();
            informationGrid.Controls.Clear();
            informationGrid.RowStyles.Clear();
            informationGrid.ColumnStyles.Clear();
            informationGrid.ColumnCount = 1;
            informationGrid.RowCount = 1;
            informationGrid.AutoSize = true;
            informationGrid.AutoSizeMode = AutoSizeMode.GrowAndShrink;
            informationGrid.Dock = DockStyle.Top;
            informationGrid.Height = 0;
            informationGrid.MinimumSize = Size.Empty;
            informationGrid.MaximumSize = Size.Empty;
            informationGrid.Padding = new Padding(7, 2, 7, 2);
            informationGrid.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100f));
            informationGrid.RowStyles.Add(new RowStyle(SizeType.AutoSize));

            _informationMessagesViewport = new InformationMessagesViewport
            {
                Dock = DockStyle.Top,
                AutoScroll = true,
                Height = Dpi(136),
                MinimumSize = new Size(0, Dpi(136)),
                MaximumSize = new Size(0, Dpi(136)),
                BackColor = UiPanel,
                Margin = Padding.Empty,
                Padding = Padding.Empty,
                BorderStyle = BorderStyle.None
            };
            _informationMessagesFlow = new FlowLayoutPanel
            {
                AutoSize = true,
                AutoSizeMode = AutoSizeMode.GrowAndShrink,
                FlowDirection = FlowDirection.TopDown,
                WrapContents = false,
                Dock = DockStyle.None,
                Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right,
                Location = Point.Empty,
                Margin = Padding.Empty,
                Padding = Padding.Empty,
                BackColor = UiPanel
            };
            _informationMessagesViewport.Controls.Add(_informationMessagesFlow);
            foreach (Control message in new Control[] { lTarget, lInfo, lStatus })
            {
                message.Margin = Padding.Empty;
                message.Width = 420;
                _informationMessagesFlow.Controls.Add(message);
            }

            _previewLegend = new FlowLayoutPanel
            {
                AutoSize = true,
                AutoSizeMode = AutoSizeMode.GrowAndShrink,
                FlowDirection = FlowDirection.LeftToRight,
                WrapContents = false,
                Visible = false,
                Margin = Padding.Empty,
                Padding = Padding.Empty,
                BackColor = UiPanel
            };
            _previewLegend.Controls.Add(new Label
            {
                AutoSize = true,
                Text = "━━━━ Вершины",
                ForeColor = Color.FromArgb(35, 190, 250),
                Font = new Font(Font, FontStyle.Bold),
                Margin = new Padding(0, 1, 12, 1)
            });
            _previewLegend.Controls.Add(new Label
            {
                AutoSize = true,
                Text = "━━ Впадины",
                ForeColor = Color.White,
                Margin = new Padding(0, 1, 12, 1)
            });
            _previewLegend.Controls.Add(new Label
            {
                AutoSize = true,
                Text = "╱ Фаски",
                ForeColor = Color.FromArgb(255, 191, 64),
                Margin = new Padding(0, 1, 12, 1)
            });
            _previewLegend.Controls.Add(new Label
            {
                AutoSize = true,
                Text = "■ Поверхность",
                ForeColor = Color.FromArgb(53, 128, 187),
                Font = new Font(Font, FontStyle.Bold),
                Margin = new Padding(0, 1, 0, 1)
            });
            _informationMessagesFlow.Controls.Add(_previewLegend);
            lWarn.Margin = Padding.Empty;
            lWarn.Width = 420;
            _informationMessagesFlow.Controls.Add(lWarn);

            // Keep all currently visible actions on one horizontal row.
            // Hidden actions do not reserve cells; visible buttons are reflowed when visibility changes.
            _selectionActionPanel = new TableLayoutPanel
            {
                AutoSize = false,
                Dock = DockStyle.Fill,
                ColumnCount = 3,
                RowCount = 1,
                Height = Dpi(38),
                Margin = Padding.Empty,
                Padding = Padding.Empty,
                BackColor = UiPanel,
                GrowStyle = TableLayoutPanelGrowStyle.FixedSize
            };
            _modeActionButtons = _selectionActionPanel;
            for (int i = 0; i < 3; i++)
                _selectionActionPanel.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100f / 3f));
            _selectionActionPanel.RowStyles.Add(new RowStyle(SizeType.Absolute, Dpi(36)));

            bCreateNew = MakeSecondaryButton("Новая резьба", ButtonGlyph.NewThread);
            bCreateNew.Visible = false;
            bCreateNew.AccessibleName = "Перейти к созданию новой резьбы";
            bCreateNew.AccessibleDescription = "Завершить режим редактирования без применения изменений и перейти к выбору рёбер для новой резьбы. Существующая геометрия останется без изменений.";
            bEditExisting = MakeSecondaryButton("Правка", ButtonGlyph.Edit);
            bEditExisting.Visible = true;
            bEditExisting.AccessibleName = "Выбрать существующую резьбу для редактирования";
            bEditExisting.AccessibleDescription = "Приостановить выбор новых рёбер и выбрать резьбу Helivanta или штатную операцию «Резьба Inventor» в дереве модели. Текущая геометрия не изменяется до подтверждения правки.";
            bIntegrityCheck = MakeSecondaryButton("Проверка резьб", ButtonGlyph.Analyze);
            bIntegrityCheck.AccessibleName = "Проверка резьб";
            bIntegrityCheck.AccessibleDescription = "Проверка параметров построенных резьб";
            bIntegrityCheck.Click += (s, e) => ThreadIntegrityDialog.ShowForActiveDocument(_app, this);
            bResume = MakeSecondaryButton("Выбрать рёбра", ButtonGlyph.Edges);
            bResume.AccessibleName = "Выбрать рёбра";
            bResume.AccessibleDescription = "Возобновить интерактивный выбор круговых рёбер в активной детали Inventor.";
            bResume.Visible = false;
            bResume.Click += (s, e) => StartSelection();
            bPreview = MakeSecondaryButton("Предпросмотр", ButtonGlyph.Preview);
            bPreview.Visible = false;
            bPreview.AccessibleDescription = "Показывает временную полупрозрачную поверхность и контуры будущей резьбы в окне модели Inventor. Не создаёт CAD-операций.";
            bPreview.Click += (s, e) => ToggleThreadPreview();

            Button[] informationActions = { bCreateNew, bEditExisting, bPreview, bIntegrityCheck, bResume };
            for (int i = 0; i < informationActions.Length; i++)
            {
                Button action = informationActions[i];
                action.Dock = DockStyle.Fill;
                action.MinimumSize = new Size(0, 30);
                action.Margin = new Padding(2, 2, 2, 2);
                // Keep a readable, consistent caption size; layout, not font shrinking,
                // provides the width needed by each action.
                action.Font = new Font("Segoe UI", 8f, FontStyle.Regular);
                action.VisibleChanged += (s, e) => ReflowInformationActions();
                _selectionActionPanel.Controls.Add(action, i % 3, 0);
            }
            ReflowInformationActions();
            informationGrid.Controls.Add(_informationMessagesViewport, 0, 0);
            informationGrid.ResumeLayout(true);
            _previewLegend.VisibleChanged += (s, e) => RefreshInformationLayout();
            _previewToolTip = new ToolTip { ShowAlways = true, AutoPopDelay = 15000, InitialDelay = 450, ReshowDelay = 100 };




            _previewDocumentTimer = new System.Windows.Forms.Timer { Interval = 300 };
            _previewDocumentTimer.Tick += (s, e) =>
            {
                if (_threadPreview != null && _threadPreview.IsVisible && !_threadPreview.BelongsToActiveDocument())
                {
                    ClearThreadPreview();
                    if (!_closing && lStatus != null)
                    {
                        lStatus.ForeColor = UiMuted;
                        lStatus.Text = "Предпросмотр удалён: активный документ изменился.";
                    }
                }
            };

            // Parameter changes are bursty (ComboBox notifications and NumericUpDown input).
            // Debounce them, then rebuild the non-transacting overlay once with the final values.
            _previewRefreshTimer = new System.Windows.Forms.Timer { Interval = 180 };
            _previewRefreshTimer.Tick += (s, e) =>
            {
                _previewRefreshTimer.Stop();
                RefreshThreadPreviewNow(false);
            };

            EventHandler refreshInformation = (s, e) => RefreshInformationLayout();
            // Dynamic Target & Status paragraphs are localized at the presentation boundary.
            // Internal geometry/parameter values remain untouched; only these display controls change.
            lTarget.TextChanged += (s, e) => LocalizeStatusText(lTarget);
            lInfo.TextChanged += (s, e) => LocalizeStatusText(lInfo);
            lStatus.TextChanged += (s, e) => LocalizeStatusText(lStatus);
            lWarn.TextChanged += (s, e) => LocalizeStatusText(lWarn);
            lTarget.TextChanged += refreshInformation;
            lTarget.TextChanged += (s, e) => UpdateBoundSliderRanges();
            lInfo.TextChanged += refreshInformation;
            lStatus.TextChanged += refreshInformation;
            lWarn.TextChanged += refreshInformation;
            lWarn.VisibleChanged += refreshInformation;

            // All mode, selection, and preview actions occupy their reserved fixed row below
            // the selection instructions. Visibility changes never move the later information rows.
            AddSection(informationSection);

            // Actions are deliberately outside the Information section so long messages
            // can never be covered by buttons or constrained by a fixed footer row.
            var informationActionsSection = NewSection(UseNewLayout ? "БЫСТРЫЕ ДЕЙСТВИЯ" : "Действия");
            var informationActionsGrid = GetSectionGrid(informationActionsSection);
            informationActionsGrid.ColumnCount = 1;
            informationActionsGrid.RowCount = 1;
            informationActionsGrid.ColumnStyles.Clear();
            informationActionsGrid.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100f));
            informationActionsGrid.RowStyles.Clear();
            informationActionsGrid.RowStyles.Add(new RowStyle(SizeType.Absolute, Dpi(38)));
            informationActionsGrid.Controls.Add(_selectionActionPanel, 0, 0);
            AddSection(informationActionsSection);

            // Direction belongs to thread definition, not to the feature-creation controls.
            rbR = CreateChoiceRadio("Правая", true, "thread-hand");
            rbL = CreateChoiceRadio("Левая", false, "thread-hand");

            // --- Thread type / template ---
            var typeSection = NewSection(UseNewLayout ? "ТИП РЕЗЬБЫ И СТАНДАРТ" : "Тип резьбы");
            var typeGrid = GetSectionGrid(typeSection);
            rbExt = CreateChoiceRadio("Наружная", true, "thread-location");
            rbInt = CreateChoiceRadio("Внутренняя", false, "thread-location");

            // Keep direction choices in the same horizontal columns as thread type:
            // “Правая” starts exactly below “Наружная”, and “Левая” below “Внутренняя”.
            // Match the first-row radio preferred widths so FlowLayoutPanel cannot drift
            // the second radio's X coordinate due to different caption lengths.
            int externalRadioWidth = UseNewLayout ? Dpi(104) : rbExt.GetPreferredSize(Size.Empty).Width;
            int internalRadioWidth = UseNewLayout ? Dpi(118) : rbInt.GetPreferredSize(Size.Empty).Width;
            rbExt.Width = rbR.Width = externalRadioWidth;
            rbInt.Width = rbL.Width = internalRadioWidth;
            if (UseNewLayout)
            {
                rbExt.Height = rbInt.Height = rbR.Height = rbL.Height = Dpi(30);
            }
            var directionPanel = InlinePanel(rbR, rbL);
            if (UseNewLayout)
            {
                rbR.Margin = rbL.Margin = Padding.Empty;
                directionPanel.Width = externalRadioWidth + internalRadioWidth;
                directionPanel.Height = Dpi(30);
            }
            else
            {
                rbR.Margin = new Padding(0, 1, 5, 1);
                rbL.Margin = new Padding(0, 1, 5, 1);
                directionPanel.Width = externalRadioWidth + 5 + internalRadioWidth + 5;
                directionPanel.Height = 22;
            }
            directionPanel.AutoSize = false;
            directionPanel.Margin = new Padding(0, 1, 0, 1);

            cbStd = Combo(190);
            // The standard selector must use the native selection state. Owner-drawing this
            // specific DropDownList was the source area for repeated SelectedIndex loss on
            // popup-close under Inventor; other themed dropdowns remain owner-drawn.
            cbStd.DrawMode = DrawMode.Normal;
            // Keep native selection notifications (owner-draw previously caused index rollback),
            // but use Flat rendering so the closed field respects the graphite BackColor.
            cbStd.FlatStyle = FlatStyle.Flat;
            cbStd.BackColor = UiField;
            cbStd.ForeColor = UiText;
            foreach (ThreadStandard s in Enum.GetValues(typeof(ThreadStandard)))
                cbStd.Items.Add(HelivantaLocalization.Translate(ThreadStandards.Title(s)));
            var locationPanel = InlinePanel(rbExt, rbInt);
            if (UseNewLayout)
            {
                rbExt.Margin = rbInt.Margin = Padding.Empty;
                locationPanel.AutoSize = false;
                locationPanel.Width = externalRadioWidth + internalRadioWidth;
                locationPanel.Height = Dpi(30);
            }
            AddRow(typeGrid, "Тип:", locationPanel);
            AddRow(typeGrid, "Направление:", directionPanel);
            AddRow(typeGrid, "Шаблон:", cbStd);
            // Taper controls belong to the thread definition, directly under Template,
            // not in the generic feature-construction section.
            chTapered = CreateToggle("Коническая резьба — подготовить поверхность автоматически", false, true);
            cbTaperStandard = Combo(190);
            cbTaperStandard.Items.Add("NPT");
            cbTaperStandard.Items.Add("JIS Taper");
            cbTaperStandard.SelectedIndex = 0;
            cbTaperDesignation = Combo(190);
            cbTaperDesignation.DropDownStyle = ComboBoxStyle.DropDownList;
            cbTaperDesignation.AccessibleName = "Типоразмер конической резьбы";
            cbTaperDesignation.AccessibleDescription = "Типоразмер из таблицы Inventor. Шаг или число ниток на дюйм задаются выбранным табличным размером.";
            chTaperStrictStandard = CreateToggle("Строго по стандарту конических резьб", true);
            chTaperStrictStandard.AccessibleDescription = "Включено: диаметры конуса берутся из таблицы Inventor. Выключено: сохраняется диаметр исходной цилиндрической поверхности на дальнем конце, а диаметр у выбранного ребра вычисляется по конусности 1:16; режим считается нестандартным.";
            lTaperGeometryModeNote = new Label
            {
                AutoSize = true,
                MaximumSize = new Size(Dpi(430), 0),
                ForeColor = UiMuted,
                Font = new Font(Font.FontFamily, Math.Max(8f, Font.Size - 0.5f), FontStyle.Regular),
                Text = "Свободный режим сохраняет диаметр заготовки на конце резьбы и пересчитывает входной диаметр по 1:16.",
                Visible = false,
                Margin = new Padding(0, Dpi(1), 0, Dpi(3))
            };
            chTaperStrictStandard.Visible = false;
            nTaperRatio = Num(0.001m, 0.5m, 4, 0.001m, 0.0625m);
            nTaperRatio.Enabled = false; // native standard table controls taper; ratio is display-only legacy data
            cbTaperStandard.Enabled = cbTaperDesignation.Enabled = false;
            AddFull(typeGrid, chTapered);
            AddRow(typeGrid, "Стандарт конуса:", cbTaperStandard);
            AddRow(typeGrid, "Типоразмер:", cbTaperDesignation);
            AddFull(typeGrid, chTaperStrictStandard);
            AddFull(typeGrid, lTaperGeometryModeNote);
            chTaperStrictStandard.CheckedChanged += (s, e) =>
            {
                if (lTaperGeometryModeNote != null)
                    lTaperGeometryModeNote.Visible = chTapered != null && chTapered.Checked && !chTaperStrictStandard.Checked;
                if (_loading) return;
                if (lStatus != null && chTapered != null && chTapered.Checked)
                {
                    lStatus.ForeColor = chTaperStrictStandard.Checked ? UiMuted : UiWarning;
                    lStatus.Text = chTaperStrictStandard.Checked
                        ? "Строгий режим: диаметры и длина конуса будут взяты из таблицы Inventor. Пользовательская длина может сделать резьбу нестандартной."
                        : "Свободный режим: диаметр заготовки на дальнем конце сохраняется; геометрия не заявляется как соответствующая стандарту.";
                }
                // Returning from free geometry to strict mode restores the table length immediately.
                // User can still deliberately override it later; existing custom-length warning remains.
                if (chTaperStrictStandard.Checked && chTapered != null && chTapered.Checked &&
                    cbTaperDesignation != null && !string.IsNullOrWhiteSpace(cbTaperDesignation.Text))
                    ApplyTaperTableLengthFromTable();
                UpdateInfo();
            };
            chTapered.CheckedChanged += (s, e) =>
            {
                bool tapered = chTapered.Checked;
                // Reject the transition before mutating the layout; a failed preview close must
                // never briefly hide/show rows or leave stale ComboBox arrows on screen.
                if (tapered && (_previewRequested || (_threadPreview != null && _threadPreview.IsVisible)) && !ClearThreadPreview())
                {
                    chTapered.Checked = false;
                    lStatus.ForeColor = UiWarning;
                    lStatus.Text = "Сначала закройте предпросмотр текущей цилиндрической резьбы; затем включите конический режим.";
                    return;
                }

                ApplyTaperModeUI(tapered);
                if (tapered)
                {
                    // The list is already populated during initialization. Only resolve the
                    // closest row if the target/standard key has changed; do not re-enumerate
                    // every Inventor table size on each toggle.
                    if (Target != null && cbTaperDesignation != null && cbTaperDesignation.Items.Count > 0)
                        ScheduleClosestTaperDesignationSelection();
                    else if (cbTaperDesignation != null && cbTaperDesignation.Items.Count == 0)
                        ScheduleTaperDesignationRefresh(false);
                    SyncPreviewButtonVisibility();
                    if (lStatus != null && Target == null)
                    {
                        lStatus.ForeColor = Color.FromArgb(255, 191, 64);
                        lStatus.Text = "Автоподготовка конуса 1:16: выберите круговое ребро цилиндрической поверхности на входе резьбы.";
                    }
                }
                else if (lStatus != null)
                {
                    lStatus.ForeColor = UiText;
                    lStatus.Text = "Цилиндрический режим.";
                }
                UpdateInfo();
            };
            cbTaperStandard.SelectedIndexChanged += (s, e) => RefreshTaperDesignations(true);
            cbTaperDesignation.SelectedIndexChanged += (s, e) =>
            {
                if (!_refreshingTaperDesignations)
                {
                    CancelTaperAutoSelection();
                    if (Target != null) _lastTaperAutoSelectionKey = GetTaperAutoSelectionKey();
                    if (chTapered != null && chTapered.Checked)
                        ApplyTaperTableLengthFromTable();
                }
            };
            rbExt.CheckedChanged += (s, e) => { if (rbExt.Checked) RefreshTaperDesignations(true); };
            rbInt.CheckedChanged += (s, e) => { if (rbInt.Checked) RefreshTaperDesignations(true); };
            RefreshTaperDesignations();
            AddSection(typeSection);

            // --- Size section ---
            _threadSizeSection = NewSection(UseNewLayout ? "РАЗМЕР И ДОПУСК" : "Размер резьбы");
            var sizeGrid = GetSectionGrid(_threadSizeSection);
            cbSize = Combo(190);
            cbMat = Combo(110);
            // Keep the technology selector owner-drawn like the other themed selectors so its
            // closed field uses the graphite palette instead of the native white selection face.
            // Selection lifecycle remains handled by the existing committed-index policy below.
            cbMat.DrawMode = DrawMode.OwnerDrawFixed;
            cbMat.Items.AddRange(new object[] { "Металл (0)", "Смола (0,1)", "SLS-печать (0,15)", "FDM-печать (0,3)", "Другое (ввод вручную)" });
            cbCham = Combo(120);
            cbDia = new ThemedComboBox { DropDownStyle = ComboBoxStyle.DropDown, Width = 88, MaxDropDownItems = 16, BackColor = UiField, ForeColor = UiText };
            cbPitch = new ThemedComboBox { DropDownStyle = ComboBoxStyle.DropDown, Width = 88, MaxDropDownItems = 16, BackColor = UiField, ForeColor = UiText };

            rbMmD = UnitRadio("мм", true, "diameter-unit");
            rbInD = UnitRadio("дюйм", false, "diameter-unit");
            rbMmP = UnitRadio("мм", true, "pitch-unit");
            rbInP = UnitRadio("дюйм", false, "pitch-unit");

            var diaPanel = InlinePanel(cbDia, rbMmD, rbInD);
            var pitchPanel = InlinePanel(cbPitch, rbMmP, rbInP);

            AddRow(sizeGrid, "Типоразмер:", cbSize);
            lDia = AddRow(sizeGrid, "Номинальный диаметр:", diaPanel);
            lPitch = AddRow(sizeGrid, "Шаг:", pitchPanel);
            cbTolerance = Combo(190);
            cbTolerance.Items.AddRange(new object[] { "Не задан", "6H — внутренняя (ISO)", "6g — наружная (ISO)" });
            cbTolerance.SelectedIndex = 0;
            AddRow(sizeGrid, "Класс допуска:", cbTolerance);
            AddSection(_threadSizeSection);

            // --- Build settings section ---
            var buildSection = NewSection(UseNewLayout ? "ГЕОМЕТРИЯ И ОПЕРАЦИИ" : "Параметры построения");
            var buildGrid = GetSectionGrid(buildSection);
            _buildGrid = buildGrid;
            ConfigureBuildGrid(buildGrid);
            nStarts = Num(1, 12, 0, 1, 1);
            nClear = Num(0, 3, 3, 0.01m, 0m);
            nCham = Num(0.05m, 50, 2, 0.1m, 1m);
            nCham.Width = 62;
            nLen = Num(1m, 10000, 2, 1, 20);
            nOff = Num(0, 10000, 2, 0.5m, 0);
            nRun = Num(0.5m, 20, 1, 0.5m, 1m);

            chFull = CreateToggle("На всю длину поверхности", true, true);
            chRun = CreateToggle("Выход инструмента за деталь", true, true);
            // The simplified run-out option was removed: always use the smooth Loft path,
            // with the existing validated segmented-Coil fallback only if Inventor rejects Loft.
            var runoutModePanel = InlinePanel(new Label
            {
                Text = HelivantaUserSettings.Current.Language == "en" ? "Smooth runout" : "Плавный сбег", AutoSize = false, Width = 150, Height = 20,
                TextAlign = ContentAlignment.MiddleLeft, ForeColor = UiText
            });
            runoutModePanel.AutoSize = false;
            runoutModePanel.Width = 154;
            runoutModePanel.Height = 22;
            chRound = CreateToggle("Скруглять", true);
            chMirror = CreateToggle("Зеркально (для упорных резьб)", false);
            chMirror.Enabled = false;
            chCham = CreateToggle("Фаски", true);
            cbCham.Items.AddRange(new object[] { "В начале", "В конце", "С обоих краёв" });
            // Replace static number-only fields with compact sliders bound to the same
            // NumericUpDown instances; all existing ValueChanged/build logic remains authoritative.
            _startsSlider = AddBuildSliderInputRow(buildGrid, "Число заходов:", nStarts, 1m, 12m, 1m, 60);
            AddBuildSingleInputRow(buildGrid, "Технология:", cbMat);
            cbMat.Width = 190;
            AddBuildSingleInputRow(buildGrid, "Тех. зазор, мм:", nClear);
            _lengthSlider = AddBuildSliderInputRow(buildGrid, "Длина резьбы, мм:", nLen, 1m, 100m, 1m, 72);
            AddBuildOptionRow(buildGrid, chFull);
            _offsetSlider = AddBuildSliderInputRow(buildGrid, "Отступ от ребра, мм:", nOff, 0m, 100m, 0.5m, 72);
            AddBuildOptionRow(buildGrid, chRun);
            AddBuildControlRow(buildGrid, "Длина сбега, шагов:", nRun, runoutModePanel);

            AddBuildChamferRow(buildGrid, chCham, cbCham, nCham);
            // Default chamfer settings: enabled, at the beginning, 1 mm for cylindrical threads.
            cbCham.SelectedIndex = 0;
            cbCham.Enabled = true;
            nCham.Value = 1m;
            cbCham.Visible = false; // selection is now presented by equal-width segment buttons
            nCham.Visible = true;
            SetNumericLocked(nCham, false);
            if (chamferOptions != null) chamferOptions.Visible = true;

            AddBuildFormRow(buildGrid, "Профиль:", chRound, chMirror);
            chSortFolders = CreateToggle("Сортировать резьбы по папкам", true);
            AddBuildSingleControlRow(buildGrid, chSortFolders);
            AddSection(buildSection);
            UpdateBoundSliderRanges();
            ApplyTaperModeUI(false);

            // Main-form size is not recomputed from parameter events. The user may still
            // resize vertically; DPI changes are handled through the explicit responsive pass.

            // --- Footer ---
            footerButtons = new FlowLayoutPanel
            {
                Dock = DockStyle.Fill,
                AutoSize = false,
                FlowDirection = FlowDirection.LeftToRight,
                WrapContents = false,
                BackColor = UseNewLayout ? UiPanel : UiSurface,
                Margin = UseNewLayout ? new Padding(0, Dpi(6), 0, 0) : Padding.Empty,
                Padding = UseNewLayout ? new Padding(Dpi(6), Dpi(5), Dpi(3), 0) : new Padding(0, 3, 0, 0),
                Height = Dpi(UseNewLayout ? 42 : 35)
            };
            bReset = MakeSecondaryButton("Сброс", ButtonGlyph.Reset);
            bUndo = MakeSecondaryButton("Отмена", ButtonGlyph.Undo);
            bBuild = MakePrimaryButton("Построить", ButtonGlyph.Build);
            // Reserve enough width for every mode's longest caption; do not resize/reflow
            // the footer when the main action changes from Build to Edit/Next.
            bBuild.Width = 132;
            bReset.Width = 90;
            bUndo.Width = 90;
            bClose = MakeSecondaryButton("Выход", ButtonGlyph.Close);
            if (!UseNewLayout)
            {
                bAbout = MakeAboutButton();
                bHelp = MakeHelpButton();
            }
            if (UseNewLayout)
            {
                footerButtons.Paint += (sender, args) =>
                {
                    using (var pen = new Pen(UiBorder, Math.Max(1f, DeviceDpi / 96f)))
                        args.Graphics.DrawLine(pen, 0, 0, footerButtons.Width, 0);
                };
            }
            footerButtons.Controls.Add(bReset);
            footerButtons.Controls.Add(bUndo);
            footerButtons.Controls.Add(bBuild);
            footerButtons.Controls.Add(bClose);
            if (!UseNewLayout)
            {
                footerButtons.Controls.Add(bAbout);
                footerButtons.Controls.Add(bHelp);
            }
            root.Controls.Add(footerButtons, 0, 2);

            // Events
            cbStd.DropDown += OnStandardDropDownOpened;
            cbStd.SelectedIndexChanged += OnStandardSelectionChanged;
            cbStd.SelectionChangeCommitted += OnStandardSelectionCommitted;
            cbStd.DropDownClosed += OnStandardDropDownClosed;
            cbSize.SelectedIndexChanged += (s, e) =>
            {
                if (_loading) return;
                var sz = cbSize.SelectedItem as ThreadSize;
                if (sz != null) SelectSize(sz);
            };
            EventHandler diaUnitChanged = (s, e) =>
            {
                var rb = s as RadioButton;
                if (rb == null || !rb.Checked || _loading) return;
                SetInchDia(rb == rbInD);
            };
            EventHandler pitchUnitChanged = (s, e) =>
            {
                var rb = s as RadioButton;
                if (rb == null || !rb.Checked || _loading) return;
                SetInchPitch(rb == rbInP);
            };
            rbMmD.CheckedChanged += diaUnitChanged;
            rbInD.CheckedChanged += diaUnitChanged;
            rbMmP.CheckedChanged += pitchUnitChanged;
            rbInP.CheckedChanged += pitchUnitChanged;

            cbDia.TextChanged += (s, e) => { if (!_loading) OnDiaChanged(); };
            cbPitch.TextChanged += (s, e) => { if (!_loading) { SyncSizeCombo(); UpdateInfo(); } };

            EventHandler typeChanged = (s, e) =>
            {
                var rb = s as RadioButton;
                if (rb != null && !rb.Checked) return;
                if (_loading) return;
                if (Target != null) { RebuildLists(); AutoSelectSize(); }
                UpdateInfo();
            };
            rbExt.CheckedChanged += typeChanged;
            rbInt.CheckedChanged += typeChanged;
            cbTolerance.SelectedIndexChanged += (s, e) => { if (!_loading) UpdateInfo(); };

            nStarts.ValueChanged += (s, e) => { if (!_loading) UpdateInfo(); };
            nClear.ValueChanged += (s, e) => { if (!_loading) UpdateInfo(); };
            nLen.ValueChanged += (s, e) =>
            {
                if (!_loading && chTapered != null && chTapered.Checked && !_settingTaperTableLength)
                    MarkTaperLengthAsCustom("Длина резьбы изменена вручную.");
                if (!_loading) UpdateInfo();
            };
            nOff.ValueChanged += (s, e) => { if (!_loading) UpdateInfo(); };
            nRun.ValueChanged += (s, e) => { if (!_loading) UpdateInfo(); };
            cbMat.DropDown += OnMaterialDropDownOpened;
            cbMat.SelectedIndexChanged += OnMaterialSelectionChanged;
            cbMat.SelectionChangeCommitted += OnMaterialSelectionCommitted;
            cbMat.DropDownClosed += OnMaterialDropDownClosed;
            cbCham.DropDown += OnChamferDropDownOpened;
            cbCham.SelectedIndexChanged += OnChamferSelectionChanged;
            cbCham.SelectionChangeCommitted += OnChamferSelectionCommitted;
            cbCham.DropDownClosed += OnChamferDropDownClosed;
            nCham.ValueChanged += (s, e) => { if (!_loading) UpdateInfo(); };
            chCham.CheckedChanged += (s, e) =>
            {
                bool on = chCham.Checked;
                cbCham.Visible = false; // model-only ComboBox; three visible segments control its selection
                cbCham.Enabled = on;
                nCham.Visible = on;
                if (rbChamStart != null) rbChamStart.Enabled = on;
                if (rbChamEnd != null) rbChamEnd.Enabled = on;
                if (rbChamBoth != null) rbChamBoth.Enabled = on;
                if (chamferOptions != null) chamferOptions.Visible = on;
                if (on && (!ThreadChamferSelectionPolicy.IsValidIndex(cbCham.SelectedIndex, cbCham.Items.Count) ||
                    cbCham.SelectedIndex != _lastCommittedChamferIndex))
                {
                    int restored = ThreadChamferSelectionPolicy.ResolveStableIndex(
                        -1, _lastCommittedChamferIndex, cbCham.Items.Count);
                    if (!ThreadChamferSelectionPolicy.IsValidIndex(restored, cbCham.Items.Count)) restored = 0;
                    bool wasLoading = _loading;
                    _loading = true;
                    try { cbCham.SelectedIndex = restored; }
                    finally { _loading = wasLoading; }
                    _lastCommittedChamferIndex = restored;
                    _pendingChamferIndex = -1;
                    _chamferCommitObserved = false;
                    _preserveCommittedChamferUntilDropdownReopened = true;
                }
                nCham.Enabled = on;
                SyncChamferSegmentButtons();
                SetNumericLocked(nCham, !(on && ThreadChamferSelectionPolicy.IsValidIndex(
                    _lastCommittedChamferIndex, cbCham.Items.Count)));
                RefreshChamferComboVisuals();
                if (_taperModeTransitionInProgress) return;
                UpdateInfo();
                ApplyResponsiveLayout();
            };
            chFull.CheckedChanged += (s, e) =>
            {
                SetNumericLocked(nLen, chFull.Checked);
                nLen.ForeColor = UiText;
                if (!_loading && chTapered != null && chTapered.Checked)
                {
                    if (chFull.Checked)
                    {
                        MarkTaperLengthAsCustom("Включена полная длина поверхности.");
                    }
                    else
                    {
                        // Any transition away from full-surface mode returns to the table length,
                        // including when an existing tapered thread was loaded in edit mode with
                        // FullLength already set in persisted metadata.
                        ApplyTaperTableLengthFromTable();
                    }
                }
                if (!_loading) UpdateInfo();
            };
            chRun.CheckedChanged += (s, e) => { if (!_loading) UpdateInfo(); };
            chRound.CheckedChanged += (s, e) => { if (!_loading) UpdateInfo(); };
            chMirror.CheckedChanged += (s, e) => { if (!_loading) UpdateInfo(); };
            if (chSortFolders != null) chSortFolders.CheckedChanged += (s, e) => { if (!_loading) UpdateInfo(); };
            rbR.CheckedChanged += (s, e) => { if (!_loading && rbR.Checked) UpdateInfo(); };
            rbL.CheckedChanged += (s, e) => { if (!_loading && rbL.Checked) UpdateInfo(); };
            SetNumericLocked(nLen, chFull.Checked);
            SetNumericLocked(nRun, false);

            AcceptButton = bBuild;
            CancelButton = bClose;
            var userDefaults = HelivantaUserSettings.Current;
            int defaultStandardIndex = 0;
            if (userDefaults != null && !string.IsNullOrWhiteSpace(userDefaults.DefaultStandard))
            {
                for (int i = 0; i < cbStd.Items.Count; i++)
                    if (cbStd.Items[i].ToString().StartsWith(userDefaults.DefaultStandard, StringComparison.OrdinalIgnoreCase)) { defaultStandardIndex = i; break; }
            }
            cbStd.SelectedIndex = Math.Max(0, Math.Min(defaultStandardIndex, cbStd.Items.Count - 1));
            _lastValidStandardIndex = cbStd.SelectedIndex;
            chMirror.Enabled = false;
            OnStandardChanged();
            RefreshStandardComboVisuals();
            int defaultTechnologyIndex = userDefaults.DefaultTechnology == "Resin" ? 1 : userDefaults.DefaultTechnology == "SLS" ? 2 : userDefaults.DefaultTechnology == "FDM" ? 3 : 0;
            cbMat.SelectedIndex = Math.Max(0, Math.Min(defaultTechnologyIndex, cbMat.Items.Count - 1));
            if (rbExt != null) rbExt.Checked = userDefaults.DefaultExternal;
            if (rbInt != null) rbInt.Checked = !userDefaults.DefaultExternal;
            if (rbR != null) rbR.Checked = userDefaults.DefaultRightHand;
            if (rbL != null) rbL.Checked = !userDefaults.DefaultRightHand;
            _lastCommittedMaterialIndex = cbMat.SelectedIndex;
            RefreshMaterialComboVisuals();
            cbCham.SelectedIndex = 0;
            _lastCommittedChamferIndex = 0;
            _pendingChamferIndex = -1;
            _chamferCommitObserved = false;
            _preserveCommittedChamferUntilDropdownReopened = true;
            RefreshChamferComboVisuals();

            bBuild.Click += (s, e) => DoBuild();
            bCreateNew.Click += (s, e) => SwitchToCreateMode();
            bEditExisting.Click += (s, e) => RequestEditExistingThread();
            bClose.Click += (s, e) => Close();
            bAbout.Click += (s, e) => { using (var about = new AboutDialog()) about.ShowDialog(this); };
            if (bSettings != null) bSettings.Click += (s, e) => { using (var settings = new HelivantaSettingsDialog(this)) { if (settings.ShowDialog(this) == DialogResult.OK) { ApplySavedThemeToControls(this); RefreshInlineHelpLocalization(); if (lTarget != null) lTarget.Text = HelivantaLocalization.Translate(lTarget.Text); if (lInfo != null) lInfo.Text = HelivantaLocalization.Translate(lInfo.Text); if (lStatus != null) lStatus.Text = HelivantaLocalization.Translate(lStatus.Text); if (lWarn != null) lWarn.Text = HelivantaLocalization.Translate(lWarn.Text); UpdateInfo(); Invalidate(true); MessageBox.Show(this, HelivantaLocalization.Translate("Настройки сохранены. Подписи команд ленты обновлены; раздел Инструкция обновлён с учётом выбранного языка. Для остальных окон закройте и откройте их повторно."), "Helivanta", MessageBoxButtons.OK, MessageBoxIcon.Information); } } };
            bHelp.Click += (s, e) => ToggleInlineHelp(!_inlineHelpMode);
            bReset.Click += (s, e) => ResetDialogDefaults();
            bUndo.Click += (s, e) => DoUndo();
            InstallButtonToolTips();

            _sel = new EdgeSelector(app);
            _sel.Changed += OnSelectionChanged;
            _sel.Message += ShowMessage;
            _sel.Terminated += () =>
            {
                bResume.Visible = true;
                SyncPreviewButtonVisibility();
                ApplyResponsiveLayout();
                ShowMessage("Выбор рёбер приостановлен (Esc или другая команда Inventor).");
            };

            Shown += (s, e) =>
            {
                // Keep the form transparent while Inventor/WinForms settle its initial
                // DPI, wrapped text, scroll-bar metrics and final position. A couple of
                // queued passes absorb layout/DpiChanged events before the first visible frame.
                try { _resizeTimer.Stop(); } catch { }
                try { if (!_editMode && !_nativeConversionMode) StartSelection(); }
                catch (Exception ex) { try { ShowMessage("Не удалось начать выбор: " + ex.Message); } catch { } }

                try
                {
                    BeginInvoke((Action)(() => CompleteInitialPresentationPass(0)));
                }
                catch
                {
                    try { ApplyResponsiveLayout(); } catch { }
                    ForceRightAlignment();
                    _initialLayoutSettled = true;
                    _initialPresentationPending = false;
                    Opacity = 1.0;
                }
            };
            Resize += (s, e) =>
            {
                if (!_layouting) ScheduleResizeRefresh();
            };
            DpiChanged += (s, e) =>
            {
                if (_closing || IsDisposed || !IsHandleCreated) return;
                try
                {
                    BeginInvoke((Action)(() =>
                    {
                        if (_closing || IsDisposed) return;
                        if (_initialPresentationPending) return;
                        _lastSectionWidth = -1;
                        ApplyResponsiveLayout(true);
                    }));
                }
                catch { }
            };
            FormClosing += (s, e) =>
            {
                // Preview owns only NonTransactingClientGraphics; never close while Inventor
                // refuses to delete those graphics, or an orphaned phantom could remain onscreen.
                bool previewCleared = false;
                try { previewCleared = ClearThreadPreview(); } catch { }
                if (!previewCleared)
                {
                    e.Cancel = true;
                    if (lStatus != null && !lStatus.IsDisposed)
                    {
                        lStatus.ForeColor = UiWarning;
                        lStatus.Text = "Не удалось удалить временную графику предпросмотра. Закрытие отменено; выключите предпросмотр и повторите.";
                    }
                    return;
                }
                try { if (_previewControlsDialog != null) _previewControlsDialog.CloseFromOwner(); } catch { }
                _previewControlsDialog = null;
                _closing = true;
                try { DetachTransactionEvents(); } catch { }
                try { _previewDocumentTimer.Stop(); } catch { }
                try { if (_previewRefreshTimer != null) _previewRefreshTimer.Stop(); } catch { }
                try { _resizeTimer.Stop(); } catch { }
                try { _sel.Dispose(); } catch { }
                // Foreground is restored after FormClosed, once this owned HWND and the child
                // palette are gone. Activating the owner before destroying this dialog can make
                // Windows reactivate the previously foreground unrelated app afterward.
            };
            FormClosed += (s, e) =>
            {
                try { _resizeTimer.Stop(); } catch { }
                try { _resizeTimer.Dispose(); } catch { }
                try { _previewDocumentTimer.Stop(); } catch { }
                try { _previewDocumentTimer.Dispose(); } catch { }
                try { if (_previewRefreshTimer != null) { _previewRefreshTimer.Stop(); _previewRefreshTimer.Dispose(); } } catch { }
                try { if (_previewToolTip != null) _previewToolTip.Dispose(); } catch { }
                try { ClearThreadPreview(); } catch { }
                try { if (_previewControlsDialog != null) _previewControlsDialog.CloseFromOwner(); } catch { }
                _previewControlsDialog = null;
                try { _sel.Dispose(); } catch { }
                _sel = null;
                // The AddIn schedules host activation after all FormClosed handlers and owner
                // window cleanup finish, avoiding the OS reactivating a previously foreground app.
            };
        }

        /// <summary>
        /// Compute the final initial size and place the native window on the right side of
        /// Inventor's monitor before Show(owner). This avoids a visible left-to-right jump
        /// caused by applying DPI-aware sizing only after the owner has shown the form.
        /// </summary>
        public void PrepareInitialPosition()
        {
            if (IsDisposed || _closing) return;
            try
            {
                PerformLayout();
                ApplyResponsiveLayout();
                _ = Handle;
                ForceRightAlignment();
            }
            catch
            {
                try { _ = Handle; ForceRightAlignment(); } catch { }
            }
        }

        private void NotifyInitialPresentationCompleted()
        {
            if (_initialPresentationCompletionNotified) return;
            _initialPresentationCompletionNotified = true;
            try
            {
                EventHandler handler = InitialPresentationCompleted;
                if (handler != null) handler(this, EventArgs.Empty);
            }
            catch { }
        }

        private void CompleteInitialPresentationPass(int pass)
        {
            if (IsDisposed || _closing) return;

            try
            {
                _resizeTimer.Stop();
                PerformLayout();
                ApplyResponsiveLayout();
                ForceRightAlignment();

                // Keep the form invisible through three layout turns. The extra turn absorbs
                // owner-window activation and native ComboBox/Edit recalculations before display.
                if (pass < 2)
                {
                    BeginInvoke((Action)(() => CompleteInitialPresentationPass(pass + 1)));
                    return;
                }

                _resizeTimer.Stop();
                _initialLayoutSettled = true;
                _initialPresentationPending = false;
                ForceRightAlignment();
                Opacity = 1.0;
                NotifyInitialPresentationCompleted();
            }
            catch
            {
                try { ApplyResponsiveLayout(); } catch { }
                _initialLayoutSettled = true;
                _initialPresentationPending = false;
                ForceRightAlignment();
                Opacity = 1.0;
                NotifyInitialPresentationCompleted();
            }
        }

        // Пользователь может менять ширину и высоту окна, включая углы. Автоматическое
        // изменение размера из-за параметров/статуса отключено; DPI и первый показ отдельны.
        protected override void WndProc(ref Message m)
        {
            const int WM_ENTERSIZEMOVE = 0x0231;
            const int WM_EXITSIZEMOVE = 0x0232;
            bool exitingSizeMove = m.Msg == WM_EXITSIZEMOVE;
            if (m.Msg == WM_ENTERSIZEMOVE)
            {
                _inSizing = true;
                _resizeTimer.Stop();
            }

            base.WndProc(ref m);

            if (exitingSizeMove)
            {
                _inSizing = false;
                ScheduleResizeRefresh(true);
            }

        }

        private void ScheduleResizeRefresh(bool immediate = false)
        {
            if (IsDisposed || _inSizing) return;
            _resizeTimer.Stop();
            if (immediate)
            {
                RefreshVerticalLayout();
                return;
            }
            _resizeTimer.Start();
        }

        private void RefreshVerticalLayout()
        {
            if (IsDisposed || bodyViewport == null || bodyStack == null || _layouting) return;
            // Keep AutoScroll enabled so fixed-height sections remain accessible when the
            // user deliberately makes the form shorter.
            int previousClientWidth = bodyViewport.ClientSize.Width;
            if (!bodyViewport.AutoScroll) bodyViewport.AutoScroll = true;
            bodyViewport.PerformLayout();

            // On a user resize/DPI transition, refresh widths only if the viewport width
            // really changed. Text changes never enter this path.
            if (bodyViewport.ClientSize.Width != previousClientWidth)
            {
                ResizeSectionWidths();
                RefreshInformationLayoutCore();
                bodyStack.PerformLayout();
            }
        }

        // Do not set WS_EX_COMPOSITED on the whole dialog. It forces every descendant HWND
        // into bottom-to-top painting; the inline help previously shimmered despite stable text
        // assignments. Custom-painted surfaces retain local WinForms double buffering instead.

        private sealed class BufferedTableLayoutPanel : TableLayoutPanel
        {
            public BufferedTableLayoutPanel()
            {
                SetStyle(ControlStyles.UserPaint | ControlStyles.AllPaintingInWmPaint |
                          ControlStyles.OptimizedDoubleBuffer | ControlStyles.ResizeRedraw, true);
                DoubleBuffered = true;
            }
        }

        /// <summary>
        /// Owner-drawn, scrollable help article. Drawing the complete paragraph block into one
        /// WinForms buffer avoids native EDIT control repaint interactions inside Inventor.
        /// Text remains copyable through Ctrl+C or the context menu.
        /// </summary>
        private sealed class BufferedHelpArticleViewer : Panel
        {
            private const int MinTextWidth = 80;
            private const int TextPadding = 9;
            private string _bodyText = string.Empty;
            private int _measuredTextWidth = -1;
            private int _measuredTextHeight;
            private bool _measuring;
            private readonly ContextMenuStrip _copyMenu;
            private readonly ToolStripMenuItem _copyItem;
            private readonly Font _ownedFont;

            // Runtime article content is supplied by the Help controller, not by the WinForms designer.
            // Explicitly opt out of design-time serialization to satisfy WFO1000 and avoid persisting
            // documentation text into InitializeComponent.
            [System.ComponentModel.Browsable(false)]
            [System.ComponentModel.DesignerSerializationVisibility(System.ComponentModel.DesignerSerializationVisibility.Hidden)]
            public string BodyText
            {
                get { return _bodyText; }
                set
                {
                    string next = value ?? string.Empty;
                    if (string.Equals(_bodyText, next, StringComparison.Ordinal)) return;
                    _bodyText = next;
                    AutoScrollPosition = Point.Empty;
                    RecalculateTextLayout();
                    Invalidate();
                }
            }

            public BufferedHelpArticleViewer(Color backColor, Color foreColor, Font font)
            {
                AutoScroll = true;
                AutoScrollMargin = new Size(0, 0);
                AutoScrollMinSize = Size.Empty;
                BackColor = backColor;
                ForeColor = foreColor;
                _ownedFont = font;
                Font = font;
                Padding = new Padding(8);
                BorderStyle = BorderStyle.FixedSingle;
                TabStop = true;
                SetStyle(ControlStyles.UserPaint | ControlStyles.AllPaintingInWmPaint |
                         ControlStyles.OptimizedDoubleBuffer | ControlStyles.ResizeRedraw | ControlStyles.Selectable, true);
                DoubleBuffered = true;

                _copyMenu = new ContextMenuStrip();
                _copyItem = new ToolStripMenuItem("Копировать текст инструкции");
                _copyItem.Click += (s, e) => CopyArticleToClipboard();
                _copyMenu.Items.Add(_copyItem);
                ContextMenuStrip = _copyMenu;
                RefreshLocalization();

                Scroll += (s, e) => Invalidate();
            }

            public void RefreshLocalization()
            {
                if (_copyItem != null)
                    _copyItem.Text = HelivantaUserSettings.Current.Language == "en" ? "Copy help text" : "Копировать текст инструкции";
            }

            protected override void OnSizeChanged(EventArgs e)
            {
                base.OnSizeChanged(e);
                RecalculateTextLayout();
            }

            protected override void OnFontChanged(EventArgs e)
            {
                base.OnFontChanged(e);
                RecalculateTextLayout();
            }

            protected override void OnScroll(ScrollEventArgs se)
            {
                base.OnScroll(se);
                Invalidate();
            }

            protected override void OnMouseDown(MouseEventArgs e)
            {
                if (e.Button == MouseButtons.Left && CanFocus) Focus();
                base.OnMouseDown(e);
            }

            protected override bool IsInputKey(Keys keyData)
            {
                Keys key = keyData & Keys.KeyCode;
                if (key == Keys.PageUp || key == Keys.PageDown || key == Keys.Home || key == Keys.End ||
                    key == Keys.Up || key == Keys.Down)
                    return true;
                return base.IsInputKey(keyData);
            }

            protected override void OnKeyDown(KeyEventArgs e)
            {
                base.OnKeyDown(e);
                if (e.Control && e.KeyCode == Keys.C)
                {
                    CopyArticleToClipboard();
                    e.Handled = true;
                    e.SuppressKeyPress = true;
                    return;
                }

                Point current = AutoScrollPosition; // WinForms returns negative coordinates.
                int currentY = Math.Max(0, -current.Y);
                int nextY = currentY;
                int page = Math.Max(24, ClientSize.Height - 24);
                switch (e.KeyCode)
                {
                    case Keys.PageDown: nextY += page; break;
                    case Keys.PageUp: nextY -= page; break;
                    case Keys.Down: nextY += Math.Max(12, Font.Height); break;
                    case Keys.Up: nextY -= Math.Max(12, Font.Height); break;
                    case Keys.Home: nextY = 0; break;
                    case Keys.End: nextY = Math.Max(0, _measuredTextHeight + Padding.Vertical - ClientSize.Height); break;
                    default: return;
                }
                nextY = Math.Max(0, Math.Min(nextY, Math.Max(0, AutoScrollMinSize.Height - ClientSize.Height)));
                AutoScrollPosition = new Point(0, nextY);
                Invalidate();
                e.Handled = true;
            }

            protected override void OnPaintBackground(PaintEventArgs e)
            {
                e.Graphics.Clear(BackColor);
            }

            protected override void OnPaint(PaintEventArgs e)
            {
                base.OnPaint(e);
                if (string.IsNullOrEmpty(_bodyText)) return;

                int width = CurrentTextWidth();
                Point scroll = AutoScrollPosition;
                var textRect = new Rectangle(
                    Padding.Left + scroll.X,
                    Padding.Top + scroll.Y,
                    width,
                    Math.Max(Font.Height, _measuredTextHeight + TextPadding));
                TextRenderer.DrawText(
                    e.Graphics,
                    _bodyText,
                    Font,
                    textRect,
                    ForeColor,
                    TextFormatFlags.WordBreak | TextFormatFlags.TextBoxControl | TextFormatFlags.NoPrefix |
                    TextFormatFlags.PreserveGraphicsClipping | TextFormatFlags.PreserveGraphicsTranslateTransform);
            }

            private int CurrentTextWidth()
            {
                int width = ClientSize.Width - Padding.Horizontal - TextPadding;
                if (VerticalScroll.Visible) width -= SystemInformation.VerticalScrollBarWidth;
                return Math.Max(MinTextWidth, width);
            }

            private void RecalculateTextLayout()
            {
                if (_measuring || IsDisposed) return;
                _measuring = true;
                try
                {
                    int width = CurrentTextWidth();
                    if (width != _measuredTextWidth || _measuredTextHeight == 0)
                    {
                        _measuredTextWidth = width;
                        if (string.IsNullOrEmpty(_bodyText))
                        {
                            _measuredTextHeight = Font.Height;
                        }
                        else
                        {
                            Size proposed = new Size(width, 100000);
                            Size measured = TextRenderer.MeasureText(
                                _bodyText,
                                Font,
                                proposed,
                                TextFormatFlags.WordBreak | TextFormatFlags.TextBoxControl | TextFormatFlags.NoPrefix);
                            _measuredTextHeight = Math.Max(Font.Height, measured.Height);
                        }
                    }

                    int scrollHeight = Math.Max(0, _measuredTextHeight + Padding.Vertical + TextPadding);
                    Size newMinSize = new Size(0, scrollHeight);
                    if (AutoScrollMinSize != newMinSize) AutoScrollMinSize = newMinSize;
                }
                finally
                {
                    _measuring = false;
                }

                // AutoScroll may add/remove the vertical scrollbar, changing the effective client
                // width. Re-measure once layout has settled so the wrapped text and paint bounds
                // use the same width as the visible viewport.
                if (!IsDisposed && CurrentTextWidth() != _measuredTextWidth)
                {
                    RecalculateTextLayout();
                    return;
                }
                Invalidate();
            }

            private void CopyArticleToClipboard()
            {
                if (string.IsNullOrEmpty(_bodyText)) return;
                try { Clipboard.SetText(_bodyText); }
                catch { /* Clipboard can be unavailable in a remote/locked desktop session. */ }
            }

            protected override void Dispose(bool disposing)
            {
                if (disposing)
                {
                    try { if (_copyMenu != null) _copyMenu.Dispose(); } catch { }
                }
                base.Dispose(disposing);
                if (disposing)
                {
                    try { if (_ownedFont != null) _ownedFont.Dispose(); } catch { }
                }
            }
        }

        private Image LoadEmbeddedWordmark()
        {
            // Keep the approved official wordmark, selecting the contrast-correct asset per theme.
            Assembly assembly = Assembly.GetExecutingAssembly();
            bool light = HelivantaUserSettings.Current.Theme == "Light";
            string[] preferred = light
                ? new[] { "Helivanta-Wordmark-Light-Cropped.png", "Helivanta-Wordmark-Light.png", "Helivanta-Wordmark.png" }
                : new[] { "Helivanta-Wordmark-Dark-Cropped.png", "Helivanta-Wordmark-Dark.png", "Helivanta-Wordmark.png" };
            foreach (string suffix in preferred)
            {
                foreach (string resourceName in assembly.GetManifestResourceNames())
                {
                    if (!resourceName.EndsWith(suffix, StringComparison.OrdinalIgnoreCase)) continue;
                    using (Stream stream = assembly.GetManifestResourceStream(resourceName))
                    {
                        if (stream == null) continue;
                        using (Image source = Image.FromStream(stream)) return new Bitmap(source);
                    }
                }
            }
            return null;
        }

        private Icon LoadEmbeddedIcon()
        {
            foreach (string n in Assembly.GetExecutingAssembly().GetManifestResourceNames())
                if (n.EndsWith("Helivanta.ico", StringComparison.OrdinalIgnoreCase))
                {
                    using (Stream s = Assembly.GetExecutingAssembly().GetManifestResourceStream(n))
                        return new Icon(s);
                }
            return SystemIcons.Application;
        }

        private RadioButton UnitRadio(string text, bool checkedState, string groupKey)
        {
            if (UseNewLayout)
            {
                return new SegmentRadioButton(groupKey)
                {
                    Text = text,
                    AutoSize = false,
                    Width = Dpi(string.Equals(text, "мм", StringComparison.Ordinal) ? 42 : 62),
                    Height = Dpi(28),
                    Checked = checkedState,
                    ForeColor = UiText,
                    Margin = Padding.Empty,
                    AccessibleName = text
                };
            }
            return new ThemedRadioButton
            {
                Text = text,
                AutoSize = true,
                Checked = checkedState,
                ForeColor = UiText,
                Margin = new Padding(1, 1, 5, 1)
            };
        }

        private RadioButton CreateChoiceRadio(string text, bool checkedState, string groupKey)
        {
            if (UseNewLayout)
            {
                return new SegmentRadioButton(groupKey)
                {
                    Text = text,
                    AutoSize = false,
                    Width = Dpi(104),
                    Height = Dpi(30),
                    Checked = checkedState,
                    ForeColor = UiText,
                    Margin = Padding.Empty,
                    AccessibleName = text
                };
            }
            return new ThemedRadioButton
            {
                Text = text,
                AutoSize = true,
                Checked = checkedState,
                ForeColor = UiText
            };
        }

        private CheckBox CreateToggle(string text, bool checkedState, bool switchOnLeft = false)
        {
            if (UseNewLayout)
                return new ToggleSwitch(text, checkedState, switchOnLeft)
                {
                    AccessibleName = text,
                    AccessibleRole = AccessibleRole.CheckButton
                };
            return new ThemedCheckBox { Text = text, AutoSize = true, Checked = checkedState };
        }

        private void LocalizeStatusText(TextBox textBox)
        {
            if (textBox == null || textBox.IsDisposed || _localizingStatusText ||
                !string.Equals(HelivantaUserSettings.Current.Language, "en", StringComparison.OrdinalIgnoreCase)) return;
            string translated = HelivantaLocalization.Translate(textBox.Text ?? string.Empty);
            if (string.Equals(translated, textBox.Text, StringComparison.Ordinal)) return;
            _localizingStatusText = true;
            try
            {
                int selectionStart = textBox.SelectionStart;
                textBox.Text = translated;
                try { textBox.SelectionStart = Math.Min(selectionStart, textBox.TextLength); } catch { }
            }
            finally { _localizingStatusText = false; }
        }

        private void HookTargetStatusLocalization(TextBox box)
        {
            if (box == null) return;
            box.TextChanged += (sender, args) =>
            {
                if (_localizingTargetStatusText || box.IsDisposed) return;
                string source = box.Text;
                string localized = HelivantaLocalization.Translate(source);
                if (string.Equals(source, localized, StringComparison.Ordinal)) return;
                int selectionStart = 0;
                try { selectionStart = Math.Min(box.SelectionStart, localized.Length); } catch { }
                _localizingTargetStatusText = true;
                try
                {
                    box.Text = localized;
                    try { box.SelectionStart = selectionStart; } catch { }
                }
                finally { _localizingTargetStatusText = false; }
            };
        }

        private TextBox NewInfoLabel(string text)
        {
            return new SelectableInfoTextBox
            {
                Text = text,
                MinimumSize = new Size(0, 25),
                MaximumSize = Size.Empty
            };
        }

        private sealed class InformationMessagesViewport : Panel
        {
            public InformationMessagesViewport()
            {
                AutoScroll = true;
                TabStop = false;
            }

            public void ForwardMouseWheel(MouseEventArgs e)
            {
                if (IsDisposed || !IsHandleCreated || e == null) return;
                base.OnMouseWheel(e);
            }

            public void ScrollMessageIntoView(Control message)
            {
                if (IsDisposed || !IsHandleCreated || message == null || message.IsDisposed) return;
                try
                {
                    // WinForms can scroll nested descendants into view; defer until layout
                    // has recalculated message heights and the scrollable extent.
                    BeginInvoke((Action)(() =>
                    {
                        if (!IsDisposed && message.Visible && !message.IsDisposed)
                            ScrollControlIntoView(message);
                    }));
                }
                catch (InvalidOperationException) { }
            }
        }

        private sealed class SelectableInfoTextBox : TextBox
        {
            private const int EM_GETLINECOUNT = 0x00BA;
            private bool _pendingTopReset;

            public override string Text
            {
                get => base.Text;
                set => base.Text = HelivantaLocalization.Translate(value);
            }

            [DllImport("user32.dll", EntryPoint = "SendMessageW")]
            private static extern IntPtr SendNativeMessage(IntPtr hWnd, int msg, IntPtr wParam, IntPtr lParam);

            public int GetNativeVisualLineCount()
            {
                if (!IsHandleCreated || IsDisposed) return 0;
                try { return Math.Max(1, SendNativeMessage(Handle, EM_GETLINECOUNT, IntPtr.Zero, IntPtr.Zero).ToInt32()); }
                catch { return 0; }
            }

            public SelectableInfoTextBox()
            {
                Multiline = true;
                ReadOnly = true;
                BorderStyle = BorderStyle.None;
                WordWrap = true;
                ScrollBars = ScrollBars.None;
                HideSelection = false;
                AutoSize = false;
                TabStop = true;
                Margin = Padding.Empty;
                Padding = Padding.Empty;
                BackColor = UiPanel;
                ForeColor = UiMuted;
            }

            protected override void OnTextChanged(EventArgs e)
            {
                // Keep new status text anchored to its first line without requesting any
                // parent layout or measuring a new height.
                _pendingTopReset = true;
                base.OnTextChanged(e);
                bool hasContent = !string.IsNullOrWhiteSpace(Text);
                if (Visible != hasContent) Visible = hasContent;
                RefreshOverflowScrollBar();
                EnsureImportantMessageVisible();
            }

            private void EnsureImportantMessageVisible()
            {
                // Errors and warnings should be brought into view immediately even when
                // the message list is already scrolled to an earlier status.
                if (!Visible || IsDisposed || !IsHandleCreated || Parent == null) return;
                if (ForeColor != UiError && ForeColor != UiWarning) return;
                Control flow = Parent;
                Control viewport = flow != null ? flow.Parent : null;
                if (viewport == null || viewport.IsDisposed || !viewport.IsHandleCreated) return;
                try
                {
                    Action scroll = () =>
                    {
                        if (IsDisposed || !Visible || viewport.IsDisposed) return;
                        if (viewport is InformationMessagesViewport scrollableViewport)
                            scrollableViewport.ScrollMessageIntoView(this);
                    };
                    if (IsHandleCreated) BeginInvoke(scroll);
                    else scroll();
                }
                catch (InvalidOperationException) { }
            }

            public void RefreshOverflowScrollBar()
            {
                if (IsDisposed) return;
                int textWidth = Math.Max(100, Width - Padding.Horizontal - 12);
                string text = string.IsNullOrEmpty(Text) ? " " : Text;
                Size measured = TextRenderer.MeasureText(text, Font,
                    new Size(textWidth, 100000), TextFormatFlags.WordBreak | TextFormatFlags.TextBoxControl);
                int wantedHeight = Math.Max(Font.Height + 8, measured.Height + 10);
                if (Height != wantedHeight) Height = wantedHeight;
                if (ScrollBars != ScrollBars.None) ScrollBars = ScrollBars.None;
            }

            protected override void OnSizeChanged(EventArgs e)
            {
                base.OnSizeChanged(e);
                if (IsHandleCreated) RefreshOverflowScrollBar();
            }

            protected override void OnForeColorChanged(EventArgs e)
            {
                base.OnForeColorChanged(e);
                EnsureImportantMessageVisible();
            }

            protected override void OnVisibleChanged(EventArgs e)
            {
                base.OnVisibleChanged(e);
                EnsureImportantMessageVisible();
            }

            public void EnsurePendingTopVisible()
            {
                if (!_pendingTopReset || !IsHandleCreated) return;
                try
                {
                    Select(0, 0);
                    ScrollToCaret();
                    _pendingTopReset = false;
                }
                catch { }
            }

            protected override void OnMouseWheel(MouseEventArgs e)
            {
                base.OnMouseWheel(e);
                Control parent = Parent;
                Control viewport = parent != null ? parent.Parent : null;
                if (viewport is InformationMessagesViewport scrollableViewport)
                    scrollableViewport.ForwardMouseWheel(e);
            }

            protected override void OnKeyDown(KeyEventArgs e)
            {
                if (e.Control && e.KeyCode == Keys.A)
                { SelectAll(); e.SuppressKeyPress = true; return; }
                if (e.Control && e.KeyCode == Keys.C)
                { Copy(); e.SuppressKeyPress = true; return; }
                base.OnKeyDown(e);
            }

        }

        private TableLayoutPanel NewSection(string title)
        {
            int sectionNumber = ++_sectionCounter;
            var outer = new BufferedTableLayoutPanel
            {
                ColumnCount = 1,
                RowCount = 2,
                AutoSize = true,
                AutoSizeMode = AutoSizeMode.GrowAndShrink,
                Dock = DockStyle.Top,
                Margin = new Padding(0, 0, 0, Dpi(UseNewLayout ? 5 : 8)),
                Padding = new Padding(1),
                BackColor = UiBorder,
                ForeColor = UiText,
                Tag = title
            };
            outer.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100f));

            // Each section uses an icon-led, diagonally hatched header and an accent rail.
            // Section numbers were removed after confirming they visually collided with the glyphs.
            var header = new SectionHeaderPanel
            {
                Dock = DockStyle.Fill,
                ColumnCount = 3,
                RowCount = 1,
                Height = Dpi(UseNewLayout ? 29 : 30),
                BackColor = UseNewLayout ? UiPanel2 : UiHeader,
                HatchEnabled = true,
                Margin = Padding.Empty,
                Padding = Padding.Empty
            };
            // With section numbers removed, no blank number/gutter columns remain: the icon and
            // title start immediately after the accent rail, aligning with the Inventor panel style.
            header.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, Dpi(UseNewLayout ? 3 : 4)));
            header.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, Dpi(UseNewLayout ? 30 : 28)));
            header.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100f));
            header.RowStyles.Add(new RowStyle(SizeType.Percent, 100f));

            var accent = new Panel
            {
                Dock = DockStyle.Fill,
                BackColor = UiAccent,
                Margin = Padding.Empty
            };
            // Build131 diagnostic: section numbering is intentionally removed from the UI.
            // Keep its former column width reserved so icon/title positions stay unchanged;
            // this isolates whether the perceived duplicate number came from the label overlay.
            SectionGlyphKind glyphKind = GetSectionGlyphKind(sectionNumber);
            var sectionGlyph = new SectionGlyph(glyphKind)
            {
                Dock = DockStyle.Fill,
                Margin = new Padding(Dpi(2), Dpi(2), Dpi(1), Dpi(2)),
                Text = string.Empty,
                AccessibleName = GetSectionGlyphAccessibleName(glyphKind),
                AccessibleDescription = "Пиктограмма раздела",
                TabStop = false
            };
            var titleLabel = new Label
            {
                Text = title,
                Dock = DockStyle.Fill,
                ForeColor = UseNewLayout ? UiAccentHover : UiText,
                Font = new Font("Segoe UI Semibold", UseNewLayout ? 9.2f : 9.5f, FontStyle.Bold),
                TextAlign = ContentAlignment.MiddleLeft,
                BackColor = Color.Transparent,
                AutoEllipsis = true,
                Margin = new Padding(Dpi(5), 0, Dpi(6), 0)
            };
            header.Controls.Add(accent, 0, 0);
            header.Controls.Add(sectionGlyph, 1, 0);
            header.Controls.Add(titleLabel, 2, 0);
            outer.RowStyles.Add(new RowStyle(SizeType.Absolute, Dpi(UseNewLayout ? 29 : 30)));
            outer.Controls.Add(header, 0, 0);

            var grid = new BufferedTableLayoutPanel
            {
                ColumnCount = 2,
                RowCount = 0,
                AutoSize = true,
                AutoSizeMode = AutoSizeMode.GrowAndShrink,
                Dock = DockStyle.Fill,
                BackColor = UiPanel,
                Padding = UseNewLayout
                    ? new Padding(Dpi(10), Dpi(5), Dpi(10), Dpi(6))
                    : new Padding(Dpi(10), Dpi(7), Dpi(10), Dpi(8)),
                Margin = Padding.Empty,
                Tag = "section-grid"
            };
            grid.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, Dpi(158)));
            grid.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100f));
            outer.RowStyles.Add(new RowStyle(SizeType.AutoSize));
            outer.Controls.Add(grid, 0, 1);
            return outer;
        }

        private static SectionGlyphKind GetSectionGlyphKind(int sectionNumber)
        {
            switch (sectionNumber)
            {
                case 1: return SectionGlyphKind.Target;
                case 2: return SectionGlyphKind.Actions;
                case 3: return SectionGlyphKind.Thread;
                case 4: return SectionGlyphKind.Dimensions;
                default: return SectionGlyphKind.Geometry;
            }
        }

        private static string GetSectionGlyphAccessibleName(SectionGlyphKind glyphKind)
        {
            switch (glyphKind)
            {
                case SectionGlyphKind.Target: return "Выбор цели";
                case SectionGlyphKind.Actions: return "Быстрые действия";
                case SectionGlyphKind.Thread: return "Тип и стандарт резьбы";
                case SectionGlyphKind.Dimensions: return "Размеры и допуски";
                default: return "Геометрия и операции";
            }
        }

        private TableLayoutPanel GetSectionGrid(TableLayoutPanel section)
        {
            foreach (Control c in section.Controls)
                if (c is TableLayoutPanel grid && Equals(grid.Tag, "section-grid"))
                    return grid;
            throw new InvalidOperationException("Внутренняя сетка секции не найдена.");
        }

        private void ConfigureBuildGrid(TableLayoutPanel grid)
        {
            grid.SuspendLayout();
            grid.ColumnCount = 4;
            grid.ColumnStyles.Clear();
            grid.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 116));
            grid.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 88));
            // Reserve enough width for the technology combo instead of allowing the
            // rightmost field to be clipped by the previous 120 px caption column.
            grid.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 88));
            grid.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100f));
            grid.Padding = new Padding(Dpi(8), Dpi(3), Dpi(8), Dpi(3));
            grid.ResumeLayout();
        }

        private void AddBuildPairRow(TableLayoutPanel grid, string leftCaption, Control leftControl, string rightCaption, Control rightControl)
        {
            int row = grid.RowCount++;
            grid.RowStyles.Add(new RowStyle(SizeType.AutoSize));

            var l1 = new Label { Text = leftCaption, AutoSize = true, ForeColor = UseNewLayout ? UiMuted : UiText, Margin = new Padding(0, 2, 5, 2), Dock = DockStyle.Fill, TextAlign = ContentAlignment.MiddleLeft };
            grid.Controls.Add(l1, 0, row);
            leftControl.Margin = new Padding(0, 2, 5, 2);
            leftControl.Anchor = AnchorStyles.Left;
            grid.Controls.Add(leftControl, 1, row);

            var l2 = new Label { Text = rightCaption, AutoSize = true, ForeColor = UseNewLayout ? UiMuted : UiText, Margin = new Padding(0, 2, 5, 2), Dock = DockStyle.Fill, TextAlign = ContentAlignment.MiddleLeft };
            grid.Controls.Add(l2, 2, row);
            rightControl.Margin = new Padding(0, 2, 0, 2);
            rightControl.Anchor = AnchorStyles.Left;
            grid.Controls.Add(rightControl, 3, row);
        }

        private int AddBuildSingleInputRow(TableLayoutPanel grid, string caption, Control field)
        {
            int row = grid.RowCount++;
            grid.RowStyles.Add(new RowStyle(SizeType.AutoSize));
            var label = new Label
            {
                Text = caption,
                AutoSize = true,
                ForeColor = UseNewLayout ? UiMuted : UiText,
                Margin = new Padding(0, 2, 5, 2),
                Dock = DockStyle.Fill,
                TextAlign = ContentAlignment.MiddleLeft
            };
            grid.Controls.Add(label, 0, row);
            field.Margin = new Padding(0, 1, 6, 1);
            field.Anchor = AnchorStyles.Left;
            grid.Controls.Add(field, 1, row);
            grid.SetColumnSpan(field, 3);
            return row;
        }

        private void AddBuildControlRow(TableLayoutPanel grid, string caption, Control fieldOrFirst, Control second)
        {
            int row = grid.RowCount++;
            grid.RowStyles.Add(new RowStyle(SizeType.AutoSize));

            var label = new Label { Text = caption, AutoSize = true, ForeColor = UseNewLayout ? UiMuted : UiText, Margin = new Padding(0, 2, 5, 2), Dock = DockStyle.Fill, TextAlign = ContentAlignment.MiddleLeft };
            grid.Controls.Add(label, 0, row);
            fieldOrFirst.Margin = new Padding(0, 1, 6, 1);
            fieldOrFirst.Anchor = AnchorStyles.Left;
            grid.Controls.Add(fieldOrFirst, 1, row);

            second.ForeColor = UiText;
            second.Margin = new Padding(0, 1, 0, 1);
            second.Anchor = AnchorStyles.Left;
            grid.Controls.Add(second, 2, row);
            grid.SetColumnSpan(second, 2);
        }

        private GlowSlider AddBuildSliderInputRow(TableLayoutPanel grid, string caption,
            NumericUpDown field, decimal minimum, decimal maximum, decimal step, int numericWidth)
        {
            int row = grid.RowCount++;
            // Stable track height prevents the AutoSize card from oscillating while the
            // slider thumb moves or the numeric text changes.
            grid.RowStyles.Add(new RowStyle(SizeType.Absolute, Dpi(32)));

            var label = new Label
            {
                Text = caption,
                AutoSize = true,
                ForeColor = UseNewLayout ? UiMuted : UiText,
                Margin = new Padding(0, 2, Dpi(5), 2),
                Dock = DockStyle.Fill,
                TextAlign = ContentAlignment.MiddleLeft
            };
            grid.Controls.Add(label, 0, row);

            var input = new TableLayoutPanel
            {
                ColumnCount = 2,
                RowCount = 1,
                AutoSize = false,
                Dock = DockStyle.Fill,
                Height = Dpi(32),
                MinimumSize = new Size(0, Dpi(32)),
                BackColor = UiPanel,
                Margin = new Padding(0, 0, Dpi(3), 0),
                Padding = Padding.Empty
            };
            input.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100f));
            input.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, Dpi(numericWidth + 7)));
            input.RowStyles.Add(new RowStyle(SizeType.Absolute, Dpi(32)));

            var slider = new GlowSlider
            {
                Dock = DockStyle.Fill,
                Margin = new Padding(Dpi(2), 0, Dpi(6), 0),
                BackColor = UiPanel,
                AccessibleName = caption.Trim().TrimEnd(':')
            };
            slider.SetRange(minimum, maximum, step);
            slider.Bind(field);

            field.Width = Dpi(numericWidth);
            field.Margin = new Padding(Dpi(2), Dpi(3), Dpi(4), Dpi(3));
            field.Anchor = AnchorStyles.Left | AnchorStyles.Right;
            field.Dock = DockStyle.None;

            input.Controls.Add(slider, 0, 0);
            input.Controls.Add(field, 1, 0);
            grid.Controls.Add(input, 1, row);
            grid.SetColumnSpan(input, 3);
            return slider;
        }

        private void AddBuildOptionRow(TableLayoutPanel grid, Control option)
        {
            int row = grid.RowCount++;
            grid.RowStyles.Add(new RowStyle(SizeType.AutoSize));
            option.Margin = new Padding(0, Dpi(1), 0, Dpi(1));
            option.Anchor = AnchorStyles.Left;
            grid.Controls.Add(option, 1, row);
            grid.SetColumnSpan(option, 3);
        }

        private void UpdateBoundSliderRanges()
        {
            if (_startsSlider != null && nStarts != null)
                _startsSlider.SetRange(nStarts.Minimum, nStarts.Maximum, Math.Max(1m, nStarts.Increment));

            decimal surfaceLength = 100m;
            try
            {
                if (Target != null && Target.LengthCm > 0.0 && !double.IsNaN(Target.LengthCm) && !double.IsInfinity(Target.LengthCm))
                    surfaceLength = ClampDecimal(Target.LengthCm * 10.0, 1m, 10000m);
            }
            catch { surfaceLength = 100m; }

            if (_lengthSlider != null && nLen != null)
            {
                decimal maximum = Math.Max(nLen.Minimum, Math.Min(nLen.Maximum, surfaceLength));
                _lengthSlider.SetRange(nLen.Minimum, maximum, Math.Max(nLen.Increment, 0.1m));
                _lengthSlider.RefreshBoundState();
            }
            if (_offsetSlider != null && nOff != null)
            {
                decimal maximum = Math.Max(nOff.Minimum, Math.Min(nOff.Maximum, surfaceLength));
                _offsetSlider.SetRange(nOff.Minimum, maximum, Math.Max(nOff.Increment, 0.1m));
                _offsetSlider.RefreshBoundState();
            }
        }

        private int AddBuildChamferRow(TableLayoutPanel grid, CheckBox chamferToggle, ComboBox position, NumericUpDown length)
        {
            int row = grid.RowCount++;
            grid.RowStyles.Add(new RowStyle(SizeType.AutoSize));

            var chamferRow = new BufferedTableLayoutPanel
            {
                ColumnCount = 2,
                RowCount = 1,
                AutoSize = true,
                AutoSizeMode = AutoSizeMode.GrowAndShrink,
                BackColor = UiPanel,
                Margin = new Padding(0, 1, 0, 1),
                Padding = Padding.Empty,
                Dock = DockStyle.Fill
            };
            chamferRow.ColumnStyles.Add(new ColumnStyle(SizeType.AutoSize));
            chamferRow.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100f));
            chamferRow.RowStyles.Add(new RowStyle(SizeType.AutoSize));

            int controlHeight = Math.Max(position.Height, length.Height);
            int togglePad = Math.Max(0, (controlHeight - chamferToggle.Height) / 2);
            chamferToggle.Margin = new Padding(0, togglePad, 8, togglePad);
            chamferToggle.Anchor = AnchorStyles.Left;
            chamferRow.Controls.Add(chamferToggle, 0, 0);

            // The ComboBox remains the authoritative selected-index model for existing
            // validation/persistence code but is never parented into the visible layout.
            position.Visible = false;
            position.TabStop = false;
            position.AccessibleName = "Расположение фаски (внутреннее состояние)";
            position.AccessibleDescription = "Видимое управление заменено тремя сегментированными кнопками.";

            chamferOptions = new FlowLayoutPanel
            {
                AutoSize = true,
                AutoSizeMode = AutoSizeMode.GrowAndShrink,
                FlowDirection = FlowDirection.LeftToRight,
                WrapContents = false,
                BackColor = UiPanel,
                Margin = Padding.Empty,
                Padding = Padding.Empty,
                Anchor = AnchorStyles.Left
            };

            rbChamStart = CreateChamferSegment("В начале", "chamfer-position", 0, "Фаска в начале резьбы");
            rbChamEnd = CreateChamferSegment("В конце", "chamfer-position", 1, "Фаска в конце резьбы");
            rbChamBoth = CreateChamferSegment("Оба края", "chamfer-position", 2, "Фаски на обоих краях резьбы");
            int segmentWidth = Dpi(78);
            int segmentHeight = Dpi(30);
            foreach (SegmentRadioButton segment in new[] { rbChamStart, rbChamEnd, rbChamBoth })
            {
                segment.Width = segmentWidth;
                segment.Height = segmentHeight;
                segment.Margin = Padding.Empty;
            }
            rbChamStart.Click += (s, e) => SelectChamferSegment(0);
            rbChamEnd.Click += (s, e) => SelectChamferSegment(1);
            rbChamBoth.Click += (s, e) => SelectChamferSegment(2);

            var lenLabel = new Label
            {
                Text = "Длина:",
                AutoSize = false,
                Width = Dpi(60),
                Height = segmentHeight,
                ForeColor = UiMuted,
                TextAlign = ContentAlignment.MiddleLeft,
                AutoEllipsis = false,
                Margin = new Padding(Dpi(12), 0, Dpi(4), 0)
            };
            length.Width = Dpi(56);
            // FlowLayoutPanel top-aligns children by their bounds; compensate for the
            // shorter NumericUpDown so its centerline matches the 30-DPI-aware segments.
            int lengthVerticalPad = Math.Max(0, (segmentHeight - length.Height) / 2);
            length.Margin = new Padding(0, lengthVerticalPad, 0, 0);

            chamferOptions.Controls.Add(rbChamStart);
            chamferOptions.Controls.Add(rbChamEnd);
            chamferOptions.Controls.Add(rbChamBoth);
            chamferOptions.Controls.Add(lenLabel);
            chamferOptions.Controls.Add(length);
            chamferRow.Controls.Add(chamferOptions, 1, 0);
            grid.Controls.Add(chamferRow, 0, row);
            grid.SetColumnSpan(chamferRow, 4);
            SyncChamferSegmentButtons();
            return row;
        }

        private SegmentRadioButton CreateChamferSegment(string text, string groupKey, int index, string description)
        {
            return new SegmentRadioButton(groupKey)
            {
                Text = text,
                AccessibleName = text,
                AccessibleDescription = description,
                Tag = index,
                BackColor = UiPanel,
                ForeColor = UiText,
                UseVisualStyleBackColor = false,
                TabStop = true
            };
        }

        private void SelectChamferSegment(int index)
        {
            if (_loading || cbCham == null || chCham == null || !chCham.Checked ||
                !ThreadChamferSelectionPolicy.IsValidIndex(index, cbCham.Items.Count)) return;

            bool wasLoading = _loading;
            _loading = true;
            try { cbCham.SelectedIndex = index; }
            finally { _loading = wasLoading; }

            _lastCommittedChamferIndex = index;
            _pendingChamferIndex = -1;
            _chamferCommitObserved = false;
            _preserveCommittedChamferUntilDropdownReopened = true;
            SyncChamferSegmentButtons();
            nCham.Enabled = true;
            SetNumericLocked(nCham, false);
            UpdateInfo();
        }

        private void SyncChamferSegmentButtons()
        {
            if (cbCham == null) return;
            int selected = cbCham.SelectedIndex;
            if (rbChamStart != null && !rbChamStart.IsDisposed) rbChamStart.Checked = selected == 0;
            if (rbChamEnd != null && !rbChamEnd.IsDisposed) rbChamEnd.Checked = selected == 1;
            if (rbChamBoth != null && !rbChamBoth.IsDisposed) rbChamBoth.Checked = selected == 2;
        }

        private int AddBuildFormRow(TableLayoutPanel grid, string caption, CheckBox first, CheckBox second)
        {
            // Keep the caption and both options on one stable row.  Using three
            // AutoSize columns prevents the second checkbox from being clipped while
            // still allowing the whole group to shrink naturally with DPI scaling.
            int row = grid.RowCount++;
            grid.RowStyles.Add(new RowStyle(SizeType.AutoSize));

            var formRow = new BufferedTableLayoutPanel
            {
                ColumnCount = 4,
                RowCount = 1,
                AutoSize = true,
                AutoSizeMode = AutoSizeMode.GrowAndShrink,
                Dock = DockStyle.Fill,
                BackColor = UiPanel,
                Margin = new Padding(0, 1, 0, 1),
                Padding = Padding.Empty
            };
            formRow.ColumnStyles.Add(new ColumnStyle(SizeType.AutoSize));
            formRow.ColumnStyles.Add(new ColumnStyle(SizeType.AutoSize));
            formRow.ColumnStyles.Add(new ColumnStyle(SizeType.AutoSize));
            formRow.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100f));

            var label = new Label
            {
                Text = caption,
                AutoSize = true,
                ForeColor = UseNewLayout ? UiMuted : UiText,
                Margin = new Padding(0, 2, 8, 2),
                TextAlign = ContentAlignment.MiddleLeft
            };

            first.AutoSize = true;
            first.Margin = new Padding(0, 1, 9, 1);
            second.AutoSize = true;
            second.Margin = new Padding(0, 1, 0, 1);

            formRow.Controls.Add(label, 0, 0);
            formRow.Controls.Add(first, 1, 0);
            formRow.Controls.Add(second, 2, 0);

            grid.Controls.Add(formRow, 0, row);
            grid.SetColumnSpan(formRow, 4);
            return row;
        }

        private int AddBuildSingleControlRow(TableLayoutPanel grid, Control control)
        {
            int row = grid.RowCount++;
            grid.RowStyles.Add(new RowStyle(SizeType.AutoSize));
            control.ForeColor = UiText;
            control.Margin = new Padding(0, 1, 0, 1);
            control.Anchor = AnchorStyles.Left;
            grid.Controls.Add(control, 0, row);
            grid.SetColumnSpan(control, 4);
            return row;
        }

        private void AddSection(TableLayoutPanel section)
        {
            int row = bodyStack.RowCount++;
            bodyStack.RowStyles.Add(new RowStyle(SizeType.AutoSize));
            bodyStack.Controls.Add(section, 0, row);
        }

        private Label AddRow(TableLayoutPanel grid, string caption, Control control)
        {
            int row = grid.RowCount++;
            grid.RowStyles.Add(new RowStyle(SizeType.AutoSize));

            var label = new Label
            {
                Text = caption,
                AutoSize = true,
                ForeColor = UseNewLayout ? UiMuted : UiText,
                Margin = new Padding(0, 2, 7, 2),
                Dock = DockStyle.Fill,
                TextAlign = ContentAlignment.MiddleLeft
            };
            grid.Controls.Add(label, 0, row);

            control.Margin = new Padding(0, 1, 0, 1);
            control.Anchor = AnchorStyles.Left;
            grid.Controls.Add(control, 1, row);
            return label;
        }

        private void AddFull(TableLayoutPanel grid, Control control)
        {
            int row = grid.RowCount++;
            grid.RowStyles.Add(new RowStyle(SizeType.AutoSize));
            control.Margin = new Padding(0, 1, 0, 2);
            grid.Controls.Add(control, 0, row);
            grid.SetColumnSpan(control, 2);
        }

        private FlowLayoutPanel InlinePanel(params Control[] controls)
        {
            var p = new FlowLayoutPanel
            {
                AutoSize = true,
                AutoSizeMode = AutoSizeMode.GrowAndShrink,
                FlowDirection = FlowDirection.LeftToRight,
                WrapContents = false,
                Margin = Padding.Empty,
                Padding = Padding.Empty,
                BackColor = UiPanel
            };
            foreach (Control c in controls)
            {
                if (c is ComboBox cb) cb.BackColor = UiField;
                c.ForeColor = UiText;
                // Editable diameter/pitch ComboBoxes need a dedicated gap after the native
                // dropdown button. Their child edit HWND can paint up to the native arrow edge;
                // reserve extra space before the unit segmented buttons at every DPI/theme.
                c.Margin = c is SegmentRadioButton ? Padding.Empty :
                    (c == cbDia || c == cbPitch ? new Padding(0, 1, 10, 1) : new Padding(0, 1, 5, 1));
                p.Controls.Add(c);
            }
            return p;
        }

        private enum ButtonGlyph { None, Reset, Undo, Build, Close, Info, Help, Select, Edit, NewThread, Preview, Analyze, Edges, Settings }

        private IEnumerable<Button> EnumerateButtons(Control parent)
        {
            if (parent == null) yield break;
            foreach (Control child in parent.Controls)
            {
                Button button = child as Button;
                if (button != null) yield return button;
                foreach (Button nested in EnumerateButtons(child)) yield return nested;
            }
        }

        private string GetButtonToolTipText(Button button)
        {
            if (button == null) return string.Empty;
            if (ReferenceEquals(button, bPreview)) return HelivantaLocalization.Translate("Предпросмотр создаваемой резьбы");
            if (ReferenceEquals(button, bIntegrityCheck)) return HelivantaLocalization.Translate("Проверка параметров построенных резьб");
            if (ReferenceEquals(button, bEditExisting)) return HelivantaLocalization.Translate("Правка существующих резьб");
            string shortName = (button.Text ?? string.Empty).Trim();
            if (string.IsNullOrWhiteSpace(shortName)) shortName = (button.AccessibleName ?? string.Empty).Trim();
            if (string.IsNullOrWhiteSpace(shortName)) shortName = (button.AccessibleDescription ?? string.Empty).Trim();
            // Tooltips are deliberately concise. Full accessible descriptions remain intact on controls.
            shortName = shortName.Replace("\r", " ").Replace("\n", " ").Trim();
            shortName = HelivantaLocalization.Translate(shortName);
            const int maxTooltipLength = 52;
            if (shortName.Length > maxTooltipLength)
                shortName = shortName.Substring(0, maxTooltipLength - 1).TrimEnd() + "…";
            return shortName;
        }

        private void UpdateButtonToolTip(Button button)
        {
            if (_previewToolTip == null || button == null || button.IsDisposed) return;
            _previewToolTip.SetToolTip(button, GetButtonToolTipText(button));
        }

        private void RefreshButtonToolTips()
        {
            if (_previewToolTip == null || IsDisposed) return;
            foreach (Button button in EnumerateButtons(this)) UpdateButtonToolTip(button);
        }

        private void InstallButtonToolTips()
        {
            if (_previewToolTip == null)
                _previewToolTip = new ToolTip { ShowAlways = true, AutoPopDelay = 15000, InitialDelay = 450, ReshowDelay = 100 };
            foreach (Button button in EnumerateButtons(this))
            {
                UpdateButtonToolTip(button);
                // WinForms Button exposes TextChanged, but not AccessibleNameChanged or
                // AccessibleDescriptionChanged. Accessibility metadata is set before this
                // initial pass; code paths that change AccessibleName call
                // RefreshButtonToolTips() explicitly.
                button.TextChanged += (s, e) => UpdateButtonToolTip(s as Button);
            }
        }

        private Button MakePrimaryButton(string text, ButtonGlyph glyph)
        {
            return new RoundedIconButton(glyph, true)
            {
                Text = text,
                Size = new Size(104, 32),
                Margin = new Padding(2, 0, 0, 0),
                Font = new Font("Segoe UI", 9f, FontStyle.Regular),
                AccessibleName = text
            };
        }

        private Button MakeSecondaryButton(string text, ButtonGlyph glyph)
        {
            // The four Information-section actions share the same width and height. This keeps
            // their edges aligned and leaves enough room for every caption next to its glyph.
            int width = (text == "Выбрать ребра" || text == "Предпросмотр" ||
                         text == "Новая резьба" || text == "Правка") ? 148 :
                        (text == "Выход" ? 82 : 90);
            return new RoundedIconButton(glyph, false)
            {
                Text = text,
                Size = new Size(width, 32),
                Margin = new Padding(2, 0, 0, 0),
                Font = new Font("Segoe UI", 9f, FontStyle.Regular),
                AccessibleName = text
            };
        }


        private Button MakeSettingsButton()
        {
            var b = new RoundedIconButton(ButtonGlyph.Settings, false) { Text = string.Empty, Size = new Size(32, 32), Margin = new Padding(2, 0, 0, 0), Font = new Font("Segoe UI", 9f), AccessibleName = "Настройки" };
            var tip = new ToolTip(); tip.SetToolTip(b, HelivantaLocalization.Translate("Настройки Helivanta")); return b;
        }

        private void ApplySavedThemeToControls(Control root)
        {
            foreach (Control c in root.Controls)
            {
                Color old = c.BackColor;
                if (old == Color.FromArgb(37,48,63) || old == Color.FromArgb(239,242,245)) c.BackColor = UiSurface;
                else if (old == Color.FromArgb(48,63,80) || old == Color.FromArgb(250,251,252)) c.BackColor = UiPanel;
                else if (old == Color.FromArgb(43,57,73) || old == Color.FromArgb(231,235,239)) c.BackColor = UiPanel2;
                else if (old == Color.FromArgb(55,71,89) || old == Color.FromArgb(222,228,234)) c.BackColor = UiHeader;
                else if (old == Color.FromArgb(33,44,58) || old == Color.FromArgb(255,255,255)) c.BackColor = UiField;
                if (c is Label || c is CheckBox || c is RadioButton) c.ForeColor = UiText;
                if (c is ComboBox || c is NumericUpDown || c is TextBox) { c.BackColor = UiField; c.ForeColor = UiText; }
                if (c is ThemedComboBox themedCombo) themedCombo.RefreshTheme();
                if (c is Button) { c.ForeColor = Color.White; if (!(c is RoundedIconButton)) c.BackColor = UiAccent; }
                ApplySavedThemeToControls(c);
            }
            if (root is ThreadDialog)
            {
                if (_previewControlsDialog != null && !_previewControlsDialog.IsDisposed)
                    _previewControlsDialog.RefreshTheme();
                Control[] marks = root.Controls.Find("headWordmark", true);
                if (marks.Length > 0 && marks[0] is PictureBox mark)
                {
                    try
                    {
                        Image next = LoadEmbeddedWordmark();
                        Image previous = mark.Image;
                        mark.Image = next;
                        if (previous != null) previous.Dispose();
                    }
                    catch { }
                }
            }
            root.Invalidate(true);
        }

        private Button MakeAboutButton()
        {
            var b = new RoundedIconButton(ButtonGlyph.Info, false)
            {
                Text = string.Empty,
                Size = new Size(32, 32),
                Margin = new Padding(2, 0, 0, 0),
                Font = new Font("Segoe UI", 9f, FontStyle.Regular),
                AccessibleName = "О плагине"
            };
            var tip = new ToolTip();
            tip.SetToolTip(b, HelivantaLocalization.Translate("О плагине"));
            return b;
        }

        private void ToggleInlineHelp(bool show)
        {
            if (show == _inlineHelpMode) return;
            if (show) EnsureInlineHelpPanel();
            _inlineHelpMode = show;
            bodyViewport.Visible = !show;
            if (_inlineHelpPanel != null) _inlineHelpPanel.Visible = show;
            foreach (Control control in footerButtons.Controls)
                control.Visible = !show;
            if (show)
            {
                if (_inlineHelpSearch != null) _inlineHelpSearch.Focus();
                if (_inlineHelpSections != null && _inlineHelpSections.Items.Count > 0 && _inlineHelpSections.SelectedIndex < 0)
                    _inlineHelpSections.SelectedIndex = 0;
            }
            else
            {
                ApplyResponsiveLayout();
            }
        }

        private void EnsureInlineHelpPanel()
        {
            if (_inlineHelpPanel != null) return;
            PopulateInlineHelpTopics();
            _inlineHelpPanel = new Panel
            {
                Dock = DockStyle.Fill,
                BackColor = UiSurface,
                Padding = new Padding(2),
                Visible = false
            };
            var layout = new TableLayoutPanel
            {
                Dock = DockStyle.Fill,
                ColumnCount = 1,
                RowCount = 2,
                BackColor = UiSurface,
                Margin = Padding.Empty,
                Padding = Padding.Empty
            };
            layout.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100f));
            layout.RowStyles.Add(new RowStyle(SizeType.AutoSize));
            layout.RowStyles.Add(new RowStyle(SizeType.Percent, 100f));
            var helpToolbar = new TableLayoutPanel
            {
                Dock = DockStyle.Top,
                ColumnCount = 2,
                RowCount = 1,
                AutoSize = true,
                BackColor = UiSurface,
                Margin = new Padding(0, 0, 0, 7),
                Padding = Padding.Empty
            };
            helpToolbar.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100f));
            helpToolbar.ColumnStyles.Add(new ColumnStyle(SizeType.AutoSize));
            _inlineHelpSearch = new TextBox
            {
                Dock = DockStyle.Top,
                Font = new Font("Segoe UI", 10f),
                BackColor = UiField,
                ForeColor = UiText,
                BorderStyle = BorderStyle.FixedSingle,
                PlaceholderText = HelivantaUserSettings.Current.Language == "en"
                    ? "Search help: taper, chamfers, size, error…"
                    : "Поиск по инструкции: конус, фаски, размер, ошибка…",
                Margin = new Padding(0, 2, 8, 0)
            };
            var helpBack = new Button
            {
                Text = HelivantaUserSettings.Current.Language == "en" ? "← Back" : "← Назад",
                AutoSize = false,
                Size = new Size(94, 26),
                Height = 26,
                BackColor = UiHeader,
                ForeColor = UiText,
                FlatStyle = FlatStyle.Flat,
                Font = new Font("Segoe UI Semibold", 9f, FontStyle.Bold),
                Margin = new Padding(0, 2, 0, 0),
                Padding = new Padding(8, 0, 8, 0),
                Cursor = Cursors.Hand
            };
            _inlineHelpBackButton = helpBack;
            helpBack.FlatAppearance.BorderColor = UiBorder;
            helpBack.FlatAppearance.BorderSize = 1;
            var backPath = new GraphicsPath();
            int backRadius = Dpi(7);
            backPath.AddArc(0, 0, backRadius * 2, backRadius * 2, 180, 90);
            backPath.AddArc(helpBack.Width - backRadius * 2 - 1, 0, backRadius * 2, backRadius * 2, 270, 90);
            backPath.AddArc(helpBack.Width - backRadius * 2 - 1, helpBack.Height - backRadius * 2 - 1, backRadius * 2, backRadius * 2, 0, 90);
            backPath.AddArc(0, helpBack.Height - backRadius * 2 - 1, backRadius * 2, backRadius * 2, 90, 90);
            backPath.CloseFigure();
            helpBack.Region = new Region(backPath);
            helpBack.Click += (s, e) => ToggleInlineHelp(false);
            helpToolbar.Controls.Add(_inlineHelpSearch, 0, 0);
            helpToolbar.Controls.Add(helpBack, 1, 0);
            layout.Controls.Add(helpToolbar, 0, 0);
            var split = new SplitContainer
            {
                Dock = DockStyle.Fill,
                Orientation = Orientation.Vertical,
                SplitterDistance = 100,
                SplitterWidth = Dpi(6),
                BackColor = UiSurface,
                BorderStyle = BorderStyle.None,
                FixedPanel = FixedPanel.Panel1,
                Margin = Padding.Empty
            };
            var topicsPane = new BufferedTableLayoutPanel
            {
                Dock = DockStyle.Fill,
                ColumnCount = 1,
                RowCount = 2,
                BackColor = UiPanel,
                Padding = new Padding(0, 0, Dpi(4), 0),
                Margin = Padding.Empty
            };
            topicsPane.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100f));
            topicsPane.RowStyles.Add(new RowStyle(SizeType.Absolute, Dpi(30)));
            topicsPane.RowStyles.Add(new RowStyle(SizeType.Percent, 100f));
            var topicsHeading = new Label
            {
                Text = HelivantaUserSettings.Current.Language == "en" ? "  HELP LIBRARY  ·  12 TOPICS" : "  СПРАВОЧНИК  ·  12 ТЕМ",
                Dock = DockStyle.Fill,
                BackColor = UiHeader,
                ForeColor = UiMuted,
                Font = new Font("Segoe UI Semibold", 8f, FontStyle.Bold),
                TextAlign = ContentAlignment.MiddleLeft,
                Margin = new Padding(0, 0, 0, Dpi(4)),
                Padding = Padding.Empty
            };
            _inlineHelpTopicHeading = topicsHeading;
            _inlineHelpSections = new ListBox
            {
                Dock = DockStyle.Fill,
                IntegralHeight = false,
                DrawMode = DrawMode.OwnerDrawFixed,
                ItemHeight = Dpi(35),
                BackColor = UiPanel,
                ForeColor = UiText,
                BorderStyle = BorderStyle.None,
                Font = new Font("Segoe UI", 9f),
                HorizontalScrollbar = false,
                Margin = Padding.Empty,
                Padding = Padding.Empty,
                SelectionMode = SelectionMode.One
            };
            _inlineHelpSections.DrawItem += DrawInlineHelpTopic;
            _inlineHelpSections.SelectedIndexChanged += (s, e) => _inlineHelpSections.Invalidate();
            topicsPane.Controls.Add(topicsHeading, 0, 0);
            topicsPane.Controls.Add(_inlineHelpSections, 0, 1);
            split.Panel1.Controls.Add(topicsPane);
            split.SizeChanged += (s, e) => AdjustInlineHelpSplitter(split);
            // The help article is rendered by one managed, double-buffered surface instead of
            // a native EDIT HWND. The previous ReadOnly TextBox continued to shimmer inside the
            // form's composited HWND tree even when its Text was only assigned on actual changes.
            // This viewer owns wrapping/scrolling and paints the complete article in one buffer.
            var articleView = new BufferedTableLayoutPanel
            {
                Dock = DockStyle.Fill,
                ColumnCount = 1,
                RowCount = 2,
                BackColor = UiPanel,
                Margin = Padding.Empty,
                Padding = Padding.Empty
            };
            articleView.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100f));
            articleView.RowStyles.Add(new RowStyle(SizeType.Absolute, Dpi(34)));
            articleView.RowStyles.Add(new RowStyle(SizeType.Percent, 100f));
            var articleHeading = new Panel
            {
                Dock = DockStyle.Fill,
                BackColor = UiHeader,
                Margin = new Padding(0, 0, 0, Dpi(5)),
                Padding = Padding.Empty
            };
            articleHeading.Paint += (s, e) =>
            {
                using (var brush = new SolidBrush(UiHelpAmber))
                    e.Graphics.FillRectangle(brush, 0, 0, Math.Max(1, Dpi(3)), articleHeading.Height);
            };
            _inlineHelpArticleTitle = new Label
            {
                Dock = DockStyle.Fill,
                Text = "Выберите раздел инструкции",
                AutoEllipsis = true,
                BackColor = Color.Transparent,
                ForeColor = UiText,
                Font = new Font("Segoe UI Semibold", 10.5f, FontStyle.Bold),
                TextAlign = ContentAlignment.MiddleLeft,
                Padding = new Padding(Dpi(11), 0, Dpi(8), 0),
                Margin = Padding.Empty
            };
            articleHeading.Controls.Add(_inlineHelpArticleTitle);
            _inlineHelpArticle = new BufferedHelpArticleViewer(UiPanel, UiText, new Font("Segoe UI", 10f))
            {
                Dock = DockStyle.Fill,
                Margin = Padding.Empty,
                AccessibleName = "Текст инструкции",
                AccessibleDescription = "Прокручиваемый текст выбранного раздела. Контекстное меню копирует статью целиком."
            };
            articleView.Controls.Add(articleHeading, 0, 0);
            articleView.Controls.Add(_inlineHelpArticle, 0, 1);
            split.Panel2.Controls.Add(articleView);
            layout.Controls.Add(split, 0, 1);
            _inlineHelpPanel.Controls.Add(layout);
            root.Controls.Add(_inlineHelpPanel, 0, 1);
            root.SetCellPosition(_inlineHelpPanel, new TableLayoutPanelCellPosition(0, 1));

            _inlineHelpSections.SelectedIndexChanged += (s, e) =>
            {
                if (!_filteringInlineHelp) ShowInlineHelpArticle();
            };
            _inlineHelpSearch.TextChanged += (s, e) => FilterInlineHelpTopics();
            FilterInlineHelpTopics();
            _inlineHelpRenderedLanguage = HelivantaUserSettings.Current.Language ?? "ru";
        }

        private void RefreshInlineHelpLocalization()
        {
            if (_inlineHelpPanel == null || _inlineHelpPanel.IsDisposed) return;
            string currentLanguage = HelivantaUserSettings.Current.Language ?? "ru";
            bool languageChanged = !string.Equals(_inlineHelpRenderedLanguage, currentLanguage, StringComparison.OrdinalIgnoreCase);
            bool en = HelivantaInlineHelpLocalization.IsEnglish;
            // The search is performed against the visible localized titles and article body. A
            // query from the previous language must not cause the library to look empty.
            if (languageChanged && _inlineHelpSearch != null) _inlineHelpSearch.Clear();
            if (_inlineHelpSearch != null)
                _inlineHelpSearch.PlaceholderText = en
                    ? "Search help: taper, chamfers, size, error…"
                    : "Поиск по инструкции: конус, фаски, размер, ошибка…";
            if (_inlineHelpTopicHeading != null)
                _inlineHelpTopicHeading.Text = en ? "  HELP LIBRARY  ·  12 TOPICS" : "  СПРАВОЧНИК  ·  12 ТЕМ";
            if (_inlineHelpBackButton != null)
                _inlineHelpBackButton.Text = en ? "← Back" : "← Назад";
            if (_inlineHelpArticle != null) _inlineHelpArticle.RefreshLocalization();
            _displayedInlineHelpTopic = string.Empty;
            _displayedInlineHelpText = string.Empty;
            FilterInlineHelpTopics();
            _inlineHelpRenderedLanguage = currentLanguage;
            if (_inlineHelpArticleTitle != null) _inlineHelpArticleTitle.AccessibleName = en ? "Help article title" : "Заголовок статьи инструкции";
            if (_inlineHelpArticle != null)
            {
                _inlineHelpArticle.AccessibleName = en ? "Help article text" : "Текст инструкции";
                _inlineHelpArticle.AccessibleDescription = en
                    ? "Scrollable text for the selected topic. The context menu copies the full article."
                    : "Прокручиваемый текст выбранного раздела. Контекстное меню копирует статью целиком.";
            }
        }

        private void AdjustInlineHelpSplitter(SplitContainer split)
        {
            if (split == null || split.IsDisposed || split.Width <= 0) return;
            int minLeft = Dpi(188);
            int minRight = Dpi(250);
            int maxLeft = split.ClientSize.Width - minRight - split.SplitterWidth;
            if (maxLeft < minLeft) return;
            // Apply panel minimums only after the split control has its real laid-out size;
            // assigning them in the constructor can fail against WinForms' temporary size.
            if (split.Panel1MinSize != minLeft) split.Panel1MinSize = minLeft;
            if (split.Panel2MinSize != minRight) split.Panel2MinSize = minRight;
            int target = Math.Max(minLeft, Math.Min(Dpi(232), maxLeft));
            if (split.SplitterDistance != target)
            {
                try { split.SplitterDistance = target; }
                catch (ArgumentOutOfRangeException) { /* Wait for the next settled layout pass. */ }
            }
        }

        private void DrawInlineHelpTopic(object sender, DrawItemEventArgs e)
        {
            if (e.Index < 0 || e.Index >= _inlineHelpSections.Items.Count) return;
            ListBox list = (ListBox)sender;
            bool selected = (e.State & DrawItemState.Selected) == DrawItemState.Selected;
            Rectangle bounds = e.Bounds;
            Color background = selected ? Color.FromArgb(78, 70, 54) : UiPanel;
            using (var brush = new SolidBrush(background)) e.Graphics.FillRectangle(brush, bounds);
            if (selected)
            {
                using (var brush = new SolidBrush(UiHelpAmber))
                    e.Graphics.FillRectangle(brush, bounds.Left, bounds.Top + 3, Math.Max(2, Dpi(3)), Math.Max(1, bounds.Height - 6));
            }

            string title = Convert.ToString(list.Items[e.Index]) ?? string.Empty;
            string glyph = GetInlineHelpGlyph(HelivantaInlineHelpLocalization.SourceTitle(title));
            int glyphWidth = Dpi(30);
            Color glyphColor = selected ? UiHelpAmber : UiMuted;
            using (var glyphFont = new Font("Segoe UI Symbol", 12f, FontStyle.Regular, GraphicsUnit.Point))
            {
                var glyphRect = new Rectangle(bounds.Left + Dpi(8), bounds.Top, glyphWidth, bounds.Height);
                TextRenderer.DrawText(e.Graphics, glyph, glyphFont, glyphRect, glyphColor,
                    TextFormatFlags.HorizontalCenter | TextFormatFlags.VerticalCenter | TextFormatFlags.NoPrefix | TextFormatFlags.EndEllipsis);
            }

            Color textColor = selected ? Color.FromArgb(255, 239, 205) : UiText;
            var textRect = new Rectangle(bounds.Left + Dpi(39), bounds.Top + Dpi(1),
                Math.Max(1, bounds.Width - Dpi(44)), Math.Max(1, bounds.Height - Dpi(2)));
            TextRenderer.DrawText(e.Graphics, title, list.Font, textRect, textColor,
                TextFormatFlags.Left | TextFormatFlags.VerticalCenter | TextFormatFlags.EndEllipsis | TextFormatFlags.NoPrefix);
            if (e.Index < list.Items.Count - 1)
            {
                using (var pen = new Pen(Color.FromArgb(65, UiBorder), 1f))
                    e.Graphics.DrawLine(pen, bounds.Left + Dpi(8), bounds.Bottom - 1, bounds.Right - Dpi(5), bounds.Bottom - 1);
            }
            if ((e.State & DrawItemState.Focus) == DrawItemState.Focus)
                e.DrawFocusRectangle();
        }

        private static string GetInlineHelpGlyph(string title)
        {
            if (title.StartsWith("Быстрый", StringComparison.Ordinal)) return "✦";
            if (title.StartsWith("Выбор", StringComparison.Ordinal)) return "⌖";
            if (title.StartsWith("Цилиндрическая", StringComparison.Ordinal)) return "◉";
            if (title.StartsWith("Коническая", StringComparison.Ordinal)) return "◢";
            if (title.StartsWith("Типоразмеры", StringComparison.Ordinal)) return "⌀";
            if (title.StartsWith("Размер", StringComparison.Ordinal)) return "↔";
            if (title.StartsWith("Длина", StringComparison.Ordinal)) return "↕";
            if (title.StartsWith("Фаски", StringComparison.Ordinal)) return "◇";
            if (title.StartsWith("Предварительный", StringComparison.Ordinal)) return "◫";
            if (title.StartsWith("Построение", StringComparison.Ordinal)) return "⚙";
            if (title.StartsWith("Редактирование", StringComparison.Ordinal)) return "✎";
            if (title.StartsWith("Диагностика", StringComparison.Ordinal)) return "ⓘ";
            return "•";
        }

        private void PopulateInlineHelpTopics()
        {
            if (_inlineHelpTopics.Count > 0) return;
            _inlineHelpTopics.Add(new KeyValuePair<string, string>("Быстрый старт",
                "1. Откройте деталь IPT в Autodesk Inventor 2027.\n2. Запустите «Создать резьбу».\n3. Выберите круговое ребро; можно выбрать несколько совместимых рёбер.\n4. Настройте тип, направление, стандарт и размер.\n5. Проверьте длину, отступ и доступные параметры, затем нажмите «Построить».\n\nПредпросмотр показывает приближённую форму и не заменяет итоговую проверку физической B-Rep-геометрии."));
            _inlineHelpTopics.Add(new KeyValuePair<string, string>("Выбор рёбер",
                "Выберите круговое ребро, от которого начинается резьба. Повторный щелчок по выбранному ребру снимает выбор. Несовместимые рёбра и зоны, перекрывающие существующую резьбу, отклоняются. Выбранные рёбра можно просмотреть через «Предпросмотр» перед построением."));
            _inlineHelpTopics.Add(new KeyValuePair<string, string>("Цилиндрическая резьба",
                "Выберите наружную или внутреннюю резьбу, правое или левое направление и стандарт ISO, BSW, ANSI, Tr, S или Rd. Выберите типоразмер либо задайте диаметр и шаг вручную. Для диаметра без точного табличного соответствия используется «Пользовательский», а не автоматически увеличенный ближайший размер."));
            _inlineHelpTopics.Add(new KeyValuePair<string, string>("Коническая резьба — режимы",
                "Включите «Коническая резьба — подготовить поверхность автоматически», чтобы показать настройки NPT/JIS Taper и чекбокс «Строго по стандарту конических резьб». В коническом режиме параметры, применимые только к цилиндрическому построению, скрываются; при возврате к цилиндрическому режиму их прежние значения восстанавливаются.\n\nСтрогий режим использует диаметры конуса из таблицы Inventor. Свободный режим сохраняет диаметр исходной цилиндрической поверхности на дальнем конце и рассчитывает диаметр у выбранного ребра по конусности 1:16; такой результат не заявляется как соответствующий стандарту. Свободный режим показывает дополнительное пояснение.\n\nТехнологический зазор для конической резьбы остаётся нулевым. Проверка минимальной толщины стенки может отказать в построении — не обходите это ограничение изменением параметров вне предусмотренных настроек."));
            _inlineHelpTopics.Add(new KeyValuePair<string, string>("Типоразмеры NPT и JIS Taper",
                "Выберите стандарт конуса и типоразмер из списка. Размеры и длина берутся из доступной таблицы Inventor. Если размер отображается, но построение отклонено, это не обязательно ошибка поиска: проверьте сообщение о толщине стенки и выбранную геометрию. Табличное разрешение и успешное создание физической геометрии — разные проверки."));
            _inlineHelpTopics.Add(new KeyValuePair<string, string>("Размер и технологический зазор",
                "«Типоразмер» задаёт стандартные сочетания номинального диаметра и шага. «Тех. зазор» — дополнительный полный радиальный зазор для цилиндрических резьб, а не поле допуска ISO 965. Готовые значения: металл — 0 мм, смола — 0,10 мм, SLS — 0,15 мм, FDM — 0,30 мм; «Другое» позволяет ввести значение вручную. В коническом режиме зазор равен нулю и цилиндрическая настройка скрыта."));
            _inlineHelpTopics.Add(new KeyValuePair<string, string>("Длина, отступ и сбег",
                "«Длина резьбы» задаёт осевую длину. При включённом «На всю длину поверхности» длина определяется поверхностью. «Отступ от ребра» задаёт расстояние до начала рабочей зоны. «Длина сбега, шагов» задаёт постепенное затухание профиля; на короткой поверхности фактическая длина может быть ограничена защитной проверкой."));
            _inlineHelpTopics.Add(new KeyValuePair<string, string>("Фаски и форма профиля",
                "Фаски можно включать и настраивать в поддерживаемых режимах; если Inventor отклоняет построение фаски, повторите операцию без фаски или уменьшите её длину. В коническом режиме доступны только те элементы, которые поддерживает текущий путь построения; функции, относящиеся только к цилиндрической резьбе, скрываются. Скругление формы зуба — цилиндрическая функция и в коническом режиме не отображается."));
            _inlineHelpTopics.Add(new KeyValuePair<string, string>("Предварительный просмотр",
                "Предпросмотр строит временную приближённую сетку и контуры. Он не создаёт постоянных операций и не изменяет дерево модели. После изменения параметров включите его повторно. В цилиндрическом режиме размерный профиль и основные параметры показаны рядом; в коническом режиме боковой вид конуса расположен сверху слева, вертикальная таблица параметров — справа, а профиль резьбы занимает оставшуюся область. Сетка схематична и не гарантирует точную форму всех боковых поверхностей, скруглений, фасок или окончательного сбега."));
            _inlineHelpTopics.Add(new KeyValuePair<string, string>("Построение, отмена и сброс",
                "«Построить» создаёт физическую геометрию. Дождитесь завершения операции. «Отмена» отменяет последнее построение Helivanta в текущей сессии; команды Ctrl+Z/Ctrl+Y Inventor также синхронизируются с защитой занятых зон. «Сброс» снимает неподтверждённый выбор и возвращает параметры по умолчанию. «Выход» закрывает диалог, уже созданная геометрия остаётся в документе."));
            _inlineHelpTopics.Add(new KeyValuePair<string, string>("Редактирование и преобразование",
                "Для изменения резьбы Helivanta выберите папку «Резьба — …» в дереве модели, объект внутри неё или команду «Изменить резьбу». Параметры загружаются из сохранённых метаданных. После успешной правки группа сохраняет прежний идентификатор; другие группы не заменяются. Если ниже в истории есть зависимые операции, появится предупреждение. Перед редактированием или преобразованием штатной цилиндрической резьбы Inventor сохраните копию IPT. Конические/неизвестные профили штатной косметической резьбы пока не преобразуются этим конвейером. Если откат после ошибки не подтверждён, не сохраняйте документ."));
            _inlineHelpTopics.Add(new KeyValuePair<string, string>("Диагностика и журналы",
                "Секция «Цель и состояние» показывает этап операции, результат, ключевые параметры и предупреждения; в английском интерфейсе локализуются также динамические сообщения начала/завершения правки и детали параметров. Полные журналы находятся в %LOCALAPPDATA%\\Helivanta\\Logs. Активный лог и архивы ограничены примерно 1 МБ каждый; для каждого лога сохраняется до четырёх архивов, архивы старше 14 дней удаляются.\n\nЕсли операция не создала результат, проверьте выбранную поверхность, длину, фаски и сбег. Не обходите предупреждения о недостаточной толщине стенки конической резьбы. При ошибке геометрии не сохраняйте файл, если восстановление исходной модели не подтверждено. Для сложного случая передайте разработчику журнал из папки Logs и точные шаги воспроизведения."));
            _inlineHelpTopics.Add(new KeyValuePair<string, string>("Настройки, язык и предупреждения",
                "В настройках можно выбрать тему Dark/Light, акцент Amber/Blue/Gray и язык RU/EN. Выбранные параметры сохраняются в профиле текущего пользователя; при смене языка обновляются подписи команд и подсказки ленты Inventor. Сообщения «Цель и состояние» описывают начало, завершение или отмену операции. Если предупреждение сообщает «Модель не изменена», не обходите защитные ограничения: проверьте указанную причину и выберите безопасную геометрию. Числовые значения в предупреждениях относятся к текущей детали и параметрам — это не универсальные пределы стандарта."));
        }

        private void FilterInlineHelpTopics()
        {
            if (_inlineHelpSections == null) return;
            string query = (_inlineHelpSearch == null ? string.Empty : _inlineHelpSearch.Text).Trim();
            string oldTitle = _inlineHelpSections.SelectedItem as string;
            var matches = _inlineHelpTopics
                .Where(topic => query.Length == 0 ||
                    HelivantaInlineHelpLocalization.DisplayTitle(topic.Key).IndexOf(query, StringComparison.CurrentCultureIgnoreCase) >= 0 ||
                    HelivantaInlineHelpLocalization.DisplayBody(topic.Key, topic.Value).IndexOf(query, StringComparison.CurrentCultureIgnoreCase) >= 0)
                .Select(topic => HelivantaInlineHelpLocalization.DisplayTitle(topic.Key))
                .ToList();

            // Avoid clearing/rebuilding the ListBox for keystrokes that do not change its result set.
            bool sameItems = _inlineHelpSections.Items.Count == matches.Count;
            if (sameItems)
            {
                for (int i = 0; i < matches.Count; i++)
                {
                    if (!string.Equals(_inlineHelpSections.Items[i] as string, matches[i], StringComparison.Ordinal))
                    {
                        sameItems = false;
                        break;
                    }
                }
            }
            if (sameItems)
            {
                if (matches.Count == 0)
                    SetInlineHelpArticle("Ничего не найдено", "Попробуйте другой запрос.");
                else if (_inlineHelpSections.SelectedIndex < 0)
                    _inlineHelpSections.SelectedIndex = 0;
                else
                    ShowInlineHelpArticle(); // No-op when the displayed topic/text are already current.
                return;
            }

            _filteringInlineHelp = true;
            _inlineHelpSections.BeginUpdate();
            try
            {
                _inlineHelpSections.Items.Clear();
                foreach (string title in matches)
                    _inlineHelpSections.Items.Add(title);
            }
            finally
            {
                _inlineHelpSections.EndUpdate();
                _filteringInlineHelp = false;
            }

            int matchIndex = oldTitle == null ? -1 : _inlineHelpSections.Items.IndexOf(oldTitle);
            if (matchIndex >= 0)
                _inlineHelpSections.SelectedIndex = matchIndex;
            else if (_inlineHelpSections.Items.Count > 0)
                _inlineHelpSections.SelectedIndex = 0;
            else
                SetInlineHelpArticle("Ничего не найдено", "Попробуйте другой запрос.");
        }

        private void SetInlineHelpArticle(string title, string body)
        {
            if (_inlineHelpArticleTitle == null || _inlineHelpArticle == null) return;
            title = title ?? string.Empty;
            body = body ?? string.Empty;
            string sourceTitle = HelivantaInlineHelpLocalization.SourceTitle(title);
            string displayTitle = HelivantaInlineHelpLocalization.DisplayTitle(sourceTitle);
            string displayBody = HelivantaInlineHelpLocalization.DisplayBody(sourceTitle, body);
            bool titleChanged = !string.Equals(_displayedInlineHelpTopic, displayTitle, StringComparison.Ordinal);
            bool bodyChanged = !string.Equals(_displayedInlineHelpText, displayBody, StringComparison.Ordinal);
            if (!titleChanged && !bodyChanged) return;

            _displayedInlineHelpTopic = displayTitle;
            _displayedInlineHelpText = displayBody;
            if (titleChanged) _inlineHelpArticleTitle.Text = displayTitle;
            if (bodyChanged)
            {
                _inlineHelpArticle.BodyText = displayBody;
                // Do not call ScrollToCaret or apply selection formatting; assigning a new
                // topic naturally starts at the beginning, while unchanged topics never repaint.
            }
        }

        private void ShowInlineHelpArticle()
        {
            if (_inlineHelpSections == null || _inlineHelpArticle == null) return;
            string selected = _inlineHelpSections.SelectedItem as string;
            if (string.IsNullOrEmpty(selected))
            {
                SetInlineHelpArticle("Выберите раздел инструкции", "Выберите тему в списке слева.");
                return;
            }
            string sourceTitle = HelivantaInlineHelpLocalization.SourceTitle(selected);
            var topic = _inlineHelpTopics.FirstOrDefault(x => string.Equals(x.Key, sourceTitle, StringComparison.Ordinal));
            if (topic.Key == null)
            {
                SetInlineHelpArticle("Раздел не найден", "Выберите другую тему инструкции.");
                return;
            }
            SetInlineHelpArticle(topic.Key, topic.Value ?? string.Empty);
        }

        private Button MakeHelpButton()
        {
            var b = new RoundedIconButton(ButtonGlyph.Help, false)
            {
                Text = string.Empty,
                Size = new Size(32, 32),
                Margin = new Padding(2, 0, 0, 0),
                Font = new Font("Segoe UI", 9f, FontStyle.Regular),
                AccessibleName = "Инструкция"
            };
            var tip = new ToolTip();
            tip.SetToolTip(b, HelivantaLocalization.Translate("Инструкция по использованию"));
            return b;
        }

        private void SetNumericLocked(NumericUpDown control, bool locked)
        {
            if (control == null) return;
            if (control.Tag == null) control.Tag = control.Increment;
            control.ReadOnly = locked;
            control.InterceptArrowKeys = !locked;
            control.TabStop = !locked;
            control.Increment = locked ? 0m : (decimal)control.Tag;
            control.BackColor = UiField;
            control.ForeColor = UiText;
            if (ReferenceEquals(control, nLen) && _lengthSlider != null)
                _lengthSlider.RefreshBoundState();
        }

        private ComboBox Combo(int width)
        {
            return new ThemedComboBox
            {
                DropDownStyle = ComboBoxStyle.DropDownList,
                Width = width,
                Height = 23,
                MaxDropDownItems = 16,
                BackColor = UiField,
                ForeColor = UiText
            };
        }

        private NumericUpDown Num(decimal min, decimal max, int dec, decimal inc, decimal val)
        {
            return new ThemedNumericUpDown
            {
                Minimum = min,
                Maximum = max,
                DecimalPlaces = dec,
                Increment = inc,
                Value = val,
                Width = 84,
                Height = 24,
                BackColor = UiField,
                ForeColor = UiText
            };
        }

        private void ReflowInformationActions()
        {
            if (_selectionActionPanel == null || _selectionActionPanel.IsDisposed) return;

            _selectionActionPanel.SuspendLayout();
            try
            {
                int column = 0;
                foreach (Control control in _selectionActionPanel.Controls)
                {
                    if (control == null || control.IsDisposed || !control.Visible) continue;
                    _selectionActionPanel.SetCellPosition(control, new TableLayoutPanelCellPosition(column++, 0));
                }

                int visibleCount = Math.Max(1, column);
                for (int i = 0; i < _selectionActionPanel.ColumnStyles.Count; i++)
                {
                    _selectionActionPanel.ColumnStyles[i].SizeType = SizeType.Percent;
                    _selectionActionPanel.ColumnStyles[i].Width = i < visibleCount ? 100f / visibleCount : 0f;
                }
            }
            finally
            {
                _selectionActionPanel.ResumeLayout(true);
            }
        }

        private void RefreshInformationLayout()
        {
            if (IsDisposed || informationSection == null || bodyStack == null || _layouting) return;
            // Text and visibility changes must update the message content after the initial
            // presentation too. The viewport is fixed-height, so this pass cannot resize the
            // outer form or move the independent Actions section.
            RefreshInformationLayoutCore();
        }

        private void RefreshInformationLayoutCore()
        {
            if (IsDisposed || informationSection == null || bodyStack == null) return;
            int w = Math.Max(280, bodyViewport != null ? bodyViewport.ClientSize.Width - 20 : 430);
            FitInfoBox(lTarget, w);
            FitInfoBox(lInfo, w);
            FitInfoBox(lStatus, w);
            FitInfoBox(lWarn, w);

            // The viewport height is intentionally invariant: only its inner content grows
            // and the Panel's own scrollbar exposes overflow. Never derive viewport/form height
            // from message text, visibility, or button positions.
            if (_informationMessagesFlow != null && _informationMessagesViewport != null)
            {
                int viewportHeight = Math.Max(120, (int)Math.Round(136 * Math.Max(1f, DeviceDpi / 96f)));
                _informationMessagesViewport.MinimumSize = new Size(0, viewportHeight);
                _informationMessagesViewport.MaximumSize = new Size(0, viewportHeight);
                _informationMessagesViewport.Height = viewportHeight;
                int messageWidth = Math.Max(180, _informationMessagesViewport.ClientSize.Width -
                    (_informationMessagesViewport.VerticalScroll.Visible ? SystemInformation.VerticalScrollBarWidth : 0) - 2);
                // Do not reset Location here: AutoScroll adjusts the child position while
                // scrolling. Forcing Point.Empty on every refresh destroys the scroll offset.
                _informationMessagesFlow.Width = messageWidth;
                foreach (Control message in _informationMessagesFlow.Controls)
                {
                    if (message is TextBox textBox) FitInfoBox(textBox, messageWidth);
                    else message.Width = messageWidth;
                }
                _informationMessagesFlow.PerformLayout();
                _informationMessagesViewport.AutoScrollMinSize = new Size(0, _informationMessagesFlow.Height + 2);
            }

            if (informationSection.Controls.Count > 0 && informationSection.Controls[0] is TableLayoutPanel infoGrid)
                infoGrid.PerformLayout();
            informationSection.PerformLayout();
            bodyStack.PerformLayout();
            if (bodyViewport != null) bodyViewport.PerformLayout();
        }

        private static void FitInfoBox(TextBox box, int width)
        {
            if (box == null || box.IsDisposed) return;
            width = Math.Max(120, width);
            // Width is refreshed only during initial sizing, a user resize or DPI change.
            // The containing Information section sizes itself to visible content with a safe cap.
            if (box.Width != width) box.Width = width;
            if (box is SelectableInfoTextBox infoBox)
                infoBox.RefreshOverflowScrollBar();
        }

        private void ResizeSectionWidths()
        {
            // Called only by the initial layout, user-requested vertical resize, and DPI path.
            if (bodyViewport == null || bodyStack == null) return;
            int w = Math.Max(300, bodyViewport.ClientSize.Width - 2);
            if (w == _lastSectionWidth) return;
            _lastSectionWidth = w;
            bodyStack.Width = w;

            foreach (Control c in bodyStack.Controls)
            {
                if (c is TableLayoutPanel sec)
                {
                    sec.Width = w;
                    foreach (Control child in sec.Controls)
                    {
                        if (child is Panel p && p.Controls.Count > 0)
                        {
                            // header already fills its row
                        }
                        if (child is TableLayoutPanel grid && Equals(grid.Tag, "section-grid"))
                        {
                            grid.Width = Math.Max(280, w - 2);
                            if (ReferenceEquals(sec, informationSection))
                            {
                                // Information is a single-column fixed-height viewport/footer layout.
                                grid.ColumnStyles[0].SizeType = SizeType.Percent;
                                grid.ColumnStyles[0].Width = 100f;
                            }
                            else
                            {
                                int labelWidth = Math.Min(170, Math.Max(126, (int)(w * 0.35)));
                                grid.ColumnStyles[0].SizeType = SizeType.Absolute;
                                grid.ColumnStyles[0].Width = labelWidth;
                            }
                        }
                    }
                }
            }

            // Message controls grow to their full text height inside the one shared viewport;
            // the fixed Information section and its footer keep the parent form geometry stable.
            int maxLabel = Math.Max(280, w - 18);
            if (lTarget != null) lTarget.MaximumSize = new Size(maxLabel, 0);
            if (lInfo != null) lInfo.MaximumSize = new Size(maxLabel, 0);
            if (lStatus != null) lStatus.MaximumSize = new Size(maxLabel, 0);
            if (lWarn != null) lWarn.MaximumSize = new Size(maxLabel, 0);
            if (_previewLegend != null) _previewLegend.MaximumSize = new Size(maxLabel, 0);
            FitInfoBox(lTarget, maxLabel);
            FitInfoBox(lInfo, maxLabel);
            FitInfoBox(lStatus, maxLabel);
            FitInfoBox(lWarn, maxLabel);
            bodyStack.PerformLayout();
            if (root != null) root.PerformLayout();
        }

        private Rectangle GetHostWorkingArea()
        {
            // Place the dialog on the same monitor as Inventor, then anchor it to that
            // monitor's right edge. Screen.FromControl(this) used the primary monitor
            // while the invisible form still had its default location at (0,0).
            try
            {
                var mainFrame = new IntPtr(_app.MainFrameHWND);
                if (mainFrame != IntPtr.Zero)
                    return Screen.FromHandle(mainFrame).WorkingArea;
            }
            catch { }

            try
            {
                if (IsHandleCreated) return Screen.FromHandle(Handle).WorkingArea;
            }
            catch { }

            return Screen.PrimaryScreen != null
                ? Screen.PrimaryScreen.WorkingArea
                : new Rectangle(0, 0, 1280, 800);
        }

        private void ForceRightAlignment()
        {
            try
            {
                if (!IsHandleCreated) return;
                IntPtr mainFrame = IntPtr.Zero;
                try { mainFrame = new IntPtr(_app.MainFrameHWND); } catch { }
                if (NativeWindowPositioning.MoveToRight(Handle, mainFrame, 18, 8)) return;

                // Last-resort WinForms fallback if native monitor/window APIs are unavailable.
                Rectangle wa = GetHostWorkingArea();
                int edgeMargin = 8;
                int rightMargin = 18;
                int x = Math.Max(wa.Left + edgeMargin, wa.Right - Width - rightMargin);
                int y = wa.Top + Math.Min(20, Math.Max(edgeMargin, (wa.Height - Height) / 5));
                y = Math.Max(wa.Top + edgeMargin, Math.Min(y, wa.Bottom - Height - edgeMargin));
                Location = new Point(x, y);
            }
            catch { }
        }

        private void ApplyResponsiveLayout(bool allowAfterInitialLayout = false)
        {
            if (_layouting || IsDisposed) return;
            // All direct calls from parameter/button/selection events become no-ops once
            // the window is settled. Only initial presentation and a real DPI transition
            // may compute a new outer size.
            if (_initialLayoutSettled && !allowAfterInitialLayout) return;
            _layouting = true;
            try
            {
                var wa = GetHostWorkingArea();
                float scale = Math.Max(1f, DeviceDpi / 96f);
                int desiredW = Math.Min((int)(LogicalWidth * scale), wa.Width - 20);
                desiredW = Math.Max((int)(430 * scale), desiredW);

                ClientSize = new Size(desiredW, Math.Max(360, Height));
                ResizeSectionWidths();
                RefreshInformationLayoutCore();
                bodyStack.PerformLayout();
                footerButtons.PerformLayout();
                root.PerformLayout();

                int headerH = UseNewLayout ? 53 : 47;
                int footerH = Math.Max(36, UseNewLayout ? footerButtons.Height + footerButtons.Margin.Vertical : footerButtons.PreferredSize.Height + 2);
                int contentH = bodyStack.GetPreferredSize(new Size(bodyViewport.ClientSize.Width, 0)).Height;
                int desiredH = (int)(headerH * scale) + contentH + footerH + (int)(15 * scale);
                // Expand to the available display height instead of capping the form at
                // 78% of the screen (which forced scrolling despite unused vertical space).
                // Account for the non-client frame because ClientSize is used for sizing.
                int frameHeight = Math.Max(0, Height - ClientSize.Height);
                int screenMargin = Math.Max(ScreenEdgeMargin, (int)(ScreenEdgeMargin * scale));
                int maxH = Math.Max(360, wa.Height - frameHeight - 2 * screenMargin);
                int minH = Math.Min(maxH, (int)(470 * scale));
                int finalH = Math.Min(Math.Max(desiredH, minH), maxH);

                ClientSize = new Size(desiredW, finalH);
                ResizeSectionWidths();
                RefreshInformationLayoutCore();
                bodyStack.PerformLayout();
                root.PerformLayout();

                // Width/scrollbar changes can alter wrapping; perform one final height
                // pass using the settled client width so the dialog does not clip the
                // top Information row or leave stale blank space below the sections.
                int settledContentH = bodyStack.GetPreferredSize(new Size(bodyViewport.ClientSize.Width, 0)).Height;
                int settledDesiredH = (int)(headerH * scale) + settledContentH + footerH + (int)(15 * scale);
                int settledH = Math.Min(Math.Max(settledDesiredH, minH), maxH);
                if (Math.Abs(settledH - ClientSize.Height) > 2)
                {
                    ClientSize = new Size(desiredW, settledH);
                    ResizeSectionWidths();
                    RefreshInformationLayoutCore();
                    bodyStack.PerformLayout();
                    root.PerformLayout();
                }

                ForceRightAlignment();
            }
            finally
            {
                _layouting = false;
            }
            RefreshVerticalLayout();
        }

        /// <summary>Switches this dialog from edge-picking/build mode into editing one persisted Helivanta thread.</summary>
        internal bool TryBeginEdit(object selectedObject, out string error)
        {
            error = null;
            string id;
            if (!ThreadMetadataStore.TryGetThreadIdFromSelection(_app == null ? null : _app.ActiveDocument as Inventor.PartDocument,
                                                                  selectedObject, out id, out error))
                return false;

            Inventor.PartDocument doc = _app == null ? null : _app.ActiveDocument as Inventor.PartDocument;
            ThreadMetadataGroup group;
            if (!ThreadEditService.TryGetEditableGroup(doc, id, out group, out error)) return false;

            try
            {
                ClearThreadPreview();
                try { _sel.Stop(); } catch { }
                try { _sel.Clear(false); } catch { }
                Target = null;
                _editMode = true;
                _editThreadId = group.Record.ThreadId;
                _editNominalDiaMm = group.Record.Parameters.NominalDiaMm;
                cbDia.Enabled = false; // Existing thread nominal diameter is immutable during edit.

                LoadEditParameters(group.Record.Parameters);
                // A persisted tapered group cannot be switched to the cylindrical feature family in-place.
                // That transition has different host geometry and must be handled as a new thread.
                if (chTapered != null) chTapered.Enabled = !group.Record.Parameters.Tapered;
                bResume.Visible = false;
                if (bPreview != null) bPreview.Visible = false;
                bBuild.Text = HelivantaLocalization.Translate("Обновить");
                bBuild.AccessibleName = "Применить изменения к выбранной резьбе";
                bCreateNew.Visible = true;
                bEditExisting.Visible = false;
                // Reflow explicitly after switching modes. VisibleChanged can run while the
                // modeless form or its parent layout is suspended/hidden, in which case
                // WinForms reports effective visibility inconsistently and leaves the new
                // action sharing a cell with another button. Recompute after both flags settle.
                ReflowInformationActions();
                RefreshButtonToolTips();
                Text = HelivantaLocalization.Translate("Helivanta — редактирование резьбы");
                rbExt.Enabled = false;
                rbInt.Enabled = false;
                lTarget.Text = "Редактируется существующая резьба · ID " + _editThreadId.Substring(0, Math.Min(8, _editThreadId.Length));
                lStatus.ForeColor = UiSuccess;
                lStatus.Text = "Параметры загружены из IPT. При применении изменится только эта группа резьбы; исходный ID сохраняется.";
                RefreshBuildZonesFromMetadata();
                SyncPreviewButtonVisibility();
                UpdateUndoButton();
                UpdateInfo();
                ApplyResponsiveLayout();
                return true;
            }
            catch (Exception ex)
            {
                error = "Не удалось открыть параметры выбранной резьбы: " + ex.Message;
                _editMode = false;
                _editThreadId = null;
                _editNominalDiaMm = 0.0;
                cbDia.Enabled = true;
                if (chTapered != null) chTapered.Enabled = true;
                rbExt.Enabled = true;
                rbInt.Enabled = true;
                bBuild.Text = HelivantaLocalization.Translate("Построить");
                bBuild.AccessibleName = "Построить новую резьбу";
                bCreateNew.Visible = false;
                bEditExisting.Visible = true;
                ReflowInformationActions();
                RefreshButtonToolTips();
                Text = HelivantaLocalization.Translate("Helivanta — физическая резьба");
                return false;
            }
        }

        /// <summary>
        /// Reuses the ordinary Helivanta physical-thread dialog for a selected native Inventor
        /// ThreadFeature. Native cosmetic editing is intentionally not offered: Build replaces
        /// the cosmetic operation with physical geometry through ThreadBuilder.
        /// </summary>
        internal bool TryBeginNativeConversion(NativeThreadConversionPlan plan, out string error)
        {
            error = null;
            if (plan == null || plan.Feature == null || plan.InitialTarget == null || plan.Parameters == null)
            {
                error = "Нет корректной штатной резьбы Inventor для преобразования.";
                return false;
            }
            bool continuingSequence = NativeThreadConversionSequencePolicy.CanAcceptNextFeature(
                _nativeConversionMode, _nativeConversionCompleted, _nativeConversionAwaitingNextSelection);
            if (_editMode || (_nativeConversionCompleted && !continuingSequence) ||
                (_nativeConversionMode && !_nativeConversionCompleted))
            {
                error = "Текущее окно не ожидает выбора следующей штатной резьбы. Нажмите «Следующая» после успешного преобразования или откройте новую команду.";
                return false;
            }

            NativeThreadConversionPlan previousPlan = _nativeConversionPlan;
            string previousThreadId = _nativeConversionThreadId;

            try
            {
                ClearThreadPreview();
                try { if (_sel != null) _sel.Stop(); } catch { }
                try { if (_sel != null) _sel.Clear(false); } catch { }
                // Reload persisted Helivanta groups before each conversion step. A failed load
                // must not silently leave an empty/stale overlap inventory and permit a mutation.
                if (!RefreshBuildZonesFromMetadata())
                {
                    error = "Не удалось прочитать сохранённые группы Helivanta для проверки пересечений. Преобразование не начато; исходная ThreadFeature не изменена.";
                    return false;
                }
                Inventor.PartDocument activePart = _app == null ? null : _app.ActiveDocument as Inventor.PartDocument;
                if (activePart == null)
                {
                    error = "Активная деталь недоступна для проверки пересечений. Преобразование не начато.";
                    return false;
                }
                // ThreadBuilder's transient target normally carries this value; normalize it
                // explicitly for the native-conversion path so document identity cannot cause
                // an existing persisted Helivanta zone to be silently skipped.
                plan.InitialTarget.SourceDocument = activePart;
                plan.InitialTarget.SourceDocumentInternalName = activePart.InternalName;
                Target = null;
                _nativeConversionMode = true;
                _nativeConversionCompleted = false;
                _nativeConversionAwaitingNextSelection = false;
                _nativeConversionPlan = plan;
                _nativeConversionThreadId = null;
                _editNominalDiaMm = plan.Parameters.NominalDiaMm;

                // Load the native profile into the same parameter controls used by ordinary
                // Helivanta creation. The target itself is restored only after controls load,
                // avoiding the regular-selection auto-size behavior during form initialization.
                LoadEditParameters(plan.Parameters);
                Target = plan.InitialTarget;
                cbDia.Enabled = false;
                rbExt.Enabled = false;
                rbInt.Enabled = false;
                bResume.Visible = false;
                // Keep the in-dialog escape hatch to ordinary thread creation available
                // while converting a native Inventor cosmetic thread as well.
                bCreateNew.Visible = true;
                bEditExisting.Visible = false;
                ReflowInformationActions();
                bBuild.Text = HelivantaLocalization.Translate("Изменить");
                bBuild.AccessibleName = "Изменить выбранную штатную резьбу Inventor с помощью Helivanta";
                bBuild.AccessibleDescription = "Заменить выбранную косметическую резьбу Inventor реальной физической геометрией Helivanta с применением настроек стандарта, шага, зазора, сбега, скруглений и фасок. При ошибке операция откатывается.";
                bBuild.Enabled = true;
                bPreview.Visible = true;
                Text = HelivantaLocalization.Translate("Helivanta — преобразование резьбы Inventor");
                lTarget.Text = "Штатная резьба Inventor: " + (plan.FeatureName ?? "Резьба Inventor") + ". Настройте физическую резьбу Helivanta и нажмите «Изменить».";
                lStatus.ForeColor = UiMuted;
                lStatus.Text = "Исходная операция пока не изменена. При преобразовании косметическая резьба Inventor будет заменена физической геометрией Helivanta.";
                _lastBuildWarning = "";
                _lastBuildInfo = "Изменение не начато. Настройки применятся после нажатия «Изменить»; при ошибке транзакция будет отменена.";
                RefreshButtonToolTips();
                SyncPreviewButtonVisibility();
                UpdateUndoButton();
                UpdateInfo();
                ApplyResponsiveLayout();
                return true;
            }
            catch (Exception ex)
            {
                error = "Не удалось подготовить обычный диалог Helivanta для преобразования штатной резьбы: " + ex.Message;
                if (continuingSequence)
                {
                    // Keep the already completed conversion session usable if loading the next
                    // feature's parameters fails. The previous conversion remains committed.
                    _nativeConversionMode = true;
                    _nativeConversionCompleted = true;
                    _nativeConversionAwaitingNextSelection = false;
                    _nativeConversionPlan = previousPlan;
                    _nativeConversionThreadId = previousThreadId;
                    Target = null;
                    try { if (previousPlan != null) LoadEditParameters(previousPlan.Parameters); } catch { }
                    cbDia.Enabled = false;
                    rbExt.Enabled = false;
                    rbInt.Enabled = false;
                    bBuild.Text = HelivantaLocalization.Translate("Следующая");
                    bBuild.AccessibleName = "Выбрать следующую штатную резьбу Inventor для преобразования";
                    bBuild.AccessibleDescription = "Предыдущая конвертация сохранена. Выберите следующую штатную операцию «Резьба Inventor».";
                    bBuild.Enabled = true;
                    bPreview.Visible = false;
                    bReset.Enabled = false;
                    lStatus.ForeColor = UiError;
                    lStatus.Text = "Не удалось загрузить следующую резьбу. Предыдущая конвертация сохранена. Нажмите «Следующая», чтобы повторить выбор.";
                    _lastBuildInfo = error;
                    RefreshButtonToolTips();
                    UpdateUndoButton();
                    UpdateInfo();
                    ApplyResponsiveLayout();
                    return false;
                }
                _nativeConversionMode = false;
                _nativeConversionPlan = null;
                _nativeConversionThreadId = null;
                _nativeConversionAwaitingNextSelection = false;
                _editNominalDiaMm = 0.0;
                Target = null;
                cbDia.Enabled = true;
                rbExt.Enabled = true;
                rbInt.Enabled = true;
                bBuild.Text = HelivantaLocalization.Translate("Построить");
                bBuild.AccessibleName = "Построить новую резьбу";
                bCreateNew.Visible = false;
                bEditExisting.Visible = true;
                bPreview.Visible = false;
                ReflowInformationActions();
                RefreshButtonToolTips();
                Text = HelivantaLocalization.Translate("Helivanta — физическая резьба");
                return false;
            }
        }

        /// <summary>Stops edge picking temporarily so the Inventor browser can select an existing Helivanta thread.</summary>
        internal void PauseSelectionForEditPick()
        {
            if (IsDisposed || _closing) return;
            try { ClearThreadPreview(); } catch { }
            try { if (_sel != null) _sel.Stop(); } catch { }
            SyncPreviewButtonVisibility();
        }

        /// <summary>Resumes the current creation selection if the user cancels the edit-pick prompt.</summary>
        internal void ResumeSelectionAfterEditPickCancelled()
        {
            if (_editMode || IsDisposed || _closing) return;
            if (_nativeConversionMode)
            {
                if (_nativeConversionAwaitingNextSelection && _nativeConversionCompleted)
                {
                    _nativeConversionAwaitingNextSelection = false;
                    bBuild.Text = HelivantaLocalization.Translate("Следующая");
                    bBuild.AccessibleName = "Выбрать следующую штатную резьбу Inventor для преобразования";
                    bBuild.Enabled = true;
                    lTarget.Text = "Предыдущая штатная резьба уже преобразована. Для продолжения нажмите «Следующая» и выберите другую штатную операцию «Резьба Inventor».";
                    lStatus.ForeColor = UiMuted;
                    lStatus.Text = "Выбор следующей резьбы отменён. Предыдущие преобразования сохранены.";
                    RefreshButtonToolTips();
                    UpdateUndoButton();
                    UpdateInfo();
                }
                return;
            }
            try
            {
                // Restore the regular target instructions (or the still-active edge summary)
                // after the temporary browser-pick instructions have been shown.
                StartSelection();
                OnSelectionChanged();
                lStatus.ForeColor = UiMuted;
                lStatus.Text = "Выбор резьбы для редактирования отменён. Продолжайте выбирать рёбра для создания.";
            }
            catch { }
        }

        private void RequestEditExistingThread()
        {
            if (_editMode || _nativeConversionMode || IsDisposed || _closing) return;
            PauseSelectionForEditPick();
            lTarget.Text = "Выберите резьбу Helivanta или штатную операцию «Резьба Inventor» в дереве построений.";
            lStatus.ForeColor = UiMuted;
            lStatus.Text = "Ожидаем выбор резьбы Helivanta или операции «Резьба Inventor»…";
            Action handler = EditSelectionRequested;
            if (handler != null)
            {
                try { handler(); }
                catch (Exception ex)
                {
                    ResumeSelectionAfterEditPickCancelled();
                    ShowMessage("Не удалось начать выбор резьбы для редактирования: " + ex.Message);
                }
            }
            else
            {
                ResumeSelectionAfterEditPickCancelled();
                ShowMessage("Выбор резьбы для редактирования недоступен. Запустите команду «Изменить резьбу» на ленте Inventor.");
            }
        }

        /// <summary>
        /// Leaves edit mode without touching the existing model geometry and reuses this dialog
        /// for a fresh edge-selection/build session. Unapplied form changes are explicitly confirmed.
        /// </summary>
        private void SwitchToCreateMode()
        {
            bool fromEdit = _editMode;
            bool fromNativeConversion = _nativeConversionMode;
            if ((!fromEdit && !fromNativeConversion) || IsDisposed || _closing) return;

            // Native cosmetic conversion has its own mode, but it must offer the same
            // in-window route to ordinary edge selection. Leaving before conversion keeps
            // the source ThreadFeature untouched; leaving after a successful conversion
            // preserves that already committed geometry and only ends the conversion sequence.
            string promptText = fromNativeConversion
                ? (_nativeConversionCompleted
                    ? "Завершить выбор штатных резьб Inventor и перейти к созданию новой резьбы? Уже выполненные преобразования сохранятся."
                    : "Отменить текущую подготовку преобразования штатной резьбы Inventor и перейти к созданию новой резьбы? Исходная операция Inventor останется без изменений.")
                : "Выходим из режима редактирования резьб. Существующие резьбы сохранятся, неподтверждённые параметры будут сброшены. Перейти?";
            using (var prompt = new ThemedConfirmDialog(
                "Переход к созданию резьбы", promptText))
            {
                if (prompt.ShowDialog(this) != DialogResult.Yes) return;
            }

            ClearThreadPreview();
            try { if (_sel != null) _sel.Stop(); } catch { }
            try { if (_sel != null) _sel.Clear(false); } catch { }

            _editMode = false;
            _editThreadId = null;
            _nativeConversionMode = false;
            _nativeConversionCompleted = false;
            _nativeConversionAwaitingNextSelection = false;
            _nativeConversionPlan = null;
            _nativeConversionThreadId = null;
            _editNominalDiaMm = 0.0;
            cbDia.Enabled = true;
            if (chTapered != null) chTapered.Enabled = true;
            rbExt.Enabled = true;
            rbInt.Enabled = true;
            bBuild.Text = HelivantaLocalization.Translate("Построить");
            bBuild.AccessibleName = "Построить новую резьбу";
            bCreateNew.Visible = false;
            bEditExisting.Visible = true;
            bPreview.Visible = false;
            bReset.Enabled = true;
            ReflowInformationActions();
            RefreshButtonToolTips();
            Text = HelivantaLocalization.Translate("Helivanta — физическая резьба");
            lTarget.Text = "Выберите на модели круговые рёбра, с которых начинается резьба. Можно выбрать несколько рёбер одного диаметра.";
            lStatus.ForeColor = UiText;
            lStatus.Text = "Режим создания новой резьбы. Выбирайте рёбра в окне модели.";
            _lastBuildInfo = "Готово к построению. После нажатия «Построить» здесь будет показан результат или подробная ошибка Inventor.";
            _lastBuildWarning = "";

            // ResetDialogDefaults clears edit-loaded values, restores creation defaults and starts
            // edge selection again; it does not close/recreate the modeless form.
            ResetDialogDefaults();
            UpdateUndoButton();
            ApplyResponsiveLayout();
            try { Activate(); } catch { }
        }

        private void LoadEditParameters(ThreadParametersSnapshot p)
        {
            if (p == null) throw new InvalidOperationException("Метаданные не содержат сохранённых параметров.");
            if (p.Standard < 0 || p.Standard > 5) throw new InvalidOperationException("Неизвестный стандарт резьбы в метаданных.");

            _loading = true;
            _inchDia = false;
            _inchPitch = false;
            rbMmD.Checked = true;
            rbInD.Checked = false;
            rbMmP.Checked = true;
            rbInP.Checked = false;
            cbStd.SelectedIndex = p.Standard;
            _lastValidStandardIndex = p.Standard;
            rbExt.Checked = p.External;
            rbInt.Checked = !p.External;
            rbR.Checked = p.RightHand;
            rbL.Checked = !p.RightHand;
            chFull.Checked = p.FullLength;
            chRun.Checked = p.RunOut;
            chRound.Checked = p.Round;
            // Legacy SimplifiedRunout metadata is ignored; new edits use smooth run-out.
            chMirror.Checked = p.Mirror;
            if (chSortFolders != null) chSortFolders.Checked = p.SortThreadsIntoFolders;
            chCham.Checked = p.ChamferMode > 0;
            cbCham.SelectedIndex = p.ChamferMode > 0 ? Math.Max(0, Math.Min(2, p.ChamferMode - 1)) : -1;
            cbTolerance.SelectedIndex = string.Equals(p.ToleranceClass, "6H", StringComparison.OrdinalIgnoreCase) ? 1 :
                string.Equals(p.ToleranceClass, "6g", StringComparison.OrdinalIgnoreCase) ? 2 : 0;
            _lastCommittedChamferIndex = cbCham.SelectedIndex;
            _pendingChamferIndex = -1;
            _chamferCommitObserved = false;
            _preserveCommittedChamferUntilDropdownReopened =
                ThreadChamferSelectionPolicy.IsValidIndex(_lastCommittedChamferIndex, cbCham.Items.Count);
            nStarts.Value = ClampDecimal(p.Starts, nStarts.Minimum, nStarts.Maximum);
            nLen.Value = ClampDecimal(p.LengthMm > 0 ? p.LengthMm : 20, nLen.Minimum, nLen.Maximum);
            nOff.Value = ClampDecimal(p.OffsetMm, nOff.Minimum, nOff.Maximum);
            nRun.Value = ClampDecimal(p.RunSteps > 0 ? p.RunSteps : 1, nRun.Minimum, nRun.Maximum);
            nCham.Value = ClampDecimal(p.ChamferMm > 0 ? p.ChamferMm : 1, nCham.Minimum, nCham.Maximum);
            _all.Clear();
            _all.AddRange(ThreadStandards.Sizes((ThreadStandard)p.Standard));
            _loading = false;

            UpdateUnitToggle();
            RebuildLists();
            _loading = true;
            cbDia.Text = FmtDia(p.NominalDiaMm);
            FillPitchItems(p.NominalDiaMm);
            cbPitch.Text = FmtPitch(p.PitchMm);

            int material = ThreadTechnologySelectionPolicy.FindPresetIndex(p.ClearanceMm, 0.0006);
            cbMat.SelectedIndex = material;
            _lastCommittedMaterialIndex = material;
            _pendingMaterialIndex = -1;
            _materialCommitObserved = false;
            _preserveCommittedMaterialUntilDropdownReopened = true;
            nClear.Value = ClampDecimal(p.ClearanceMm, nClear.Minimum, nClear.Maximum);
            SetNumericLocked(nClear, ThreadTechnologySelectionPolicy.IsPresetIndex(material));

            // Restore the tapered definition as well as the ordinary fields. Historically edit
            // mode loaded only cylindrical settings, leaving a persisted tapered group in the UI's
            // previous/default mode. Then DoEditBuild could skip the geometry-confirmation path.
            _taperLengthOverrideNoticeShown = false;
            _lastBuildWarning = string.Empty;
            if (chTapered != null && cbTaperStandard != null && cbTaperDesignation != null)
            {
                if (chTapered.Checked != p.Tapered)
                    chTapered.Checked = p.Tapered; // CheckedChanged applies tapered-mode enable/disable policy.
                else
                    // Reapply only when Checked did not change (e.g. the modeless dialog was reused).
                    ApplyTaperModeUI(p.Tapered);
                if (chTapered.Checked != p.Tapered)
                    throw new InvalidOperationException("Не удалось восстановить сохранённый режим конической резьбы. Правка остановлена без изменения модели.");
                if (chTaperStrictStandard != null)
                    chTaperStrictStandard.Checked = p.TaperGeometryMode == (int)TaperGeometryModeKind.StrictStandard;

                if (p.Tapered)
                {
                    int standardIndex = cbTaperStandard.Items.IndexOf(p.TaperStandard ?? string.Empty);
                    if (standardIndex >= 0) cbTaperStandard.SelectedIndex = standardIndex;
                    else cbTaperStandard.SelectedIndex = -1;

                    // Re-read available table designations for the loaded external/internal mode;
                    // never silently replace an unavailable persisted designation with the first row.
                    RefreshTaperDesignations(false);
                    int designationIndex = cbTaperDesignation.Items.IndexOf(p.TaperDesignation ?? string.Empty);
                    cbTaperDesignation.SelectedIndex = designationIndex;
                    if (designationIndex < 0)
                    {
                        _lastBuildWarning = "Сохранённое обозначение конической резьбы отсутствует в текущей таблице Inventor. Перед правкой выберите действующее обозначение вручную; автоматическая подмена заблокирована.";
                    }
                }
                cbTaperStandard.Enabled = p.Tapered;
                cbTaperDesignation.Enabled = p.Tapered;

                // ApplyTaperModeUI can temporarily clear these values when the mode changes. Restore
                // the exact persisted edit parameters after that UI transition; custom/full length is
                // then handled by MarkTaperLengthAsCustom and the explicit geometry confirmation.
                chFull.Checked = p.FullLength;
                nLen.Value = ClampDecimal(p.LengthMm > 0 ? p.LengthMm : 20, nLen.Minimum, nLen.Maximum);
                nStarts.Value = ClampDecimal(p.Starts, nStarts.Minimum, nStarts.Maximum);
                nClear.Value = p.Tapered ? 0m : ClampDecimal(p.ClearanceMm, nClear.Minimum, nClear.Maximum);
                SetNumericLocked(nLen, p.FullLength);
                SetNumericLocked(nClear, ThreadTechnologySelectionPolicy.IsPresetIndex(material));
            }

            SetNumericLocked(nLen, p.FullLength);
            SetNumericLocked(nRun, !p.RunOut);
            cbCham.Enabled = p.ChamferMode > 0;
            nCham.Enabled = p.ChamferMode > 0;
            cbCham.Visible = false;
            nCham.Visible = p.ChamferMode > 0;
            if (chamferOptions != null) chamferOptions.Visible = p.ChamferMode > 0;
            chMirror.Enabled = p.Standard == (int)ThreadStandard.S;
            _loading = false;

            SyncSizeCombo();
            RefreshMaterialComboVisuals();
            RefreshChamferComboVisuals();
            UpdateUnitToggle();
            UpdateInfo();
        }

        private static decimal ClampDecimal(double value, decimal minimum, decimal maximum)
        {
            if (double.IsNaN(value) || double.IsInfinity(value)) return minimum;
            decimal converted;
            try { converted = (decimal)value; }
            catch { converted = minimum; }
            if (converted < minimum) return minimum;
            if (converted > maximum) return maximum;
            return converted;
        }

        private bool RefreshBuildZonesFromMetadata()
        {
            Inventor.PartDocument doc = _app == null ? null : _app.ActiveDocument as Inventor.PartDocument;
            List<ThreadMetadataGroup> groups;
            string error;
            if (doc == null || !ThreadMetadataStore.TryLoadAllGroups(doc, out groups, out error)) return false;

            _buildZones.Clear();
            _buildSelections.Clear();
            ClearRedoBuildTracking();
            foreach (ThreadMetadataGroup group in groups)
            {
                ThreadTargetSnapshot t = group.Record.Target;
                ThreadTarget target = new ThreadTarget
                {
                    Center = (double[])t.Center.Clone(),
                    U = (double[])t.Axis.Clone(),
                    RadiusCm = t.RadiusCm,
                    LengthCm = t.LengthCm,
                    IsExternal = t.IsExternal,
                    BodyName = t.BodyName,
                    SourceDocument = doc,
                    SourceDocumentInternalName = doc.InternalName
                };
                ThreadParametersSnapshot p = group.Record.Parameters;
                _buildZones.Add(CreateBuildZones(new List<ThreadTarget> { target }, new ThreadParams
                {
                    FullLength = p.FullLength,
                    LengthMm = p.LengthMm,
                    OffsetMm = p.OffsetMm
                }));
                _buildSelections.Add(new List<ThreadTarget>());
            }
            _sessionBuilds = _buildZones.Count;
            return true;
        }

        private void QueueEditStateRefresh(string message)
        {
            try
            {
                Action refresh = () =>
                {
                    if (IsDisposed || _closing) return;
                    bool groupReloaded = false;
                    string reloadFailure = null;
                    try
                    {
                        if (!string.IsNullOrWhiteSpace(_editThreadId))
                        {
                            Inventor.PartDocument doc = _app.ActiveDocument as Inventor.PartDocument;
                            ThreadMetadataGroup group;
                            string error;
                            if (ThreadMetadataStore.TryLoadGroup(doc, _editThreadId, out group, out error))
                            {
                                LoadEditParameters(group.Record.Parameters);
                                groupReloaded = true;
                            }
                            else reloadFailure = error;
                        }
                        else reloadFailure = "Не задан ThreadId текущей группы.";
                    }
                    catch (Exception ex) { reloadFailure = ex.Message; }

                    try { RefreshBuildZonesFromMetadata(); } catch { }
                    string effectiveMessage = message;
                    Color statusColor = UiMuted;
                    if (!groupReloaded)
                    {
                        effectiveMessage += " Не удалось подтвердить восстановление параметров текущей группы" +
                            (string.IsNullOrWhiteSpace(reloadFailure) ? "." : ": " + reloadFailure + ".") +
                            " НЕ СОХРАНЯЙТЕ этот IPT; закройте документ без сохранения и откройте последнюю сохранённую копию.";
                        statusColor = UiError;
                    }
                    if (lStatus != null) { lStatus.ForeColor = statusColor; lStatus.Text = effectiveMessage; }
                    _lastBuildInfo = effectiveMessage;
                    UpdateInfo();
                    UpdateUndoButton();
                };
                if (IsHandleCreated && InvokeRequired) BeginInvoke(refresh);
                else refresh();
            }
            catch { }
        }

        private void ResetDialogDefaults()
        {
            if (_nativeConversionMode)
            {
                if (_nativeConversionCompleted || _nativeConversionPlan == null) return;
                try
                {
                    ClearThreadPreview();
                    Target = null;
                    LoadEditParameters(_nativeConversionPlan.Parameters);
                    Target = _nativeConversionPlan.InitialTarget;
                    cbDia.Enabled = false;
                    rbExt.Enabled = false;
                    rbInt.Enabled = false;
                    lStatus.ForeColor = UiMuted;
                    lStatus.Text = "Настройки физической резьбы восстановлены из исходной операции Inventor. Сама операция не изменялась.";
                    _lastBuildInfo = lStatus.Text;
                    SyncPreviewButtonVisibility();
                    UpdateInfo();
                }
                catch (Exception ex)
                {
                    lStatus.ForeColor = UiError;
                    lStatus.Text = "Не удалось восстановить параметры преобразования: " + ex.Message;
                }
                return;
            }
            if (_editMode)
            {
                Inventor.PartDocument editDoc = _app.ActiveDocument as Inventor.PartDocument;
                ThreadMetadataGroup savedGroup;
                string savedError;
                if (ThreadMetadataStore.TryLoadGroup(editDoc, _editThreadId, out savedGroup, out savedError))
                {
                    LoadEditParameters(savedGroup.Record.Parameters);
                    lStatus.ForeColor = UiMuted;
                    lStatus.Text = "Несохранённые изменения формы сброшены к параметрам, сохранённым в IPT.";
                }
                else ShowMessage("Не удалось загрузить исходные параметры: " + savedError);
                return;
            }
            try
            {
                ClearThreadPreview();
                _sel.Stop();
                _sel.Clear(false);
                // Clear(false) intentionally suppresses Changed during the multi-control
                // reset operation, so update the selection-dependent command explicitly.
                SyncPreviewButtonVisibility();
                Target = null;
                _loading = true;

                _inchDia = false;
                _inchPitch = false;
                rbMmD.Checked = true;
                rbInD.Checked = false;
                rbMmP.Checked = true;
                rbInP.Checked = false;

                rbExt.Checked = true;
                rbInt.Checked = false;
                if (chTaperStrictStandard != null) chTaperStrictStandard.Checked = true;
                rbR.Checked = true;
                rbL.Checked = false;
                cbStd.SelectedIndex = (int)ThreadStandard.ISO;
                _lastValidStandardIndex = (int)ThreadStandard.ISO;
                _all.Clear();
                _all.AddRange(ThreadStandards.Sizes(ThreadStandard.ISO));

                nStarts.Value = 1;
                cbMat.SelectedIndex = 0;
                _lastCommittedMaterialIndex = 0;
                _pendingMaterialIndex = -1;
                _materialCommitObserved = false;
                _preserveCommittedMaterialUntilDropdownReopened = true;
                nClear.Value = 0m;
                chFull.Checked = true;
                nLen.Value = 20m;
                SetNumericLocked(nLen, true);
                nOff.Value = 0m;
                chRun.Checked = true;
                nRun.Value = 1m;
                SetNumericLocked(nRun, false);
                chRound.Checked = true;
                chMirror.Checked = false;
                if (chSortFolders != null) chSortFolders.Checked = true;
                chCham.Checked = true;
                cbCham.SelectedIndex = 0;
                _lastCommittedChamferIndex = 0;
                _pendingChamferIndex = -1;
                _chamferCommitObserved = false;
                _preserveCommittedChamferUntilDropdownReopened = true;
                nCham.Value = 1m;
                cbCham.Visible = false;
                nCham.Visible = true;
                cbCham.Enabled = true;
                SetNumericLocked(nCham, false);
                if (chamferOptions != null) chamferOptions.Visible = true;

                _loading = false;
                UpdateUnitToggle();
                RebuildLists();

                ThreadSize def = _all.FirstOrDefault(x => x.Name == "M10 x 1.5") ?? _all.FirstOrDefault();
                if (def != null) SelectSize(def);
                else
                {
                    cbDia.Text = "10";
                    cbPitch.Text = "1.5";
                    SyncSizeCombo();
                }

                chMirror.Enabled = false;
                RefreshMaterialComboVisuals();
                RefreshChamferComboVisuals();
                lStatus.ForeColor = UiSuccess;
                lStatus.Text = "Параметры и неподтверждённый выбор рёбер сброшены.";
                bResume.Visible = false;
                if (_informationMessagesViewport != null)
                {
                    _informationMessagesViewport.AutoScrollPosition = Point.Empty;
                    _informationMessagesViewport.PerformLayout();
                }
                ApplyResponsiveLayout();
                StartSelection();
            }
            catch (Exception ex)
            {
                _loading = false;
                ShowMessage("Не удалось выполнить сброс: " + ex.Message);
                StartSelection();
            }
        }

        private void AttachTransactionEvents()
        {
            try { _transactionEvents = _app.TransactionManager.TransactionEvents; }
            catch { _transactionEvents = null; return; }
            // Attach separately so a failure of one COM event does not leave an earlier
            // subscription untracked and impossible to detach during form shutdown.
            try { _transactionEvents.OnUndo += TransactionEvents_OnUndo; } catch { }
            try { _transactionEvents.OnRedo += TransactionEvents_OnRedo; } catch { }
            try { _transactionEvents.OnCommit += TransactionEvents_OnCommit; } catch { }
        }

        private void DetachTransactionEvents()
        {
            Inventor.TransactionEvents events = _transactionEvents;
            _transactionEvents = null;
            if (events == null) return;
            try { events.OnUndo -= TransactionEvents_OnUndo; } catch { }
            try { events.OnRedo -= TransactionEvents_OnRedo; } catch { }
            try { events.OnCommit -= TransactionEvents_OnCommit; } catch { }
        }

        private static HelivantaTransactionKind ClassifyTransaction(Inventor.Transaction transaction, out string threadId)
        {
            string displayName = null;
            try { if (transaction != null) displayName = transaction.DisplayName; } catch { }
            return ThreadEditSafetyPolicy.ClassifyTransaction(
                displayName, ThreadBuilder.TransactionPrefix, ThreadBuilder.EditTransactionPrefix, out threadId);
        }

        private void TransactionEvents_OnUndo(Inventor.Transaction TransactionObject,
            Inventor.NameValueMap Context, Inventor.EventTimingEnum BeforeOrAfter,
            out Inventor.HandlingCodeEnum HandlingCode)
        {
            HandlingCode = Inventor.HandlingCodeEnum.kEventNotHandled;
            TransactionLifecycleDiagnostics.Write("ThreadDialog", "OnUndo." + BeforeOrAfter, _app,
                null, TransactionObject, false,
                "closing=" + _closing + "; pluginUndoInProgress=" + _pluginUndoInProgress);
            if (_closing) return;
            if (_pluginUndoInProgress)
            {
                _nativeUndoKind = HelivantaTransactionKind.Other;
                _nativeUndoThreadId = null;
                return;
            }
            if (BeforeOrAfter == Inventor.EventTimingEnum.kBefore)
            {
                // Capture both the operation kind and edit ThreadId before Inventor mutates the stack.
                _nativeUndoKind = ClassifyTransaction(TransactionObject, out _nativeUndoThreadId);
                return;
            }
            if (BeforeOrAfter != Inventor.EventTimingEnum.kAfter) return;
            HelivantaTransactionKind kind = _nativeUndoKind;
            string threadId = _nativeUndoThreadId;
            _nativeUndoKind = HelivantaTransactionKind.Other;
            _nativeUndoThreadId = null;
            if (kind == HelivantaTransactionKind.Other) return;

            if (kind == HelivantaTransactionKind.Build && _nativeConversionMode && _nativeConversionCompleted)
            {
                ResumeNativeConversionAfterUndo("Преобразование отменено командой Inventor Undo.");
                return;
            }

            if (kind == HelivantaTransactionKind.Edit)
            {
                if (_editMode && string.Equals(threadId, _editThreadId, StringComparison.Ordinal))
                    QueueEditStateRefresh("↶ Изменение этой резьбы отменено командой Inventor Undo. Параметры и геометрия восстановлены.");
                else
                    QueueModelStateRefresh("↶ Изменение другой резьбы отменено командой Inventor Undo. Состояние модели обновлено.");
                return;
            }

            if (_editMode)
            {
                QueueModelStateRefresh("↶ Построение Helivanta отменено командой Inventor Undo. Состояние модели обновлено.");
                return;
            }
            MoveLastActiveBuildToRedo();
            QueueUndoTrackingUiRefresh("↶ Построение резьбы отменено командой Inventor Undo. Внутренний список построенных зон обновлён.");
        }

        private void TransactionEvents_OnRedo(Inventor.Transaction TransactionObject,
            Inventor.NameValueMap Context, Inventor.EventTimingEnum BeforeOrAfter,
            out Inventor.HandlingCodeEnum HandlingCode)
        {
            HandlingCode = Inventor.HandlingCodeEnum.kEventNotHandled;
            TransactionLifecycleDiagnostics.Write("ThreadDialog", "OnRedo." + BeforeOrAfter, _app,
                null, TransactionObject, false,
                "closing=" + _closing + "; pluginUndoInProgress=" + _pluginUndoInProgress);
            if (_closing) return;
            if (_pluginUndoInProgress)
            {
                _nativeRedoKind = HelivantaTransactionKind.Other;
                _nativeRedoThreadId = null;
                return;
            }
            if (BeforeOrAfter == Inventor.EventTimingEnum.kBefore)
            {
                _nativeRedoKind = ClassifyTransaction(TransactionObject, out _nativeRedoThreadId);
                return;
            }
            if (BeforeOrAfter != Inventor.EventTimingEnum.kAfter) return;
            HelivantaTransactionKind kind = _nativeRedoKind;
            string threadId = _nativeRedoThreadId;
            _nativeRedoKind = HelivantaTransactionKind.Other;
            _nativeRedoThreadId = null;
            if (kind == HelivantaTransactionKind.Other) return;

            if (kind == HelivantaTransactionKind.Build && _nativeConversionMode &&
                !_nativeConversionCompleted && !string.IsNullOrWhiteSpace(_nativeConversionThreadId))
            {
                ThreadMetadataGroup restoredGroup;
                string restoredError;
                if (ThreadMetadataStore.TryLoadGroup(_app.ActiveDocument as Inventor.PartDocument,
                    _nativeConversionThreadId, out restoredGroup, out restoredError))
                {
                    _nativeConversionCompleted = true;
                    _nativeConversionAwaitingNextSelection = false;
                    bBuild.Enabled = true;
                    bBuild.Text = HelivantaLocalization.Translate("Следующая");
                    bBuild.AccessibleName = "Выбрать следующую штатную резьбу Inventor для преобразования";
                    bBuild.AccessibleDescription = "Преобразование восстановлено командой Inventor Redo. Нажмите, чтобы выбрать следующую штатную операцию «Резьба Inventor».";
                    bPreview.Visible = false;
                    bReset.Enabled = false;
                    lStatus.ForeColor = UiSuccess;
                    lStatus.Text = "Преобразование физической резьбы восстановлено командой Inventor Redo.";
                    _lastBuildInfo = lStatus.Text;
                    UpdateUndoButton();
                    UpdateInfo();
                    return;
                }
            }

            if (kind == HelivantaTransactionKind.Edit)
            {
                if (_editMode && string.Equals(threadId, _editThreadId, StringComparison.Ordinal))
                    QueueEditStateRefresh("↻ Изменение этой резьбы восстановлено командой Inventor Redo. Параметры и геометрия обновлены.");
                else
                    QueueModelStateRefresh("↻ Изменение другой резьбы восстановлено командой Inventor Redo. Состояние модели обновлено.");
                return;
            }

            if (_editMode)
            {
                QueueModelStateRefresh("↻ Построение Helivanta восстановлено командой Inventor Redo. Состояние модели обновлено.");
                return;
            }
            RestoreLastUndoneBuild();
            QueueUndoTrackingUiRefresh("↻ Построение резьбы восстановлено командой Inventor Redo. Внутренний список построенных зон обновлён.");
        }

        private void TransactionEvents_OnCommit(Inventor.Transaction TransactionObject,
            Inventor.NameValueMap Context, Inventor.EventTimingEnum BeforeOrAfter,
            out Inventor.HandlingCodeEnum HandlingCode)
        {
            HandlingCode = Inventor.HandlingCodeEnum.kEventNotHandled;
            if (BeforeOrAfter != Inventor.EventTimingEnum.kAfter || _closing) return;
            // A new edit or unrelated operation invalidates an old redo branch. Normal build
            // bookkeeping is updated explicitly in DoBuild immediately after the commit.
            string threadId;
            HelivantaTransactionKind kind = ClassifyTransaction(TransactionObject, out threadId);
            if (kind != HelivantaTransactionKind.Build) ClearRedoBuildTracking();
        }

        private void MoveLastActiveBuildToRedo()
        {
            if (_buildZones.Count == 0) return;
            List<BuiltThreadZone> zones = _buildZones[_buildZones.Count - 1];
            _buildZones.RemoveAt(_buildZones.Count - 1);
            _redoBuildZones.Add(zones);

            List<ThreadTarget> selection;
            if (_buildSelections.Count > 0)
            {
                selection = _buildSelections[_buildSelections.Count - 1];
                _buildSelections.RemoveAt(_buildSelections.Count - 1);
            }
            else selection = new List<ThreadTarget>();
            _redoBuildSelections.Add(selection);
            _sessionBuilds = _buildZones.Count;
        }

        private void RestoreLastUndoneBuild()
        {
            if (_redoBuildZones.Count == 0) return;
            List<BuiltThreadZone> zones = _redoBuildZones[_redoBuildZones.Count - 1];
            _redoBuildZones.RemoveAt(_redoBuildZones.Count - 1);
            _buildZones.Add(zones);

            List<ThreadTarget> selection;
            if (_redoBuildSelections.Count > 0)
            {
                selection = _redoBuildSelections[_redoBuildSelections.Count - 1];
                _redoBuildSelections.RemoveAt(_redoBuildSelections.Count - 1);
            }
            else selection = new List<ThreadTarget>();
            _buildSelections.Add(selection);
            _sessionBuilds = _buildZones.Count;
        }

        private void ClearRedoBuildTracking()
        {
            _redoBuildSelections.Clear();
            _redoBuildZones.Clear();
        }

        private void QueueModelStateRefresh(string message)
        {
            try
            {
                if (IsDisposed || _closing) return;
                Action refresh = () =>
                {
                    if (IsDisposed || _closing) return;
                    try
                    {
                        RefreshBuildZonesFromMetadata();
                        if (lStatus != null)
                        {
                            lStatus.ForeColor = UiMuted;
                            lStatus.Text = message;
                        }
                        _lastBuildInfo = message;
                        UpdateInfo();
                        UpdateUndoButton();
                    }
                    catch { }
                };
                if (IsHandleCreated && InvokeRequired) BeginInvoke(refresh);
                else refresh();
            }
            catch { }
        }

        private void QueueUndoTrackingUiRefresh(string message)
        {
            try
            {
                if (IsDisposed || _closing) return;
                Action refresh = () =>
                {
                    if (IsDisposed || _closing) return;
                    try
                    {
                        if (lStatus != null)
                        {
                            lStatus.ForeColor = UiMuted;
                            lStatus.Text = message;
                        }
                        if (lInfo != null)
                        {
                            _lastBuildInfo = message;
                            UpdateInfo();
                        }
                        UpdateUndoButton();
                    }
                    catch { }
                };
                if (IsHandleCreated && InvokeRequired) BeginInvoke(refresh);
                else refresh();
            }
            catch { }
        }

        private bool ResumeNativeConversionAfterUndo(string undoMessage)
        {
            _nativeConversionCompleted = false;
            _nativeConversionAwaitingNextSelection = false;

            NativeThreadConversionPlan refreshedPlan;
            string refreshError;
            if (NativeThreadConversionService.TryRefreshAfterUndo(_app, _nativeConversionPlan,
                out refreshedPlan, out refreshError))
            {
                // Undo restored the cosmetic feature. Refresh COM references from the document
                // rather than reusing edge references invalidated by the previous conversion.
                // The visible parameter controls are deliberately left untouched so the user can
                // correct settings and immediately run the same feature again.
                _nativeConversionPlan = refreshedPlan;
                Target = refreshedPlan.InitialTarget;
                bBuild.Text = HelivantaLocalization.Translate("Изменить");
                bBuild.AccessibleName = "Изменить выбранную штатную резьбу Inventor с помощью Helivanta";
                bBuild.AccessibleDescription = "Повторно заменить восстановленную штатную резьбу Inventor физической геометрией Helivanta с текущими настройками.";
                bBuild.Enabled = true;
                bPreview.Visible = true;
                bReset.Enabled = true;
                _lastBuildWarning = string.Empty;
                lStatus.ForeColor = UiSuccess;
                lStatus.Text = (string.IsNullOrWhiteSpace(undoMessage) ? "Преобразование отменено." : undoMessage) +
                    " Исходная штатная резьба восстановлена. Исправьте параметры и снова нажмите «Изменить»; повторно выбирать резьбу не нужно.";
                _lastBuildInfo = lStatus.Text;
                RefreshButtonToolTips();
                SyncPreviewButtonVisibility();
                UpdateUndoButton();
                UpdateInfo();
                ApplyResponsiveLayout();
                return true;
            }

            bool sourceRestored = NativeThreadConversionService.VerifyOriginalFeatureRestored(
                _app == null ? null : _app.ActiveDocument as Inventor.PartDocument, _nativeConversionPlan);
            Target = null;
            bBuild.Text = HelivantaLocalization.Translate("Изменить");
            bBuild.AccessibleName = "Изменить выбранную штатную резьбу Inventor с помощью Helivanta";
            bBuild.AccessibleDescription = "Кнопка недоступна, так как исходную штатную резьбу не удалось безопасно подготовить после Undo.";
            bBuild.Enabled = false;
            bPreview.Visible = false;
            bReset.Enabled = false;
            lStatus.ForeColor = sourceRestored ? UiWarning : UiError;
            lStatus.Text = sourceRestored
                ? "Исходная резьба Inventor восстановлена, но Helivanta не смогла безопасно повторно открыть её для изменения. Закройте окно и выберите штатную резьбу заново. Причина: " + (refreshError ?? "не определена")
                : "Inventor выполнил Undo, но исходную штатную операцию не удалось подтвердить. НЕ СОХРАНЯЙТЕ этот IPT; закройте документ без сохранения и откройте последнюю сохранённую копию.";
            _lastBuildInfo = lStatus.Text;
            RefreshButtonToolTips();
            UpdateUndoButton();
            UpdateInfo();
            ApplyResponsiveLayout();
            return false;
        }

        private void UpdateUndoButton()
        {
            if (bUndo == null) return;
            bool canUndo = false;
            try
            {
                canUndo = _nativeConversionMode
                    ? (_nativeConversionCompleted && !_nativeConversionAwaitingNextSelection && ThreadBuilder.CanUndoLastBuild(_app))
                    : (_editMode
                        ? ThreadBuilder.CanUndoLastEdit(_app, _editThreadId)
                        : (_sessionBuilds > 0 && ThreadBuilder.CanUndoLastBuild(_app)));
            }
            catch { canUndo = false; }
            bUndo.Enabled = canUndo;
        }

        private void DoUndo()
        {
            if (_nativeConversionMode)
            {
                if (!_nativeConversionCompleted || !ThreadBuilder.CanUndoLastBuild(_app))
                {
                    ShowMessage("Отмена преобразования доступна только сразу после успешной конвертации штатной резьбы.");
                    UpdateUndoButton();
                    return;
                }
                try
                {
                    Cursor = Cursors.WaitCursor;
                    _pluginUndoInProgress = true;
                    try { ThreadBuilder.UndoLastBuild(_app); }
                    finally { _pluginUndoInProgress = false; }
                    ResumeNativeConversionAfterUndo("Преобразование отменено.");
                }
                catch (Exception ex)
                {
                    lStatus.ForeColor = UiError;
                    lStatus.Text = "Не удалось выполнить Undo преобразования: " + ex.Message + ". При сомнении закройте IPT без сохранения.";
                    _lastBuildInfo = lStatus.Text;
                    UpdateInfo();
                }
                finally
                {
                    Cursor = Cursors.Default;
                    UpdateUndoButton();
                }
                return;
            }
            if (_editMode)
            {
                if (!ThreadBuilder.CanUndoLastEdit(_app, _editThreadId))
                {
                    ShowMessage("Отмена недоступна: последним действием не было изменение существующей резьбы.");
                    UpdateUndoButton();
                    return;
                }
                try
                {
                    Cursor = Cursors.WaitCursor;
                    try { _sel.Stop(); } catch { }
                    _pluginUndoInProgress = true;
                    try { ThreadBuilder.UndoLastBuild(_app); }
                    finally { _pluginUndoInProgress = false; }
                    RefreshBuildZonesFromMetadata();
                    Inventor.PartDocument doc = _app.ActiveDocument as Inventor.PartDocument;
                    ThreadMetadataGroup group;
                    string metadataError;
                    if (ThreadMetadataStore.TryLoadGroup(doc, _editThreadId, out group, out metadataError))
                    {
                        LoadEditParameters(group.Record.Parameters);
                        lStatus.ForeColor = UiSuccess;
                        lStatus.Text = "Изменение резьбы отменено. Исходная геометрия и параметры восстановлены.";
                    }
                    else
                    {
                        lStatus.ForeColor = UiError;
                        lStatus.Text = "Inventor выполнил Undo, но исходная группа не прошла проверку метаданных: " +
                            (metadataError ?? "причина не определена") +
                            ". НЕ СОХРАНЯЙТЕ этот IPT; закройте документ без сохранения и откройте последнюю сохранённую копию.";
                    }
                    _lastBuildInfo = lStatus.Text;
                    UpdateInfo();
                }
                catch (Exception ex)
                {
                    lStatus.ForeColor = UiError;
                    lStatus.Text = "Не удалось подтвердить завершение Undo для изменения резьбы: " + ex.Message +
                        ". Не сохраняйте деталь, если геометрия/параметры не совпадают с ожидаемым состоянием; при сомнении закройте IPT без сохранения и откройте последнюю сохранённую копию.";
                    _lastBuildInfo = lStatus.Text;
                    try { UpdateInfo(); } catch { }
                }
                finally
                {
                    Cursor = Cursors.Default;
                    UpdateUndoButton();
                }
                return;
            }

            if (_sessionBuilds <= 0 || !ThreadBuilder.CanUndoLastBuild(_app))
            {
                ShowMessage("Отмена недоступна: последним действием была не операция Helivanta.");
                UpdateUndoButton();
                return;
            }

            // Keep the selection belonging to the build being undone. After Inventor Undo the
            // original Edge COM references can be stale, so EdgeSelector will re-find the same
            // geometric edges in the restored model.
            List<ThreadTarget> restoreSelection = _buildSelections.Count > 0
                ? _buildSelections[_buildSelections.Count - 1]
                : null;

            try
            {
                Cursor = Cursors.WaitCursor;
                _sel.Stop();
                _pluginUndoInProgress = true;
                try
                {
                    ThreadBuilder.UndoLastBuild(_app);
                }
                finally
                {
                    _pluginUndoInProgress = false;
                }
                // The native Undo event is intentionally ignored while our own Undo button is
                // executing. Move the registry entry to the redo stack exactly once here.
                MoveLastActiveBuildToRedo();

                bool restored = restoreSelection != null && _sel.RestoreTargets(restoreSelection);
                Target = restored && _sel.Targets.Count > 0 ? _sel.Targets[0] : null;
                // Target is assigned before this refresh so a restored edge is treated as the
                // existing reference, not as a newly-picked edge that would auto-select a pitch.
                OnSelectionChanged();

                lStatus.ForeColor = restored ? UiSuccess : UiWarning;
                if (restored)
                {
                    lStatus.Text = _sessionBuilds > 0
                        ? "Последнее построение отменено. Рёбра восстановлены — можно изменить параметры и построить резьбу снова."
                        : "Последнее построение отменено. Рёбра восстановлены — можно изменить параметры и построить резьбу снова.";
                }
                else
                {
                    lStatus.Text = "Построение отменено, но не удалось автоматически восстановить выбранные рёбра. Выберите их снова.";
                }
            }
            catch (Exception ex)
            {
                lStatus.ForeColor = UiError;
                lStatus.Text = "Ошибка отмены: " + ex.Message;
            }
            finally
            {
                Cursor = Cursors.Default;
                UpdateUndoButton();
                StartSelection();
            }
        }

        // ---------- values ----------
        private static string Fmt(double v) { return Math.Round(v, 3).ToString("0.###", Inv); }

        private static bool TryNum(string text, out double v)
        {
            return double.TryParse((text ?? "").Trim().Replace(',', '.'), NumberStyles.Float, Inv, out v);
        }

        // "1 1/8", "5/16", "1/4.5", "0.05" -> number (inch fields accept fractions)
        private static bool TryNumFrac(string text, out double v)
        {
            v = 0.0;
            string t = (text ?? "").Trim().Replace(',', '.');
            if (t.Length == 0) return false;
            double total = 0.0;
            foreach (string part in t.Split(new[] { ' ' }, StringSplitOptions.RemoveEmptyEntries))
            {
                double x;
                int k = part.IndexOf('/');
                if (k > 0)
                {
                    double num, den;
                    if (!double.TryParse(part.Substring(0, k), NumberStyles.Float, Inv, out num) ||
                        !double.TryParse(part.Substring(k + 1), NumberStyles.Float, Inv, out den) || den == 0.0) return false;
                    x = num / den;
                }
                else if (!double.TryParse(part, NumberStyles.Float, Inv, out x)) return false;
                total += x;
            }
            v = total;
            return true;
        }

        // the fields show mm or inches (each field has its own switch); everything inside works in mm
        private double DiaMm
        {
            get
            {
                double v;
                bool ok = _inchDia ? TryNumFrac(cbDia.Text, out v) : TryNum(cbDia.Text, out v);
                return ok ? (_inchDia ? v * 25.4 : v) : 0.0;
            }
        }

        private double PitchMm
        {
            get
            {
                double v;
                bool ok = _inchPitch ? TryNumFrac(cbPitch.Text, out v) : TryNum(cbPitch.Text, out v);
                return ok ? (_inchPitch ? v * 25.4 : v) : 0.0;
            }
        }

        // inches as a fraction of 1/64 ("1 1/8", "5/16"), otherwise decimal ("0.112")
        private string FmtDia(double mm)
        {
            if (!_inchDia) return Fmt(mm);
            double inch = mm / 25.4;
            int whole = (int)Math.Floor(inch + 1e-9);
            int n64 = (int)Math.Round((inch - whole) * 64.0);
            if (Math.Abs(inch - (whole + n64 / 64.0)) < 1e-4)
            {
                if (n64 == 64) { whole++; n64 = 0; }
                if (n64 == 0) return whole.ToString(Inv);
                int num = n64, den = 64;
                while (num % 2 == 0) { num /= 2; den /= 2; }
                return (whole > 0 ? whole + " " : "") + num + "/" + den;
            }
            return inch.ToString("0.#####", Inv);
        }

        // pitch in inches as 1/TPI ("1/20", "1/4.5"), otherwise decimal
        private string FmtPitch(double mm)
        {
            if (!_inchPitch) return Fmt(mm);
            double inch = mm / 25.4;
            double tpi = 1.0 / inch;
            if (Math.Abs(tpi * 8.0 - Math.Round(tpi * 8.0)) < 0.01)
                return "1/" + (Math.Round(tpi * 8.0) / 8.0).ToString("0.###", Inv);
            return inch.ToString("0.#####", Inv);
        }

        // the switches are available for the standards with inch characteristics
        private void UpdateUnitToggle()
        {
            bool inchStd = Std == ThreadStandard.BSW || Std == ThreadStandard.ANSI || Std == ThreadStandard.Rd;
            rbMmD.Enabled = rbInD.Enabled = rbMmP.Enabled = rbInP.Enabled = inchStd;
            if (!inchStd)
            {
                if (_inchDia) SetInchDia(false);
                if (_inchPitch) SetInchPitch(false);
            }
        }

        private void SetInchDia(bool inch)
        {
            if (inch == _inchDia) return;
            double d = DiaMm;   // old unit -> mm
            _inchDia = inch;
            _loading = true;
            rbMmD.Checked = !inch; rbInD.Checked = inch;
            lDia.Text = inch ? "Номинальный диаметр, дюйм:" : "Номинальный диаметр, мм:";
            _loading = false;
            RebuildLists();   // diameter list in the new unit
            _loading = true;
            if (d > 0) cbDia.Text = FmtDia(d);
            _loading = false;
            SyncSizeCombo();
            UpdateInfo();
        }

        private void SetInchPitch(bool inch)
        {
            if (inch == _inchPitch) return;
            double p = PitchMm;   // old unit -> mm
            _inchPitch = inch;
            _loading = true;
            rbMmP.Checked = !inch; rbInP.Checked = inch;
            lPitch.Text = inch ? "Шаг, дюйм:" : "Шаг, мм:";
            double d = DiaMm;
            if (d > 0) FillPitchItems(d);   // pitch list in the new unit
            if (p > 0) cbPitch.Text = FmtPitch(p);
            _loading = false;
            SyncSizeCombo();
            UpdateInfo();
        }

        private ThreadStandard Std
        {
            get
            {
                // The native ComboBox can briefly (and on some Inventor systems, persistently)
                // report SelectedIndex == -1 after a committed selection. The
                // confirmed index is the source of truth for catalogues and Build parameters.
                int standardCount = Enum.GetValues(typeof(ThreadStandard)).Length;
                int selected = _lastValidStandardIndex;
                if (!ThreadStandardSelectionPolicy.IsValidIndex(selected, standardCount)) selected = 0;
                return (ThreadStandard)selected;
            }
        }
        private bool IsExternal() { return rbExt.Checked; }

        // ---------- lists ----------
        // With a picked edge, offer nearby table sizes by NOMINAL diameter only.
        // An internal cylinder must not be auto-mapped to a different major diameter
        // merely because its bore resembles that size's basic minor diameter.
        private bool Fits(ThreadSize s)
        {
            if (Target == null) return true;
            double faceDia = Target.RadiusCm * 20.0;
            return ThreadNominalDiameterPolicy.DiameterDifferenceMm(faceDia, s.DiameterMm) <= 2.0;
        }

        private void OnMaterialDropDownOpened(object sender, EventArgs e)
        {
            // Re-synchronize the native ComboBox before accepting another choice. After an
            // add-in form is closed/reopened, WinForms can paint a stale native row despite
            // the committed technology and its clearance still being correct. The committed
            // index is authoritative; copy it back into the native list as the popup opens.
            if (ThreadTechnologySelectionPolicy.IsValidIndex(_lastCommittedMaterialIndex, cbMat.Items.Count) &&
                cbMat.SelectedIndex != _lastCommittedMaterialIndex)
            {
                _loading = true;
                try { cbMat.SelectedIndex = _lastCommittedMaterialIndex; }
                finally { _loading = false; }
            }

            // The previously committed choice is the rollback point if the user presses Esc.
            _pendingMaterialIndex = -1;
            _materialCommitObserved = false;
            _preserveCommittedMaterialUntilDropdownReopened = false;
        }

        private void OnMaterialSelectionChanged(object sender, EventArgs e)
        {
            int selected = cbMat == null ? -1 : cbMat.SelectedIndex;
            if (_loading)
            {
                if (ThreadTechnologySelectionPolicy.IsValidIndex(selected, cbMat.Items.Count))
                    _lastCommittedMaterialIndex = selected;
                return;
            }

            // Ignore stale native notifications after a committed pick. In particular, a
            // native ComboBox can report the old row or -1 just after popup close.
            if (_preserveCommittedMaterialUntilDropdownReopened)
            {
                if (!cbMat.DroppedDown)
                {
                    _pendingMaterialIndex = _lastCommittedMaterialIndex;
                    _materialCommitObserved = true;
                    QueueMaterialSelectionApply();
                }
                return;
            }

            if (ThreadTechnologySelectionPolicy.IsValidIndex(selected, cbMat.Items.Count))
            {
                if (selected != _lastCommittedMaterialIndex)
                {
                    _pendingMaterialIndex = selected;
                    if (!cbMat.DroppedDown)
                    {
                        // A different stable index observed after close can be a delayed
                        // SelectionChangeCommitted notification, so accept it as the new choice.
                        _materialCommitObserved = true;
                        QueueMaterialSelectionApply();
                    }
                }
                return;
            }

            if (!cbMat.DroppedDown) QueueMaterialSelectionApply();
        }

        private void OnMaterialSelectionCommitted(object sender, EventArgs e)
        {
            if (cbMat == null || _loading) return;
            int committed = ThreadTechnologySelectionPolicy.ResolveCommittedIndex(
                cbMat.SelectedIndex, _pendingMaterialIndex, _lastCommittedMaterialIndex, cbMat.Items.Count);
            if (!ThreadTechnologySelectionPolicy.IsValidIndex(committed, cbMat.Items.Count)) return;

            _pendingMaterialIndex = committed;
            _materialCommitObserved = true;
            _preserveCommittedMaterialUntilDropdownReopened = true;
            _lastCommittedMaterialIndex = committed;
            RefreshMaterialComboVisuals();

            // Apply the clearance preset at the explicit user-commit boundary, while the
            // intended row is still known. The queued close handler restores the native row.
            ApplyMaterialSelection(committed);
            if (!cbMat.DroppedDown) QueueMaterialSelectionApply();
        }

        private void OnMaterialDropDownClosed(object sender, EventArgs e)
        {
            QueueMaterialSelectionApply();
            if (IsHandleCreated && !IsDisposed)
            {
                try { BeginInvoke((Action)RefreshMaterialComboVisuals); }
                catch { RefreshMaterialComboVisuals(); }
            }
        }

        private void QueueMaterialSelectionApply()
        {
            if (_materialApplyPending || !IsHandleCreated || IsDisposed || cbMat == null) return;
            _materialApplyPending = true;
            try { BeginInvoke((Action)ApplyPendingMaterialSelection); }
            catch
            {
                _materialApplyPending = false;
                ApplyPendingMaterialSelection();
            }
        }

        private void ApplyPendingMaterialSelection()
        {
            _materialApplyPending = false;
            if (IsDisposed || cbMat == null || cbMat.Items.Count == 0 || cbMat.DroppedDown) return;

            int requested = _pendingMaterialIndex;
            bool commitObserved = _materialCommitObserved;
            _pendingMaterialIndex = -1;
            _materialCommitObserved = false;
            int selected = ThreadTechnologySelectionPolicy.ResolveAfterDropdownClose(
                commitObserved, requested, cbMat.SelectedIndex, _lastCommittedMaterialIndex, cbMat.Items.Count);
            if (!ThreadTechnologySelectionPolicy.IsValidIndex(selected, cbMat.Items.Count)) return;

            _loading = true;
            try
            {
                if (cbMat.SelectedIndex != selected) cbMat.SelectedIndex = selected;
            }
            finally { _loading = false; }

            _lastCommittedMaterialIndex = selected;
            _preserveCommittedMaterialUntilDropdownReopened = true;
            ApplyMaterialSelection(selected);
            RefreshMaterialComboVisuals();
        }

        private void RefreshMaterialComboVisuals()
        {
            if (cbMat == null || cbMat.IsDisposed || cbMat.Items.Count == 0) return;
            int committed = ThreadTechnologySelectionPolicy.IsValidIndex(_lastCommittedMaterialIndex, cbMat.Items.Count)
                ? _lastCommittedMaterialIndex
                : ThreadTechnologySelectionPolicy.ResolveStableIndex(cbMat.SelectedIndex, 0, cbMat.Items.Count);
            if (!ThreadTechnologySelectionPolicy.IsValidIndex(committed, cbMat.Items.Count)) return;

            // Keep a committed label for the closed field, matching the now-stable Template
            // selector. This protects display across re-created modeless dialogs as well as
            // transient/empty native Text from ComboBox popup-close notifications.
            if (cbMat is ThemedComboBox technologyCombo)
                technologyCombo.SetClosedFieldTextOverride(cbMat.GetItemText(cbMat.Items[committed]));

            // Never force a repaint while the popup is open: doing so can provoke another
            // stale notification. The text override is used only when the popup is closed.
            if (!cbMat.DroppedDown) RefreshComboVisual(cbMat);
        }

        private void OnChamferDropDownOpened(object sender, EventArgs e)
        {
            // Reassert the previously committed location before accepting another choice.
            // This prevents a stale native row from becoming the base state on reopen.
            if (ThreadChamferSelectionPolicy.IsValidIndex(_lastCommittedChamferIndex, cbCham.Items.Count) &&
                cbCham.SelectedIndex != _lastCommittedChamferIndex)
            {
                bool wasLoading = _loading;
                _loading = true;
                try { cbCham.SelectedIndex = _lastCommittedChamferIndex; }
                finally { _loading = wasLoading; }
            }

            _pendingChamferIndex = -1;
            _chamferCommitObserved = false;
            _preserveCommittedChamferUntilDropdownReopened = false;
            RefreshChamferComboVisuals();
        }

        private void OnChamferSelectionChanged(object sender, EventArgs e)
        {
            int selected = cbCham == null ? -1 : cbCham.SelectedIndex;
            SyncChamferSegmentButtons();
            if (_loading)
            {
                if (ThreadChamferSelectionPolicy.IsValidIndex(selected, cbCham.Items.Count))
                    _lastCommittedChamferIndex = selected;
                return;
            }

            // After a user commit, ignore trailing native notifications that expose the old
            // row or -1. Reapply the committed index after the popup has finished closing.
            if (_preserveCommittedChamferUntilDropdownReopened)
            {
                if (!cbCham.DroppedDown)
                {
                    _pendingChamferIndex = _lastCommittedChamferIndex;
                    _chamferCommitObserved = true;
                    QueueChamferSelectionApply();
                }
                return;
            }

            if (ThreadChamferSelectionPolicy.IsValidIndex(selected, cbCham.Items.Count))
            {
                if (selected != _lastCommittedChamferIndex)
                {
                    _pendingChamferIndex = selected;
                    if (!cbCham.DroppedDown)
                    {
                        // A distinct stable closed-field value may be the delayed native
                        // notification for a user commit, as in the standard selector.
                        _chamferCommitObserved = true;
                        QueueChamferSelectionApply();
                    }
                }
                return;
            }

            if (!cbCham.DroppedDown) QueueChamferSelectionApply();
        }

        private void OnChamferSelectionCommitted(object sender, EventArgs e)
        {
            if (cbCham == null || _loading) return;
            int committed = ThreadChamferSelectionPolicy.ResolveCommittedIndex(
                cbCham.SelectedIndex, _pendingChamferIndex, _lastCommittedChamferIndex, cbCham.Items.Count);
            if (!ThreadChamferSelectionPolicy.IsValidIndex(committed, cbCham.Items.Count)) return;

            _pendingChamferIndex = committed;
            _chamferCommitObserved = true;
            _preserveCommittedChamferUntilDropdownReopened = true;
            _lastCommittedChamferIndex = committed;
            RefreshChamferComboVisuals();
            nCham.Enabled = chCham.Checked;
            SetNumericLocked(nCham, !chCham.Checked);
            UpdateInfo();

            if (!cbCham.DroppedDown) QueueChamferSelectionApply();
        }

        private void OnChamferDropDownClosed(object sender, EventArgs e)
        {
            QueueChamferSelectionApply();
            if (IsHandleCreated && !IsDisposed)
            {
                try { BeginInvoke((Action)RefreshChamferComboVisuals); }
                catch { RefreshChamferComboVisuals(); }
            }
        }

        private void QueueChamferSelectionApply()
        {
            if (_chamferApplyPending || !IsHandleCreated || IsDisposed || cbCham == null) return;
            _chamferApplyPending = true;
            try { BeginInvoke((Action)ApplyPendingChamferSelection); }
            catch
            {
                _chamferApplyPending = false;
                ApplyPendingChamferSelection();
            }
        }

        private void ApplyPendingChamferSelection()
        {
            _chamferApplyPending = false;
            if (IsDisposed || cbCham == null || cbCham.Items.Count == 0 || cbCham.DroppedDown) return;

            int requested = _pendingChamferIndex;
            bool commitObserved = _chamferCommitObserved;
            _pendingChamferIndex = -1;
            _chamferCommitObserved = false;
            int selected = ThreadChamferSelectionPolicy.ResolveAfterDropdownClose(
                commitObserved, requested, cbCham.SelectedIndex,
                _lastCommittedChamferIndex, cbCham.Items.Count);
            if (!ThreadChamferSelectionPolicy.IsValidIndex(selected, cbCham.Items.Count)) return;

            _loading = true;
            try
            {
                if (cbCham.SelectedIndex != selected) cbCham.SelectedIndex = selected;
            }
            finally { _loading = false; }

            _lastCommittedChamferIndex = selected;
            _preserveCommittedChamferUntilDropdownReopened = true;
            nCham.Enabled = chCham.Checked;
            SetNumericLocked(nCham, !(chCham.Checked &&
                ThreadChamferSelectionPolicy.IsValidIndex(selected, cbCham.Items.Count)));
            RefreshChamferComboVisuals();
            UpdateInfo();
        }

        private void RefreshChamferComboVisuals()
        {
            if (cbCham == null || cbCham.IsDisposed || cbCham.Items.Count == 0) return;
            SyncChamferSegmentButtons();
            if (!cbCham.Visible) return;
            if (ThreadChamferSelectionPolicy.IsValidIndex(_lastCommittedChamferIndex, cbCham.Items.Count))
            {
                if (cbCham is ThemedComboBox chamferCombo)
                    chamferCombo.SetClosedFieldTextOverride(cbCham.GetItemText(cbCham.Items[_lastCommittedChamferIndex]));
            }

            // Do not force a repaint while the native popup is open; its own highlighted row
            // must remain interactive. The override is used only for the closed field.
            if (!cbCham.DroppedDown) RefreshComboVisual(cbCham);
        }

        private void ApplyMaterialSelection(int selectedIndex)
        {
            decimal preset;
            if (ThreadTechnologySelectionPolicy.TryGetPresetClearance(selectedIndex, out preset))
            {
                nClear.Value = ClampDecimal((double)preset, nClear.Minimum, nClear.Maximum);
                SetNumericLocked(nClear, true);
            }
            else
            {
                // “Другое” leaves the current clearance intact and unlocks manual editing.
                SetNumericLocked(nClear, false);
            }
            UpdateInfo();
        }

        private void OnStandardSelectionChanged(object sender, EventArgs e)
        {
            int selected = cbStd == null ? -1 : cbStd.SelectedIndex;

            // Programmatic assignments (dialog initialization, loading saved parameters,
            // reset) happen under _loading and are managed by the calling operation.
            if (_loading)
            {
                if (ThreadStandardSelectionPolicy.IsValidIndex(selected, cbStd.Items.Count))
                    _lastValidStandardIndex = selected;
                return;
            }

            // Do not rebuild catalogues from inside a native ComboBox notification. Record a
            // candidate and resolve it only after the popup is closed. In Inventor/WinForms the
            // owner-drawn field can briefly report SelectedIndex == -1 after a valid S click;
            // that state must not discard the committed item or leave the size list at M45.
            // After a user commit, ignore trailing native index notifications until the
            // selector is opened for the next choice. Some owner-drawn ComboBoxes emit the
            // previous index (or -1) after SelectionChangeCommitted; treating that delayed
            // notification as a fresh choice was able to undo the user's selection.
            if (_preserveCommittedStandardUntilDropdownReopened)
            {
                if (!cbStd.DroppedDown)
                {
                    // Reassert the already-confirmed index as the restoration candidate;
                    // do not let a late old SelectedIndex become the new pending standard.
                    _pendingStandardIndex = _lastValidStandardIndex;
                    _standardCommitObserved = true;
                    QueueStandardSelectionRestore();
                }
                return;
            }

            if (ThreadStandardSelectionPolicy.IsValidIndex(selected, cbStd.Items.Count))
            {
                if (selected != _lastValidStandardIndex)
                {
                    _pendingStandardIndex = selected;
                    if (!cbStd.DroppedDown)
                    {
                        // A different valid index observed after popup-close is itself a
                        // stable user selection, even if SelectionChangeCommitted arrived
                        // late (some native notification sequences do this).
                        _standardCommitObserved = true;
                        QueueStandardSelectionApply();
                    }
                }
                return;
            }

            if (!cbStd.DroppedDown) QueueStandardSelectionApply();
        }

        private void OnStandardDropDownOpened(object sender, EventArgs e)
        {
            // Keep the last applied standard as the rollback point if the user presses Esc.
            _pendingStandardIndex = -1;
            _standardCommitObserved = false;
            _preserveCommittedStandardUntilDropdownReopened = false;
        }

        private void OnStandardSelectionCommitted(object sender, EventArgs e)
        {
            if (cbStd == null || _loading) return;

            // SelectionChangeCommitted is the user-intent boundary. Resolve it immediately
            // instead of waiting for the native owner-drawn field to settle: Inventor can
            // clear SelectedIndex while closing the popup, after which a build must still use
            // the newly chosen standard rather than silently falling back to ISO/M45.
            int committed = ThreadStandardSelectionPolicy.ResolveCommittedIndex(
                cbStd.SelectedIndex, _pendingStandardIndex, _lastValidStandardIndex, cbStd.Items.Count);
            if (!ThreadStandardSelectionPolicy.IsValidIndex(committed, cbStd.Items.Count)) return;

            int previous = _lastValidStandardIndex;
            _pendingStandardIndex = committed;
            _standardCommitObserved = true;
            _preserveCommittedStandardUntilDropdownReopened = true;
            _lastValidStandardIndex = committed;
            chMirror.Enabled = (ThreadStandard)committed == ThreadStandard.S;

            // Rebuild the size/pitch catalogues immediately, while the committed index is
            // still available as authoritative state. The standard popup itself is not
            // repopulated by OnStandardChanged, so this is safe before native close completes.
            if (committed != previous) OnStandardChanged();
            RefreshStandardComboVisuals();

            // Reinstate the visible selected row after the native popup has fully closed.
            // DropDownClosed also queues this path; duplicate queue attempts are coalesced.
            if (!cbStd.DroppedDown) QueueStandardSelectionApply();
        }

        private void ApplyPendingStandardSelection()
        {
            _standardApplyPending = false;
            if (IsDisposed || cbStd == null || cbStd.Items.Count == 0) return;
            if (cbStd.DroppedDown) return;

            int requested = _pendingStandardIndex;
            bool commitObserved = _standardCommitObserved;
            _pendingStandardIndex = -1;
            _standardCommitObserved = false;
            int previous = _lastValidStandardIndex;
            int selected = ThreadStandardSelectionPolicy.ResolveAfterDropdownClose(
                commitObserved, requested, cbStd.SelectedIndex, previous, cbStd.Items.Count);
            if (selected < 0) return;

            _loading = true;
            try
            {
                if (cbStd.SelectedIndex != selected) cbStd.SelectedIndex = selected;
            }
            finally { _loading = false; }

            _lastValidStandardIndex = selected;
            chMirror.Enabled = (ThreadStandard)selected == ThreadStandard.S;
            if (selected != previous) OnStandardChanged();
            RefreshStandardComboVisuals();
        }

        private void OnStandardDropDownClosed(object sender, EventArgs e)
        {
            if (cbStd == null) return;
            // Always resolve after the native close, not only when the field is already blank:
            // some versions report the old item first and clear it in a later notification.
            QueueStandardSelectionApply();

            if (IsHandleCreated && !IsDisposed)
            {
                try { BeginInvoke((Action)RefreshStandardComboVisuals); }
                catch { RefreshStandardComboVisuals(); }
            }
        }

        private void QueueStandardSelectionRestore()
        {
            QueueStandardSelectionApply();
        }

        private void QueueStandardSelectionApply()
        {
            if (_standardApplyPending || !IsHandleCreated || IsDisposed || cbStd == null) return;
            _standardApplyPending = true;
            try { BeginInvoke((Action)ApplyPendingStandardSelection); }
            catch
            {
                _standardApplyPending = false;
                ApplyPendingStandardSelection();
            }
        }

        private void RefreshStandardComboVisuals()
        {
            // Keep a committed label on the control itself. The native ComboBox can retain the
            // correct SelectedIndex (and Build parameters) while exposing an empty/stale Text
            // after popup-close; the closed field painter uses this value as its authority.
            if (cbStd is ThemedComboBox standardCombo)
                standardCombo.SetClosedFieldTextOverride(ThreadStandards.Title(Std));

            // Do not repaint/update the native standard selector while its popup is open;
            // that can cause Windows to deliver a stale previous SelectedIndex notification.
            if (cbStd == null || !cbStd.DroppedDown) RefreshComboVisual(cbStd);
            RefreshComboVisual(cbSize);
            RefreshComboVisual(cbDia);
            RefreshComboVisual(cbPitch);
        }

        private static void RefreshComboVisual(ComboBox combo)
        {
            if (combo == null || combo.IsDisposed || !combo.IsHandleCreated) return;
            try
            {
                combo.Invalidate(true);
                combo.Update();
            }
            catch { }
        }

        private void OnStandardChanged()
        {
            // In edit mode, switching standards must not reset the user's nominal diameter
            // to the first catalog size. Keep the previous nominal diameter and pitch; the
            // size combo will become "Пользовательский" when the new standard has no exact match.
            double editDia = NominalDiameterIsLockedForCurrentMode ? _editNominalDiaMm : 0.0;
            double editPitch = NominalDiameterIsLockedForCurrentMode ? PitchMm : 0.0;
            UpdateUnitToggle();
            _all.Clear();
            _all.AddRange(ThreadStandards.Sizes(Std));
            RebuildLists();
            if (NominalDiameterIsLockedForCurrentMode && editDia > 0.0)
            {
                _loading = true;
                cbDia.Text = FmtDia(editDia);
                FillPitchItems(editDia);
                if (editPitch > 0.0) cbPitch.Text = FmtPitch(editPitch);
                _loading = false;
                SyncSizeCombo();
                UpdateInfo();
                return;
            }
            if (Target != null) { AutoSelectSize(); return; }

            // default size of the standard
            ThreadSize def = null;
            foreach (var s in _all)
                if (s.Name == "M10 x 1.5" || s.Name == "1/2\" BSW - 12 TPI" || s.Name == "1/2-13 UNC" ||
                    s.Name == "Tr 20 x 4" || s.Name == "S 20 x 4" || s.Name == "Rd 20 x 1/8\"") { def = s; break; }
            if (def == null && _all.Count > 0) def = _all[0];
            if (def != null) SelectSize(def);
        }

        // refill size and diameter lists (text of the editable boxes is kept)
        private void RebuildLists()
        {
            string dt = cbDia.Text, pt = cbPitch.Text;
            _loading = true;
            var visible = _all.Where(Fits)
                .Where(s => !NominalDiameterIsLockedForCurrentMode || _editNominalDiaMm <= 0.0 ||
                    ThreadNominalDiameterPolicy.MatchesStandardDiameter(_editNominalDiaMm, s.DiameterMm))
                .ToList();
            cbSize.Items.Clear();
            cbSize.Items.Add("Пользовательский");
            foreach (var s in visible) cbSize.Items.Add(s);
            cbDia.Items.Clear();
            foreach (double d in visible.Select(s => Math.Round(s.DiameterMm, 5)).Distinct().OrderBy(x => x))
                cbDia.Items.Add(FmtDia(d));
            // Explicitly restore editable fields after the catalogue Items collections rebuild.
            cbDia.Text = NominalDiameterIsLockedForCurrentMode && _editNominalDiaMm > 0.0 ? FmtDia(_editNominalDiaMm) : dt;
            cbPitch.Text = pt;
            _loading = false;
            SyncSizeCombo();
            RefreshStandardComboVisuals();
        }

        private List<double> PitchesFor(double dia)
        {
            return _all.Where(s => Math.Abs(s.DiameterMm - dia) < 0.001)
                       .Select(s => s.PitchMm).Distinct().OrderByDescending(x => x).ToList();
        }

        private void FillPitchItems(double dia)
        {
            string pt = cbPitch.Text;
            cbPitch.Items.Clear();

            // For an exact catalogue diameter, list only the pitches defined for that size.
            // For a user-defined diameter, the standard table has no exact row, so offer
            // the family catalogue pitches plus common metric pitches (including 2.5 mm)
            // instead of leaving the dropdown empty. The field remains editable for custom values.
            List<double> pitches = PitchesFor(dia);
            if (pitches.Count == 0)
                pitches = ThreadPitchSuggestionPolicy.ForCustomDiameter(_all.Select(s => s.PitchMm));

            foreach (double p in pitches) cbPitch.Items.Add(FmtPitch(p));
            cbPitch.Text = pt;
        }

        private void SelectSize(ThreadSize s)
        {
            if (NominalDiameterIsLockedForCurrentMode && _editNominalDiaMm > 0.0 &&
                !ThreadNominalDiameterPolicy.MatchesStandardDiameter(_editNominalDiaMm, s.DiameterMm))
            {
                _loading = true;
                cbDia.Text = FmtDia(_editNominalDiaMm);
                _loading = false;
                SyncSizeCombo();
                ShowMessage(string.Format(
                    "При редактировании номинальный диаметр фиксирован на Ø{0:0.###} мм. Выберите типоразмер с тем же диаметром; другой диаметр требует отдельной резьбы на подходящем цилиндре.",
                    _editNominalDiaMm));
                return;
            }
            _loading = true;
            cbDia.Text = FmtDia(s.DiameterMm);
            FillPitchItems(s.DiameterMm);
            cbPitch.Text = FmtPitch(s.PitchMm);
            _loading = false;
            SyncSizeCombo();
            UpdateInfo();
        }

        private void OnDiaChanged()
        {
            double d = DiaMm;
            if (d > 0)
            {
                _loading = true;
                FillPitchItems(d);
                var pitches = PitchesFor(d);
                if (pitches.Count > 0 && !pitches.Any(p => Math.Abs(p - PitchMm) < 0.0006))
                    cbPitch.Text = FmtPitch(pitches[0]);   // coarse pitch of this diameter
                _loading = false;
            }
            SyncSizeCombo();
            UpdateInfo();
        }

        // selects the size that matches the current diameter and pitch, otherwise "Пользовательский"
        private void SyncSizeCombo()
        {
            _loading = true;
            int idx = 0;
            double d = DiaMm, p = PitchMm;
            for (int i = 1; i < cbSize.Items.Count; i++)
            {
                var s = cbSize.Items[i] as ThreadSize;
                if (s != null && Math.Abs(s.DiameterMm - d) < 0.0006 && Math.Abs(s.PitchMm - p) < 0.0006) { idx = i; break; }
            }
            cbSize.SelectedIndex = idx;
            _loading = false;
        }

        private void StartSelection()
        {
            bool started = _sel != null && _sel.Start();
            // Start() may drop a stale selection after a document switch without raising
            // Changed. Always resync the button from the authoritative selector state.
            SyncPreviewButtonVisibility();
            if (started)
            {
                bResume.Visible = false;
                if (_sel.Targets.Count == 0) { lStatus.ForeColor = UiText; lStatus.Text = "Выбирайте рёбра в окне модели."; }
            }
            else ShowMessage("Откройте деталь (.ipt): рёбра выбираются в среде детали.");
        }

        private void ShowMessage(string text)
        {
            lStatus.ForeColor = UiWarning;
            lStatus.Text = text;
        }

        /// <summary>
        /// Keep the Preview command in sync with the authoritative logical edge selection.
        /// Several lifecycle paths intentionally suppress EdgeSelector.Changed while they
        /// restore or clear state; those paths call this method explicitly.
        /// </summary>
        private void SyncPreviewButtonVisibility()
        {
            if (bPreview == null || bPreview.IsDisposed) return;
            bool hasSelection = false;
            if (_nativeConversionMode)
            {
                hasSelection = !_nativeConversionCompleted && _nativeConversionPlan != null &&
                    _nativeConversionPlan.InitialTarget != null;
            }
            else
            {
                try
                {
                    hasSelection = _sel != null && _sel.Targets != null &&
                        _sel.Targets.Count > 0 && _sel.HasTargetsForActiveDocument;
                }
                catch { hasSelection = false; }
            }
            // Assignment is deliberate even if the parent is temporarily hidden: the
            // control's own visibility/enabled state must be correct when the layout becomes visible.
            // Preview is supported for a selected tapered edge as a non-transacting schematic.
            bPreview.Visible = hasSelection;
            bPreview.Enabled = hasSelection && !_buildInProgress && !_closing;
        }

        // the set of selected edges changed
        private void OnSelectionChanged()
        {
            ClearThreadPreview();
            var list = _sel.Targets;
            bool hasSelection = list != null && list.Count > 0;
            SyncPreviewButtonVisibility();
            ThreadTarget first = hasSelection ? list[0] : null;
            bool refChanged = (Target == null) != (first == null) ||
                              (first != null && (Math.Abs(first.RadiusCm - Target.RadiusCm) > 0.0005 || first.IsExternal != Target.IsExternal));
            Target = first;
            UpdateBoundSliderRanges();
            if (refChanged) CancelTaperAutoSelection();

            UpdateUndoButton();
            if (first == null)
            {
                lTarget.Text = "Выберите на модели круговые рёбра, с которых начинается резьба. " +
                               "Можно выбрать несколько рёбер одного диаметра; повторный щелчок снимает выбор.";
                RebuildLists();   // full list again
                UpdateInfo();
                return;
            }

            lTarget.Text = string.Format("Выбрано рёбер: {0} · Ø {1:0.###} мм, {2}, длина от ребра {3:0.##} мм",
                list.Count, first.RadiusCm * 20.0, first.IsExternal ? "наружная" : "внутренняя (отверстие)", first.LengthCm * 10.0)
                + (first.StartIsShoulder ? "; начало у буртика" : "") + (first.EndIsShoulder ? "; конец у буртика" : "");

            if (refChanged)   // new diameter / type: choose the size again (otherwise keep the user's choice)
            {
                _loading = true;
                rbExt.Checked = first.IsExternal;
                rbInt.Checked = !first.IsExternal;
                _loading = false;
                RebuildLists();
                AutoSelectSize();
            }
            if (chTapered != null && chTapered.Checked)
                RefreshTaperDesignations(true);
            UpdateInfo();
        }

        // Preserve the selected cylinder's diameter as the nominal diameter for both
        // external and internal threads. A table match is permitted only when that exact
        // nominal diameter exists in the selected standard; do not substitute an internal
        // minor-diameter match (which silently changes Ø45 to e.g. Ø49.05).
        private void AutoSelectSize()
        {
            if (Target == null) return;
            double faceDia = Target.RadiusCm * 20.0;
            double currentPitch = PitchMm;

            ThreadSize best = _all
                .Where(s => ThreadNominalDiameterPolicy.MatchesStandardDiameter(faceDia, s.DiameterMm))
                .OrderBy(s => currentPitch > 0.0 ? Math.Abs(s.PitchMm - currentPitch) : 0.0)
                .FirstOrDefault();

            lStatus.ForeColor = UiText;
            if (best != null)
            {
                SelectSize(best);
                // Keep the measured edge diameter as the displayed nominal diameter.
                // The match tolerance above only absorbs geometric floating-point noise.
                _loading = true;
                cbDia.Text = FmtDia(ThreadNominalDiameterPolicy.PreserveSelectedDiameter(faceDia));
                _loading = false;
                SyncSizeCombo();
                lStatus.Text = "Типоразмер подобран по номинальному диаметру ребра: " + best.Name;
            }
            else
            {
                // No table entry for this nominal diameter: keep the selected edge's
                // diameter unchanged and let SyncSizeCombo select "Пользовательский".
                // The current pitch is deliberately retained for the user to confirm/edit;
                // technical clearance remains a separate profile parameter during build.
                _loading = true;
                cbDia.Text = FmtDia(ThreadNominalDiameterPolicy.PreserveSelectedDiameter(faceDia));
                FillPitchItems(faceDia);
                _loading = false;
                SyncSizeCombo();
                lStatus.Text = string.Format(
                    "Диаметр Ø{0:0.###} мм сохранён по выбранному ребру. В стандарте {1} нет такого номинального диаметра — используется «Пользовательский». Для шага доступны типовые варианты и ручной ввод.",
                    faceDia, ThreadStandards.Title(Std));
            }
        }

        // Build the name against the current standard's table, never against the selected
        // ComboBox object. During an edit-time template switch, a stale UI item from the
        // previous standard can have the same diameter/pitch (e.g. M45 x 3 vs Tr 45 x 3).
        private string BuildSizeName(double dia, double pitch)
        {
            return ThreadSizeNamePolicy.Build(Std, _all, dia, pitch);
        }

        private void UpdateInfo()
        {
            // Keep the current phantom alive while the debounced refresh updates it with the
            // latest parameters. The overlay uses only NonTransactingClientGraphics.
            RequestThreadPreviewRefresh();
            if (lInfo == null || cbPitch == null) return;

            string baseInfo = string.IsNullOrWhiteSpace(_lastBuildInfo)
                ? "Готово к построению."
                : _lastBuildInfo;

            if (chTapered != null && chTapered.Checked)
            {
                string currentStandard = cbTaperStandard == null ? string.Empty : Convert.ToString(cbTaperStandard.SelectedItem, Inv);
                string currentDesignation = cbTaperDesignation == null ? string.Empty : (cbTaperDesignation.Text ?? string.Empty).Trim();
                if (_lastTaperPitchMm > 0.0 && _lastTaperDepthMm > 0.0 &&
                    string.Equals(_lastTaperInfoStandard, currentStandard, StringComparison.OrdinalIgnoreCase) &&
                    string.Equals(_lastTaperInfoDesignation, currentDesignation, StringComparison.OrdinalIgnoreCase))
                {
                    lWarn.Text = string.Empty;
                    lInfo.Text = HelivantaLocalization.Translate(baseInfo + string.Format(Inv,
                        "\nШаг из таблицы Inventor = {0:0.###} мм · высота физического профиля = {1:0.###} мм\nФизическая винтовая канавка и нативное обозначение резьбы созданы.",
                        _lastTaperPitchMm, _lastTaperDepthMm));
                }
                else
                {
                    lInfo.Text = HelivantaLocalization.Translate(baseInfo + "\nКонический режим: шаг и высота профиля берутся из выбранной строки таблицы Inventor. Будут построены физические витки; цилиндрические поля шага и диаметра не используются.");
                }
                return;
            }

            double pitch = PitchMm, dia = DiaMm, clr = (double)nClear.Value;
            int n = (int)nStarts.Value;
            if (pitch <= 0 || dia <= 0)
            {
                lInfo.Text = HelivantaLocalization.Translate(baseInfo + "\n\nУкажите диаметр и шаг.");
                return;
            }

            try
            {
                var spec = ThreadStandards.Spec(Std);
                UpdateClearanceWarning(spec, pitch, clr);
                var g = ThreadStandards.ComputeGroove(spec, IsExternal(), pitch, clr, pitch * n);
                string diam = "";
                if (Target != null)
                {
                    double R = IsExternal() ? dia / 2.0 : dia / 2.0 - ThreadStandards.MinorOffset(spec, pitch);
                    double faceDia = Target.RadiusCm * 20.0;
                    double sg = IsExternal() ? -1.0 : 1.0;
                    diam = string.Format("\nØ поверхности = {0:0.###} мм · расчётный Ø = {1:0.###} мм\nØ вершин зубьев = {2:0.###} мм · Ø оснований зубьев = {3:0.###} мм",
                        faceDia, 2.0 * R, 2.0 * (R + sg * g.CapDepth), 2.0 * (R + sg * g.Depth));
                    if (Math.Abs(faceDia - 2.0 * R) > 0.005)
                        diam += string.Format("\nДиаметр поверхности будет приведён к расчётному на {0:0.###} мм.", Math.Abs(faceDia - 2.0 * R));
                }
                string calculated = string.Format("\nХод (lead) = {0:0.###} мм · глубина профиля = {1:0.###} мм{2}",
                    pitch * n, g.Depth - g.CapDepth, diam);
                string toleranceClass = GetSelectedToleranceClass();
                if (!string.IsNullOrEmpty(toleranceClass))
                    calculated += "\n" + ThreadTolerancePolicy.GetDescription(toleranceClass) + ". " + ThreadTolerancePolicy.GeometryNotice;
                lInfo.Text = HelivantaLocalization.Translate(baseInfo + calculated);
            }
            catch (Exception ex)
            {
                lInfo.Text = HelivantaLocalization.Translate(baseInfo + "\n\n⚠ Ошибка расчёта информации: " + ex.Message);
            }
        }

        private void UpdateClearanceWarning(ThreadProfileSpec spec, double pitch, double clearance)
        {
            if (lWarn == null) return;

            if (clearance <= 0.0 || pitch <= 0.0)
            {
                lWarn.ForeColor = UiMuted;
                lWarn.Text = "";
                return;
            }

            try
            {
                // Warning threshold: when the TOTAL radial clearance reaches the
                // smaller basic thread depth, each mating surface is shifted by c/2
                // equal to at least half of that smaller depth. The geometry is still
                // buildable in the normal range, but reliable flank engagement is no
                // longer expected. This is a warning only; it must not block Build.
                var ext = ThreadStandards.ComputeGroove(spec, true, pitch, 0.0, pitch);
                var intr = ThreadStandards.ComputeGroove(spec, false, pitch, 0.0, pitch);
                double minDepth = Math.Min(ext.Depth, intr.Depth);
                bool excessive = clearance >= minDepth - 1e-9;

                if (!excessive)
                {
                    lWarn.ForeColor = UiMuted;
                    lWarn.Text = "";
                    return;
                }

                double perSide = clearance / 2.0;
                lWarn.Text = string.Format(
                    "⚠ Слишком большой зазор: {0:0.###} мм (по {1:0.###} мм на сторону) для профиля с меньшей базовой глубиной {2:0.###} мм. Болт и гайка могут не иметь нормального зацепления. Построение разрешено.",
                    clearance, perSide, minDepth);
                lWarn.ForeColor = UiError;
            }
            catch
            {
                lWarn.ForeColor = UiMuted;
                lWarn.Text = "";
            }
        }

        private string StdNameForInfo(ThreadStandard s)
        {
            switch (s)
            {
                case ThreadStandard.ISO: return "ISO";
                case ThreadStandard.BSW: return "BSW";
                case ThreadStandard.ANSI: return "ANSI";
                case ThreadStandard.Tr: return "Tr";
                case ThreadStandard.S: return "S";
                case ThreadStandard.Rd: return "Rd";
                default: return s.ToString();
            }
        }

        private sealed class BuiltThreadZone
        {
            public string DocumentId;
            public string BodyName;
            public double[] AxisPoint;
            public double[] Axis;
            public double RadiusCm;
            public bool External;
            public double Lo;
            public double Hi;
        }

        private sealed class ThreadParamsView
        {
            public bool FullLength;
            public double LengthMm;
            public double OffsetMm;
        }

        private static double Dot3(double[] a, double[] b)
        {
            return a[0] * b[0] + a[1] * b[1] + a[2] * b[2];
        }

        private static bool SameCylinder(ThreadTarget a, ThreadTarget b)
        {
            if (a == null || b == null) return false;
            if (!string.Equals(a.SourceDocumentInternalName, b.SourceDocumentInternalName, StringComparison.OrdinalIgnoreCase)) return false;
            return ThreadTargetIsolationPolicy.SameCylinderGeometry(
                a.BodyName, b.BodyName, a.RadiusCm, b.RadiusCm,
                a.Center, a.U, b.Center, b.U, requireBodyNames: false);
        }

        private static void GetThreadInterval(ThreadTarget t, ThreadParamsView p, double[] refAxis, double[] refOrigin, out double lo, out double hi)
        {
            double offset = p.OffsetMm / 10.0;
            double length = p.FullLength ? t.LengthCm - offset : p.LengthMm / 10.0;
            double[] delta = { t.Center[0] - refOrigin[0], t.Center[1] - refOrigin[1], t.Center[2] - refOrigin[2] };
            double startProjection = Dot3(delta, refAxis);
            double direction = Dot3(t.U, refAxis);
            double a = startProjection + direction * offset;
            double b = startProjection + direction * (offset + length);
            lo = Math.Min(a, b);
            hi = Math.Max(a, b);
        }

        private List<BuiltThreadZone> CreateBuildZones(List<ThreadTarget> targets, ThreadParams p)
        {
            var zones = new List<BuiltThreadZone>();
            if (targets == null) return zones;
            var view = new ThreadParamsView { FullLength = p.FullLength, LengthMm = p.LengthMm, OffsetMm = p.OffsetMm };
            if (p.Tapered && targets.Count == 1)
            {
                // Store the modified host-cone interval, not only the thread turns: the cone prep
                // starts at the originally selected edge, before ThreadFeature's configured offset.
                view.FullLength = false;
                view.LengthMm = p.FullLength ? targets[0].LengthCm * 10.0 : p.OffsetMm + p.LengthMm;
                view.OffsetMm = 0.0;
            }
            foreach (ThreadTarget t in targets)
            {
                double[] axis = (double[])t.U.Clone();
                double[] origin = (double[])t.Center.Clone();
                double lo, hi;
                GetThreadInterval(t, view, axis, origin, out lo, out hi);
                zones.Add(new BuiltThreadZone
                {
                    DocumentId = t.SourceDocumentInternalName,
                    BodyName = t.BodyName,
                    AxisPoint = origin,
                    Axis = axis,
                    RadiusCm = t.RadiusCm,
                    External = t.IsExternal,
                    Lo = lo,
                    Hi = hi
                });
            }
            return zones;
        }

        private bool ValidateNoThreadOverlap(List<ThreadTarget> targets, ThreadParams p, out string error)
        {
            error = null;
            if (targets == null || targets.Count == 0) return true;
            var view = new ThreadParamsView { FullLength = p.FullLength, LengthMm = p.LengthMm, OffsetMm = p.OffsetMm };

            // New selection versus itself. Opposite ends of one cylinder are allowed only
            // when their requested axial zones do not overlap.
            for (int i = 0; i < targets.Count; i++)
            {
                for (int j = i + 1; j < targets.Count; j++)
                {
                    if (!SameCylinder(targets[i], targets[j])) continue;
                    double a0, a1, b0, b1;
                    GetThreadInterval(targets[i], view, targets[i].U, targets[i].Center, out a0, out a1);
                    GetThreadInterval(targets[j], view, targets[i].U, targets[i].Center, out b0, out b1);
                    if (Math.Min(a1, b1) - Math.Max(a0, b0) > 1e-4)
                    {
                        error = string.Format("Построение запрещено: выбранные зоны резьбы перекрываются на одной цилиндрической поверхности Ø {0:0.###} мм. Уменьшите длину/отступ или выберите другое ребро.", targets[i].RadiusCm * 20.0);
                        return false;
                    }
                }
            }

            foreach (List<BuiltThreadZone> group in _buildZones)
            {
                foreach (BuiltThreadZone old in group)
                {
                    foreach (ThreadTarget t in targets)
                    {
                        if (!string.IsNullOrWhiteSpace(old.DocumentId) &&
                            !string.IsNullOrWhiteSpace(t.SourceDocumentInternalName) &&
                            !string.Equals(old.DocumentId, t.SourceDocumentInternalName, StringComparison.OrdinalIgnoreCase)) continue;
                        if (string.IsNullOrWhiteSpace(old.DocumentId) || string.IsNullOrWhiteSpace(t.SourceDocumentInternalName))
                        {
                            error = "Построение остановлено: невозможно подтвердить принадлежность существующей резьбы и новой зоны одному документу Inventor. Для безопасности модель не изменена.";
                            return false;
                        }
                        // External/internal is deliberately NOT part of overlap identity: an
                        // overlapping coaxial zone must not be accepted only because Inventor
                        // classified the selected ends differently. Keep this geometry test shared
                        // with the same-selection and persisted-edit checks.
                        if (!ThreadTargetIsolationPolicy.SameCylinderGeometry(
                            old.BodyName, t.BodyName, old.RadiusCm, t.RadiusCm,
                            old.AxisPoint, old.Axis, t.Center, t.U, requireBodyNames: false)) continue;
                        double n0, n1;
                        GetThreadInterval(t, view, old.Axis, old.AxisPoint, out n0, out n1);
                        if (Math.Min(old.Hi, n1) - Math.Max(old.Lo, n0) > 1e-4)
                        {
                            error = string.Format("Построение запрещено: новая резьба перекрывает уже созданную резьбу на той же цилиндрической поверхности Ø {0:0.###} мм. Сначала сократите длину/измените отступ или отмените предыдущую резьбу.", t.RadiusCm * 20.0);
                            return false;
                        }
                    }
                }
            }
            Inventor.ThreadFeature ignoredNativeFeature = _nativeConversionMode && _nativeConversionPlan != null
                ? _nativeConversionPlan.Feature : null;
            if (!NativeThreadOverlapGuard.ValidateNoOverlap(_app, targets, p, ignoredNativeFeature, out error))
                return false;
            return true;
        }

        private ThreadParams CreateCurrentThreadParams()
        {
            double pitch = PitchMm;
            double dia = DiaMm;
            return new ThreadParams
            {
                Standard = Std,
                SizeName = BuildSizeName(dia, pitch),
                PitchMm = pitch,
                NominalDiaMm = dia,
                Starts = (int)nStarts.Value,
                ClearanceMm = (double)nClear.Value,
                External = IsExternal(),
                FullLength = chFull.Checked,
                LengthMm = (double)nLen.Value,
                OffsetMm = (double)nOff.Value,
                RunOut = chRun.Checked,
                RightHand = rbR.Checked,
                Round = chRound.Checked,
                Smooth = true,
                SimplifiedRunout = false,
                RunSteps = (double)nRun.Value,
                Mirror = chMirror.Checked && Std == ThreadStandard.S,
                SortThreadsIntoFolders = chSortFolders != null && chSortFolders.Checked,
                ChamferMode = ThreadChamferSelectionPolicy.ResolveChamferMode(
                    chCham.Checked, cbCham.SelectedIndex, _lastCommittedChamferIndex, cbCham.Items.Count),
                ChamferMm = (double)nCham.Value,
                ToleranceClass = GetSelectedToleranceClass(),
                Tapered = chTapered != null && chTapered.Checked,
                TaperGeometryMode = chTaperStrictStandard == null || chTaperStrictStandard.Checked
                    ? TaperGeometryModeKind.StrictStandard : TaperGeometryModeKind.FreeGeometry,
                TaperRatio = nTaperRatio != null ? (double)nTaperRatio.Value : 0.0625,
                TaperStandard = cbTaperStandard != null ? Convert.ToString(cbTaperStandard.SelectedItem, Inv) : string.Empty,
                TaperDesignation = cbTaperDesignation != null ? (cbTaperDesignation.Text ?? string.Empty).Trim() : string.Empty,
                TaperReferenceDiameterMm = dia,
                TaperReferenceLengthMm = (double)nLen.Value,
                TaperStartDiameterMm = dia,
                TaperEndDiameterMm = dia - ((double)nTaperRatio.Value * (double)nLen.Value)
            };
        }

        private void ApplyTaperModeUI(bool tapered)
        {
            if (_taperModeTransitionInProgress) return;
            if (!tapered) CancelTaperAutoSelection();

            _taperModeTransitionInProgress = true;
            bool wasLoadingAtEntry = _loading;
            List<Control> owners = CollectTaperLayoutOwners();
            var suspendedOwners = new List<Control>();

            try
            {
                // Suspend layout on affected containers from outermost to innermost. Do not send
                // WM_SETREDRAW to every child HWND: native ComboBox/NumericUpDown windows manage
                // their own non-client arrows and can retain stale bounds after recursive redraw locks.
                foreach (Control owner in owners)
                {
                    if (owner == null || owner.IsDisposed) continue;
                    owner.SuspendLayout();
                    suspendedOwners.Add(owner);
                }

                _loading = true;
                if (_threadSizeSection != null && !_threadSizeSection.IsDisposed)
                    _threadSizeSection.Visible = !tapered;
                if (chTaperStrictStandard != null && !chTaperStrictStandard.IsDisposed)
                    chTaperStrictStandard.Visible = tapered;
                if (lTaperGeometryModeNote != null && !lTaperGeometryModeNote.IsDisposed)
                    lTaperGeometryModeNote.Visible = tapered && !chTaperStrictStandard.Checked;
                if (cbTaperStandard != null) cbTaperStandard.Enabled = tapered;
                if (cbTaperDesignation != null) cbTaperDesignation.Enabled = tapered;

                if (tapered)
                {
                    if (_preTaperEnabledStates != null)
                    {
                        SetTaperCylinderRowsVisible(false);
                    }
                    else
                    {
                        _preTaperEnabledStates = new Dictionary<Control, bool>();
                        _preTaperChamferChecked = chCham != null && chCham.Checked;
                        _preTaperChamferIndex = cbCham == null ? -1 : cbCham.SelectedIndex;
                        _preTaperChamferMm = nCham == null ? 1m : nCham.Value;
                        _fullLengthBeforeTaperMode = chFull != null && chFull.Checked;
                        _clearanceBeforeTaperMode = nClear == null ? 0m : nClear.Value;
                        _preTaperRunOutChecked = chRun != null && chRun.Checked;
                        _preTaperRoundChecked = chRound != null && chRound.Checked;
                        Control[] controlsNotImplementedForNativeTaper =
                        {
                            cbStd, cbSize, cbDia, cbPitch, cbMat, cbTolerance,
                            nStarts, nClear, chRun, chRound, chMirror
                        };
                        foreach (Control control in controlsNotImplementedForNativeTaper)
                        {
                            if (control == null) continue;
                            _preTaperEnabledStates[control] = control.Enabled;
                        }

                        if (chRun != null) chRun.Checked = false;
                        if (chRound != null) chRound.Checked = false;
                        if (chFull != null) chFull.Checked = false;
                        if (nClear != null) nClear.Value = 0m;

                        foreach (Control control in controlsNotImplementedForNativeTaper)
                            if (control != null) control.Enabled = false;

                        if (nStarts != null)
                        {
                            _startsBeforeTaperMode = nStarts.Value;
                            if (nStarts.Value != 1m) nStarts.Value = 1m;
                        }
                        SetTaperCylinderRowsVisible(false);
                    }
                }
                else
                {
                    SetTaperCylinderRowsVisible(true);
                    if (_preTaperEnabledStates != null)
                    {
                        foreach (KeyValuePair<Control, bool> state in _preTaperEnabledStates)
                            if (state.Key != null && !state.Key.IsDisposed) state.Key.Enabled = state.Value;
                        _preTaperEnabledStates = null;

                        if (chRun != null) chRun.Checked = _preTaperRunOutChecked;
                        if (chRound != null) chRound.Checked = _preTaperRoundChecked;
                        if (chCham != null) chCham.Checked = _preTaperChamferChecked;
                        if (cbCham != null && cbCham.Items.Count > 0)
                            cbCham.SelectedIndex = ThreadChamferSelectionPolicy.IsValidIndex(_preTaperChamferIndex, cbCham.Items.Count)
                                ? _preTaperChamferIndex : (_preTaperChamferChecked ? 0 : -1);
                        if (nCham != null) nCham.Value = ClampDecimal((double)_preTaperChamferMm, nCham.Minimum, nCham.Maximum);
                        if (chFull != null) chFull.Checked = _fullLengthBeforeTaperMode;
                        if (nClear != null) nClear.Value = ClampDecimal((double)_clearanceBeforeTaperMode, nClear.Minimum, nClear.Maximum);

                        _taperLengthOverrideNoticeShown = false;
                        if (nStarts != null)
                            nStarts.Value = ClampDecimal((double)_startsBeforeTaperMode, nStarts.Minimum, nStarts.Maximum);
                    }
                }

                SyncChamferSegmentButtons();
            }
            catch (Exception ex)
            {
                BrowserTreeDiagnostics.WriteEvent("ThreadDialog", "taper-mode-layout-mutation-failed",
                    "tapered=" + tapered + "; " + ex.GetType().Name + ": " + ex.Message);
                if (lStatus != null && !lStatus.IsDisposed)
                {
                    lStatus.ForeColor = UiWarning;
                    lStatus.Text = "Не удалось полностью обновить компоновку конического режима. Переключите режим ещё раз; модель не изменялась.";
                }
            }
            finally
            {
                // Release layout locks child-first without performing nested intermediate layouts.
                // The explicit reflow below then recalculates preferred sizes from the changed rows
                // through the section cards to the scroll viewport in a deterministic order.
                for (int i = suspendedOwners.Count - 1; i >= 0; i--)
                {
                    Control owner = suspendedOwners[i];
                    if (owner == null || owner.IsDisposed) continue;
                    try { owner.ResumeLayout(false); }
                    catch (Exception ex)
                    {
                        BrowserTreeDiagnostics.WriteEvent("ThreadDialog", "taper-layout-resume-failed",
                            "control=" + owner.GetType().Name + "; " + ex.GetType().Name + ": " + ex.Message);
                    }
                }

                try { ReflowTaperModeLayout(); }
                finally
                {
                    _loading = wasLoadingAtEntry;
                    _taperModeTransitionInProgress = false;
                    // After the final layout, repaint the native HWND tree once. This clears
                    // any custom non-client arrow pixels left by hidden/moved ComboBox and
                    // NumericUpDown controls, without suppressing redraw or painting on mouse messages.
                    RedrawNativeControlTreeAfterTaperTransition();
                }
            }
        }

        private void ReflowTaperModeLayout()
        {
            Control taperGrid = chTapered != null ? chTapered.Parent : null;
            Control taperSection = taperGrid != null ? taperGrid.Parent : null;
            Control buildSection = _buildGrid != null ? _buildGrid.Parent : null;

            // Inner controls establish their preferred sizes first; the sections then update their
            // AutoSize heights; the vertical stack and viewport finally recompute scrolling bounds.
            TryTaperPerformLayout(taperGrid, "taper-grid");
            TryTaperPerformLayout(taperSection, "taper-section");
            TryTaperPerformLayout(_buildGrid, "build-grid");
            TryTaperPerformLayout(buildSection, "build-section");
            TryTaperPerformLayout(_threadSizeSection, "thread-size-section");

            // A scrollbar can appear/disappear after section heights are recalculated. Iterate to a
            // stable viewport width (bounded to four passes) so labels and child controls never keep
            // widths from the prior mode. ResizeSectionWidths itself also performs parent layout.
            for (int pass = 0; pass < 4; pass++)
            {
                TryTaperPerformLayout(bodyStack, "body-stack-" + pass.ToString(CultureInfo.InvariantCulture));
                TryTaperPerformLayout(root, "root-" + pass.ToString(CultureInfo.InvariantCulture));
                TryTaperPerformLayout(bodyViewport, "body-viewport-" + pass.ToString(CultureInfo.InvariantCulture));

                if (bodyViewport == null || bodyViewport.IsDisposed) break;
                int targetWidth = Math.Max(300, bodyViewport.ClientSize.Width - 2);
                if (targetWidth == _lastSectionWidth) break;

                try { ResizeSectionWidths(); }
                catch (Exception ex)
                {
                    BrowserTreeDiagnostics.WriteEvent("ThreadDialog", "taper-responsive-layout-failed",
                        "pass=" + pass.ToString(CultureInfo.InvariantCulture) + "; " +
                        ex.GetType().Name + ": " + ex.Message);
                    break;
                }
            }

            TryTaperPerformLayout(bodyStack, "body-stack-final");
            TryTaperPerformLayout(bodyViewport, "body-viewport-final");
        }

        private static void TryTaperPerformLayout(Control control, string phase)
        {
            if (control == null || control.IsDisposed) return;
            try { control.PerformLayout(); }
            catch (Exception ex)
            {
                BrowserTreeDiagnostics.WriteEvent("ThreadDialog", "taper-layout-pass-failed",
                    "phase=" + phase + "; control=" + control.GetType().Name + "; " +
                    ex.GetType().Name + ": " + ex.Message);
            }
        }

        private List<Control> CollectTaperLayoutOwners()
        {
            var set = new HashSet<Control>();
            Action<Control> addAncestors = control =>
            {
                for (Control current = control; current != null; current = current.Parent)
                {
                    // The form itself and leaf HWNDs do not participate in child layout. Keep
                    // only real containers; this avoids suspending the whole dialog around a toggle.
                    if (!(current is Form) && current.HasChildren)
                        set.Add(current);
                    if (current == this) break;
                }
            };
            addAncestors(chTapered);
            addAncestors(chTaperStrictStandard);
            addAncestors(cbTaperStandard);
            addAncestors(cbTaperDesignation);
            addAncestors(_threadSizeSection);
            addAncestors(nStarts);
            addAncestors(nClear);
            addAncestors(chRound);
            addAncestors(chRun);
            addAncestors(lTaperGeometryModeNote);
            return set.OrderBy(ControlDepth).ToList();
        }

        private static int ControlDepth(Control control)
        {
            int depth = 0;
            for (Control current = control; current != null; current = current.Parent) depth++;
            return depth;
        }

        private bool _taperDesignationRefreshPending;

        private void ScheduleTaperDesignationRefresh(bool autoSelectForTarget)
        {
            if (cbTaperDesignation == null || _taperDesignationRefreshPending) return;
            if (!autoSelectForTarget && cbTaperDesignation.Items.Count > 0) return;
            _taperDesignationRefreshPending = true;
            Action refresh = () =>
            {
                _taperDesignationRefreshPending = false;
                if (IsDisposed || cbTaperDesignation == null || cbTaperDesignation.IsDisposed ||
                    chTapered == null || !chTapered.Checked) return;
                // Runs after the current message has completed. No explicit Refresh here:
                // mode transitions perform one full-tree redraw after the atomic layout change.
                RefreshTaperDesignations(autoSelectForTarget);
            };
            if (IsHandleCreated)
            {
                try { BeginInvoke(refresh); }
                catch { refresh(); }
            }
            else refresh();
        }

        private void SetTaperCylinderRowsVisible(bool visible)
        {
            if (_buildGrid == null || _buildGrid.IsDisposed) return;
            SetBuildRowVisible(nStarts, visible);
            SetBuildRowVisible(nClear, visible);
            SetBuildRowVisible(chRound, visible);
            SetIndividualControlVisible(chRun, visible);
        }

        private void SetBuildRowVisible(Control descendant, bool visible)
        {
            if (descendant == null || _buildGrid == null || _buildGrid.IsDisposed) return;
            Control direct = descendant;
            while (direct != null && direct.Parent != _buildGrid) direct = direct.Parent;
            if (direct == null) return;
            int row = _buildGrid.GetRow(direct);
            if (row < 0 || row >= _buildGrid.RowStyles.Count) return;

            if (!visible)
            {
                if (!_preTaperBuildRowStyles.ContainsKey(row))
                {
                    RowStyle current = _buildGrid.RowStyles[row];
                    _preTaperBuildRowStyles[row] = new TaperRowStyleSnapshot
                    {
                        SizeType = current.SizeType,
                        Height = current.Height
                    };
                }
                _buildGrid.RowStyles[row].SizeType = SizeType.Absolute;
                _buildGrid.RowStyles[row].Height = 0f;
            }
            else if (_preTaperBuildRowStyles.TryGetValue(row, out TaperRowStyleSnapshot savedStyle))
            {
                _buildGrid.RowStyles[row].SizeType = savedStyle.SizeType;
                _buildGrid.RowStyles[row].Height = savedStyle.Height;
                _preTaperBuildRowStyles.Remove(row);
            }

            foreach (Control control in _buildGrid.Controls)
            {
                if (_buildGrid.GetRow(control) != row) continue;
                SetSavedVisibility(control, visible);
            }
        }

        private void SetIndividualControlVisible(Control control, bool visible)
        {
            if (control != null) SetSavedVisibility(control, visible);
        }

        private void SetSavedVisibility(Control control, bool visible)
        {
            if (control == null || control.IsDisposed) return;
            if (!visible)
            {
                if (!_preTaperVisibleStates.ContainsKey(control))
                    _preTaperVisibleStates[control] = control.Visible;
                control.Visible = false;
            }
            else if (_preTaperVisibleStates.TryGetValue(control, out bool wasVisible))
            {
                control.Visible = wasVisible;
                _preTaperVisibleStates.Remove(control);
            }
        }

        private string GetTaperAutoSelectionKey()
        {
            if (Target == null || cbTaperStandard == null) return string.Empty;
            return string.Join("|", new string[]
            {
                Convert.ToString(cbTaperStandard.SelectedItem, Inv) ?? string.Empty,
                IsExternal() ? "external" : "internal",
                (Target.RadiusCm * 20.0).ToString("0.###", Inv)
            });
        }

        private void CancelTaperAutoSelection()
        {
            if (_taperAutoSelectTimer != null)
            {
                try { _taperAutoSelectTimer.Stop(); _taperAutoSelectTimer.Dispose(); } catch { }
                _taperAutoSelectTimer = null;
            }
            _taperAutoSelectDesignations = null;
            _taperAutoSelectCandidates = null;
            _taperAutoSelectQuery = null;
            _taperAutoSelectIndex = 0;
            _taperAutoSelectKey = null;
        }

        private void ScheduleClosestTaperDesignationSelection()
        {
            if (IsDisposed || Target == null || cbTaperDesignation == null || cbTaperDesignation.Items.Count == 0)
                return;
            string key = GetTaperAutoSelectionKey();
            if (string.IsNullOrEmpty(key) || string.Equals(key, _lastTaperAutoSelectionKey, StringComparison.Ordinal))
                return;
            if (_taperAutoSelectTimer != null && string.Equals(key, _taperAutoSelectKey, StringComparison.Ordinal))
                return;

            CancelTaperAutoSelection();
            string type = Convert.ToString(cbTaperStandard.SelectedItem, Inv);
            double ratio;
            if (!TaperedThreadGeometryPolicy.TryGetDiameterRatio(type, out ratio)) return;

            try
            {
                dynamic query = _app.GeneralOptions.ThreadTableQuery;
                string tableType = TaperThreadTableResolver.ResolveQueryType((object)query, type, IsExternal(), out _);
                _taperAutoSelectQuery = (object)query;
                _taperAutoSelectTableType = tableType;
            }
            catch (Exception ex)
            {
                BrowserTreeDiagnostics.WriteEvent("ThreadDialog", "taper-auto-select-cache-start-failed",
                    "key=" + key + "; error=" + ex.GetType().Name + ": " + ex.Message);
                return;
            }

            _taperAutoSelectKey = key;
            _taperAutoSelectType = type;
            _taperAutoSelectTargetDiameterMm = Target.RadiusCm * 20.0;
            _taperAutoSelectRatio = ratio;
            _taperAutoSelectExternal = IsExternal();
            _taperAutoSelectRight = rbR != null && rbR.Checked;
            _taperAutoSelectDesignations = cbTaperDesignation.Items.Cast<object>()
                .Select(item => Convert.ToString(item, Inv))
                .Where(value => !string.IsNullOrWhiteSpace(value)).Distinct(StringComparer.OrdinalIgnoreCase).ToList();
            _taperAutoSelectCandidates = new List<Tuple<string, double>>();
            _taperAutoSelectIndex = 0;
            _taperAutoSelectTimer = new System.Windows.Forms.Timer { Interval = 15 };
            _taperAutoSelectTimer.Tick += (sender, args) => ProcessTaperAutoSelectionBatch();
            _taperAutoSelectTimer.Start();
        }

        private void ProcessTaperAutoSelectionBatch()
        {
            if (IsDisposed || _taperAutoSelectTimer == null) { CancelTaperAutoSelection(); return; }
            if (!string.Equals(_taperAutoSelectKey, GetTaperAutoSelectionKey(), StringComparison.Ordinal))
            {
                CancelTaperAutoSelection();
                return;
            }

            // Each timer tick reads only a couple of table rows. This gives WinForms/Inventor
            // opportunities to paint and process input instead of blocking the entire mode switch
            // while dozens of COM CreateThreadInfo calls run in one message handler.
            int end = Math.Min(_taperAutoSelectIndex + 2, _taperAutoSelectDesignations.Count);
            while (_taperAutoSelectIndex < end)
            {
                string designation = _taperAutoSelectDesignations[_taperAutoSelectIndex++];
                try
                {
                    dynamic query = _taperAutoSelectQuery;
                    dynamic info = query.CreateThreadInfo(!_taperAutoSelectExternal, _taperAutoSelectRight,
                        _taperAutoSelectTableType, designation);
                    bool metric = Convert.ToBoolean(info.Metric, Inv);
                    double tableDiameter;
                    if (_taperAutoSelectExternal)
                    {
                        tableDiameter = double.NaN;
                        try
                        {
                            double outside = Convert.ToDouble(info.OutsidePipeDiameter, Inv);
                            if (IsValidPositiveFinite(outside)) tableDiameter = outside;
                        }
                        catch { }
                        if (!IsValidPositiveFinite(tableDiameter))
                        {
                            try { tableDiameter = Convert.ToDouble(info.NominalExternalDiameter, Inv); }
                            catch { tableDiameter = double.NaN; }
                        }
                        if (!metric && IsValidPositiveFinite(tableDiameter)) tableDiameter *= 25.4;
                    }
                    else
                    {
                        tableDiameter = Convert.ToDouble(info.BasicMinorDiameter, Inv);
                        if (!metric) tableDiameter *= 25.4;
                        double lengthMm;
                        if (!TryGetTaperStandardLengthFromInfo(info, _taperAutoSelectType, false, out lengthMm))
                            continue;
                        tableDiameter += lengthMm * _taperAutoSelectRatio;
                    }

                    if (IsValidPositiveFinite(tableDiameter))
                        _taperAutoSelectCandidates.Add(Tuple.Create(designation, tableDiameter));
                }
                catch { /* One unsupported/legacy designation must not stop the other rows. */ }
            }

            if (_taperAutoSelectIndex >= _taperAutoSelectDesignations.Count)
                FinishTaperAutoSelection();
        }

        private static bool IsValidPositiveFinite(double value)
        {
            return !double.IsNaN(value) && !double.IsInfinity(value) && value > 0.0;
        }

        private static bool TryGetTaperStandardLengthFromInfo(object threadInfo, string standard, bool external, out double lengthMm)
        {
            lengthMm = 0.0;
            if (threadInfo == null) return false;
            try
            {
                dynamic info = threadInfo;
                bool metric = Convert.ToBoolean(info.Metric, Inv);
                string[] properties = external
                    ? new[] { "OverallExternalLength", "NominalExternalLength", "EffectiveLength", "EngagementLength" }
                    : string.Equals((standard ?? string.Empty).Trim(), "NPT", StringComparison.OrdinalIgnoreCase)
                        ? new[] { "EffectiveLength", "EngagementLength", "NominalExternalLength", "OverallExternalLength" }
                        : new[] { "EngagementLength", "EffectiveLength", "NominalExternalLength", "OverallExternalLength" };
                foreach (string propertyName in properties)
                {
                    try
                    {
                        double raw;
                        switch (propertyName)
                        {
                            case "OverallExternalLength": raw = Convert.ToDouble(info.OverallExternalLength, Inv); break;
                            case "NominalExternalLength": raw = Convert.ToDouble(info.NominalExternalLength, Inv); break;
                            case "EffectiveLength": raw = Convert.ToDouble(info.EffectiveLength, Inv); break;
                            case "EngagementLength": raw = Convert.ToDouble(info.EngagementLength, Inv); break;
                            default: continue;
                        }
                        double candidate = metric ? raw : raw * 25.4;
                        if (IsValidPositiveFinite(candidate)) { lengthMm = candidate; return true; }
                    }
                    catch { }
                }
            }
            catch { }
            return false;
        }

        private void FinishTaperAutoSelection()
        {
            string key = _taperAutoSelectKey;
            string closest = null;
            try
            {
                closest = TaperedThreadGeometryPolicy.FindClosestDesignation(
                    _taperAutoSelectTargetDiameterMm, _taperAutoSelectCandidates);
            }
            catch { }

            CancelTaperAutoSelection();
            if (IsDisposed || Target == null || !string.Equals(key, GetTaperAutoSelectionKey(), StringComparison.Ordinal)) return;
            _lastTaperAutoSelectionKey = key;

            bool wasRefreshing = _refreshingTaperDesignations;
            _refreshingTaperDesignations = true;
            try
            {
                if (!string.IsNullOrWhiteSpace(closest) && cbTaperDesignation.Items.Contains(closest))
                    cbTaperDesignation.SelectedItem = closest;
                else
                {
                    cbTaperDesignation.SelectedIndex = -1;
                    cbTaperDesignation.Text = string.Empty;
                }
            }
            finally { _refreshingTaperDesignations = wasRefreshing; }

            if (chTapered != null && chTapered.Checked && !string.IsNullOrWhiteSpace(cbTaperDesignation.Text))
                ApplyTaperTableLengthFromTable();
            else if (chTapered != null && chTapered.Checked && lStatus != null && string.IsNullOrWhiteSpace(closest))
            {
                lStatus.ForeColor = UiWarning;
                lStatus.Text = string.Format(Inv,
                    "Не удалось автоматически подобрать типоразмер {1} для ребра Ø{0:0.###} мм. Проверьте выбор в списке. Перед любым изменением геометрии Helivanta покажет расчёт диаметров и запросит подтверждение.",
                    Target.RadiusCm * 20.0, _taperAutoSelectType ?? string.Empty);
            }
            UpdateInfo();
        }

        private void RefreshTaperDesignations(bool autoSelectForTarget = true)
        {
            if (cbTaperDesignation == null || cbTaperStandard == null) return;
            CancelTaperAutoSelection();
            bool wasRefreshingTaper = _refreshingTaperDesignations;
            _refreshingTaperDesignations = true;
            string type = Convert.ToString(cbTaperStandard.SelectedItem, Inv);
            string previous = cbTaperDesignation.Text;
            cbTaperDesignation.BeginUpdate();
            string closestDesignation = null;
            int availableSizeCount = 0;
            int availableDesignationCount = 0;
            Exception tableQueryException = null;
            string tableTypeDiagnostic = "not-resolved";
            try
            {
                cbTaperDesignation.Items.Clear();
                try
                {
                    dynamic query = _app.GeneralOptions.ThreadTableQuery;
                    string tableType = TaperThreadTableResolver.ResolveQueryType((object)query, type, IsExternal(), out tableTypeDiagnostic);
                    BrowserTreeDiagnostics.WriteEvent("ThreadDialog", "taper-thread-table-type-resolved",
                        "displayType=" + type + "; queryType=" + tableType + "; external=" + IsExternal() +
                        "; targetDiameterMm=" + (Target == null ? "none" : (Target.RadiusCm * 20.0).ToString("0.###", Inv)) +
                        "; resolution=" + (tableTypeDiagnostic ?? string.Empty));
                    string[] sizes = query.GetAvailableThreadSizes(!IsExternal(), tableType);
                    availableSizeCount = sizes == null ? 0 : sizes.Length;
                    if (sizes != null)
                    {
                        foreach (string size in sizes)
                        {
                            if (string.IsNullOrWhiteSpace(size)) continue;
                            string[] designations = query.GetAvailableDesignations(!IsExternal(), tableType, size);
                            if (designations == null) continue;
                            availableDesignationCount += designations.Length;
                            foreach (string designation in designations)
                                if (!string.IsNullOrWhiteSpace(designation) && !cbTaperDesignation.Items.Contains(designation))
                                    cbTaperDesignation.Items.Add(designation);
                        }
                    }
                }
                catch (Exception ex)
                {
                    tableQueryException = ex;
                }

                if (cbTaperDesignation.Items.Count == 0)
                {
                    string availableTypes = "unavailable";
                    string typeQueryError = null;
                    try
                    {
                        dynamic query = _app.GeneralOptions.ThreadTableQuery;
                        string[] types = query.GetAvailableThreadTypes();
                        availableTypes = types == null ? "<null>" : string.Join("; ", types);
                    }
                    catch (Exception ex) { typeQueryError = ex.GetType().Name + ": " + ex.Message; }
                    BrowserTreeDiagnostics.WriteEvent("ThreadDialog", "taper-designations-empty",
                        "type=" + type + "; external=" + IsExternal() + "; sizes=" + availableSizeCount +
                        "; designationRows=" + availableDesignationCount + "; tableTypeResolution=" + tableTypeDiagnostic +
                        "; availableThreadTypes=" + availableTypes +
                        "; getAvailableTypesError=" + typeQueryError + "; queryError=" +
                        (tableQueryException == null ? "none" : tableQueryException.ToString()));
                }

                if (autoSelectForTarget && Target != null && cbTaperDesignation.Items.Count > 0)
                    closestDesignation = FindClosestTaperDesignation(type);

                if (!string.IsNullOrWhiteSpace(closestDesignation) && cbTaperDesignation.Items.Contains(closestDesignation))
                {
                    cbTaperDesignation.SelectedItem = closestDesignation;
                }
                else if (Target != null && autoSelectForTarget)
                {
                    // Never silently default a Ø22 edge to the first tiny NPT designation.
                    cbTaperDesignation.SelectedIndex = -1;
                    cbTaperDesignation.Text = string.Empty;
                }
                else if (!string.IsNullOrWhiteSpace(previous) && cbTaperDesignation.Items.Contains(previous))
                {
                    cbTaperDesignation.SelectedItem = previous;
                }
                else if (cbTaperDesignation.Items.Count > 0)
                {
                    cbTaperDesignation.SelectedIndex = 0;
                }
                else cbTaperDesignation.Text = previous;
            }
            finally
            {
                cbTaperDesignation.EndUpdate();
                _refreshingTaperDesignations = wasRefreshingTaper;
            }

            BrowserTreeDiagnostics.WriteEvent("ThreadDialog", "taper-designations-refreshed",
                "displayType=" + type + "; external=" + IsExternal() +
                "; targetDiameterMm=" + (Target == null ? "none" : (Target.RadiusCm * 20.0).ToString("0.###", Inv)) +
                "; sizes=" + availableSizeCount + "; designationRows=" + availableDesignationCount +
                "; items=" + cbTaperDesignation.Items.Count + "; closest=" + (closestDesignation ?? "none") +
                "; selected=" + (cbTaperDesignation.SelectedItem == null ? "none" : Convert.ToString(cbTaperDesignation.SelectedItem, Inv)) +
                "; error=" + (tableQueryException == null ? "none" : tableQueryException.GetType().Name + ": " + tableQueryException.Message));

            if (autoSelectForTarget && Target != null)
                _lastTaperAutoSelectionKey = GetTaperAutoSelectionKey();

            if (!wasRefreshingTaper && chTapered != null && chTapered.Checked &&
                !string.IsNullOrWhiteSpace(cbTaperDesignation.Text))
                ApplyTaperTableLengthFromTable();

            if (Target != null && autoSelectForTarget && string.IsNullOrWhiteSpace(closestDesignation) && chTapered != null && chTapered.Checked && lStatus != null)
            {
                lStatus.ForeColor = UiWarning;
                lStatus.Text = string.Format(Inv,
                    "Не удалось автоматически подобрать типоразмер {1} для ребра Ø{0:0.###} мм. Проверьте выбор в списке. Перед любым изменением геометрии Helivanta покажет расчёт диаметров и запросит подтверждение.",
                    Target.RadiusCm * 20.0, type);
            }
        }

        private void ApplyTaperTableLengthFromTable()
        {
            if (_loading || _settingTaperTableLength || chTapered == null || !chTapered.Checked ||
                cbTaperStandard == null || cbTaperDesignation == null || nLen == null || chFull == null)
                return;

            string type = Convert.ToString(cbTaperStandard.SelectedItem, Inv);
            string designation = (cbTaperDesignation.Text ?? string.Empty).Trim();
            double tableLengthMm;
            string tableField;
            string error;
            if (!TryGetTaperStandardLengthMm(type, designation, IsExternal(), out tableLengthMm, out tableField, out error))
            {
                if (lStatus != null)
                {
                    lStatus.ForeColor = UiWarning;
                    lStatus.Text = "Не удалось получить стандартную длину конической резьбы из таблицы Inventor. " +
                        (error ?? "Укажите длину вручную; она будет считаться нестандартной.");
                }
                return;
            }

            if (tableLengthMm < (double)nLen.Minimum || tableLengthMm > (double)nLen.Maximum)
            {
                if (lStatus != null)
                {
                    lStatus.ForeColor = UiWarning;
                    lStatus.Text = string.Format(Inv,
                        "Табличная длина {0:0.###} мм ({1}) выходит за диапазон поля длины. Укажите допустимую длину вручную; построение будет нестандартным.",
                        tableLengthMm, tableField);
                }
                return;
            }

            bool wasLoading = _loading;
            _loading = true;
            _settingTaperTableLength = true;
            try
            {
                chFull.Checked = false;
                nLen.Value = ClampDecimal(tableLengthMm, nLen.Minimum, nLen.Maximum);
            }
            finally
            {
                _settingTaperTableLength = false;
                _loading = wasLoading;
            }

            _taperLengthOverrideNoticeShown = false;
            if (lStatus != null && Target != null &&
                tableLengthMm + (double)nOff.Value > Target.LengthCm * 10.0 + 1e-6)
            {
                lStatus.ForeColor = UiWarning;
                lStatus.Text = string.Format(Inv,
                    "Табличная длина конической резьбы {0:0.###} мм ({1}) превышает доступную длину поверхности с учётом отступа. Построение будет заблокировано, пока длина не станет допустимой.",
                    tableLengthMm, tableField);
            }
            else if (lStatus != null)
            {
                lStatus.ForeColor = UiMuted;
                lStatus.Text = string.Format(Inv,
                    "Длина конической резьбы установлена по таблице Inventor: {0:0.###} мм ({1}). Тех. зазор для стандартной конической посадки отключён.",
                    tableLengthMm, tableField);
            }
            UpdateInfo();
        }

        private bool TryGetTaperStandardLengthMm(string standard, string designation, bool external,
            out double lengthMm, out string sourceField, out string error)
        {
            lengthMm = 0.0;
            sourceField = null;
            error = null;
            if (string.IsNullOrWhiteSpace(standard) || string.IsNullOrWhiteSpace(designation))
            {
                error = "Не выбраны стандарт и табличное обозначение.";
                return false;
            }
            try
            {
                dynamic query = _app.GeneralOptions.ThreadTableQuery;
                string tableType = TaperThreadTableResolver.ResolveQueryType((object)query, standard, external, out string tableTypeDiagnostic);
                dynamic info = query.CreateThreadInfo(!external, rbR != null && rbR.Checked, tableType, designation);
                bool metric = Convert.ToBoolean(info.Metric, Inv);
                // For external tapered threads the user-facing standard length is the overall
                // external length. For internal NPT, prefer the effective length over the shorter
                // hand-tight engagement length; Build91 selected EngagementLength first (e.g.
                // 10.668 mm for NPT 1-1/2), making the modeled internal thread look truncated.
                string[] properties = external
                    ? new[] { "OverallExternalLength", "NominalExternalLength", "EffectiveLength", "EngagementLength" }
                    : string.Equals((standard ?? string.Empty).Trim(), "NPT", StringComparison.OrdinalIgnoreCase)
                        ? new[] { "EffectiveLength", "EngagementLength", "NominalExternalLength", "OverallExternalLength" }
                        : new[] { "EngagementLength", "EffectiveLength", "NominalExternalLength", "OverallExternalLength" };
                foreach (string propertyName in properties)
                {
                    try
                    {
                        // TaperedThreadInfo is a COM IDispatch object in Inventor. Read the
                        // known API properties through dynamic dispatch rather than reflection
                        // on the runtime __ComObject implementation.
                        double raw;
                        switch (propertyName)
                        {
                            case "OverallExternalLength": raw = Convert.ToDouble(info.OverallExternalLength, Inv); break;
                            case "NominalExternalLength": raw = Convert.ToDouble(info.NominalExternalLength, Inv); break;
                            case "EffectiveLength": raw = Convert.ToDouble(info.EffectiveLength, Inv); break;
                            case "EngagementLength": raw = Convert.ToDouble(info.EngagementLength, Inv); break;
                            default: continue;
                        }
                        double mm = metric ? raw : raw * 25.4;
                        if (!double.IsNaN(mm) && !double.IsInfinity(mm) && mm > 0.0)
                        {
                            lengthMm = mm;
                            sourceField = propertyName;
                            return true;
                        }
                    }
                    catch { }
                }
                error = "Таблица не предоставила положительную длину OverallExternalLength / NominalExternalLength / EffectiveLength / EngagementLength.";
                return false;
            }
            catch (Exception ex)
            {
                error = "Ошибка чтения TaperedThreadInfo: " + ex.Message;
                return false;
            }
        }

        private void MarkTaperLengthAsCustom(string reason)
        {
            if (chTapered == null || !chTapered.Checked) return;
            if (!_taperLengthOverrideNoticeShown)
            {
                _taperLengthOverrideNoticeShown = true;
                try
                {
                    using (var notice = new ThemedConfirmDialog(
                        "Нестандартная длина конической резьбы",
                        "Изменена стандартная длина конической резьбы.\r\n\r\n" +
                        "Построение будет выполнено по пользовательской длине или на всю поверхность и может не соответствовать табличной длине выбранного стандарта. " +
                        "Перед выпуском детали проверьте глубину ввинчивания и требования чертежа.\r\n\r\n" + reason,
                        true))
                    {
                        notice.ShowDialog(this);
                    }
                }
                catch { }
            }
            if (lStatus != null)
            {
                lStatus.ForeColor = UiWarning;
                lStatus.Text = "Нестандартная длина конической резьбы. Сверьте её с таблицей и чертежом перед построением.";
            }
        }

        private string FindClosestTaperDesignation(string type)
        {
            if (Target == null || cbTaperDesignation == null || cbTaperDesignation.Items.Count == 0) return null;
            double ratio;
            if (!TaperedThreadGeometryPolicy.TryGetDiameterRatio(type, out ratio)) return null;

            // Auto-selection must not depend on the currently entered host length. Otherwise a
            // short Ø45 stock surface can clear the designation even though the table has valid
            // JIS rows. Compare against each row's own standard anchor/length instead.
            double targetDiameterMm = Target.RadiusCm * 20.0;
            var diameterCandidates = new List<Tuple<string, double>>();
            try
            {
                dynamic query = _app.GeneralOptions.ThreadTableQuery;
                string tableType = TaperThreadTableResolver.ResolveQueryType((object)query, type, IsExternal(), out string tableTypeDiagnostic);
                foreach (object item in cbTaperDesignation.Items)
                {
                    string designation = Convert.ToString(item, Inv);
                    if (string.IsNullOrWhiteSpace(designation)) continue;
                    try
                    {
                        dynamic info = query.CreateThreadInfo(!IsExternal(), rbR != null && rbR.Checked, tableType, designation);
                        bool metric = Convert.ToBoolean(info.Metric, Inv);
                        double tableDiameter;
                        if (IsExternal())
                        {
                            // Match the selected stock against the physical pipe OD first. For NPT,
                            // NominalExternalDiameter is a separate (smaller) table value and can
                            // cause the correct 1/2 NPT choice for Ø22 mm stock to be rejected.
                            tableDiameter = double.NaN;
                            try
                            {
                                double outside = Convert.ToDouble(info.OutsidePipeDiameter, Inv);
                                if (!double.IsNaN(outside) && !double.IsInfinity(outside) && outside > 0.0)
                                    tableDiameter = outside;
                            }
                            catch { }
                            if (double.IsNaN(tableDiameter) || double.IsInfinity(tableDiameter) || tableDiameter <= 0.0)
                            {
                                try { tableDiameter = Convert.ToDouble(info.NominalExternalDiameter, Inv); }
                                catch { tableDiameter = double.NaN; }
                            }
                            tableDiameter = metric ? tableDiameter : tableDiameter * 25.4;
                            // The picked external edge becomes the small end; the cone expands toward the shoulder.
                        }
                        else
                        {
                            tableDiameter = Convert.ToDouble(info.BasicMinorDiameter, Inv);
                            tableDiameter = metric ? tableDiameter : tableDiameter * 25.4;
                            double tableLengthMm;
                            if (!TryGetTaperStandardLengthMm(type, designation, false,
                                out tableLengthMm, out _, out _)) continue;
                            tableDiameter += tableLengthMm * ratio;
                        }
                        if (double.IsNaN(tableDiameter) || double.IsInfinity(tableDiameter) || tableDiameter <= 0.0) continue;
                        diameterCandidates.Add(Tuple.Create(designation, tableDiameter));
                    }
                    catch { }
                }
            }
            catch { return null; }

            // A larger stock/standard delta is not an automatic refusal anymore. The selected size
            // is the closest tabular fit; DoBuild always shows a geometry-change confirmation before mutation.
            return TaperedThreadGeometryPolicy.FindClosestDesignation(targetDiameterMm, diameterCandidates);
        }

        private string GetSelectedToleranceClass()
        {
            if (cbTolerance == null || cbTolerance.SelectedIndex <= 0) return string.Empty;
            string requested = cbTolerance.SelectedIndex == 1 ? "6H" :
                cbTolerance.SelectedIndex == 2 ? "6g" : string.Empty;
            string normalized;
            return ThreadTolerancePolicy.TryNormalize(Std, IsExternal(), requested, out normalized)
                ? normalized : string.Empty;
        }

        private IWin32Window GetInventorNativeWindowOwner()
        {
            try
            {
                IntPtr inventorHandle = new IntPtr(_app.MainFrameHWND);
                if (inventorHandle != IntPtr.Zero) return new WindowWrapper(inventorHandle);
            }
            catch { }
            // Fall back to the modeless thread dialog only if Inventor's HWND cannot be queried.
            return this;
        }

        private void EnsurePreviewControlsDialog()
        {
            if (_previewControlsDialog != null && !_previewControlsDialog.IsDisposed) return;
            _previewControlsDialog = new PreviewControlsDialog(
                _app,
                _previewTransparencyPercent,
                _previewLineThicknessPercent,
                OnPreviewTransparencyChanged,
                OnPreviewLineThicknessChanged,
                OnPreviewControlsCloseRequested,
                CreateCurrentEngineeringDiagramState);
            try { if (Icon != null) _previewControlsDialog.Icon = Icon; } catch { }
        }

        private ThreadEngineeringDiagramState CreateCurrentEngineeringDiagramState()
        {
            bool tapered = chTapered != null && chTapered.Checked;
            ThreadParams currentTaperParams = null;
            ThreadTarget currentTaperTarget = null;
            string currentTaperKey = string.Empty;
            bool taperResolved = false;
            if (tapered)
            {
                try
                {
                    currentTaperParams = CreateCurrentThreadParams();
                    List<ThreadTarget> diagramTargets = GetCurrentPreviewTargets();
                    if (diagramTargets.Count == 1)
                    {
                        currentTaperTarget = diagramTargets[0];
                        currentTaperKey = BuildTaperDiagramCacheKey(currentTaperParams, currentTaperTarget);
                        taperResolved = _diagramTaperCacheValid &&
                            string.Equals(currentTaperKey, _diagramTaperCacheKey, StringComparison.Ordinal);
                    }
                }
                catch { taperResolved = false; }
            }

            return new ThreadEngineeringDiagramState
            {
                Standard = Std,
                External = IsExternal(),
                Mirror = chMirror != null && chMirror.Checked && Std == ThreadStandard.S,
                Tapered = tapered,
                RoundProfile = !tapered && chRound != null && chRound.Checked,
                ChamferEnabled = chCham != null && chCham.Checked,
                ChamferPosition = cbCham != null ? (cbCham.SelectedItem != null ? Convert.ToString(cbCham.SelectedItem, Inv) : (cbCham.Text ?? string.Empty).Trim()) : string.Empty,
                ChamferLengthMm = nCham != null ? (double)nCham.Value : 0.0,
                TaperFreeGeometry = tapered && currentTaperParams != null &&
                    currentTaperParams.TaperGeometryMode == TaperGeometryModeKind.FreeGeometry,
                TaperStandard = cbTaperStandard != null ? Convert.ToString(cbTaperStandard.SelectedItem, Inv) : string.Empty,
                TaperDesignation = cbTaperDesignation != null ? (cbTaperDesignation.Text ?? string.Empty).Trim() : string.Empty,
                SizeName = tapered
                    ? (cbTaperDesignation != null ? (cbTaperDesignation.Text ?? string.Empty).Trim() : string.Empty)
                    : (cbSize != null && cbSize.SelectedItem != null && cbSize.SelectedItem is ThreadSize
                        ? (cbSize.SelectedItem as ThreadSize).Name : BuildSizeName(DiaMm, PitchMm)),
                // Taper dimensions are populated only from a matching successful table lookup.
                // Never leak values from hidden cylindrical controls or a previously selected cone.
                DiameterMm = tapered ? (taperResolved ? _diagramTaperCacheStartDiameterMm : 0.0) : DiaMm,
                PitchMm = tapered ? (taperResolved ? _diagramTaperCachePitchMm : 0.0) : PitchMm,
                LengthMm = nLen != null ? (double)nLen.Value : 0.0,
                OffsetMm = nOff != null ? (double)nOff.Value : 0.0,
                FullLength = chFull != null && chFull.Checked,
                TaperResolved = taperResolved,
                TaperDepthMm = taperResolved ? _diagramTaperCacheDepthMm : 0.0,
                TaperStartDiameterMm = taperResolved ? _diagramTaperCacheStartDiameterMm : 0.0,
                TaperEndDiameterMm = taperResolved ? _diagramTaperCacheEndDiameterMm : 0.0,
                TaperHostLengthMm = taperResolved ? _diagramTaperCacheHostLengthMm : 0.0,
                TaperRatio = taperResolved ? _diagramTaperCacheRatio : 1.0 / 16.0
            };
        }

        private static string BuildTaperDiagramCacheKey(ThreadParams p, ThreadTarget target)
        {
            if (p == null || target == null) return string.Empty;
            // Include every UI/stock input that can change the table-resolved start/end diameters.
            // Numeric values use invariant round-trip formatting to avoid locale-dependent cache hits.
            return string.Join("|", p.TaperStandard ?? string.Empty, p.TaperDesignation ?? string.Empty,
                p.External ? "E" : "I", ((int)p.TaperGeometryMode).ToString(Inv), p.FullLength ? "F" : "P",
                p.LengthMm.ToString("R", Inv), p.OffsetMm.ToString("R", Inv),
                target.BodyName ?? string.Empty, target.RadiusCm.ToString("R", Inv), target.LengthCm.ToString("R", Inv),
                CoordinateKey(target.Center), CoordinateKey(target.U));
        }

        private static string CoordinateKey(double[] coordinates)
        {
            if (coordinates == null) return string.Empty;
            return string.Join(",", coordinates.Select(v => v.ToString("R", Inv)));
        }

        private string OnPreviewTransparencyChanged(int percent)
        {
            _previewTransparencyPercent = Math.Max(0, Math.Min(100, percent));
            if (_threadPreview == null || !_threadPreview.IsVisible)
                return "Значение сохранено для следующего предпросмотра.";
            try
            {
                _threadPreview.SetTransparencyPercent(_previewTransparencyPercent);
                if (!string.IsNullOrWhiteSpace(_threadPreview.TransparencyFallbackWarning))
                    return _threadPreview.TransparencyFallbackWarning;
                if (!_threadPreview.HasShadedMesh)
                    return "Затенённая поверхность недоступна; изменение влияет только на будущую поверхность, если она будет создана.";
                return "Прозрачность фантома: " + _previewTransparencyPercent + "%.";
            }
            catch (Exception ex)
            {
                return "Inventor не применил прозрачность: " + ex.Message;
            }
        }

        private string OnPreviewLineThicknessChanged(int percent)
        {
            _previewLineThicknessPercent = Math.Max(50, Math.Min(200, percent));
            if (_threadPreview == null || !_threadPreview.IsVisible)
                return "Толщина сохранена для следующего предпросмотра.";
            try
            {
                _threadPreview.SetLineThicknessPercent(_previewLineThicknessPercent);
                return "Толщина линий: " + _previewLineThicknessPercent + "% от исходных значений.";
            }
            catch (Exception ex) { return "Не удалось изменить толщину линий: " + ex.Message; }
        }

        private void OnPreviewControlsCloseRequested()
        {
            if (_closing) return;

            // X and the palette button have the same semantics: delete transient preview graphics,
            // preserve source-body/model visibility and logical targets, and restore the HighlightSet.
            bool cleared = false;
            try { cleared = ClearThreadPreview(); } catch { }
            if (!cleared)
            {
                if (lStatus != null && !lStatus.IsDisposed)
                {
                    lStatus.ForeColor = UiWarning;
                    lStatus.Text = "Не удалось удалить графику предпросмотра. Повторите выключение; модель не изменена.";
                }
                return;
            }

            try
            {
                var saved = HelivantaUserSettings.Current;
                saved.PreviewOpacity = _previewTransparencyPercent;
                saved.PreviewLineScale = _previewLineThicknessPercent;
                HelivantaUserSettings.Save(saved);
            }
            catch { }

            if (lStatus != null && !lStatus.IsDisposed)
            {
                lStatus.ForeColor = UiMuted;
                lStatus.Text = _nativeConversionMode
                    ? "Предпросмотр скрыт. Исходная резьба Inventor не изменена; продолжите настройку и нажмите «Изменить»."
                    : "Предпросмотр скрыт. Выбранное ребро сохранено для построения — нажмите «Построить».";
            }

            // Inventor can terminate InteractionEvents as the separate palette takes focus.
            // Run after the palette's click/close stack finishes, then rebuild the visual
            // highlight and resume edge picking only in the same active part document.
            try { BeginInvoke((Action)RestoreSelectionAfterPreviewDismissed); }
            catch { RestoreSelectionAfterPreviewDismissed(); }
        }

        private List<ThreadTarget> GetCurrentPreviewTargets()
        {
            if (_nativeConversionMode)
            {
                return _nativeConversionCompleted || _nativeConversionPlan == null || _nativeConversionPlan.InitialTarget == null
                    ? new List<ThreadTarget>()
                    : new List<ThreadTarget> { _nativeConversionPlan.InitialTarget };
            }

            return _sel == null || _sel.Targets == null
                ? new List<ThreadTarget>()
                : new List<ThreadTarget>(_sel.Targets);
        }

        private void ToggleThreadPreview()
        {
            if (_previewRequested || (_threadPreview != null && _threadPreview.IsVisible))
            {
                bool cleared = ClearThreadPreview();
                if (!cleared) return;
                try { BeginInvoke((Action)RestoreSelectionAfterPreviewDismissed); }
                catch { RestoreSelectionAfterPreviewDismissed(); }
                if (lStatus != null)
                {
                    lStatus.ForeColor = UiMuted;
                    lStatus.Text = "Предпросмотр скрыт. Для построения резьбы нажмите «Построить».";
                }
                return;
            }

            List<ThreadTarget> targets = GetCurrentPreviewTargets();
            if (targets.Count == 0)
            {
                lStatus.ForeColor = UiWarning;
                lStatus.Text = _nativeConversionMode
                    ? "Предпросмотр недоступен после завершения преобразования."
                    : "Сначала выберите круговое ребро для предпросмотра.";
                return;
            }

            _previewRequested = true;
            RefreshThreadPreviewNow(true);
        }

        private void RequestThreadPreviewRefresh()
        {
            if (!_previewRequested || _loading || _closing || _buildInProgress || _previewRefreshInProgress || IsDisposed)
                return;
            if (_previewRefreshTimer == null)
                return;
            try
            {
                _previewRefreshTimer.Stop();
                _previewRefreshTimer.Start();
            }
            catch { }
        }

        private void RefreshThreadPreviewNow(bool revealControlsIfNeeded)
        {
            if (!_previewRequested || _loading || _closing || _buildInProgress || IsDisposed || _previewRefreshInProgress)
                return;

            _previewRefreshInProgress = true;
            try
            {
                List<ThreadTarget> previewTargets = GetCurrentPreviewTargets();
                if (previewTargets.Count == 0)
                    throw new InvalidOperationException("Сначала выберите круговое ребро для предпросмотра.");
                bool taperedPreview = chTapered != null && chTapered.Checked;
                if (taperedPreview && previewTargets.Count != 1)
                    throw new InvalidOperationException("Для конического предпросмотра выберите одно круговое ребро. Одновременный фантом нескольких конических резьб пока не поддерживается.");
                if (!taperedPreview && (PitchMm <= 0 || DiaMm <= 0))
                    throw new InvalidOperationException("Укажите корректные диаметр и шаг.");

                Inventor.PartDocument part = _app.ActiveDocument as Inventor.PartDocument;
                if (part == null)
                    throw new InvalidOperationException("Активный документ должен быть деталью Inventor (.ipt).");

                ThreadParams parameters = CreateCurrentThreadParams();
                _diagramTaperCacheValid = false;
                _diagramTaperCacheKey = string.Empty;
                if (parameters.Tapered)
                {
                    string taperPreviewError;
                    if (!NativeTaperedThreadBuilder.TryPreparePreviewParameters(_app, previewTargets[0], parameters, out taperPreviewError))
                        throw new InvalidOperationException("Не удалось рассчитать табличный конический предпросмотр: " + taperPreviewError);
                    _diagramTaperCachePitchMm = parameters.PitchMm;
                    _diagramTaperCacheDepthMm = parameters.TaperThreadDepthMm;
                    _diagramTaperCacheStartDiameterMm = parameters.TaperStartDiameterMm;
                    _diagramTaperCacheEndDiameterMm = parameters.TaperEndDiameterMm;
                    _diagramTaperCacheHostLengthMm = parameters.TaperReferenceLengthMm;
                    _diagramTaperCacheRatio = parameters.TaperRatio;
                    _diagramTaperCacheKey = BuildTaperDiagramCacheKey(parameters, previewTargets[0]);
                    _diagramTaperCacheValid = !string.IsNullOrWhiteSpace(_diagramTaperCacheKey) &&
                        _diagramTaperCachePitchMm > 0.0 && _diagramTaperCacheDepthMm > 0.0 &&
                        _diagramTaperCacheStartDiameterMm > 0.0 && _diagramTaperCacheEndDiameterMm > 0.0 &&
                        _diagramTaperCacheHostLengthMm > 0.0;
                }
                // Preview is an exploratory, non-transacting visualization: it must remain available
                // even for parameters that the real build will refuse (e.g. a thin wall). Keep the
                // wall-thickness guard exclusively on the actual create/convert/edit path. The Build
                // command performs the authoritative preflight before it mutates model geometry.
                if (_threadPreview == null) _threadPreview = new ThreadPreviewOverlay(_app);
                _threadPreview.SetTransparencyPercent(_previewTransparencyPercent);
                _threadPreview.SetLineThicknessPercent(_previewLineThicknessPercent);
                _threadPreview.Show(part, previewTargets, parameters);
                _threadPreview.SetTransparencyPercent(_previewTransparencyPercent);
                _threadPreview.SetLineThicknessPercent(_previewLineThicknessPercent);

                EnsurePreviewControlsDialog();
                _previewControlsDialog.SetSessionValues(_previewTransparencyPercent, _previewLineThicknessPercent);
                if (revealControlsIfNeeded || !_previewControlsDialog.Visible)
                    _previewControlsDialog.ShowBeside(this, GetInventorNativeWindowOwner());
                _previewControlsDialog.SetBodyVisibilityState("Фантом виден сквозь тело");
                _previewControlsDialog.SetStatus(_editMode
                    ? "Фантом обновляется автоматически. При построении стенка будет проверена повторно после подготовки исходной поверхности; небезопасная замена будет отменена."
                    : "Фантом обновляется автоматически при изменении параметров. Модель и история Undo/Redo не изменяются.");

                _previewDocumentTimer.Start();
                if (_previewLegend != null) _previewLegend.Visible = false;
                string extentDescription = parameters.Tapered
                    ? HelivantaLocalization.Translate("Схематичный конический фантом 1:16; шаг, высота профиля и длина получены из выбранной строки таблицы Inventor. Это предпросмотр, не проверка производственного калибра.")
                    : DescribePreviewExtent(parameters, previewTargets);
                string previewStatus;
                if (_threadPreview.HasShadedMesh)
                {
                    previewStatus = "Предпросмотр включён и обновлён: полупрозрачная поверхность показывает форму зубьев.\n" +
                        extentDescription + "\n" +
                        (parameters.Tapered
                            ? "Конический фантом схематический: фаски, выход инструмента, плавный сбег и скругление профиля не применяются в коническом режиме. Проверяйте итоговый B-rep после построения."
                            : "Скругление вершин и впадин отображается на фантоме при включённом «Скруглять». Фаски показаны схематично; для точной физической геометрии нажмите «Построить».");
                }
                else
                {
                    previewStatus = "Показаны только контуры: затенённая поверхность недоступна" +
                        (string.IsNullOrWhiteSpace(_threadPreview.ShadedMeshFallbackReason) ? "." : " (" + _threadPreview.ShadedMeshFallbackReason + ").") + "\n" +
                        extentDescription + "\n" + (parameters.Tapered
                            ? "Коническая схема показывает табличный шаг и профиль без фасок/сбега. Геометрия детали не менялась."
                            : "Цвета и назначение контуров показаны ниже. Геометрия детали не менялась.");
                }
                previewStatus += "\nПроверка стенки выполняется только перед реальным построением; предпросмотр не блокируется по толщине стенки.";
                if (!string.IsNullOrWhiteSpace(_threadPreview.ChamferPreviewWarning))
                    previewStatus += "\n" + _threadPreview.ChamferPreviewWarning;
                if (_editMode)
                    previewStatus += "\nПри редактировании проверка толщины стенки будет выполнена повторно перед заменой; небезопасная операция будет отменена.";
                if (!string.IsNullOrWhiteSpace(_threadPreview.TransparencyFallbackWarning))
                    previewStatus += "\n" + _threadPreview.TransparencyFallbackWarning;
                lStatus.ForeColor = !string.IsNullOrWhiteSpace(_threadPreview.TransparencyFallbackWarning) ||
                    !string.IsNullOrWhiteSpace(_threadPreview.ChamferPreviewWarning)
                    ? UiWarning : UiMuted;
                lStatus.Text = HelivantaLocalization.Translate(previewStatus);
            }
            catch (Exception ex)
            {
                bool cleanupSucceeded = true;
                try
                {
                    if (_threadPreview != null)
                    {
                        _threadPreview.Clear();
                        cleanupSucceeded = _threadPreview.LastClearSucceeded;
                    }
                }
                catch { cleanupSucceeded = false; }

                if (!cleanupSucceeded)
                {
                    _previewRequested = false;
                    try { if (_previewRefreshTimer != null) _previewRefreshTimer.Stop(); } catch { }
                    if (_previewControlsDialog != null && !_previewControlsDialog.IsDisposed)
                        _previewControlsDialog.SetStatus("Не удалось удалить старый фантом. Повторите выключение предпросмотра перед продолжением.");
                    lStatus.ForeColor = UiError;
                    lStatus.Text = "Не удалось безопасно обновить/удалить предпросмотр. Построение не выполнялось. Выключите предпросмотр и повторите.";
                }
                else
                {
                    if (_previewControlsDialog != null && !_previewControlsDialog.IsDisposed && _previewControlsDialog.Visible)
                        _previewControlsDialog.SetStatus("Предпросмотр приостановлен: " + ex.Message + " Исправьте параметры — фантом обновится автоматически.");
                    lStatus.ForeColor = ex.Message.IndexOf("Построение запрещено", StringComparison.OrdinalIgnoreCase) >= 0
                        ? UiError : UiWarning;
                    lStatus.Text = "Предпросмотр приостановлен: " + ex.Message + " Измените параметры, чтобы восстановить фантом.";
                }
            }
            finally
            {
                _previewRefreshInProgress = false;
            }
        }

        private string DescribePreviewExtent(ThreadParams parameters, IList<ThreadTarget> targets)
        {
            if (parameters == null) return HelivantaLocalization.Translate("Длина фантома не определена.");
            double offsetMm = parameters.OffsetMm;
            string mm = HelivantaLocalization.Translate("мм");
            if (parameters.FullLength)
                return HelivantaLocalization.Translate("Длина фантома: вся доступная поверхность с учётом отступа ") +
                    offsetMm.ToString("0.###", Inv) + " " + mm + ".";

            string message = HelivantaLocalization.Translate("Длина фантома ограничена значением из поля «Длина резьбы»: ") +
                parameters.LengthMm.ToString("0.###", Inv) + " " + mm + " " +
                HelivantaLocalization.Translate("от каждого выбранного ребра.");
            if (targets != null)
            {
                double requestedCm = parameters.LengthMm / 10.0;
                double offsetCm = parameters.OffsetMm / 10.0;
                foreach (ThreadTarget target in targets)
                {
                    if (target == null) continue;
                    double availableCm = target.LengthCm - offsetCm;
                    if (availableCm > 0.0 && requestedCm >= availableCm - Math.Max(0.005, availableCm * 0.002))
                    {
                        return message + HelivantaLocalization.Translate(" Внимание: заданная длина практически равна доступной длине одной из поверхностей, поэтому фантом может выглядеть полноразмерным. Уменьшите «Длина резьбы», если нужен более короткий участок.");
                    }
                }
            }
            return message;
        }

        private bool ClearThreadPreview()
        {
            _previewRequested = false;
            try { if (_previewRefreshTimer != null) _previewRefreshTimer.Stop(); } catch { }
            bool wasPreviewVisible = _threadPreview != null && _threadPreview.IsVisible;
            if (_previewLegend != null && !_previewLegend.IsDisposed) _previewLegend.Visible = false;
            try { if (_previewDocumentTimer != null) _previewDocumentTimer.Stop(); } catch { }

            bool cleanupSucceeded = true;
            try
            {
                if (_threadPreview != null)
                {
                    _threadPreview.Clear();
                    cleanupSucceeded = _threadPreview.LastClearSucceeded;
                }
            }
            catch (Exception ex)
            {
                cleanupSucceeded = false;
                TransactionLifecycleDiagnostics.Write("ThreadDialog", "preview-graphics-cleanup-failed",
                    _app, null, null, false, ex.ToString());
            }

            try
            {
                if (_previewControlsDialog != null)
                {
                    if (cleanupSucceeded) _previewControlsDialog.HideForPreviewOff();
                    else _previewControlsDialog.SetStatus("Не удалось полностью удалить временную графику. Повторите выключение предпросмотра.");
                }
            }
            catch { }

            if (cleanupSucceeded)
            {
                try { if (_sel != null) _sel.RefreshVisualSelection(wasPreviewVisible); } catch { }
            }
            else if (lStatus != null && !lStatus.IsDisposed)
            {
                lStatus.ForeColor = UiWarning;
                lStatus.Text = "Не удалось полностью удалить временную графику предпросмотра. Повторите выключение перед продолжением.";
            }
            return cleanupSucceeded;
        }

        private void RestoreSelectionAfterPreviewDismissed()
        {
            if (_closing || IsDisposed || _nativeConversionMode || _sel == null || _sel.Targets.Count == 0) return;
            try
            {
                // Restart, rather than just conditionally starting, so an interaction that
                // still reports Active but lost Inventor's input focus cannot remain stale.
                // The selector's guarded restart preserves targets and refuses a document switch.
                if (_sel.RestartIfSameDocument())
                {
                    if (bResume != null && !bResume.IsDisposed) bResume.Visible = false;
                }
            }
            catch { }
            try { _sel.RefreshVisualSelection(recreateHighlightSet: true); } catch { }
        }

        // ---------- build ----------
        private void DoEditBuild()
        {
            if (string.IsNullOrWhiteSpace(_editThreadId))
            {
                lStatus.ForeColor = UiError;
                lStatus.Text = "Не задана редактируемая группа резьбы. Закройте окно и выберите операцию снова.";
                return;
            }
            Inventor.PartDocument activePart = _app == null ? null : _app.ActiveDocument as Inventor.PartDocument;
            ThreadMetadataGroup savedEditGroup;
            string savedGroupError;
            if (!ThreadEditService.TryGetEditableGroup(activePart, _editThreadId, out savedEditGroup, out savedGroupError) ||
                savedEditGroup == null || savedEditGroup.Record == null || savedEditGroup.Record.Parameters == null || savedEditGroup.Record.Target == null)
            {
                lStatus.ForeColor = UiError;
                lStatus.Text = savedGroupError ?? "Не удалось прочитать сохранённые метаданные редактируемой группы.";
                return;
            }
            double pitch = PitchMm, dia = DiaMm;
            if (pitch <= 0 || dia <= 0)
            {
                lStatus.ForeColor = UiError;
                lStatus.Text = "Укажите корректные номинальный диаметр и шаг (числа в мм).";
                return;
            }

            ThreadParams parameters = CreateCurrentThreadParams();
            if (savedEditGroup.Record.Parameters.Tapered && !parameters.Tapered)
            {
                lStatus.ForeColor = UiError;
                lStatus.Text = "Сохранённую коническую резьбу нельзя перевести в цилиндрический режим в окне Правка. Конический режим восстановлен; для другого типа резьбы отмените правку и создайте новую группу.";
                _loading = true;
                try { if (chTapered != null) chTapered.Checked = true; }
                finally { _loading = false; }
                return;
            }
            bool hasDownstreamOperations;
            int downstreamOperationCount;
            string historyError;
            if (!ThreadEditService.TryGetHistoryRisk(_app == null ? null : _app.ActiveDocument as Inventor.PartDocument,
                    _editThreadId, out hasDownstreamOperations, out downstreamOperationCount, out historyError))
            {
                lStatus.ForeColor = UiError;
                lStatus.Text = historyError ?? "Не удалось проверить историю построений детали.";
                return;
            }
            if (hasDownstreamOperations)
            {
                string noun = downstreamOperationCount == 1 ? "операция" :
                    (downstreamOperationCount >= 2 && downstreamOperationCount <= 4 ? "операции" : "операций");
                string riskMessage = "После выбранной резьбы в истории построений находится " + downstreamOperationCount +
                    " последующих " + noun + ". При замене резьбы ссылки этих объектов на грани и рёбра могут измениться, и последующее построение может завершиться ошибкой. Продолжить замену? Если результат окажется неверным, завершённую замену можно отменить командой Inventor «Отменить» (Ctrl+Z).";
                using (var prompt = new ThemedConfirmDialog("Внимание: последующие операции", riskMessage))
                {
                    if (prompt.ShowDialog(this) != DialogResult.Yes)
                    {
                        lStatus.ForeColor = UiMuted;
                        lStatus.Text = "Редактирование отменено. Модель не изменена.";
                        return;
                    }
                }
            }
            if (parameters.Tapered)
            {
                string confirmationText, confirmationError;
                if (!NativeTaperedThreadBuilder.TryBuildGeometryChangeSummaryFromSnapshot(
                    _app, savedEditGroup.Record.Target, savedEditGroup.Record.Parameters, parameters,
                    out confirmationText, out confirmationError))
                {
                    lStatus.ForeColor = UiError;
                    lStatus.Text = string.IsNullOrWhiteSpace(confirmationError)
                        ? "Не удалось рассчитать изменение геометрии конической резьбы."
                        : confirmationError;
                    _lastBuildInfo = "✖ Предварительный расчёт для правки не выполнен. Старая группа не изменена.";
                    UpdateInfo();
                    return;
                }
                using (var prompt = new ThemedConfirmDialog("Подтвердите изменение геометрии", confirmationText))
                {
                    if (prompt.ShowDialog(this) != DialogResult.Yes)
                    {
                        lStatus.ForeColor = UiText;
                        lStatus.Text = "Правка конической резьбы отменена. Существующая геометрия сохранена.";
                        _lastBuildInfo = "Правка конической резьбы отменена до удаления старой группы.";
                        UpdateInfo();
                        return;
                    }
                }
                // Runtime-only consent gate required by NativeTaperedThreadBuilder.Build.
                // It is intentionally set only after the explicit dialog returned Yes.
                parameters.TaperGeometryChangeConfirmed = true;
            }

            try
            {
                _buildInProgress = true;
                Cursor = Cursors.WaitCursor;
                lStatus.ForeColor = UiText;
                lStatus.Text = "Проверка группы и безопасная замена резьбы…";
                _lastBuildInfo = "⏳ Редактирование резьбы начато. Проверяются метаданные, исходная поверхность и история операций.";
                UpdateInfo();

                ThreadTarget rebuiltTarget;
                string warning, error;
                bool replaced = ThreadEditService.TryReplace(_app, _editThreadId, parameters,
                    out rebuiltTarget, out warning, out error);
                if (!replaced)
                {
                    lStatus.ForeColor = UiError;
                    lStatus.Text = error ?? "Редактирование не выполнено; модель не должна быть изменена.";
                    _lastBuildInfo = "✖ Редактирование не выполнено.\n\n" + lStatus.Text +
                        "\n\nПолная техническая ошибка и стек сохранены в журнале:\n%LOCALAPPDATA%\\Helivanta\\Logs\\build-diagnostics.log";
                    AppendFailedBuildDiagnosticLog(parameters, 1, 0.0, lStatus.Text, new InvalidOperationException(lStatus.Text), "Редактирование резьбы");
                    UpdateInfo();
                    return;
                }

                RefreshBuildZonesFromMetadata();
                _lastBuildWarning = warning ?? "";
                lStatus.ForeColor = string.IsNullOrWhiteSpace(_lastBuildWarning) ? UiSuccess : UiWarning;
                lStatus.Text = "Резьба обновлена. ID группы сохранён; остальные группы Helivanta не заменялись." +
                    (string.IsNullOrWhiteSpace(_lastBuildWarning) ? "" : "\n⚠ " + _lastBuildWarning);
                string threadLengthInfo = parameters.FullLength ? "вся поверхность" : parameters.LengthMm.ToString("0.###", Inv) + " мм";
                _lastBuildInfo = "✓ Редактирование завершено.\n" +
                    "Параметры: " + (parameters.External ? "наружная" : "внутренняя") + " · " + StdNameForInfo(parameters.Standard) + " · " +
                    parameters.SizeName + " · шаг — " + parameters.PitchMm.ToString("0.###", Inv) + " мм · заходов — " + parameters.Starts +
                    " · длина — " + threadLengthInfo + " · ID — " + _editThreadId +
                    (string.IsNullOrWhiteSpace(_lastBuildWarning) ? "" : "\n\n⚠ Предупреждение:\n" + _lastBuildWarning);
                UpdateInfo();
            }
            catch (Exception ex)
            {
                lStatus.ForeColor = UiError;
                lStatus.Text = "Редактирование не выполнено. См. технические сведения в секции «Информация».";
                _lastBuildInfo = "✖ Редактирование не выполнено.\n\n" +
                    ThreadBuilder.GetUserFacingError(ex) + "\n\n" + ex.Message;
                UpdateInfo();
            }
            finally
            {
                _buildInProgress = false;
                SyncPreviewButtonVisibility();
                Cursor = Cursors.Default;
                UpdateUndoButton();
                // Edit mode intentionally does not restart edge selection. The dialog stays bound to the same ThreadId.
            }
        }

        private void DoNativeConversionBuild()
        {
            if (_nativeConversionCompleted)
            {
                RequestNextNativeConversionSelection();
                return;
            }
            NativeThreadConversionPlan plan = _nativeConversionPlan;
            if (plan == null || plan.InitialTarget == null)
            {
                lStatus.ForeColor = UiError;
                lStatus.Text = "План преобразования потерян. Закройте окно и выберите штатную резьбу Inventor заново.";
                return;
            }

            if (PitchMm <= 0 || DiaMm <= 0)
            {
                lStatus.ForeColor = UiError;
                lStatus.Text = "Укажите корректные номинальный диаметр и шаг (числа в мм).";
                return;
            }

            ThreadParams parameters = CreateCurrentThreadParams();
            var conversionTargets = new List<ThreadTarget> { plan.InitialTarget };
            string overlapError;
            if (!ValidateNoThreadOverlap(conversionTargets, parameters, out overlapError))
            {
                lStatus.ForeColor = UiError;
                lStatus.Text = overlapError;
                _lastBuildInfo = "Преобразование запрещено: обнаружено пересечение зон резьбы.";
                UpdateInfo();
                return;
            }

            string threadId = null;
            string warning = null;
            string error = null;
            _buildInProgress = true;
            Cursor = Cursors.WaitCursor;
            try
            {
                ClearThreadPreview();
                try { if (_sel != null) _sel.Stop(); } catch { }
                _lastBuildWarning = "";
                _lastBuildInfo = "⏳ Преобразование штатной резьбы Inventor в физическую резьбу Helivanta…";
                lStatus.ForeColor = UiText;
                lStatus.Text = "Преобразование начато. Исходная косметическая операция будет удалена только внутри транзакции.";
                UpdateInfo();

                if (!NativeThreadConversionService.TryConvert(_app, plan, parameters,
                    out threadId, out warning, out error))
                {
                    lStatus.ForeColor = UiError;
                    lStatus.Text = "Преобразование не выполнено. Проверьте техническое сообщение в секции «Информация».";
                    _lastBuildInfo = "✖ Преобразование штатной резьбы Inventor не выполнено.\n\n" +
                        (error ?? "Причина не определена.");
                    if (!string.IsNullOrWhiteSpace(error) && error.IndexOf("КРИТИЧЕСКИ", StringComparison.OrdinalIgnoreCase) >= 0)
                    {
                        bBuild.Enabled = false;
                        bPreview.Visible = false;
                    }
                    UpdateInfo();
                    return;
                }

                _nativeConversionCompleted = true;
                _nativeConversionThreadId = threadId;
                Target = null;
                _lastBuildWarning = warning ?? "";
                bBuild.Text = HelivantaLocalization.Translate("Следующая");
                bBuild.AccessibleName = "Выбрать следующую штатную резьбу Inventor для преобразования";
                bBuild.AccessibleDescription = "Уже выполненное преобразование сохранено. Нажмите, чтобы выбрать следующую штатную операцию «Резьба Inventor» и преобразовать её в физическую резьбу Helivanta.";
                bBuild.Enabled = true;
                bPreview.Visible = false;
                bReset.Enabled = false;
                lStatus.ForeColor = string.IsNullOrWhiteSpace(_lastBuildWarning) ? UiSuccess : UiWarning;
                lStatus.Text = "Преобразование завершено: штатная косметическая резьба заменена физической геометрией Helivanta. Нажмите «Следующая», чтобы выбрать ещё одну штатную резьбу." +
                    (string.IsNullOrWhiteSpace(_lastBuildWarning) ? "" : "\n⚠ " + _lastBuildWarning);
                _lastBuildInfo = "✓ Преобразование завершено. Штатная резьба Inventor заменена реальной физической резьбой Helivanta.\n" +
                    "Стандарт: " + StdNameForInfo(parameters.Standard) + " · размер: " + parameters.SizeName +
                    " · шаг: " + parameters.PitchMm.ToString("0.###", Inv) + " мм · заходов: " + parameters.Starts +
                    " · длина: " + (parameters.FullLength ? "вся поверхность" : parameters.LengthMm.ToString("0.###", Inv) + " мм") +
                    " · ID: " + (threadId ?? "не определён") +
                    (string.IsNullOrWhiteSpace(_lastBuildWarning) ? "" : "\n\n⚠ Предупреждение построения:\n" + _lastBuildWarning);
                RefreshButtonToolTips();
                SyncPreviewButtonVisibility();
                UpdateUndoButton();
                UpdateInfo();
                ApplyResponsiveLayout();
            }
            catch (Exception ex)
            {
                string technical = string.IsNullOrWhiteSpace(error) ? ex.ToString() : error + "\n" + ex;
                string userMessage = ThreadBuilder.GetUserFacingError(ex);
                try
                {
                    AppendFailedBuildDiagnosticLog(parameters, 1, 0.0, userMessage, ex,
                        "Преобразование штатной резьбы Inventor (UI phase)");
                }
                catch { }
                lStatus.ForeColor = UiError;
                lStatus.Text = "Преобразование не выполнено. Проверьте состояние модели перед сохранением.";
                _lastBuildInfo = "✖ Ошибка преобразования штатной резьбы Inventor.\n\n" +
                    userMessage + "\n\n" + technical +
                    "\n\nПолный журнал ошибки сохранён в %LOCALAPPDATA%\\Helivanta\\Logs\\build-diagnostics.log";
                UpdateInfo();
            }
            finally
            {
                _buildInProgress = false;
                SyncPreviewButtonVisibility();
                Cursor = Cursors.Default;
                UpdateUndoButton();
            }
        }

        private void RequestNextNativeConversionSelection()
        {
            NativeThreadConversionSequenceState state = NativeThreadConversionSequencePolicy.Resolve(
                _nativeConversionMode, _nativeConversionCompleted, _nativeConversionAwaitingNextSelection);
            if (state != NativeThreadConversionSequenceState.RequestNextSelection)
            {
                if (state == NativeThreadConversionSequenceState.AwaitingNextSelection)
                    ShowMessage("Выберите штатную резьбу в дереве построений или отмените выбор.");
                else
                    ShowMessage("Сначала успешно преобразуйте текущую штатную резьбу Inventor.");
                return;
            }

            _nativeConversionAwaitingNextSelection = true;
            bBuild.Text = HelivantaLocalization.Translate("Следующая");
            bBuild.AccessibleName = "Выбрать следующую штатную резьбу Inventor для преобразования";
            bBuild.Enabled = false;
            lTarget.Text = "Выберите следующую штатную операцию «Резьба Inventor» в левом дереве построений.";
            lStatus.ForeColor = UiMuted;
            lStatus.Text = "Ожидаем следующую штатную резьбу Inventor. Ранее выполненные преобразования сохраняются.";
            RefreshButtonToolTips();
            UpdateUndoButton();
            UpdateInfo();

            // Do not let the previous ThreadFeature (which has just been replaced) be picked
            // again by the modeless Browser prompt's first polling tick.
            try
            {
                Inventor.PartDocument doc = _app.ActiveDocument as Inventor.PartDocument;
                if (doc != null && doc.SelectSet != null) ((dynamic)doc.SelectSet).Clear();
            }
            catch { }

            Action handler = EditSelectionRequested;
            if (handler == null)
            {
                _nativeConversionAwaitingNextSelection = false;
                bBuild.Enabled = true;
                lStatus.ForeColor = UiError;
                lStatus.Text = "Механизм выбора следующей резьбы недоступен. Запустите команду выбора повторно.";
                UpdateInfo();
                return;
            }

            try { handler(); }
            catch (Exception ex)
            {
                _nativeConversionAwaitingNextSelection = false;
                bBuild.Enabled = true;
                lStatus.ForeColor = UiError;
                lStatus.Text = "Не удалось начать выбор следующей резьбы: " + ex.Message;
                UpdateUndoButton();
                UpdateInfo();
            }
        }

        /// <summary>
        /// Rejects a browser object that is not a native ThreadFeature while preserving all
        /// earlier successful conversions and returning the main action to an enabled Next state.
        /// </summary>
        internal void RejectNextNativeConversionSelection(string reason)
        {
            if (!IsAwaitingNextNativeConversionSelection) return;
            _nativeConversionAwaitingNextSelection = false;
            bBuild.Text = HelivantaLocalization.Translate("Следующая");
            bBuild.AccessibleName = "Выбрать следующую штатную резьбу Inventor для преобразования";
            bBuild.AccessibleDescription = "Нажмите, чтобы выбрать следующую штатную операцию «Резьба Inventor».";
            bBuild.Enabled = true;
            lTarget.Text = "Предыдущие штатные резьбы уже преобразованы. Нажмите «Следующая» и выберите другую штатную операцию «Резьба Inventor».";
            lStatus.ForeColor = UiWarning;
            lStatus.Text = string.IsNullOrWhiteSpace(reason)
                ? "Выбранный объект не подходит. Предыдущие преобразования сохранены; нажмите «Следующая», чтобы повторить выбор."
                : reason + " Предыдущие преобразования сохранены; нажмите «Следующая», чтобы повторить выбор.";
            RefreshButtonToolTips();
            UpdateUndoButton();
            UpdateInfo();
        }

        private void DoBuild()
        {
            if (!ClearThreadPreview()) return;
            if (_buildInProgress) return;
            if (_nativeConversionMode)
            {
                DoNativeConversionBuild();
                return;
            }
            if (_editMode)
            {
                DoEditBuild();
                return;
            }
            lStatus.ForeColor = UiText;
            if (Target == null)
            {
                lStatus.ForeColor = UiError;
                lStatus.Text = "Сначала выберите на модели круговые рёбра начала резьбы.";
                return;
            }

            bool ext = IsExternal();
            double pitch = PitchMm, dia = DiaMm;
            var p = CreateCurrentThreadParams();
            // In tapered mode the standards table is authoritative for diameter and pitch; disabled
            // parallel-thread size fields must not prevent the native tapered workflow from starting.
            if (!p.Tapered && (pitch <= 0 || dia <= 0))
            {
                lStatus.ForeColor = UiError;
                lStatus.Text = "Укажите номинальный диаметр и шаг (числа в мм).";
                return;
            }
            if (p.Tapered && (string.IsNullOrWhiteSpace(p.TaperStandard) || string.IsNullOrWhiteSpace(p.TaperDesignation)))
            {
                lStatus.ForeColor = UiError;
                lStatus.Text = "Выберите стандарт и полное обозначение конической резьбы из таблицы Inventor.";
                return;
            }
            if (p.Tapered && _sel.Targets.Count != 1)
            {
                lStatus.ForeColor = UiError;
                lStatus.Text = "Нативную коническую резьбу пока строят по одному круговому ребру за операцию.";
                return;
            }
            List<ThreadTarget> buildTargets = null;
            Stopwatch buildTimer = null;

            try
            {
                _buildInProgress = true;
                Cursor = Cursors.WaitCursor;
                _lastBuildWarning = "";
                buildTargets = new List<ThreadTarget>(_sel.Targets);
                _lastBuildInfo = string.Format("⏳ Построение начато: рёбер — {0}, стандарт — {1}, размер — {2}, направление — {3}.",
                    buildTargets.Count,
                    p.Tapered ? p.TaperStandard + " (таблица Inventor)" : StdNameForInfo(Std),
                    p.Tapered ? p.TaperDesignation : BuildSizeName(dia, pitch),
                    rbR.Checked ? "правая" : "левая");
                UpdateInfo();

                string overlapError;
                ThreadParams overlapParams = p;
                if (p.Tapered && buildTargets.Count == 1)
                {
                    // Host preparation modifies the surface from the picked edge to the end of the
                    // threaded interval; reserve that entire interval, including the pre-thread offset.
                    ThreadTarget taperTarget = buildTargets[0];
                    double hostLengthMm = p.FullLength
                        ? taperTarget.LengthCm * 10.0
                        : p.OffsetMm + p.LengthMm;
                    overlapParams = new ThreadParams
                    {
                        FullLength = false,
                        LengthMm = hostLengthMm,
                        OffsetMm = 0.0,
                        External = p.External,
                        NominalDiaMm = taperTarget.RadiusCm * 20.0,
                        SizeName = p.TaperDesignation,
                        PitchMm = p.PitchMm,
                        Starts = 1
                    };
                }
                if (!ValidateNoThreadOverlap(buildTargets, overlapParams, out overlapError))
                {
                    lStatus.ForeColor = UiError;
                    lStatus.Text = overlapError;
                    _lastBuildInfo = "✖ Построение запрещено: зона подготовки поверхности пересекается с существующей резьбой.";
                    UpdateInfo();
                    return;
                }

                if (p.Tapered)
                {
                    string confirmationText = null, confirmationError = null;
                    if (buildTargets.Count != 1 || !NativeTaperedThreadBuilder.TryBuildGeometryChangeSummary(
                        _app, buildTargets[0], p, out confirmationText, out confirmationError))
                    {
                        lStatus.ForeColor = UiError;
                        lStatus.Text = string.IsNullOrWhiteSpace(confirmationError)
                            ? "Не удалось рассчитать изменение геометрии конической резьбы."
                            : confirmationError;
                        _lastBuildInfo = "✖ Предварительный расчёт конической резьбы не выполнен; модель не изменена.";
                        UpdateInfo();
                        return;
                    }
                    using (var prompt = new ThemedConfirmDialog("Подтвердите изменение геометрии", confirmationText))
                    {
                        if (prompt.ShowDialog(this) != DialogResult.Yes)
                        {
                            lStatus.ForeColor = UiText;
                            lStatus.Text = "Построение конической резьбы отменено. Геометрия детали не изменена.";
                            _lastBuildInfo = "Построение конической резьбы отменено до изменения детали.";
                            UpdateInfo();
                            return;
                        }
                    }
                    p.TaperGeometryChangeConfirmed = true;
                }

                _sel.Stop();    // no interactive selection while the model is being modified
                buildTimer = Stopwatch.StartNew();
                int count = ThreadBuilder.BuildAll(_app, buildTargets, p);
                buildTimer.Stop();
                if (p.Tapered)
                {
                    _lastTaperInfoStandard = p.TaperStandard ?? string.Empty;
                    _lastTaperInfoDesignation = p.TaperDesignation ?? string.Empty;
                    _lastTaperPitchMm = p.PitchMm;
                    _lastTaperDepthMm = p.TaperThreadDepthMm;
                }
                // A new successful build creates a new Inventor history branch; discard any
                // previously undone build snapshots before recording this one.
                ClearRedoBuildTracking();
                _buildSelections.Add(new List<ThreadTarget>(buildTargets));
                _buildZones.Add(CreateBuildZones(buildTargets, p));
                _sessionBuilds = _buildZones.Count;
                _sel.Clear();   // the picked edges are no longer valid for active selection
                SyncPreviewButtonVisibility();
                _lastBuildWarning = ThreadBuilder.LastWarning ?? "";
                lStatus.ForeColor = string.IsNullOrEmpty(_lastBuildWarning) ? UiSuccess : UiWarning;
                lStatus.Text = "Готово: резьб — " + buildTargets.Count + ", заходов всего — " + count + "." +
                    (string.IsNullOrEmpty(_lastBuildWarning) ? " Можно выбирать следующие рёбра." :
                    "\n⚠ " + _lastBuildWarning);
                AppendBuildDiagnosticLog(p, buildTargets.Count, count, buildTimer.Elapsed.TotalSeconds, _lastBuildWarning);
                string threadLengthInfo = p.FullLength ? "вся поверхность" : p.LengthMm.ToString("0.###", Inv) + " мм";
                string chamferLocationInfo = p.ChamferMode == 1 ? "в начале" :
                    p.ChamferMode == 2 ? "в конце" : p.ChamferMode == 3 ? "с обоих краёв" : "выкл.";
                string chamferInfo = p.ChamferMode > 0
                    ? chamferLocationInfo + ", " + p.ChamferMm.ToString("0.##", Inv) + " мм"
                    : "выкл.";
                _lastBuildInfo = "✓ Последнее построение: успешно. Резьб — " + buildTargets.Count + ", заходов всего — " + count + "." +
                    "\nОбщее время: " + buildTimer.Elapsed.TotalSeconds.ToString("0.0", Inv) + " с." +
                    "\nПараметры: " + (p.External ? "наружная" : "внутренняя") + " · " +
                    (p.Tapered ? p.TaperStandard + " (таблица Inventor)" : StdNameForInfo(p.Standard)) + " · " +
                    (p.Tapered ? p.TaperDesignation : p.SizeName) + " · " + (p.RightHand ? "правая" : "левая") + " · число заходов — " + p.Starts +
                    " · сбег — " + "плавный Loft" + " · длина — " + threadLengthInfo +
                    (p.Tapered ? " · конусность — 1:16; Ø " + p.TaperStartDiameterMm.ToString("0.###", Inv) + " → " + p.TaperEndDiameterMm.ToString("0.###", Inv) + " мм" : " · фаски — " + chamferInfo) +
                    (string.IsNullOrEmpty(_lastBuildWarning) ? "" : "\n\n⚠ Предупреждение построения:\n" + _lastBuildWarning);
                UpdateInfo();
            }
            catch (Exception ex)
            {
                if (buildTimer != null && buildTimer.IsRunning) buildTimer.Stop();
                string userMessage = string.IsNullOrWhiteSpace(ThreadBuilder.LastUserError)
                    ? ThreadBuilder.GetUserFacingError(ex)
                    : ThreadBuilder.LastUserError;
                lStatus.ForeColor = UiError;
                lStatus.Text = "Построение не выполнено. См. рекомендации в секции «Информация».";
                AppendFailedBuildDiagnosticLog(p, buildTargets == null ? 0 : buildTargets.Count,
                    buildTimer == null ? 0.0 : buildTimer.Elapsed.TotalSeconds, userMessage, ex);
                _lastBuildInfo = "✖ Последнее построение: не выполнено.\n\n" + userMessage +
                    "\n\nПолная техническая ошибка сохранена в журнале:\n%LOCALAPPDATA%\\Helivanta\\Logs\\build-diagnostics.log";
                UpdateInfo();
            }
            finally
            {
                _buildInProgress = false;
                SyncPreviewButtonVisibility();
                Cursor = Cursors.Default;
                UpdateUndoButton();
                StartSelection();
                if (!string.IsNullOrWhiteSpace(_lastBuildWarning))
                {
                    lStatus.ForeColor = UiWarning;
                    lStatus.Text = "⚠ " + _lastBuildWarning + "\nВыбирайте рёбра в окне модели.";
                }
            }
        }
        private void AppendFailedBuildDiagnosticLog(ThreadParams p, int threadCount, double totalSeconds, string userMessage, Exception ex,
                                                    string operationLabel = "Построение")
        {
            try
            {
                string logDirectory = Path.Combine(
                    Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData),
                    "Helivanta", "Logs");
                Directory.CreateDirectory(logDirectory);
                string logPath = Path.Combine(logDirectory, "build-diagnostics.log");
                string runoutMode = "Плавный (авто-резервный Coil при отказе Loft)";
                string length = p.FullLength ? "вся поверхность" : p.LengthMm.ToString("0.###", Inv) + " мм";
                string technicalError = string.IsNullOrWhiteSpace(ThreadBuilder.LastError) ? ex.ToString() : ThreadBuilder.LastError;
                string text = "[" + DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss", Inv) + "] " + operationLabel + " НЕ ВЫПОЛНЕНО" + Environment.NewLine +
                    "Выбранных рёбер: " + threadCount + Environment.NewLine +
                    "Параметры: " + (p.External ? "наружная" : "внутренняя") + "; стандарт: " + (p.Tapered ? p.TaperStandard + " (таблица Inventor)" : StdNameForInfo(p.Standard)) +
                    "; размер: " + (p.Tapered ? p.TaperDesignation : p.SizeName) + "; направление: " + (p.RightHand ? "правая" : "левая") +
                    "; число заходов: " + p.Starts + "; номинальный Ø: " + p.NominalDiaMm.ToString("0.###", Inv) + " мм" +
                    "; шаг: " + p.PitchMm.ToString("0.###", Inv) + " мм; ход: " + (p.PitchMm * p.Starts).ToString("0.###", Inv) + " мм" +
                    "; зазор: " + p.ClearanceMm.ToString("0.###", Inv) + " мм; сбег: " + runoutMode + "; длина: " + length +
                    "; выход инструмента: " + (p.RunOut ? "включён" : "выключен") +
                    "; скруглять: " + (p.Round ? "да" : "нет") +
                    "; фаски: " + p.ChamferMode + " / " + p.ChamferMm.ToString("0.##", Inv) + " мм" + Environment.NewLine +
                    "Время до отказа: " + totalSeconds.ToString("0.0", Inv) + " с." + Environment.NewLine +
                    "Подсказка пользователю: " + userMessage + Environment.NewLine +
                    (string.IsNullOrWhiteSpace(ThreadBuilder.LastRunoutPerformance) ? "Частичные тайминги отсутствуют." : ThreadBuilder.LastRunoutPerformance) + Environment.NewLine +
                    "Полная техническая ошибка и стек:" + Environment.NewLine + technicalError + Environment.NewLine +
                    new string('-', 72) + Environment.NewLine;
                DiagnosticLogMaintenance.Append(logDirectory, "build-diagnostics.log", text);
            }
            catch
            {
                // Logging must never hide the actionable user-facing build error.
            }
        }

        private void AppendBuildDiagnosticLog(ThreadParams p, int threadCount, int passCount, double totalSeconds, string warning)
        {
            // Keep performance timings out of the visible Information panel, but retain a
            // complete local diagnostic record for future performance investigations.
            try
            {
                string logDirectory = Path.Combine(
                    Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData),
                    "Helivanta", "Logs");
                Directory.CreateDirectory(logDirectory);
                string logPath = Path.Combine(logDirectory, "build-diagnostics.log");
                string runoutMode = "Плавный (авто-резервный Coil при отказе Loft)";
                string length = p.FullLength ? "вся поверхность" : p.LengthMm.ToString("0.###", Inv) + " мм";
                string text = "[" + DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss", Inv) + "] Построение успешно" + Environment.NewLine +
                    "Резьб: " + threadCount + "; заходов всего: " + passCount + Environment.NewLine +
                    "Параметры: " + (p.External ? "наружная" : "внутренняя") + "; стандарт: " + (p.Tapered ? p.TaperStandard + " (таблица Inventor)" : StdNameForInfo(p.Standard)) +
                    "; размер: " + (p.Tapered ? p.TaperDesignation : p.SizeName) + "; направление: " + (p.RightHand ? "правая" : "левая") +
                    "; число заходов: " + p.Starts + "; сбег: " + runoutMode + "; длина: " + length +
                    "; зазор: " + p.ClearanceMm.ToString("0.###", Inv) + " мм; фаски: " + p.ChamferMode +
                    " / " + p.ChamferMm.ToString("0.##", Inv) + " мм" + Environment.NewLine +
                    "Общее время: " + totalSeconds.ToString("0.0", Inv) + " с." + Environment.NewLine +
                    (string.IsNullOrWhiteSpace(ThreadBuilder.LastRunoutPerformance)
                        ? "Подробные тайминги этапов отсутствуют."
                        : ThreadBuilder.LastRunoutPerformance) + Environment.NewLine +
                    (string.IsNullOrWhiteSpace(ThreadBuilder.LastMetadataStatus)
                        ? "Метаданные редактирования: статус не сформирован."
                        : "Метаданные редактирования: " + ThreadBuilder.LastMetadataStatus) + Environment.NewLine +
                    (string.IsNullOrWhiteSpace(warning) ? "Предупреждения: нет." : "Предупреждение: " + warning) +
                    Environment.NewLine + new string('-', 72) + Environment.NewLine;
                DiagnosticLogMaintenance.Append(logDirectory, "build-diagnostics.log", text);
            }
            catch
            {
                // Diagnostics must never interrupt successful geometry creation.
            }
        }

        /// <summary>
        /// NumericUpDown wrapper that keeps the WinForms edit/value model and wheel-to-viewport
        /// behavior, while placing an amber owner-drawn panel over the internal UpDownButtons child.
        /// WinForms implements that child as a managed Control (not an msctls_updown32 HWND), so
        /// attempting to subclass a native common-control window silently leaves the white buttons.
        /// </summary>
        private sealed class ThemedNumericUpDown : NumericUpDown
        {
            private const int WM_MOUSEWHEEL = 0x020A;
            private static Color SpinnerAmber => UiAccent;
            private static Color SpinnerAmberHover => UiAccentHover;
            private static Color SpinnerAmberPressed => ControlPaint.Dark(UiAccent, .28f);
            private static Color SpinnerAmberEdge => ControlPaint.Light(UiAccent, .28f);
            private Control _nativeButtons;
            private AmberSpinnerButtons _amberButtons;

            [DllImport("user32.dll", EntryPoint = "SendMessageW")]
            private static extern IntPtr SendMessage(IntPtr hWnd, int msg, IntPtr wParam, IntPtr lParam);

            public ThemedNumericUpDown()
            {
                BackColor = UiField;
                ForeColor = UiText;
                EnsureAmberButtonsOverlay();
            }

            protected override void OnHandleCreated(EventArgs e)
            {
                base.OnHandleCreated(e);
                EnsureAmberButtonsOverlay();
                PositionAmberButtonsOverlay();
            }

            protected override void OnLayout(LayoutEventArgs e)
            {
                base.OnLayout(e);
                PositionAmberButtonsOverlay();
            }

            protected override void OnEnabledChanged(EventArgs e)
            {
                base.OnEnabledChanged(e);
                if (_amberButtons != null) _amberButtons.Invalidate();
            }

            protected override void OnFontChanged(EventArgs e)
            {
                base.OnFontChanged(e);
                PositionAmberButtonsOverlay();
            }

            protected override void OnHandleDestroyed(EventArgs e)
            {
                // The overlay remains a normal child control. No HWND subclass hooks are held.
                base.OnHandleDestroyed(e);
            }

            private void EnsureAmberButtonsOverlay()
            {
                if (_amberButtons != null || IsDisposed) return;

                // .NET WinForms UpDownBase creates an internal child named UpDownButtons and a
                // separate edit child. Overlay only the button child: leave it alive underneath
                // so the framework's value, keyboard, notification, and layout lifecycles remain.
                foreach (Control child in Controls)
                {
                    if (string.Equals(child.GetType().Name, "UpDownButtons", StringComparison.Ordinal))
                    {
                        _nativeButtons = child;
                        break;
                    }
                }
                if (_nativeButtons == null) return;

                _amberButtons = new AmberSpinnerButtons(this)
                {
                    Name = "amberNumericSpinner",
                    TabStop = false,
                    AccessibleName = "Изменить числовое значение",
                    AccessibleDescription = "Янтарные кнопки увеличения и уменьшения значения"
                };
                Controls.Add(_amberButtons);
                ValueChanged += (s, e) => { if (_amberButtons != null) _amberButtons.Invalidate(); };
                _amberButtons.BringToFront();
                PositionAmberButtonsOverlay();
            }

            private void PositionAmberButtonsOverlay()
            {
                if (_amberButtons == null || _nativeButtons == null || _amberButtons.IsDisposed) return;
                if (_nativeButtons.IsDisposed || _nativeButtons.Parent != this) return;
                // Reuse the precise bounds calculated by UpDownBase for its own button child.
                // This handles visual-style borders, left/right alignment, and DPI sizing.
                Rectangle buttonBounds = _nativeButtons.Bounds;
                if (_amberButtons.Bounds != buttonBounds) _amberButtons.Bounds = buttonBounds;
                // Let parent visibility cascade naturally; copying Visible from a child while
                // its form is still hidden can accidentally pin the overlay hidden after Show().
                _amberButtons.Visible = true;
                _amberButtons.Invalidate();
            }

            protected override void WndProc(ref Message m)
            {
                // Wheel input over a numeric field scrolls the dialog rather than changing the value.
                if (m.Msg == WM_MOUSEWHEEL)
                {
                    try
                    {
                        Control ancestor = Parent;
                        while (ancestor != null)
                        {
                            if (ancestor is ScrollableControl scrollable && scrollable.AutoScroll && ancestor.IsHandleCreated)
                            {
                                SendMessage(ancestor.Handle, WM_MOUSEWHEEL, m.WParam, m.LParam);
                                m.Result = IntPtr.Zero;
                                return;
                            }
                            ancestor = ancestor.Parent;
                        }
                    }
                    catch { }
                    m.Result = IntPtr.Zero;
                    return;
                }
                base.WndProc(ref m);
            }

            private sealed class AmberSpinnerButtons : Control
            {
                private readonly ThemedNumericUpDown _owner;
                private readonly System.Windows.Forms.Timer _repeatTimer;
                private int _pressedSegment; // 1 = up, 2 = down, 0 = none
                private int _hoverSegment;
                private bool _repeatDelayElapsed;

                public AmberSpinnerButtons(ThemedNumericUpDown owner)
                {
                    _owner = owner;
                    SetStyle(ControlStyles.UserPaint | ControlStyles.AllPaintingInWmPaint |
                             ControlStyles.OptimizedDoubleBuffer | ControlStyles.ResizeRedraw, true);
                    BackColor = SpinnerAmber;
                    ForeColor = Color.White;
                    Cursor = Cursors.Default;
                    AccessibleRole = AccessibleRole.SpinButton;
                    _repeatTimer = new System.Windows.Forms.Timer();
                    _repeatTimer.Interval = Math.Max(250, SystemInformation.DoubleClickTime);
                    _repeatTimer.Tick += (s, e) =>
                    {
                        if (!_repeatDelayElapsed)
                        {
                            _repeatDelayElapsed = true;
                            _repeatTimer.Interval = 75;
                        }
                        if (Capture && _pressedSegment != 0 && IsPointInSegment(PointToClient(Control.MousePosition), _pressedSegment))
                            Step(_pressedSegment == 1);
                    };
                }

                protected override void OnPaint(PaintEventArgs e)
                {
                    base.OnPaint(e);
                    Graphics g = e.Graphics;
                    g.SmoothingMode = SmoothingMode.AntiAlias;
                    Rectangle r = ClientRectangle;
                    if (r.Width <= 0 || r.Height <= 0) return;

                    int split = r.Height / 2;
                    Rectangle up = new Rectangle(0, 0, r.Width, Math.Max(1, split));
                    Rectangle down = new Rectangle(0, split, r.Width, Math.Max(1, r.Height - split));
                    using (var normal = new SolidBrush(!Enabled ? Color.FromArgb(74, 78, 83) : SpinnerAmber))
                    using (var hover = new SolidBrush(SpinnerAmberHover))
                    using (var pressed = new SolidBrush(SpinnerAmberPressed))
                    using (var border = new Pen(SpinnerAmberEdge, Math.Max(1f, DeviceDpi / 96f)))
                    using (var divider = new Pen(Color.FromArgb(106, 72, 26), Math.Max(1f, DeviceDpi / 96f)))
                    using (var arrowNormal = new Pen(Color.White, Math.Max(1.25f, 1.55f * DeviceDpi / 96f)))
                    using (var arrowDisabled = new Pen(Color.FromArgb(155, 160, 164), Math.Max(1.25f, 1.55f * DeviceDpi / 96f)))
                    {
                        g.FillRectangle(_pressedSegment == 1 ? pressed : (_hoverSegment == 1 && Enabled ? hover : normal), up);
                        g.FillRectangle(_pressedSegment == 2 ? pressed : (_hoverSegment == 2 && Enabled ? hover : normal), down);
                        g.DrawRectangle(border, 0, 0, Math.Max(0, r.Width - 1), Math.Max(0, r.Height - 1));
                        g.DrawLine(divider, 1, split, Math.Max(1, r.Width - 2), split);
                        bool upAvailable = Enabled && !_owner.ReadOnly && _owner.Value < _owner.Maximum;
                        bool downAvailable = Enabled && !_owner.ReadOnly && _owner.Value > _owner.Minimum;
                        DrawChevron(g, upAvailable ? arrowNormal : arrowDisabled, true, up);
                        DrawChevron(g, downAvailable ? arrowNormal : arrowDisabled, false, down);
                    }
                }

                private void DrawChevron(Graphics g, Pen pen, bool up, Rectangle segment)
                {
                    float scale = DeviceDpi / 96f;
                    float cx = segment.Left + segment.Width / 2f;
                    float cy = segment.Top + segment.Height / 2f;
                    float half = Math.Max(2.4f, 3.1f * scale);
                    float h = Math.Max(1.8f, 2.2f * scale);
                    if (up)
                    {
                        g.DrawLine(pen, cx - half, cy + h / 2f, cx, cy - h / 2f);
                        g.DrawLine(pen, cx, cy - h / 2f, cx + half, cy + h / 2f);
                    }
                    else
                    {
                        g.DrawLine(pen, cx - half, cy - h / 2f, cx, cy + h / 2f);
                        g.DrawLine(pen, cx, cy + h / 2f, cx + half, cy - h / 2f);
                    }
                }

                protected override void OnMouseDown(MouseEventArgs e)
                {
                    base.OnMouseDown(e);
                    if (e.Button != MouseButtons.Left || !Enabled) return;
                    _pressedSegment = e.Y < Height / 2 ? 1 : 2;
                    _hoverSegment = _pressedSegment;
                    Capture = true;
                    _repeatDelayElapsed = false;
                    _repeatTimer.Stop();
                    _repeatTimer.Interval = Math.Max(250, SystemInformation.DoubleClickTime);
                    _repeatTimer.Start();
                    Step(_pressedSegment == 1);
                    Invalidate();
                }

                protected override void OnMouseMove(MouseEventArgs e)
                {
                    base.OnMouseMove(e);
                    int hover = e.Y < Height / 2 ? 1 : 2;
                    if (_hoverSegment != hover) { _hoverSegment = hover; Invalidate(); }
                }

                protected override void OnMouseUp(MouseEventArgs e)
                {
                    base.OnMouseUp(e);
                    if (e.Button == MouseButtons.Left) ResetPressState();
                }

                protected override void OnMouseLeave(EventArgs e)
                {
                    base.OnMouseLeave(e);
                    if (!Capture && _hoverSegment != 0) { _hoverSegment = 0; Invalidate(); }
                }

                protected override void OnMouseCaptureChanged(EventArgs e)
                {
                    base.OnMouseCaptureChanged(e);
                    if (!Capture) ResetPressState();
                }

                private void ResetPressState()
                {
                    _repeatTimer.Stop();
                    _repeatDelayElapsed = false;
                    _pressedSegment = 0;
                    Capture = false;
                    Invalidate();
                }

                private bool IsPointInSegment(Point point, int segment)
                {
                    return ClientRectangle.Contains(point) && (segment == 1 ? point.Y < Height / 2 : point.Y >= Height / 2);
                }

                private void Step(bool up)
                {
                    if (_owner == null || _owner.IsDisposed || !_owner.Enabled || _owner.ReadOnly) return;
                    if (up)
                    {
                        if (_owner.Value < _owner.Maximum) _owner.UpButton();
                    }
                    else
                    {
                        if (_owner.Value > _owner.Minimum) _owner.DownButton();
                    }
                    Invalidate(); // refresh the visual min/max arrow state immediately
                }

                protected override void Dispose(bool disposing)
                {
                    if (disposing)
                    {
                        _repeatTimer.Stop();
                        _repeatTimer.Dispose();
                    }
                    base.Dispose(disposing);
                }
            }
        }

        private sealed class ThemedComboBox : ComboBox
        {
            private const int WM_MOUSEWHEEL = 0x020A;
            private const int WM_CTLCOLOREDIT = 0x0133;
            private const int WM_CTLCOLORLISTBOX = 0x0134;
            private const int WM_CTLCOLORSTATIC = 0x0138;

            [DllImport("user32.dll", EntryPoint = "SendMessageW")]
            private static extern IntPtr SendMessage(IntPtr hWnd, int msg, IntPtr wParam, IntPtr lParam);

            [StructLayout(LayoutKind.Sequential)]
            private struct NativeRect
            {
                public int Left;
                public int Top;
                public int Right;
                public int Bottom;
            }

            [DllImport("gdi32.dll")]
            private static extern IntPtr CreateSolidBrush(int colorRef);

            [DllImport("gdi32.dll")]
            private static extern bool DeleteObject(IntPtr hObject);

            [DllImport("gdi32.dll")]
            private static extern int SetBkColor(IntPtr hdc, int colorRef);

            [DllImport("gdi32.dll")]
            private static extern int SetTextColor(IntPtr hdc, int colorRef);

            private IntPtr _fieldBrush = IntPtr.Zero;
            private readonly ToolTip _itemToolTip;
            private ComboListToolTipHook _listToolTipHook;

            // Used by the standard selector when native ComboBox.Text becomes empty or stale
            // after closing the popup. It changes only the closed field's presentation; the
            // committed index/ThreadParams remain the source of behaviour.
            private string _closedFieldTextOverride = string.Empty;

            // Runtime-only display hint; use a method instead of a public property so WinForms
            // designer serialization analysis (WFO1000) does not treat it as a designer setting.
            public void SetClosedFieldTextOverride(string value)
            {
                _closedFieldTextOverride = value ?? string.Empty;
                if (IsHandleCreated && !IsDisposed) Invalidate();
            }
            public ThemedComboBox()
            {
                DrawMode = DrawMode.OwnerDrawFixed;
                DropDownHeight = 260;
                ItemHeight = 21;
                IntegralHeight = true;
                // Let the native themed ComboBox own its frame/drop button. The text and list
                // remain owner-drawn below, but the button itself must not be painted through HDC.
                FlatStyle = FlatStyle.Standard;
                BackColor = UiField;
                ForeColor = UiText;
                Padding = new Padding(3, 0, 2, 0);
                SetStyle(ControlStyles.OptimizedDoubleBuffer | ControlStyles.ResizeRedraw, true);
                _itemToolTip = new ToolTip
                {
                    InitialDelay = 550,
                    ReshowDelay = 120,
                    AutoPopDelay = 7000,
                    ShowAlways = true
                };
            }

            private const int WM_PAINT = 0x000F;
            private const int WM_SIZE = 0x0005;
            private static Color AmberButton => UiAccent;
            private static Color AmberButtonEdge => ControlPaint.Light(UiAccent, .28f);



            protected override void OnTextChanged(EventArgs e)
            {
                base.OnTextChanged(e);
                UpdateFieldTooltip();
            }

            protected override void OnSelectedIndexChanged(EventArgs e)
            {
                base.OnSelectedIndexChanged(e);
                UpdateFieldTooltip();
            }

            private void UpdateFieldTooltip()
            {
                if (_itemToolTip == null || IsDisposed) return;
                string value = Text ?? string.Empty;
                int arrowWidth = Math.Min(25, Math.Max(21, (int)Math.Round(23.0 * DeviceDpi / 96.0)));
                int available = Math.Max(10, ClientSize.Width - arrowWidth - 15);
                bool clipped = value.Length > 0 && TextRenderer.MeasureText(value, Font).Width > available;
                _itemToolTip.SetToolTip(this, clipped ? HelivantaLocalization.Translate(value) : null);
            }

            protected override void OnDropDown(EventArgs e)
            {
                base.OnDropDown(e);
                AttachDropdownListToolTip();
                try { BeginInvoke((Action)AttachDropdownListToolTip); } catch { }
            }

            protected override void OnDropDownClosed(EventArgs e)
            {
                try { _listToolTipHook?.Dispose(); } catch { }
                _listToolTipHook = null;
                try { _itemToolTip?.Hide(this); } catch { }
                base.OnDropDownClosed(e);
            }

            private void AttachDropdownListToolTip()
            {
                if (!IsHandleCreated || IsDisposed || !DroppedDown) return;
                try
                {
                    var info = new ComboBoxInfo { cbSize = Marshal.SizeOf(typeof(ComboBoxInfo)) };
                    if (GetComboBoxInfo(Handle, ref info) && info.hwndList != IntPtr.Zero)
                    {
                        // Owner-drawn native lists can initially appear white/blank until the
                        // pointer moves over an item. Force a full popup repaint on open.
                        InvalidateRect(info.hwndList, IntPtr.Zero, true);
                        UpdateWindow(info.hwndList);
                        if (_listToolTipHook == null)
                            _listToolTipHook = new ComboListToolTipHook(this, _itemToolTip);
                        _listToolTipHook.Attach(info.hwndList);
                    }
                }
                catch { }
            }


            protected override void Dispose(bool disposing)
            {
                if (disposing)
                {
                    try { _listToolTipHook?.Dispose(); } catch { }
                    _listToolTipHook = null;
                    try { _itemToolTip?.Dispose(); } catch { }
                }
                base.Dispose(disposing);
            }

            [StructLayout(LayoutKind.Sequential)]
            private struct ComboBoxInfo
            {
                public int cbSize;
                public NativeRect rcItem;
                public NativeRect rcButton;
                public int stateButton;
                public IntPtr hwndCombo;
                public IntPtr hwndItem;
                public IntPtr hwndList;
            }

            // Native popup repaint helpers used when opening the owner-drawn template list.
            [DllImport("user32.dll", SetLastError = true)]
            private static extern bool InvalidateRect(IntPtr hWnd, IntPtr lpRect, bool bErase);

            [DllImport("user32.dll", SetLastError = true)]
            private static extern bool UpdateWindow(IntPtr hWnd);
            [DllImport("user32.dll", SetLastError = true)]
            private static extern bool RedrawWindow(IntPtr hWnd, IntPtr updateRect, IntPtr updateRegion, uint flags);

            private const uint RDW_INVALIDATE = 0x0001;
            private const uint RDW_ERASE = 0x0004;
            private const uint RDW_ALLCHILDREN = 0x0080;
            private const uint RDW_UPDATENOW = 0x0100;

            [DllImport("user32.dll", SetLastError = true)]
            private static extern bool GetComboBoxInfo(IntPtr hwndCombo, ref ComboBoxInfo info);

            private sealed class ComboListToolTipHook : NativeWindow, IDisposable
            {
                private const int WM_MOUSEMOVE = 0x0200;
                private const int LB_ITEMFROMPOINT = 0x01A9;
                private readonly ThemedComboBox _owner;
                private readonly ToolTip _tip;
                private readonly Timer _delayTimer;
                private readonly NativeWindowWrapper _window;
                private string _pendingText;
                private int _pendingIndex = -1;

                [DllImport("user32.dll", EntryPoint = "SendMessageW")]
                private static extern IntPtr SendMessage(IntPtr hWnd, int msg, IntPtr wParam, IntPtr lParam);
                [DllImport("user32.dll", SetLastError = true)]
                private static extern bool GetWindowRect(IntPtr hWnd, out NativeRect rect);

                public ComboListToolTipHook(ThemedComboBox owner, ToolTip tip)
                {
                    _owner = owner;
                    _tip = tip;
                    _window = new NativeWindowWrapper();
                    _delayTimer = new Timer { Interval = 500 };
                    _delayTimer.Tick += (s, e) => ShowPendingItem();
                }

                public void Attach(IntPtr handle)
                {
                    if (handle == IntPtr.Zero || Handle == handle) return;
                    if (Handle != IntPtr.Zero) ReleaseHandle();
                    AssignHandle(handle);
                    _window.HandleValue = handle;
                }

                protected override void WndProc(ref Message m)
                {
                    if (m.Msg == WM_MOUSEMOVE)
                    {
                        int x = unchecked((short)((long)m.LParam & 0xffff));
                        int y = unchecked((short)(((long)m.LParam >> 16) & 0xffff));
                        int packed = unchecked((int)((uint)(ushort)x | ((uint)(ushort)y << 16)));
                        int hit = SendMessage(Handle, LB_ITEMFROMPOINT, IntPtr.Zero, new IntPtr(packed)).ToInt32();
                        bool outside = ((hit >> 16) & 0xffff) != 0;
                        int index = hit & 0xffff;
                        if (!outside && index >= 0 && index < _owner.Items.Count)
                        {
                            string text = HelivantaLocalization.Translate(_owner.GetItemText(_owner.Items[index]) ?? string.Empty);
                            NativeRect rect;
                            int availableWidth = GetWindowRect(Handle, out rect) ? Math.Max(20, rect.Right - rect.Left - 24) : Math.Max(20, _owner.DropDownWidth - 24);
                            bool clipped = text.Length > 0 && TextRenderer.MeasureText(text, _owner.Font).Width > availableWidth;
                            if (clipped)
                            {
                                if (_pendingIndex != index || !string.Equals(_pendingText, text, StringComparison.Ordinal))
                                {
                                    _delayTimer.Stop();
                                    _pendingIndex = index;
                                    _pendingText = text;
                                    _delayTimer.Start();
                                }
                            }
                            else ClearPending();
                        }
                        else ClearPending();
                    }
                    base.WndProc(ref m);
            }

                private void ShowPendingItem()
                {
                    _delayTimer.Stop();
                    if (Handle == IntPtr.Zero || string.IsNullOrEmpty(_pendingText) || _pendingIndex < 0)
                    {
                        ClearPending();
                        return;
                    }
                    NativeRect rect;
                    if (!GetWindowRect(Handle, out rect))
                    {
                        ClearPending();
                        return;
                    }
                    Point cursor = Cursor.Position;
                    int x = cursor.X - rect.Left;
                    int y = cursor.Y - rect.Top;
                    if (x < 0 || y < 0 || x >= rect.Right - rect.Left || y >= rect.Bottom - rect.Top)
                    {
                        ClearPending();
                        return;
                    }
                    int packed = unchecked((int)((uint)(ushort)x | ((uint)(ushort)y << 16)));
                    int hit = SendMessage(Handle, LB_ITEMFROMPOINT, IntPtr.Zero, new IntPtr(packed)).ToInt32();
                    if ((((hit >> 16) & 0xffff) != 0) || (hit & 0xffff) != _pendingIndex)
                    {
                        ClearPending();
                        return;
                    }
                    try { _tip.Show(_pendingText, _window, x + 14, y + _owner.ItemHeight, 6500); } catch { }
                }

                private void ClearPending()
                {
                    _delayTimer.Stop();
                    _pendingIndex = -1;
                    _pendingText = null;
                    try { if (Handle != IntPtr.Zero) _tip.Hide(_window); } catch { }
                }

                public void Dispose()
                {
                    try { _delayTimer.Stop(); _delayTimer.Dispose(); } catch { }
                    try { if (Handle != IntPtr.Zero) ReleaseHandle(); } catch { }
                    try { if (_window.HandleValue != IntPtr.Zero) _tip.Hide(_window); } catch { }
                    _window.HandleValue = IntPtr.Zero;
                }

                private sealed class NativeWindowWrapper : IWin32Window
                {
                    public IntPtr HandleValue;
                    public IntPtr Handle { get { return HandleValue; } }
                }
            }

            protected override void OnHandleCreated(EventArgs e)
            {
                base.OnHandleCreated(e);
                // Keep UxTheme enabled; Windows owns the drop-button's paint and non-client frame.
                if (_fieldBrush == IntPtr.Zero)
                    _fieldBrush = CreateSolidBrush(ColorTranslator.ToWin32(UiField));
                BackColor = UiField;
                ForeColor = UiText;
            }

            protected override void OnHandleDestroyed(EventArgs e)
            {
                if (_fieldBrush != IntPtr.Zero)
                {
                    try { DeleteObject(_fieldBrush); } catch { }
                    _fieldBrush = IntPtr.Zero;
                }
                base.OnHandleDestroyed(e);
            }

            public void RefreshTheme()
            {
                BackColor = UiField;
                ForeColor = UiText;
                if (IsHandleCreated)
                {
                    if (_fieldBrush != IntPtr.Zero)
                    {
                        try { DeleteObject(_fieldBrush); } catch { }
                        _fieldBrush = IntPtr.Zero;
                    }
                    _fieldBrush = CreateSolidBrush(ColorTranslator.ToWin32(UiField));
                    try
                    {
                        var info = new ComboBoxInfo { cbSize = Marshal.SizeOf(typeof(ComboBoxInfo)) };
                        if (GetComboBoxInfo(Handle, ref info))
                        {
                            // The editable text field is a child HWND with its own cached paint.
                            // Force it to repaint with the newly selected theme brush.
                            if (info.hwndItem != IntPtr.Zero)
                            {
                                InvalidateRect(info.hwndItem, IntPtr.Zero, true);
                                RedrawWindow(info.hwndItem, IntPtr.Zero, IntPtr.Zero,
                                    RDW_INVALIDATE | RDW_ERASE | RDW_UPDATENOW | RDW_ALLCHILDREN);
                                UpdateWindow(info.hwndItem);
                            }
                            if (info.hwndList != IntPtr.Zero)
                            {
                                InvalidateRect(info.hwndList, IntPtr.Zero, true);
                                RedrawWindow(info.hwndList, IntPtr.Zero, IntPtr.Zero,
                                    RDW_INVALIDATE | RDW_ERASE | RDW_UPDATENOW | RDW_ALLCHILDREN);
                                UpdateWindow(info.hwndList);
                            }
                        }
                        InvalidateRect(Handle, IntPtr.Zero, true);
                        RedrawWindow(Handle, IntPtr.Zero, IntPtr.Zero,
                            RDW_INVALIDATE | RDW_ERASE | RDW_UPDATENOW | RDW_ALLCHILDREN);
                        UpdateWindow(Handle);
                    }
                    catch { }
                }
                Invalidate();
            }

            protected override void WndProc(ref Message m)
            {
                bool repaintArrow = m.Msg == WM_PAINT || m.Msg == WM_SIZE;
                // A wheel gesture over a closed selector must not silently change its value.
                // Forward it to the first scrollable parent instead.
                if (m.Msg == WM_MOUSEWHEEL && !DroppedDown)
                {
                    try
                    {
                        Control ancestor = Parent;
                        while (ancestor != null)
                        {
                            if (ancestor is ScrollableControl scrollable && scrollable.AutoScroll && ancestor.IsHandleCreated)
                            {
                                SendMessage(ancestor.Handle, WM_MOUSEWHEEL, m.WParam, m.LParam);
                                m.Result = IntPtr.Zero;
                                return;
                            }
                            ancestor = ancestor.Parent;
                        }
                    }
                    catch { }
                    m.Result = IntPtr.Zero;
                    return;
                }

                // Preserve field text colors for child edit/list HWNDs. WM_PAINT/WM_NCPAINT
                // are intentionally handled only by base.WndProc: in the previous implementation
                // the base handler validated the update region, then custom code drew over the
                // HWND via Graphics.FromHwnd/GetWindowDC. Those un-clipped writes could survive
                // when a parent TableLayoutPanel row collapsed or the control moved.
                if (m.Msg == WM_CTLCOLOREDIT || m.Msg == WM_CTLCOLORSTATIC || m.Msg == WM_CTLCOLORLISTBOX)
                {
                    if (_fieldBrush != IntPtr.Zero)
                    {
                        SetBkColor(m.WParam, ColorTranslator.ToWin32(UiField));
                        SetTextColor(m.WParam, ColorTranslator.ToWin32(UiText));
                        m.Result = _fieldBrush;
                        return;
                    }
                }
                base.WndProc(ref m);
                if (repaintArrow && IsHandleCreated && !IsDisposed && ClientSize.Width > 0 && ClientSize.Height > 0)
                {
                    try
                    {
                        float dpiScale = Math.Max(1f, DeviceDpi / 96f);
                        Rectangle nativeButton = GetNativeDropButtonBounds();
                        var buttonRect = Rectangle.Intersect(ClientRectangle, nativeButton);
                        if (buttonRect.Width > 0 && buttonRect.Height > 0)
                        {
                            buttonRect.Inflate(-1, -1);
                            using (Graphics g = Graphics.FromHwnd(Handle))
                            using (var fill = new SolidBrush(AmberButton))
                            using (var edge = new Pen(AmberButtonEdge, Math.Max(1f, dpiScale)))
                            using (var chevron = new Pen(Color.White, Math.Max(1.5f, 1.7f * dpiScale)))
                            {
                                g.SmoothingMode = SmoothingMode.AntiAlias;
                                g.FillRectangle(fill, buttonRect);
                                g.DrawLine(edge, buttonRect.Left, buttonRect.Top, buttonRect.Left, buttonRect.Bottom);
                                float cx = buttonRect.Left + buttonRect.Width / 2f;
                                float cy = buttonRect.Top + buttonRect.Height / 2f;
                                float d = 3.5f * dpiScale;
                                g.DrawLine(chevron, cx - d / 2f, cy - d, cx + d / 2f, cy);
                                g.DrawLine(chevron, cx + d / 2f, cy, cx - d / 2f, cy + d);
                            }
                        }
                        // A deliberate themed frame keeps the Template field visible in Light theme.
                        Color frameColor = Focused ? UiAccentHover : UiControlBorder;
                        using (Graphics g = Graphics.FromHwnd(Handle))
                        using (var frame = new Pen(frameColor, Math.Max(1f, dpiScale)))
                            g.DrawRectangle(frame, 0, 0, Math.Max(0, ClientSize.Width - 1), Math.Max(0, ClientSize.Height - 1));
                    }
                    catch { /* Native repaint should never interrupt the dialog. */ }
                }
            }

            private Rectangle GetNativeDropButtonBounds()
            {
                // COMBOBOXINFO rectangles are reported in screen coordinates. Convert the actual
                // native dropdown-button bounds to this ComboBox's client coordinates so DPI,
                // theme metrics, window placement and the embedded edit control cannot shift the
                // amber overlay over the editable diameter/pitch text.
                try
                {
                    if (IsHandleCreated)
                    {
                        var info = new ComboBoxInfo { cbSize = Marshal.SizeOf(typeof(ComboBoxInfo)) };
                        if (GetComboBoxInfo(Handle, ref info))
                        {
                            Point topLeft = PointToClient(new Point(info.rcButton.Left, info.rcButton.Top));
                            Point bottomRight = PointToClient(new Point(info.rcButton.Right, info.rcButton.Bottom));
                            Rectangle native = Rectangle.FromLTRB(topLeft.X, topLeft.Y, bottomRight.X, bottomRight.Y);
                            if (native.Width > 0 && native.Width <= ClientSize.Width && native.Height > 0 &&
                                native.Left >= 0 && native.Top >= 0 && native.Right <= ClientSize.Width &&
                                native.Bottom <= ClientSize.Height)
                                return native;
                        }
                    }
                }
                catch { }
                float dpiScale = Math.Max(1f, DeviceDpi / 96f);
                int width = Math.Min(ClientSize.Width, (int)Math.Round(24f * dpiScale));
                return new Rectangle(Math.Max(0, ClientSize.Width - width), 0, width, ClientSize.Height);
            }

            protected override void OnGotFocus(EventArgs e)
            {
                base.OnGotFocus(e);
                Invalidate();
            }

            protected override void OnLostFocus(EventArgs e)
            {
                base.OnLostFocus(e);
                Invalidate();
            }

            protected override void OnDrawItem(DrawItemEventArgs e)
            {
                if (e.Index < 0 || e.Index >= Items.Count)
                {
                    // Draw only the edit/display portion. Reserving the native arrow width avoids
                    // stale field pixels visually encroaching on the drop button.
                    float dpiScale = Math.Max(1f, DeviceDpi / 96f);
                    int fieldPadding = Math.Max(1, (int)Math.Ceiling(dpiScale));
                    Rectangle fieldBounds = e.Bounds;
                    Rectangle nativeButton = GetNativeDropButtonBounds();
                    int fieldRight = Math.Max(fieldBounds.Left + 1, nativeButton.Left - fieldPadding);
                    fieldBounds.Width = Math.Max(1, Math.Min(fieldBounds.Width, fieldRight - fieldBounds.Left));
                    fieldBounds.Height = Math.Max(1, Math.Min(fieldBounds.Height, ClientSize.Height));
                    using (var brush = new SolidBrush(UiField))
                        e.Graphics.FillRectangle(brush, fieldBounds);
                    string fieldText = ThreadStandardSelectionPolicy.ResolveFieldDisplayText(
                        _closedFieldTextOverride, Text ?? string.Empty, DroppedDown);
                    if (string.IsNullOrEmpty(fieldText) && !DroppedDown &&
                        SelectedIndex >= 0 && SelectedIndex < Items.Count)
                        fieldText = HelivantaLocalization.Translate(GetItemText(Items[SelectedIndex]) ?? string.Empty);
                    if (!string.IsNullOrEmpty(fieldText))
                        fieldText = HelivantaLocalization.Translate(fieldText);
                    TextRenderer.DrawText(e.Graphics, fieldText, Font, fieldBounds, UiText,
                            TextFormatFlags.Left | TextFormatFlags.VerticalCenter | TextFormatFlags.EndEllipsis | TextFormatFlags.NoPrefix);
                    return;
                }

                bool selected = DroppedDown && (e.State & DrawItemState.Selected) != 0;
                Color fill = selected ? UiAccent : UiField;
                using (var brush = new SolidBrush(fill))
                    e.Graphics.FillRectangle(brush, e.Bounds);
                string itemText = HelivantaLocalization.Translate(GetItemText(Items[e.Index]) ?? string.Empty);
                if (!DroppedDown && e.Index == SelectedIndex)
                    itemText = HelivantaLocalization.Translate(ThreadStandardSelectionPolicy.ResolveFieldDisplayText(
                        _closedFieldTextOverride, itemText, false));
                TextRenderer.DrawText(e.Graphics, itemText, Font, e.Bounds, UiText,
                    TextFormatFlags.Left | TextFormatFlags.VerticalCenter | TextFormatFlags.EndEllipsis | TextFormatFlags.NoPrefix);
                if (selected)
                    e.Graphics.DrawRectangle(Pens.White, e.Bounds.Left, e.Bounds.Top,
                        Math.Max(0, e.Bounds.Width - 1), Math.Max(0, e.Bounds.Height - 1));
            }
        }

        private sealed class ThemedCheckBox : CheckBox
        {
            public ThemedCheckBox()
            {
                SetStyle(ControlStyles.UserPaint | ControlStyles.AllPaintingInWmPaint | ControlStyles.OptimizedDoubleBuffer | ControlStyles.ResizeRedraw | ControlStyles.Opaque, true);
                BackColor = UiPanel;
                ForeColor = UiText;
                AutoSize = true;
                FlatStyle = FlatStyle.Flat;
                FlatAppearance.BorderSize = 0;
                UseVisualStyleBackColor = false;
            }

            public override Size GetPreferredSize(Size proposedSize)
            {
                Size text = TextRenderer.MeasureText(Text ?? string.Empty, Font, new Size(1000, 1000), TextFormatFlags.NoPrefix);
                return new Size(text.Width + 25, Math.Max(20, text.Height + 2));
            }

            protected override void OnPaintBackground(PaintEventArgs e)
            {
                using (var brush = new SolidBrush(UiPanel))
                    e.Graphics.FillRectangle(brush, ClientRectangle);
            }

            protected override void OnPaint(PaintEventArgs e)
            {
                e.Graphics.SmoothingMode = SmoothingMode.AntiAlias;
                e.Graphics.Clear(UiPanel);
                const int box = 15;
                int y = Math.Max(2, (Height - box) / 2);
                using (var fill = new SolidBrush(Checked ? UiAccent : UiField))
                    e.Graphics.FillRectangle(fill, 0, y, box, box);
                using (var pen = new Pen(Enabled ? UiControlBorder : UiBorder, 1f))
                    e.Graphics.DrawRectangle(pen, 0.5f, y + 0.5f, box - 1, box - 1);
                if (Checked)
                {
                    using (var pen = new Pen(Color.White, 1.7f))
                    {
                        pen.StartCap = LineCap.Round; pen.EndCap = LineCap.Round;
                        e.Graphics.DrawLines(pen, new[] { new PointF(3.5f, y + 7.5f), new PointF(6.5f, y + 10.5f), new PointF(12f, y + 4.5f) });
                    }
                }
                TextRenderer.DrawText(e.Graphics, Text ?? string.Empty, Font, new Rectangle(22, 0, Math.Max(0, Width - 22), Height), UiText, TextFormatFlags.Left | TextFormatFlags.VerticalCenter | TextFormatFlags.NoPrefix);
            }
        }

        private sealed class ThemedRadioButton : RadioButton
        {
            public ThemedRadioButton()
            {
                SetStyle(ControlStyles.UserPaint | ControlStyles.AllPaintingInWmPaint | ControlStyles.OptimizedDoubleBuffer | ControlStyles.ResizeRedraw | ControlStyles.Opaque, true);
                BackColor = UiPanel;
                ForeColor = UiText;
                AutoSize = true;
                FlatStyle = FlatStyle.Flat;
                FlatAppearance.BorderSize = 0;
                UseVisualStyleBackColor = false;
            }

            public override Size GetPreferredSize(Size proposedSize)
            {
                Size text = TextRenderer.MeasureText(Text ?? string.Empty, Font, new Size(1000, 1000), TextFormatFlags.NoPrefix);
                return new Size(text.Width + 25, Math.Max(20, text.Height + 2));
            }

            protected override void OnPaintBackground(PaintEventArgs e)
            {
                using (var brush = new SolidBrush(UiPanel))
                    e.Graphics.FillRectangle(brush, ClientRectangle);
            }

            protected override void OnPaint(PaintEventArgs e)
            {
                e.Graphics.SmoothingMode = SmoothingMode.AntiAlias;
                e.Graphics.Clear(UiPanel);
                const int d = 15;
                int y = Math.Max(2, (Height - d) / 2);
                using (var brush = new SolidBrush(UiField)) e.Graphics.FillEllipse(brush, 0, y, d, d);
                using (var pen = new Pen(Enabled ? UiControlBorder : UiBorder, 1.5f)) e.Graphics.DrawEllipse(pen, 0.75f, y + 0.75f, d - 1.5f, d - 1.5f);
                if (Checked)
                {
                    using (var brush = new SolidBrush(UiAccent)) e.Graphics.FillEllipse(brush, 4, y + 4, 7, 7);
                }
                TextRenderer.DrawText(e.Graphics, Text ?? string.Empty, Font, new Rectangle(22, 0, Math.Max(0, Width - 22), Height), UiText, TextFormatFlags.Left | TextFormatFlags.VerticalCenter | TextFormatFlags.NoPrefix);
            }
        }

        private sealed class RoundedIconButton : Button
        {
            private bool _hover;
            private bool _pressed;
            private readonly ButtonGlyph _glyph;
            private readonly bool _isPrimary;
            private readonly bool _iconOnly;

            public RoundedIconButton(ButtonGlyph glyph, bool isPrimary)
            {
                _glyph = glyph;
                _isPrimary = isPrimary;
                _iconOnly = (glyph == ButtonGlyph.Info || glyph == ButtonGlyph.Help || glyph == ButtonGlyph.Settings) && !isPrimary;

                SetStyle(ControlStyles.UserPaint | ControlStyles.AllPaintingInWmPaint |
                         ControlStyles.OptimizedDoubleBuffer | ControlStyles.ResizeRedraw |
                         ControlStyles.Opaque, true);
                FlatStyle = FlatStyle.Flat;
                FlatAppearance.BorderSize = 0;
                UseVisualStyleBackColor = false;
                TabStop = true;
                Cursor = Cursors.Hand;
                Padding = Padding.Empty;
                TextAlign = ContentAlignment.MiddleCenter;
            }

            protected override void OnCreateControl()
            {
                base.OnCreateControl();
                UpdateRegion();
            }

            protected override void OnResize(EventArgs e)
            {
                base.OnResize(e);
                UpdateRegion();
            }

            private void UpdateRegion()
            {
                if (Width < 2 || Height < 2) return;
                using (var path = CreateRoundedPath(new Rectangle(0, 0, Width - 1, Height - 1), Math.Min(5, Math.Max(3, Height / 10))))
                {
                    Region old = Region;
                    Region = new Region(path);
                    old?.Dispose();
                }
            }

            protected override void OnMouseEnter(EventArgs e)
            {
                _hover = true;
                Invalidate();
                base.OnMouseEnter(e);
            }

            protected override void OnMouseLeave(EventArgs e)
            {
                _hover = false;
                _pressed = false;
                Invalidate();
                base.OnMouseLeave(e);
            }

            protected override void OnMouseDown(MouseEventArgs e)
            {
                if (Enabled && e.Button == MouseButtons.Left)
                {
                    _pressed = true;
                    Invalidate();
                }
                base.OnMouseDown(e);
            }

            protected override void OnMouseUp(MouseEventArgs e)
            {
                _pressed = false;
                Invalidate();
                base.OnMouseUp(e);
            }

            protected override void OnMouseCaptureChanged(EventArgs e)
            {
                if (!Capture && _pressed)
                {
                    _pressed = false;
                    Invalidate();
                }
                base.OnMouseCaptureChanged(e);
            }

            protected override void OnGotFocus(EventArgs e)
            {
                Invalidate();
                base.OnGotFocus(e);
            }

            protected override void OnLostFocus(EventArgs e)
            {
                _pressed = false;
                Invalidate();
                base.OnLostFocus(e);
            }

            protected override void OnEnabledChanged(EventArgs e)
            {
                if (!Enabled)
                {
                    _hover = false;
                    _pressed = false;
                }
                Invalidate();
                base.OnEnabledChanged(e);
            }

            protected override void OnPaintBackground(PaintEventArgs e)
            {
                using (var brush = new SolidBrush(Parent != null ? Parent.BackColor : UiSurface))
                    e.Graphics.FillRectangle(brush, ClientRectangle);
            }

            protected override void OnPaint(PaintEventArgs e)
            {
                Graphics g = e.Graphics;
                g.SmoothingMode = SmoothingMode.AntiAlias;
                g.PixelOffsetMode = PixelOffsetMode.HighQuality;
                g.Clear(Parent != null ? Parent.BackColor : UiSurface);

                var rect = new Rectangle(0, 0, Math.Max(1, Width - 1), Math.Max(1, Height - 1));
                int radius = Math.Min(8, Math.Max(4, Height / 4));
                bool highContrast = SystemInformation.HighContrast;
                Color fill;
                Color border;
                Color ink;

                if (highContrast)
                {
                    fill = !Enabled ? SystemColors.Control :
                        _pressed ? SystemColors.Highlight :
                        _hover || Focused ? SystemColors.ControlLight :
                        (_isPrimary ? SystemColors.Highlight : SystemColors.Control);
                    border = SystemColors.WindowText;
                    ink = !Enabled ? SystemColors.GrayText :
                        (_isPrimary && !_hover && !_pressed ? SystemColors.HighlightText : SystemColors.ControlText);
                }
                else if (!Enabled)
                {
                    fill = UiPanel2;
                    border = UiBorder;
                    ink = UiMuted;
                }
                else if (_pressed)
                {
                    fill = _isPrimary ? ControlPaint.Dark(UiAccent) : UiField;
                    border = UiAccentHover;
                    ink = UiText;
                }
                else if (_isPrimary)
                {
                    fill = _hover ? UiAccentHover : UiAccent;
                    border = UiAccentHover;
                    ink = Color.White;
                }
                else
                {
                    fill = _hover ? UiAccentSoft : UiPanel2;
                    border = (_hover || Focused) ? UiAccentHover : UiControlBorder;
                    ink = UiText;
                }

                using (var path = CreateRoundedPath(rect, _iconOnly ? Math.Min(5, Math.Max(3, rect.Height / 10)) : radius))
                using (var brush = new SolidBrush(fill))
                using (var pen = new Pen(border, 1f))
                {
                    g.FillPath(brush, path);
                    g.DrawPath(pen, path);
                }

                bool informationActionGlyph = _glyph == ButtonGlyph.Edit || _glyph == ButtonGlyph.NewThread ||
                    _glyph == ButtonGlyph.Preview || _glyph == ButtonGlyph.Analyze || _glyph == ButtonGlyph.Edges;
                int iconSize = (_glyph == ButtonGlyph.Reset || _glyph == ButtonGlyph.Undo) ? 18 :
                    (informationActionGlyph ? 32 : 16);
                bool hasText = !string.IsNullOrWhiteSpace(Text);
                Font drawFont = Font;
                int textWidth = hasText ? MeasureCaptionWidth(Text, drawFont) : 0;
                int groupWidth = hasText ? iconSize + 7 + textWidth : iconSize;
                int gx = hasText ? Math.Max(6, (Width - groupWidth) / 2) : Math.Max(0, (Width - iconSize) / 2);
                int gy = Math.Max(0, (Height - iconSize) / 2);
                var glyphRect = new Rectangle(gx, gy, iconSize, iconSize);
                var saved = g.Save();
                try
                {
                    float scale = iconSize / 16f;
                    g.TranslateTransform(glyphRect.X, glyphRect.Y);
                    g.ScaleTransform(scale, scale);
                    DrawGlyph(g, new Rectangle(0, 0, 16, 16), _glyph, ink);
                }
                finally { g.Restore(saved); }

                if (hasText)
                {
                    int tx = gx + iconSize + 7;
                    var textRect = new Rectangle(tx, 0, Math.Max(0, Width - tx - 6), Height);
                    TextRenderer.DrawText(g, Text, drawFont, textRect, ink,
                        TextFormatFlags.Left | TextFormatFlags.VerticalCenter | TextFormatFlags.NoPrefix |
                        TextFormatFlags.SingleLine | TextFormatFlags.NoPadding | TextFormatFlags.EndEllipsis);
                }

                // Focus is visible for icon-only header actions as well as full buttons.
                if (Focused && ShowFocusCues)
                {
                    var focusRect = new Rectangle(3, 3, Math.Max(1, Width - 7), Math.Max(1, Height - 7));
                    using (var focusPath = CreateRoundedPath(focusRect, _iconOnly ? Math.Min(4, Math.Max(2, focusRect.Height / 10)) : Math.Max(3, radius - 2)))
                    using (var focusPen = new Pen(highContrast ? SystemColors.Highlight : UiAccentHover, 1.2f))
                        g.DrawPath(focusPen, focusPath);
                }
            }

            private static int MeasureCaptionWidth(string caption, Font font)
            {
                if (string.IsNullOrEmpty(caption) || font == null) return 0;
                return TextRenderer.MeasureText(caption, font, new Size(2000, 40),
                    TextFormatFlags.NoPrefix | TextFormatFlags.SingleLine | TextFormatFlags.NoPadding).Width;
            }

            private static GraphicsPath CreateRoundedPath(Rectangle r, int radius)
            {
                int d = Math.Min(Math.Min(radius * 2, r.Width), r.Height);
                var p = new GraphicsPath();
                p.AddArc(r.X, r.Y, d, d, 180, 90);
                p.AddArc(r.Right - d, r.Y, d, d, 270, 90);
                p.AddArc(r.Right - d, r.Bottom - d, d, d, 0, 90);
                p.AddArc(r.X, r.Bottom - d, d, d, 90, 90);
                p.CloseFigure();
                return p;
            }

            private static GraphicsPath CreateEllipsePath(Rectangle r)
            {
                var p = new GraphicsPath();
                p.AddEllipse(r);
                return p;
            }

            private static void DrawGlyph(Graphics g, Rectangle r, ButtonGlyph glyph, Color color)
            {
                using (var pen = new Pen(color, 1.8f))
                {
                    pen.StartCap = LineCap.Round;
                    pen.EndCap = LineCap.Round;
                    pen.LineJoin = LineJoin.Round;
                    float cx = r.Left + r.Width / 2f, cy = r.Top + r.Height / 2f;
                    if (glyph == ButtonGlyph.Reset)
                    {
                        // Clear circular reset arrow, using the same rounded technical stroke as other glyphs.
                        g.DrawArc(pen, r.X + 2.5f, r.Y + 2.5f, 11f, 11f, 42f, 278f);
                        PointF tip = new PointF(r.X + 12.4f, r.Y + 3.0f);
                        g.DrawLine(pen, tip, new PointF(r.X + 12.1f, r.Y + 7.0f));
                        g.DrawLine(pen, tip, new PointF(r.X + 8.4f, r.Y + 4.8f));
                    }
                    else if (glyph == ButtonGlyph.Undo)
                    {
                        g.DrawLine(pen, r.X + 2.0f, r.Y + 5.0f, r.X + 6.0f, r.Y + 2.0f);
                        g.DrawLine(pen, r.X + 2.0f, r.Y + 5.0f, r.X + 6.0f, r.Y + 8.0f);
                        g.DrawBezier(pen, r.X + 4.5f, r.Y + 5.0f, r.X + 8.5f, r.Y + 4.0f,
                            r.X + 12.0f, r.Y + 5.5f, r.X + 12.0f, r.Y + 9.5f);
                        g.DrawBezier(pen, r.X + 12.0f, r.Y + 9.5f, r.X + 12.0f, r.Y + 12.0f,
                            r.X + 10.0f, r.Y + 13.0f, r.X + 7.5f, r.Y + 13.0f);
                    }
                    else if (glyph == ButtonGlyph.Edit)
                    {
                        float left = r.X + 2.5f, right = r.Right - 2.5f;
                        float y1 = r.Y + 4.0f, y2 = r.Y + 8.0f, y3 = r.Y + 12.0f;
                        g.DrawLine(pen, left, y1, right, y1);
                        g.DrawLine(pen, left, y2, right, y2);
                        g.DrawLine(pen, left, y3, right, y3);
                        g.DrawRectangle(pen, r.X + 5.0f, y1 - 1.5f, 3.0f, 3.0f);
                        g.DrawRectangle(pen, r.X + 9.0f, y2 - 1.5f, 3.0f, 3.0f);
                        g.DrawRectangle(pen, r.X + 3.0f, y3 - 1.5f, 3.0f, 3.0f);
                    }
                    else if (glyph == ButtonGlyph.NewThread)
                    {
                        g.DrawEllipse(pen, r.X + 7, r.Y + 2, 7, 3);
                        g.DrawLine(pen, r.X + 7, r.Y + 3, r.X + 7, r.Bottom - 3);
                        g.DrawLine(pen, r.X + 14, r.Y + 3, r.X + 14, r.Bottom - 3);
                        for (int yy = r.Y + 6; yy < r.Bottom - 3; yy += 4)
                            g.DrawArc(pen, r.X + 7, yy, 7, 3, 0, 180);
                        g.DrawLine(pen, r.X + 2, cy, r.X + 7, cy);
                        g.DrawLine(pen, r.X + 4, cy - 2, r.X + 4, cy + 2);
                    }
                    else if (glyph == ButtonGlyph.Preview)
                    {
                        g.DrawArc(pen, r.X + 1, r.Y + 4, r.Width - 2, r.Height - 8, 200, 140);
                        g.DrawArc(pen, r.X + 1, r.Y + 4, r.Width - 2, r.Height - 8, 20, 140);
                        g.DrawEllipse(pen, cx - 2.5f, cy - 2.5f, 5, 5);
                    }
                    else if (glyph == ButtonGlyph.Analyze)
                    {
                        g.DrawEllipse(pen, r.X + 2, r.Y + 2, 8, 8);
                        g.DrawLine(pen, r.X + 9, r.Y + 9, r.X + 14, r.Y + 14);
                        g.DrawLine(pen, r.X + 12, r.Y + 4, r.Right - 1, r.Y + 4);
                        g.DrawLine(pen, r.X + 12, r.Y + 8, r.Right - 1, r.Y + 8);
                        g.DrawLine(pen, r.X + 12, r.Y + 12, r.Right - 3, r.Y + 12);
                    }
                    else if (glyph == ButtonGlyph.Edges)
                    {
                        g.DrawArc(pen, r.X + 2, r.Y + 2, r.Width - 4, r.Height - 4, 205, 120);
                        g.DrawArc(pen, r.X + 2, r.Y + 2, r.Width - 4, r.Height - 4, 25, 120);
                        using (var brush = new SolidBrush(color)) g.FillRectangle(brush, cx - 1.5f, r.Y + 1, 3f, 3f);
                        g.DrawLine(pen, cx, r.Y + 4, cx, r.Bottom - 2);
                    }
                    else if (glyph == ButtonGlyph.Build)
                    {
                        using (var brush = new SolidBrush(color))
                            g.FillPolygon(brush, new[] { new PointF(r.X + 4, r.Y + 2),
                                new PointF(r.Right - 3, cy), new PointF(r.X + 4, r.Bottom - 2) });
                    }
                    else if (glyph == ButtonGlyph.Close)
                    {
                        g.DrawLine(pen, r.X + 4, r.Y + 4, r.Right - 4, r.Bottom - 4);
                        g.DrawLine(pen, r.Right - 4, r.Y + 4, r.X + 4, r.Bottom - 4);
                    }
                    else if (glyph == ButtonGlyph.Info)
                    {
                        // A compact hexagonal information mark, visually consistent with CAD tool glyphs.
                        var hex = new[] { new PointF(cx, r.Y + 2), new PointF(r.Right - 3, r.Y + 5),
                            new PointF(r.Right - 3, r.Bottom - 5), new PointF(cx, r.Bottom - 2),
                            new PointF(r.X + 3, r.Bottom - 5), new PointF(r.X + 3, r.Y + 5) };
                        g.DrawPolygon(pen, hex);
                        using (var brush = new SolidBrush(color)) g.FillEllipse(brush, cx - 1f, r.Y + 5, 2f, 2f);
                        g.DrawLine(pen, cx, r.Y + 8.5f, cx, r.Bottom - 4);
                    }
                    else if (glyph == ButtonGlyph.Help)
                    {
                        // Open manual/book instead of a generic question-mark badge.
                        g.DrawLine(pen, cx, r.Y + 3, cx, r.Bottom - 3);
                        g.DrawBezier(pen, r.X + 2, r.Y + 4, r.X + 5, r.Y + 2,
                            cx - 2, r.Y + 4, cx, r.Y + 5);
                        g.DrawBezier(pen, cx, r.Y + 5, cx + 2, r.Y + 4,
                            r.Right - 5, r.Y + 2, r.Right - 2, r.Y + 4);
                        g.DrawLine(pen, r.X + 2, r.Y + 4, r.X + 2, r.Bottom - 4);
                        g.DrawLine(pen, r.Right - 2, r.Y + 4, r.Right - 2, r.Bottom - 4);
                        g.DrawBezier(pen, r.X + 2, r.Bottom - 4, r.X + 6, r.Bottom - 6,
                            cx - 2, r.Bottom - 4, cx, r.Bottom - 3);
                        g.DrawBezier(pen, cx, r.Bottom - 3, cx + 2, r.Bottom - 4,
                            r.Right - 6, r.Bottom - 6, r.Right - 2, r.Bottom - 4);
                    }
                    else if (glyph == ButtonGlyph.Settings)
                    {
                        g.DrawEllipse(pen, cx - 4.2f, cy - 4.2f, 8.4f, 8.4f);
                        g.DrawEllipse(pen, cx - 1.7f, cy - 1.7f, 3.4f, 3.4f);
                        for (int tooth = 0; tooth < 8; tooth++) { double a = tooth * Math.PI / 4.0; float x1 = cx + (float)Math.Cos(a) * 4.5f, y1 = cy + (float)Math.Sin(a) * 4.5f; float x2 = cx + (float)Math.Cos(a) * 6.2f, y2 = cy + (float)Math.Sin(a) * 6.2f; g.DrawLine(pen, x1, y1, x2, y2); }
                    }
                    else if (glyph == ButtonGlyph.Select)
                    {
                        g.DrawArc(pen, r.X + 2, r.Y + 2, r.Width - 4, r.Height - 4, 25, 120);
                        g.DrawArc(pen, r.X + 2, r.Y + 2, r.Width - 4, r.Height - 4, 205, 120);
                        g.DrawLine(pen, r.X + 4, cy, r.Right - 4, cy);
                        g.DrawLine(pen, cx, r.Y + 4, cx, r.Bottom - 4);
                    }
                }
            }
        }

        /// <summary>
        /// Compact modal confirmation using the same visual palette and rounded controls as Helivanta.
        /// Defaults to «Нет» so the edit-to-create transition is never accepted accidentally.
        /// </summary>
        private static string GetConfirmationButtonTip(Button button)
        {
            if (button == null) return string.Empty;
            string name = !string.IsNullOrWhiteSpace(button.Text) ? button.Text.Trim() : (button.AccessibleName ?? string.Empty).Trim();
            if (string.Equals(name, "Да", StringComparison.OrdinalIgnoreCase) || string.Equals(name, "Yes", StringComparison.OrdinalIgnoreCase)) return HelivantaLocalization.Translate("Да — продолжить");
            if (string.Equals(name, "Нет", StringComparison.OrdinalIgnoreCase) || string.Equals(name, "No", StringComparison.OrdinalIgnoreCase)) return HelivantaLocalization.Translate("Нет — отменить");
            if (string.Equals(name, "Отмена", StringComparison.OrdinalIgnoreCase) || string.Equals(name, "Cancel", StringComparison.OrdinalIgnoreCase)) return HelivantaLocalization.Translate("Отмена — не менять модель");
            if (name.Length > 52) name = name.Substring(0, 51).TrimEnd() + "…";
            return HelivantaLocalization.Translate(name);
        }

        private sealed class ThemedConfirmDialog : Form
        {
            public ThemedConfirmDialog(string title, string message, bool acknowledgementOnly = false)
            {
                Text = HelivantaLocalization.Translate(title ?? "Helivanta");
                FormBorderStyle = FormBorderStyle.None;
                StartPosition = FormStartPosition.CenterParent;
                ShowInTaskbar = false;
                ShowIcon = false;
                ControlBox = false;
                MinimizeBox = false;
                MaximizeBox = false;
                TopMost = false;
                BackColor = UiBorder;
                ForeColor = UiText;
                Font = new Font("Segoe UI", 9f, FontStyle.Regular, GraphicsUnit.Point);
                ClientSize = new Size(560, 330);
                KeyPreview = true;

                var frame = new Panel
                {
                    Dock = DockStyle.Fill,
                    BackColor = UiModalBorder,
                    Padding = new Padding(1),
                    Margin = Padding.Empty
                };
                Controls.Add(frame);

                var surface = new TableLayoutPanel
                {
                    Dock = DockStyle.Fill,
                    BackColor = UiModalSurface,
                    ColumnCount = 1,
                    RowCount = 3,
                    Margin = Padding.Empty,
                    Padding = Padding.Empty
                };
                surface.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100f));
                surface.RowStyles.Add(new RowStyle(SizeType.Absolute, 38f));
                surface.RowStyles.Add(new RowStyle(SizeType.Percent, 100f));
                surface.RowStyles.Add(new RowStyle(SizeType.Absolute, 58f));
                frame.Controls.Add(surface);

                var header = new TableLayoutPanel
                {
                    Dock = DockStyle.Fill,
                    BackColor = UiModalHeader,
                    ColumnCount = 2,
                    RowCount = 1,
                    Margin = Padding.Empty,
                    Padding = Padding.Empty
                };
                header.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 4f));
                header.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100f));
                header.RowStyles.Add(new RowStyle(SizeType.Percent, 100f));
                surface.Controls.Add(header, 0, 0);

                var accent = new Panel
                {
                    Dock = DockStyle.Fill,
                    BackColor = UiModalBorder,
                    Margin = Padding.Empty
                };
                header.Controls.Add(accent, 0, 0);

                var headerText = new Label
                {
                    Text = HelivantaLocalization.Translate(title ?? "Helivanta"),
                    Dock = DockStyle.Fill,
                    Padding = new Padding(13, 0, 10, 0),
                    TextAlign = ContentAlignment.MiddleLeft,
                    ForeColor = UiModalHeaderText,
                    BackColor = UiModalHeader,
                    Font = new Font("Segoe UI Semibold", 9.5f, FontStyle.Bold, GraphicsUnit.Point),
                    AutoEllipsis = true
                };
                header.Controls.Add(headerText, 1, 0);

                var body = new Panel
                {
                    Dock = DockStyle.Fill,
                    BackColor = UiModalSurface,
                    Padding = new Padding(19, 13, 19, 9),
                    Margin = Padding.Empty
                };
                surface.Controls.Add(body, 0, 1);

                var footer = new Panel
                {
                    Dock = DockStyle.Fill,
                    BackColor = UiModalPanel,
                    Padding = new Padding(0, 11, 14, 10),
                    Margin = Padding.Empty
                };
                surface.Controls.Add(footer, 0, 2);

                var messageText = new RichTextBox
                {
                    Text = HelivantaLocalization.Translate(message ?? string.Empty),
                    Dock = DockStyle.Fill,
                    ReadOnly = true,
                    DetectUrls = false,
                    WordWrap = true,
                    ScrollBars = RichTextBoxScrollBars.Vertical,
                    BorderStyle = BorderStyle.None,
                    BackColor = UiModalSurface,
                    ForeColor = UiText,
                    Font = new Font("Segoe UI", 9f, FontStyle.Regular, GraphicsUnit.Point),
                    HideSelection = false,
                    TabStop = true,
                    ShortcutsEnabled = true,
                    Margin = Padding.Empty
                };
                // In WinForms, wheel messages are often delivered to the focused control.
                // Focus the text viewport when the pointer enters it so the requested wheel
                // navigation works even if a confirmation button initially held focus.
                messageText.MouseEnter += (s, e) => { if (!messageText.Focused) messageText.Focus(); };
                body.Controls.Add(messageText);

                var buttonStrip = new FlowLayoutPanel
                {
                    Dock = DockStyle.Right,
                    Width = acknowledgementOnly ? 120 : 180,
                    AutoSize = false,
                    FlowDirection = FlowDirection.LeftToRight,
                    WrapContents = false,
                    BackColor = UiModalPanel,
                    Margin = Padding.Empty,
                    Padding = Padding.Empty
                };
                footer.Controls.Add(buttonStrip);

                var noButton = new RoundedIconButton(ButtonGlyph.Close, false)
                {
                    Text = HelivantaLocalization.Translate("Нет"),
                    Size = new Size(80, 32),
                    Margin = new Padding(4, 0, 0, 0),
                    Font = new Font("Segoe UI", 9f, FontStyle.Regular, GraphicsUnit.Point),
                    AccessibleName = "Нет",
                    AccessibleDescription = "Отменить действие и оставить текущую модель без изменений"
                };
                noButton.DialogResult = DialogResult.No;
                var yesButton = new RoundedIconButton(acknowledgementOnly ? ButtonGlyph.Info : ButtonGlyph.Build, true)
                {
                    Text = HelivantaLocalization.Translate(acknowledgementOnly ? "Понятно" : "Да"),
                    Size = new Size(acknowledgementOnly ? 104 : 80, 32),
                    Margin = new Padding(4, 0, 0, 0),
                    Font = new Font("Segoe UI", 9f, FontStyle.Regular, GraphicsUnit.Point),
                    AccessibleName = acknowledgementOnly ? "Понятно" : "Да",
                    AccessibleDescription = acknowledgementOnly
                        ? "Закрыть предупреждение о нестандартной длине"
                        : "Подтвердить продолжение операции"
                };
                yesButton.DialogResult = acknowledgementOnly ? DialogResult.OK : DialogResult.Yes;
                var promptTip = new ToolTip { ShowAlways = true };
                promptTip.SetToolTip(noButton, GetConfirmationButtonTip(noButton));
                promptTip.SetToolTip(yesButton, GetConfirmationButtonTip(yesButton));
                FormClosed += (s, e) => promptTip.Dispose();
                if (!acknowledgementOnly)
                    buttonStrip.Controls.Add(noButton);
                buttonStrip.Controls.Add(yesButton);
                // Confirmations safely default to «Нет»; information/warning notices have one explicit OK path.
                AcceptButton = acknowledgementOnly ? (IButtonControl)yesButton : noButton;
                CancelButton = acknowledgementOnly ? (IButtonControl)yesButton : noButton;
                Shown += (s, e) => (acknowledgementOnly ? (Control)yesButton : noButton).Focus();
                // Apply localized accessible names/descriptions as well as visible text.
                HelivantaLocalization.Apply(this);
            }
        }

    }
}
