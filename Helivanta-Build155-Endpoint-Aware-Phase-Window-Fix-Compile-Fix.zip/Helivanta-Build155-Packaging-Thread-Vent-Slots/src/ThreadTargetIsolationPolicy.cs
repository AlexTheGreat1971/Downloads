﻿using System;

namespace ThreadPro
{
    /// <summary>
    /// Pure geometric identity check for source cylinders referenced by persisted thread metadata.
    /// Body identity is part of the key so geometrically coincident cylinders in separate bodies
    /// of a multi-body part do not collide. Axial translation is allowed because two thread regions
    /// can occupy different intervals on the same underlying cylindrical surface.
    /// </summary>
    internal static class ThreadTargetIsolationPolicy
    {
        internal static bool SameCylinder(ThreadTargetSnapshot a, ThreadTargetSnapshot b)
        {
            // Persisted metadata requires a body name (ThreadMetadataRecord.IsValid enforces it).
            if (a == null || b == null) return false;
            return SameCylinderGeometry(a.BodyName, b.BodyName, a.RadiusCm, b.RadiusCm,
                a.Center, a.Axis, b.Center, b.Axis, requireBodyNames: true);
        }

        /// <summary>
        /// Geometry-only overload shared with the interactive build-overlap guard. That path
        /// also checks document identity and historically permits a missing BodyName on either
        /// transient selection, while persisted metadata must have both names.
        /// </summary>
        internal static bool SameCylinderGeometry(string bodyNameA, string bodyNameB,
            double radiusA, double radiusB, double[] centerA, double[] axisA,
            double[] centerB, double[] axisB, bool requireBodyNames)
        {
            if (centerA == null || centerB == null || centerA.Length < 3 || centerB.Length < 3 ||
                axisA == null || axisB == null || axisA.Length < 3 || axisB.Length < 3 ||
                !IsFinitePositive(radiusA) || !IsFinitePositive(radiusB))
                return false;

            bool hasNameA = !string.IsNullOrWhiteSpace(bodyNameA);
            bool hasNameB = !string.IsNullOrWhiteSpace(bodyNameB);
            if (requireBodyNames && (!hasNameA || !hasNameB)) return false;
            if (hasNameA && hasNameB && !string.Equals(bodyNameA, bodyNameB, StringComparison.OrdinalIgnoreCase))
                return false;

            for (int i = 0; i < 3; i++)
            {
                if (!IsFinite(centerA[i]) || !IsFinite(centerB[i]) ||
                    !IsFinite(axisA[i]) || !IsFinite(axisB[i]))
                    return false;
            }

            if (Math.Abs(radiusA - radiusB) > 0.0005) return false;
            double dot = axisA[0] * axisB[0] + axisA[1] * axisB[1] + axisA[2] * axisB[2];
            if (!IsFinite(dot) || Math.Abs(dot) < 0.9999) return false;

            double dx = centerB[0] - centerA[0];
            double dy = centerB[1] - centerA[1];
            double dz = centerB[2] - centerA[2];
            double axial = dx * axisA[0] + dy * axisA[1] + dz * axisA[2];
            double rx = dx - axisA[0] * axial;
            double ry = dy - axisA[1] * axial;
            double rz = dz - axisA[2] * axial;
            double radialOffset = Math.Sqrt(rx * rx + ry * ry + rz * rz);
            return IsFinite(radialOffset) && radialOffset <= Math.Max(0.01, radiusA * 0.0005);
        }

        private static bool IsFinite(double value)
        {
            return !double.IsNaN(value) && !double.IsInfinity(value);
        }

        private static bool IsFinitePositive(double value)
        {
            return IsFinite(value) && value > 0.0;
        }
    }
}
