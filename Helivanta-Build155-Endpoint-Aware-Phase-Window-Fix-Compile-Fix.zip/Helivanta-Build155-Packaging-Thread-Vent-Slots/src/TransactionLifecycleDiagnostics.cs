﻿using System;
using System.Globalization;
using System.Text;

namespace ThreadPro
{
    /// <summary>
    /// Best-effort, read-only diagnostics for Inventor transaction and model-state investigations.
    /// It must never throw into a modeling operation or change transaction behavior.
    /// </summary>
    internal static class TransactionLifecycleDiagnostics
    {
        private static readonly object Sync = new object();

        internal static void Write(
            string component,
            string stage,
            Inventor.Application app = null,
            object document = null,
            Inventor.Transaction transaction = null,
            bool includeModelState = false,
            string detail = null)
        {
            try
            {
                // Use object here because Inventor's COM interop exposes PartDocument
                // without a compile-time implicit conversion to Inventor._Document in
                // every call site. The logger only reads a small common surface below.
                object resolvedDocument = document;
                if (resolvedDocument == null && app != null)
                {
                    try { resolvedDocument = app.ActiveDocument; }
                    catch { }
                }

                string currentTransaction = DescribeCurrentTransaction(app);
                string suppliedTransaction = DescribeTransaction(transaction);
                string modelState = includeModelState ? DescribeModelState(resolvedDocument) : "not-requested";
                string line = string.Format(CultureInfo.InvariantCulture,
                    "{0} pid={1} thread={2} component={3} stage={4} document={5} transactionArg={6} currentTransaction={7} model={8} detail={9}{10}",
                    System.DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss.fff", CultureInfo.InvariantCulture),
                    SafeProcessId(), System.Threading.Thread.CurrentThread.ManagedThreadId,
                    Clean(component), Clean(stage), DescribeDocument(resolvedDocument), suppliedTransaction,
                    currentTransaction, modelState, Clean(detail), System.Environment.NewLine);

                string directory = System.IO.Path.Combine(
                    System.Environment.GetFolderPath(System.Environment.SpecialFolder.LocalApplicationData),
                    "Helivanta", "Logs");
                System.IO.Directory.CreateDirectory(directory);
                lock (Sync) DiagnosticLogMaintenance.Append(directory, "transaction-lifecycle.log", line);
            }
            catch
            {
                // Diagnostics must never alter or prevent a native Inventor operation.
            }
        }

        private static string DescribeCurrentTransaction(Inventor.Application app)
        {
            if (app == null) return "app-unavailable";
            try
            {
                Inventor.Transaction current = app.TransactionManager.CurrentTransaction;
                return current == null ? "none" : DescribeTransaction(current);
            }
            catch (Exception ex)
            {
                return "unavailable(" + Clean(ex.GetType().Name + ": " + ex.Message) + ")";
            }
        }

        private static string DescribeTransaction(Inventor.Transaction transaction)
        {
            if (transaction == null) return "null";
            try
            {
                string displayName = transaction.DisplayName;
                if (!string.IsNullOrWhiteSpace(displayName)) return "\"" + Clean(displayName) + "\"";
                return "present(display-name-empty)";
            }
            catch (Exception ex)
            {
                return "present(display-name-unavailable:" + Clean(ex.GetType().Name + ": " + ex.Message) + ")";
            }
        }

        private static string DescribeDocument(object document)
        {
            if (document == null) return "unavailable";
            try
            {
                dynamic dynamicDocument = document;
                string displayName = System.Convert.ToString(dynamicDocument.DisplayName, CultureInfo.InvariantCulture);
                return "\"" + Clean(displayName) + "\"";
            }
            catch (Exception ex) { return "unavailable(" + Clean(ex.GetType().Name + ": " + ex.Message) + ")"; }
        }

        private static string DescribeModelState(object document)
        {
            if (document == null) return "document-unavailable";
            Inventor.PartDocument part = document as Inventor.PartDocument;
            if (part == null) return "not-part-document";

            try
            {
                dynamic dynamicPart = part;
                dynamic bodies = dynamicPart.ComponentDefinition.SurfaceBodies;
                int count = System.Convert.ToInt32(bodies.Count, CultureInfo.InvariantCulture);
                int visibleCount = 0;
                int visibilityReadable = 0;
                for (int i = 1; i <= count; i++)
                {
                    try
                    {
                        dynamic body = bodies.Item(i);
                        bool visible = System.Convert.ToBoolean(body.Visible, CultureInfo.InvariantCulture);
                        visibilityReadable++;
                        if (visible) visibleCount++;
                    }
                    catch { }
                }

                return string.Format(CultureInfo.InvariantCulture,
                    "surfaceBodies={0};visible={1};visibilityReadable={2}/{0}", count, visibleCount, visibilityReadable);
            }
            catch (Exception ex)
            {
                return "surfaceBodies-unavailable(" + Clean(ex.GetType().Name + ": " + ex.Message) + ")";
            }
        }

        private static int SafeProcessId()
        {
            try { return System.Diagnostics.Process.GetCurrentProcess().Id; }
            catch { return -1; }
        }

        private static string Clean(string value)
        {
            if (value == null) return "";
            return value.Replace("\r", "\\r").Replace("\n", "\\n").Replace("\t", "\\t");
        }
    }
}
