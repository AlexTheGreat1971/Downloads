﻿using System;
using System.Collections.Generic;
using System.Globalization;
using Inventor;

namespace ThreadPro
{
    /// <summary>Read-only snapshot for a native Inventor cosmetic ThreadFeature.</summary>
    internal sealed class NativeThreadOverlapSnapshot
    {
        internal ThreadFeature Feature;
        internal ThreadTarget Target;
        internal bool FullDepth;
        internal double LengthMm;
        internal double OffsetMm;
        internal bool IntervalKnown;
        internal bool StandardMatched;
        internal bool CatalogueMatched;
        internal string Name;
        internal string StandardLabel;
        internal string Designation;
        internal string ParameterSummary;
        internal string InspectionMessage;
    }

    /// <summary>
    /// Detects axial conflicts between a prospective Helivanta physical thread and native Inventor
    /// cosmetic thread features. It never edits features. Unknown intervals on the same source
    /// cylinder are rejected rather than being treated as safe.
    /// </summary>
    internal static class NativeThreadOverlapGuard
    {
        internal static List<NativeThreadOverlapSnapshot> Enumerate(Inventor.Application app, PartDocument doc,
            out bool complete, out string error)
        {
            var snapshots = new List<NativeThreadOverlapSnapshot>();
            complete = true;
            error = null;
            if (app == null || doc == null)
            {
                complete = false;
                error = HelivantaLocalization.Translate("Нет активной детали для проверки штатных косметических резьб Inventor.");
                return snapshots;
            }

            try
            {
                foreach (ThreadFeature feature in doc.ComponentDefinition.Features.ThreadFeatures)
                {
                    if (feature == null) continue;
                    var snapshot = new NativeThreadOverlapSnapshot { Feature = feature };
                    try { snapshot.Name = feature.Name; } catch { snapshot.Name = HelivantaLocalization.Translate("Штатная резьба Inventor"); }
                    if (string.IsNullOrWhiteSpace(snapshot.Name)) snapshot.Name = HelivantaLocalization.Translate("Штатная резьба Inventor");

                    bool fullDepth;
                    double lengthMm, offsetMm;
                    ThreadTarget target;
                    string inspectError;
                    bool resolved = NativeThreadConversionService.TryGetOverlapSnapshot(app, feature,
                        out target, out fullDepth, out lengthMm, out offsetMm, out inspectError);
                    snapshot.Target = target;
                    snapshot.FullDepth = fullDepth;
                    snapshot.LengthMm = lengthMm;
                    snapshot.OffsetMm = offsetMm;
                    snapshot.IntervalKnown = resolved && target != null;
                    snapshot.InspectionMessage = snapshot.IntervalKnown
                        ? HelivantaLocalization.Translate("Интервал штатной косметической резьбы определён.")
                        : (string.IsNullOrWhiteSpace(inspectError)
                            ? HelivantaLocalization.Translate("Не удалось безопасно определить интервал штатной косметической резьбы.")
                            : inspectError);
                    FillThreadLabels(snapshot);
                    snapshots.Add(snapshot);
                }
            }
            catch (Exception ex)
            {
                complete = false;
                error = "Не удалось полностью перечислить штатные ThreadFeature в Inventor: " + ex.Message;
            }
            return snapshots;
        }

        internal static bool ValidateNoOverlap(Inventor.Application app, IList<ThreadTarget> proposedTargets,
            ThreadParams parameters, ThreadFeature ignoredFeature, out string error)
        {
            error = null;
            if (proposedTargets == null || proposedTargets.Count == 0) return true;
            if (parameters == null)
            {
                error = "Построение остановлено: параметры будущей резьбы недоступны для проверки пересечения со штатными ThreadFeature Inventor.";
                return false;
            }
            PartDocument doc = null;
            try { doc = app == null ? null : app.ActiveDocument as PartDocument; } catch { }
            bool complete;
            string enumerationError;
            List<NativeThreadOverlapSnapshot> snapshots = Enumerate(app, doc, out complete, out enumerationError);
            if (!complete)
            {
                error = "Построение остановлено: не удалось проверить все штатные косметические резьбы Inventor. " +
                    (enumerationError ?? "Результат проверки неполон.");
                return false;
            }

            foreach (NativeThreadOverlapSnapshot snapshot in snapshots)
            {
                if (snapshot == null || snapshot.Feature == null) continue;
                if (ignoredFeature != null && NativeThreadConversionService.SameComObjectIdentity(snapshot.Feature, ignoredFeature))
                    continue; // The selected native feature is removed inside the conversion transaction.

                foreach (ThreadTarget proposed in proposedTargets)
                {
                    if (proposed == null) continue;
                    bool sameCylinder = snapshot.Target != null && SameCylinder(proposed, snapshot.Target);
                    bool sameFace = false;
                    if (!sameCylinder || snapshot.Target == null)
                    {
                        bool faceInspectionComplete;
                        if (!TrySharesThreadedFace(snapshot.Feature, proposed, out sameFace, out faceInspectionComplete) &&
                            !faceInspectionComplete)
                        {
                            error = "Построение остановлено: штатная резьба Inventor «" + snapshot.Name +
                                "» обнаружена, но не удалось проверить, относится ли она к выбранному цилиндру. Для безопасности устраните неопределённость и повторите построение.";
                            return false;
                        }
                    }

                    if (!sameCylinder && !sameFace) continue;

                    double newStart = 0.0, newEnd = 0.0, oldStart = 0.0, oldEnd = 0.0;
                    bool intervalsKnown = snapshot.IntervalKnown && snapshot.Target != null &&
                        NativeThreadOverlapPolicy.TryGetInterval(proposed.Center, proposed.U, proposed.LengthCm,
                            parameters.FullLength, parameters.LengthMm, parameters.OffsetMm,
                            proposed.Center, proposed.U, out newStart, out newEnd) &&
                        NativeThreadOverlapPolicy.TryGetInterval(snapshot.Target.Center, snapshot.Target.U,
                            snapshot.Target.LengthCm, snapshot.FullDepth, snapshot.LengthMm, snapshot.OffsetMm,
                            proposed.Center, proposed.U, out oldStart, out oldEnd);

                    if (NativeThreadOverlapPolicy.ShouldBlock(true, intervalsKnown,
                        intervalsKnown ? newStart : 0.0, intervalsKnown ? newEnd : 0.0,
                        intervalsKnown ? oldStart : 0.0, intervalsKnown ? oldEnd : 0.0))
                    {
                        string reason = intervalsKnown
                            ? "осевые интервалы физической и косметической резьбы пересекаются"
                            : "не удалось безопасно вычислить интервал косметической резьбы на том же цилиндре";
                        error = "Построение запрещено: штатная косметическая резьба Inventor «" + snapshot.Name +
                            "» — " + reason + ". Удалите/измените штатную резьбу либо скорректируйте длину и отступ физической резьбы.";
                        return false;
                    }
                }
            }
            return true;
        }

        internal static bool TrySharesThreadedFace(ThreadFeature feature, ThreadTarget proposed,
            out bool sharesFace, out bool inspectionComplete)
        {
            sharesFace = false;
            inspectionComplete = false;
            if (feature == null || proposed == null || proposed.Body == null || proposed.SelectedFace == null)
                return false;
            try
            {
                Faces threadedFaces = feature.ThreadedFace as Faces;
                if (threadedFaces == null)
                    return TryClassifyTaperedThreadAgainstCylinder(feature, proposed, out sharesFace, out inspectionComplete);
                int threadedCount = threadedFaces.Count;
                if (threadedCount < 1)
                    return TryClassifyTaperedThreadAgainstCylinder(feature, proposed, out sharesFace, out inspectionComplete);

                // Critical isolation rule: compare ThreadedFace only to the actual selected face.
                // Comparing it with every face of proposed.Body made any cosmetic thread in the
                // same solid look like a conflict, even when it was on a different cylinder.
                foreach (Face threadedFace in threadedFaces)
                {
                    if (threadedFace == null) continue;
                    if (NativeThreadConversionService.SameComObjectIdentity(threadedFace, proposed.SelectedFace))
                    {
                        sharesFace = true;
                        inspectionComplete = true;
                        return true;
                    }
                    bool supportComparisonComplete;
                    if (SameCylinderSupportSurface(threadedFace, proposed.SelectedFace, proposed.Body,
                        out supportComparisonComplete))
                    {
                        sharesFace = true;
                        inspectionComplete = true;
                        return true;
                    }
                    if (!supportComparisonComplete)
                    {
                        // The two faces have matching cylindrical support, but their bounded axial
                        // extents could not be read. Do not guess that they are unrelated.
                        inspectionComplete = false;
                        return false;
                    }
                }
                inspectionComplete = true;
                return true;
            }
            catch
            {
                return TryClassifyTaperedThreadAgainstCylinder(feature, proposed, out sharesFace, out inspectionComplete);
            }
        }

        /// <summary>
        /// Inventor permits TaperedThreadInfo only on a conical face. If its ThreadedFace
        /// collection is unavailable and the prospective selection is cylindrical, the surfaces
        /// cannot be the same support. This avoids a failed COM read on one tapered cosmetic
        /// feature blocking every unrelated cylindrical build in the same solid.
        /// Unknown/parallel ThreadFeature types remain fail-closed.
        /// </summary>
        private static bool TryClassifyTaperedThreadAgainstCylinder(ThreadFeature feature, ThreadTarget proposed,
            out bool sharesFace, out bool inspectionComplete)
        {
            sharesFace = false;
            inspectionComplete = false;
            try
            {
                bool proposedFaceIsCylinder = proposed != null && proposed.SelectedFace != null &&
                    proposed.SelectedFace.SurfaceType == SurfaceTypeEnum.kCylinderSurface;
                TaperedThreadInfo tapered = feature == null ? null : feature.ThreadInfo as TaperedThreadInfo;
                if (!NativeThreadOverlapPolicy.CanClassifyTaperedThreadAsUnrelatedToCylinder(
                    tapered != null, proposedFaceIsCylinder)) return false;
                inspectionComplete = true;
                return true;
            }
            catch { return false; }
        }

        private static bool SameCylinderSupportSurface(Face existing, Face selected, SurfaceBody selectedBody,
            out bool comparisonComplete)
        {
            comparisonComplete = true;
            if (existing == null || selected == null || selectedBody == null) return false;
            if (existing.SurfaceType != SurfaceTypeEnum.kCylinderSurface ||
                selected.SurfaceType != SurfaceTypeEnum.kCylinderSurface) return false;
            try
            {
                SurfaceBody existingBody = existing.SurfaceBody;
                bool sameBody = NativeThreadConversionService.SameComObjectIdentity(existingBody, selectedBody);
                if (!sameBody)
                {
                    string a = null, b = null;
                    try { a = existingBody == null ? null : existingBody.Name; } catch { }
                    try { b = selectedBody.Name; } catch { }
                    if (string.IsNullOrWhiteSpace(a) || string.IsNullOrWhiteSpace(b) ||
                        !string.Equals(a, b, StringComparison.OrdinalIgnoreCase)) return false;
                }

                Cylinder aCyl = existing.Geometry as Cylinder;
                Cylinder bCyl = selected.Geometry as Cylinder;
                if (aCyl == null || bCyl == null || Math.Abs(aCyl.Radius - bCyl.Radius) > 0.0005) return false;
                double[] axisA = NormalizeVector(new[] { aCyl.AxisVector.X, aCyl.AxisVector.Y, aCyl.AxisVector.Z });
                double[] axisB = NormalizeVector(new[] { bCyl.AxisVector.X, bCyl.AxisVector.Y, bCyl.AxisVector.Z });
                double dot = axisA[0] * axisB[0] + axisA[1] * axisB[1] + axisA[2] * axisB[2];
                if (!Finite(dot) || Math.Abs(dot) < 0.9999) return false;
                double[] pA = { aCyl.BasePoint.X, aCyl.BasePoint.Y, aCyl.BasePoint.Z };
                double[] pB = { bCyl.BasePoint.X, bCyl.BasePoint.Y, bCyl.BasePoint.Z };
                double dx = pB[0] - pA[0], dy = pB[1] - pA[1], dz = pB[2] - pA[2];
                double along = dx * axisA[0] + dy * axisA[1] + dz * axisA[2];
                double rx = dx - along * axisA[0], ry = dy - along * axisA[1], rz = dz - along * axisA[2];
                if (Math.Sqrt(rx * rx + ry * ry + rz * rz) > Math.Max(0.01, aCyl.Radius * 0.0005)) return false;

                // Sharing the infinite cylinder equation is not enough: equal-diameter stepped
                // shafts can lie on the same axis at disjoint axial stations. Only classify them as
                // the same support when the bounded face intervals actually overlap.
                double minA, maxA, minB, maxB;
                if (!TryGetFaceAxialRange(existing, axisA, out minA, out maxA) ||
                    !TryGetFaceAxialRange(selected, axisA, out minB, out maxB))
                {
                    comparisonComplete = false;
                    return false;
                }
                const double axialOverlapToleranceCm = 0.001; // 0.01 mm: ignore shared shoulder boundary only.
                return Math.Min(maxA, maxB) - Math.Max(minA, minB) > axialOverlapToleranceCm;
            }
            catch
            {
                comparisonComplete = false;
                return false;
            }
        }

        private static bool TryGetFaceAxialRange(Face face, double[] axis, out double minStation, out double maxStation)
        {
            minStation = double.PositiveInfinity;
            maxStation = double.NegativeInfinity;
            if (face == null || axis == null || axis.Length < 3) return false;
            int samples = 0;
            double localMin = double.PositiveInfinity;
            double localMax = double.NegativeInfinity;
            void AddStation(double x, double y, double z)
            {
                double station = x * axis[0] + y * axis[1] + z * axis[2];
                if (double.IsNaN(station) || double.IsInfinity(station)) return;
                localMin = Math.Min(localMin, station);
                localMax = Math.Max(localMax, station);
                samples++;
            }

            try
            {
                foreach (Edge edge in face.Edges)
                {
                    if (edge == null) continue;
                    bool centerRead = false;
                    try
                    {
                        if (edge.GeometryType == CurveTypeEnum.kCircleCurve)
                        {
                            Circle circle = edge.Geometry as Circle;
                            if (circle != null)
                            {
                                AddStation(circle.Center.X, circle.Center.Y, circle.Center.Z);
                                centerRead = true;
                            }
                        }
                        else if (edge.GeometryType == CurveTypeEnum.kCircularArcCurve)
                        {
                            Arc3d arc = edge.Geometry as Arc3d;
                            if (arc != null)
                            {
                                AddStation(arc.Center.X, arc.Center.Y, arc.Center.Z);
                                centerRead = true;
                            }
                        }
                    }
                    catch { }
                    if (centerRead) continue;
                    try
                    {
                        // Inventor.Edge exposes StartVertex and StopVertex. Circle/arc edges are
                        // handled above via their analytic center, while other edges use
                        // their endpoints to determine the bounded axial range.
                        Vertex startVertex = edge.StartVertex;
                        Vertex stopVertex = edge.StopVertex;
                        if (startVertex != null)
                        {
                            Inventor.Point startPoint = startVertex.Point;
                            if (startPoint != null) AddStation(startPoint.X, startPoint.Y, startPoint.Z);
                        }
                        if (stopVertex != null)
                        {
                            Inventor.Point stopPoint = stopVertex.Point;
                            if (stopPoint != null) AddStation(stopPoint.X, stopPoint.Y, stopPoint.Z);
                        }
                    }
                    catch { }
                }
            }
            catch { return false; }

            minStation = localMin;
            maxStation = localMax;
            return samples >= 2 && !double.IsInfinity(localMin) && !double.IsInfinity(localMax) &&
                localMax - localMin > 1e-5;
        }

        private static bool Finite(double value) => !double.IsNaN(value) && !double.IsInfinity(value);

        private static double[] NormalizeVector(double[] value)
        {
            double length = Math.Sqrt(value[0] * value[0] + value[1] * value[1] + value[2] * value[2]);
            if (!double.IsFinite(length) || length < 1e-12) throw new InvalidOperationException("Invalid cylinder axis.");
            return new[] { value[0] / length, value[1] / length, value[2] / length };
        }

        internal static bool SameCylinder(ThreadTarget left, ThreadTarget right)
        {
            if (left == null || right == null) return false;
            if (!string.IsNullOrWhiteSpace(left.SourceDocumentInternalName) &&
                !string.IsNullOrWhiteSpace(right.SourceDocumentInternalName) &&
                !string.Equals(left.SourceDocumentInternalName, right.SourceDocumentInternalName, StringComparison.OrdinalIgnoreCase))
                return false;

            // A geometric match alone must not merge coincident cylinders from different solid
            // bodies. If a transient target lacks a body name, ValidateNoOverlap falls back to
            // COM identity of ThreadFeature.ThreadedFace instead of guessing from radius/axis.
            if (string.IsNullOrWhiteSpace(left.BodyName) || string.IsNullOrWhiteSpace(right.BodyName) ||
                !string.Equals(left.BodyName, right.BodyName, StringComparison.OrdinalIgnoreCase))
                return false;

            return ThreadTargetIsolationPolicy.SameCylinderGeometry(left.BodyName, right.BodyName,
                left.RadiusCm, right.RadiusCm, left.Center, left.U, right.Center, right.U, requireBodyNames: true);
        }

        internal static bool SameCylinder(ThreadTargetSnapshot left, ThreadTarget right)
        {
            if (left == null || right == null) return false;
            return ThreadTargetIsolationPolicy.SameCylinderGeometry(left.BodyName, right.BodyName,
                left.RadiusCm, right.RadiusCm, left.Center, left.Axis, right.Center, right.U, requireBodyNames: false);
        }

        private static void FillThreadLabels(NativeThreadOverlapSnapshot snapshot)
        {
            snapshot.StandardLabel = "Штатная резьба Inventor";
            snapshot.Designation = "";
            snapshot.ParameterSummary = "";
            try
            {
                StandardThreadInfo info = snapshot.Feature.ThreadInfo as StandardThreadInfo;
                if (info == null)
                {
                    snapshot.Designation = snapshot.Name;
                    snapshot.ParameterSummary = "Параметры StandardThreadInfo недоступны.";
                    return;
                }

                string type = SafeString(() => info.ThreadTypeIdentifier);
                string designation = SafeString(() => info.ThreadDesignation);
                string nominal = SafeString(() => info.NominalSize);
                bool metric = info.Metric;
                double nativePitch = Convert.ToDouble(info.Pitch, CultureInfo.InvariantCulture);
                NativeThreadConversionPolicy.ProfileDefinition profile;
                string error;
                if (NativeThreadConversionPolicy.TryResolveProfile(type, designation, nominal, metric, nativePitch,
                    out profile, out error))
                {
                    snapshot.StandardMatched = true;
                    snapshot.CatalogueMatched = MatchesNativeCatalogue(profile);
                    snapshot.StandardLabel = ThreadStandards.Title(profile.Standard);
                    snapshot.Designation = string.IsNullOrWhiteSpace(designation) ? nominal : designation;
                    string mm = HelivantaLocalization.Translate("мм");
                    snapshot.ParameterSummary = "Ø " + profile.DiameterMm.ToString("0.###", CultureInfo.InvariantCulture) +
                        " " + mm + " · P " + profile.PitchMm.ToString("0.###", CultureInfo.InvariantCulture) + " " + mm + " · " +
                        HelivantaLocalization.Translate(info.Internal ? "внутренняя" : "наружная") + " · " + HelivantaLocalization.Translate(info.RightHanded ? "правая" : "левая") +
                        (snapshot.IntervalKnown
                            ? " · " + HelivantaLocalization.Translate("длина") + " " + snapshot.LengthMm.ToString("0.###", CultureInfo.InvariantCulture) +
                              " " + mm + " · " + HelivantaLocalization.Translate("отступ") + " " + snapshot.OffsetMm.ToString("0.###", CultureInfo.InvariantCulture) + " " + mm
                            : "");
                }
                else
                {
                    snapshot.StandardLabel = string.IsNullOrWhiteSpace(type) ? "Неопределённый стандарт Inventor" : type;
                    snapshot.Designation = string.IsNullOrWhiteSpace(designation) ? nominal : designation;
                    double pitchMm = metric ? nativePitch : nativePitch * 25.4;
                    snapshot.ParameterSummary = HelivantaLocalization.Translate("Шаг") + " " + pitchMm.ToString("0.###", CultureInfo.InvariantCulture) + " " + HelivantaLocalization.Translate("мм") + " · " +
                        HelivantaLocalization.Translate(info.Internal ? "внутренняя" : "наружная") + " · " + HelivantaLocalization.Translate(info.RightHanded ? "правая" : "левая");
                }
            }
            catch (Exception ex)
            {
                snapshot.Designation = snapshot.Name;
                snapshot.ParameterSummary = "Не удалось прочитать все параметры: " + ex.Message;
            }
        }

        private static bool MatchesNativeCatalogue(NativeThreadConversionPolicy.ProfileDefinition profile)
        {
            if (profile == null) return false;
            try
            {
                foreach (ThreadSize size in ThreadStandards.Sizes(profile.Standard))
                {
                    if (Math.Abs(size.DiameterMm - profile.DiameterMm) <= 0.001 &&
                        Math.Abs(size.PitchMm - profile.PitchMm) <= 0.001)
                        return true;
                }
            }
            catch { }
            return false;
        }

        private static string SafeString(Func<string> getter)
        {
            try { return getter() ?? ""; } catch { return ""; }
        }
    }
}
