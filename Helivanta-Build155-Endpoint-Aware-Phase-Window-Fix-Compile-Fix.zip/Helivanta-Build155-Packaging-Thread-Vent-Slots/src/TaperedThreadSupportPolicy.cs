using System;

namespace ThreadPro
{
    /// <summary>
    /// Pure policy for hiding only the native tapered ThreadFeature that is tagged as a member
    /// of a matching Helivanta physical tapered-thread group. Unrelated native features stay visible
    /// in the integrity report even when their designation happens to match.
    /// </summary>
    internal static class TaperedThreadSupportPolicy
    {
        internal static bool IsMatchingHiddenSupportFeature(bool displayInModel, bool hasTaperedInfo,
            bool hasMetadataTag, string taggedThreadId, string metadataThreadId, bool metadataIsTapered,
            string metadataStandard, string nativeStandard, string metadataDesignation,
            string metadataDisplayDesignation, string nativeDesignation)
        {
            if (displayInModel || !hasTaperedInfo || !hasMetadataTag || !metadataIsTapered)
                return false;
            if (string.IsNullOrWhiteSpace(taggedThreadId) || string.IsNullOrWhiteSpace(metadataThreadId) ||
                !string.Equals(taggedThreadId.Trim(), metadataThreadId.Trim(), StringComparison.Ordinal))
                return false;
            if (string.IsNullOrWhiteSpace(metadataStandard) || string.IsNullOrWhiteSpace(nativeStandard) ||
                !string.Equals(metadataStandard.Trim(), nativeStandard.Trim(), StringComparison.OrdinalIgnoreCase))
                return false;
            if (string.IsNullOrWhiteSpace(nativeDesignation)) return false;
            string designation = nativeDesignation.Trim();
            return (!string.IsNullOrWhiteSpace(metadataDesignation) &&
                    string.Equals(metadataDesignation.Trim(), designation, StringComparison.OrdinalIgnoreCase)) ||
                   (!string.IsNullOrWhiteSpace(metadataDisplayDesignation) &&
                    string.Equals(metadataDisplayDesignation.Trim(), designation, StringComparison.OrdinalIgnoreCase));
        }
    }
}
