using System;

namespace ThreadPro
{
    /// <summary>
    /// Pure, Inventor-independent preflight policy for the Packaging / Bottle Thread
    /// semi-standard prototype. This deliberately does not construct CAD geometry.
    /// All public dimensions are millimetres.
    /// </summary>
    internal static class PackagingThreadGeometryPolicy
    {
        internal const int MinStarts = 1;
        internal const int MaxStarts = 12;
        internal const double MinPitchMm = 0.25;
        internal const double MaxPitchMm = 12.0;
        internal const double MinDiameterMm = 1.0;
        internal const double MaxDiameterMm = 500.0;
        internal const double MinHeightRatio = 0.005;
        internal const double MaxHeightRatio = 0.06;
        internal const double MinHeightMm = 0.15;
        internal const double MaxHeightMm = 2.5;
        internal const double DefaultHeightRatio = 0.025;
        internal const double DefaultEmbedRatio = 0.20;
        internal const double MinEmbedMm = 0.05;
        internal const double MinRemainingWallMm = 0.6;

        // Keep a single helical ridge section within a conservative axial/radial envelope.
        // Base width is always smaller than pitch, while radial depth is prevented from
        // growing without bound when the diameter/height ratio is increased.
        internal const double MaxProfileDepthPitchRatio = 0.80;
        internal const double MinProfileBaseWidthPitchRatio = 0.55;
        internal const double MaxProfileBaseWidthPitchRatio = 0.80;
        internal const double CrestHalfWidthRatio = 0.25;

        internal sealed class ResolvedParameters
        {
            public double DiameterMm { get; internal set; }
            public double PitchMm { get; internal set; }
            public int Starts { get; internal set; }
            public double LeadMm { get; internal set; }
            public double HeightRatio { get; internal set; }
            public double HeightMm { get; internal set; }
            public double EmbedMm { get; internal set; }
            public double ClearanceMm { get; internal set; }
            public double EffectiveHeightMm { get; internal set; }
            public double MeasuredWallMm { get; internal set; }
            public bool IsInternalThread { get; internal set; }
        }

        internal static bool TryResolve(
            double diameterMm, double pitchMm, int starts, double heightRatio,
            double clearanceMm, double measuredWallMm, bool internalThread,
            out ResolvedParameters resolved, out string error)
        {
            resolved = null;
            error = null;

            if (!Finite(diameterMm) || diameterMm < MinDiameterMm || diameterMm > MaxDiameterMm)
                return Reject("Диаметр должен быть в диапазоне 1–500 мм.", out error);
            if (!Finite(pitchMm) || pitchMm < MinPitchMm || pitchMm > MaxPitchMm)
                return Reject("Шаг должен быть в диапазоне 0,25–12 мм.", out error);
            if (starts < MinStarts || starts > MaxStarts)
                return Reject("Число заходов должно быть от 1 до 12.", out error);
            if (!Finite(heightRatio) || heightRatio < MinHeightRatio || heightRatio > MaxHeightRatio)
                return Reject("Отношение высоты профиля к диаметру должно быть в диапазоне 0,005–0,06.", out error);
            if (!Finite(clearanceMm) || clearanceMm < 0.0 || clearanceMm > 0.5)
                return Reject("Зазор печати должен быть в диапазоне 0–0,5 мм и задаётся отдельно.", out error);
            if (!Finite(measuredWallMm) || measuredWallMm <= 0.0)
                return Reject("Не удалось надёжно определить положительную толщину стенки.", out error);

            double rawHeight = diameterMm * heightRatio;
            // Height used to scale with diameter only, independent of pitch. At larger
            // diameters this produced a very deep ridge on the same fixed-pitch section;
            // Inventor's sweep/Boolean kernel can then fail although small diameters work.
            // Limit total radial depth (height + embedded root) to 0.8 P, while preserving
            // the ratio-based height everywhere inside this geometric envelope.
            double maxDepthMm = pitchMm * MaxProfileDepthPitchRatio;
            double maxHeightFromPitch = Math.Min(
                maxDepthMm - MinEmbedMm,
                maxDepthMm / (1.0 + DefaultEmbedRatio));
            double upperHeight = Math.Min(MaxHeightMm, maxHeightFromPitch);
            if (!Finite(upperHeight) || upperHeight < MinHeightMm)
                return Reject("Выбранный шаг слишком мал для минимально допустимой высоты профиля. Увеличьте шаг.", out error);
            double height = Math.Max(MinHeightMm, Math.Min(upperHeight, rawHeight));
            double embed = Math.Max(MinEmbedMm, height * DefaultEmbedRatio);
            if (!Finite(height) || !Finite(embed) || height + embed > maxDepthMm + 1e-9)
                return Reject("Глубина профиля превышает безопасный предел для выбранного шага. Увеличьте шаг или уменьшите отношение высоты.", out error);

            // Positive inward ribs do not cut the wall, but a deep root overlap is not a
            // substitute for a sound wall. Keep both the generic minimum and an overlap limit.
            if (measuredWallMm < MinRemainingWallMm)
                return Reject("Толщина стенки меньше безопасного минимума 0,6 мм.", out error);
            if (internalThread && embed > measuredWallMm * 0.5 + 1e-9)
                return Reject("Для внутреннего положительного валика глубина соединения должна быть не больше половины измеренной стенки. Уменьшите высоту профиля или проверьте толщину стенки.", out error);

            // For the inward-facing rib, its crest radius is smaller than the bore radius.
            // For the outward-facing rib, its crest radius is larger than the stock radius.
            // Clearance is deliberately NOT applied to nominal height/profile dimensions.
            resolved = new ResolvedParameters
            {
                DiameterMm = diameterMm,
                PitchMm = pitchMm,
                Starts = starts,
                LeadMm = pitchMm * starts,
                HeightRatio = heightRatio,
                HeightMm = height,
                EmbedMm = embed,
                ClearanceMm = clearanceMm,
                EffectiveHeightMm = height,
                MeasuredWallMm = measuredWallMm,
                IsInternalThread = internalThread
            };
            return true;
        }


        /// <summary>
        /// Inventor's oriented cylindrical faces report IsParamReversed=true for an exterior
        /// shaft face and false for an interior bore face. Keep the inversion in one tested policy.
        /// </summary>
        internal static bool IsInternalFromFaceParamReversed(bool faceIsParamReversed) => !faceIsParamReversed;

        internal static bool TryResolveProfileRadiiMm(double cylinderRadiusMm, double heightMm, double embedMm,
            bool internalThread, out double rootRadiusMm, out double crestRadiusMm, out string error)
        {
            rootRadiusMm = 0.0;
            crestRadiusMm = 0.0;
            error = null;
            if (!Finite(cylinderRadiusMm) || cylinderRadiusMm <= 0.0 ||
                !Finite(heightMm) || heightMm <= 0.0 ||
                !Finite(embedMm) || embedMm <= 0.0)
                return Reject("Радиус и размеры профиля должны быть конечными положительными числами.", out error);

            rootRadiusMm = internalThread ? cylinderRadiusMm + embedMm : cylinderRadiusMm - embedMm;
            crestRadiusMm = internalThread ? cylinderRadiusMm - heightMm : cylinderRadiusMm + heightMm;
            if (!Finite(rootRadiusMm) || !Finite(crestRadiusMm) || rootRadiusMm <= 0.0 || crestRadiusMm <= 0.0)
                return Reject("Радиальная глубина профиля выходит за пределы положительного радиуса.", out error);
            if (internalThread && (rootRadiusMm <= cylinderRadiusMm || crestRadiusMm >= cylinderRadiusMm || rootRadiusMm <= crestRadiusMm))
                return Reject("Внутренний валик должен заходить в стенку корнем и выступать вершиной внутрь отверстия.", out error);
            if (!internalThread && (rootRadiusMm >= cylinderRadiusMm || crestRadiusMm <= cylinderRadiusMm || rootRadiusMm >= crestRadiusMm))
                return Reject("Наружный валик должен заходить в материал корнем и выступать вершиной наружу.", out error);
            return true;
        }

        internal static double ResolveProfileBaseWidthMm(double pitchMm, double heightMm, double embedMm)
        {
            if (!Finite(pitchMm) || pitchMm <= 0.0 || !Finite(heightMm) || heightMm <= 0.0 ||
                !Finite(embedMm) || embedMm < 0.0)
                throw new ArgumentException("Profile dimensions must be finite and positive.");

            double minimumWidth = pitchMm * MinProfileBaseWidthPitchRatio;
            double maximumWidth = pitchMm * MaxProfileBaseWidthPitchRatio;
            double widthForFlankRun = (heightMm + embedMm) * 1.8;
            return Math.Min(maximumWidth, Math.Max(minimumWidth, widthForFlankRun));
        }

        internal static bool TryGetTurns(double axialLengthMm, double leadMm, out double turns)
        {
            turns = 0.0;
            if (!Finite(axialLengthMm) || axialLengthMm <= 0.0 ||
                !Finite(leadMm) || leadMm <= 0.0) return false;
            turns = axialLengthMm / leadMm;
            return Finite(turns) && turns > 0.0;
        }

        internal static double GetStartPhaseDegrees(int startIndex, int starts)
        {
            if (starts < 1 || starts > MaxStarts || startIndex < 0 || startIndex >= starts)
                throw new ArgumentOutOfRangeException();
            return 360.0 * startIndex / starts;
        }

        private static bool Reject(string message, out string error)
        {
            error = message;
            return false;
        }

        private static bool Finite(double x) => !double.IsNaN(x) && !double.IsInfinity(x);
    }
}
