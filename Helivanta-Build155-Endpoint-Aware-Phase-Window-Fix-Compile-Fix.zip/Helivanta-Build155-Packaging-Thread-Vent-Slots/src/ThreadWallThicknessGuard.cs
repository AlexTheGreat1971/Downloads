﻿using System;
using System.Collections.Generic;
using System.Globalization;
using Inventor;

namespace ThreadPro
{
    internal sealed class ThreadWallThicknessAssessment
    {
        public bool IsSafe;
        public bool MeasurementComplete;
        public int SamplesMeasured;
        public double MinimumMeasuredWallCm;
        public double RootCutDepthCm;
        public double ChamferCutDepthCm;
        public double EffectiveCutDepthCm;
        public double RadiusAdjustmentCm;
        public double RemainingWallCm;
        public double RequiredRemainingWallCm;
        public string Message;
    }

    /// <summary>
    /// Preflight wall-thickness guard. It casts radial rays through the existing solid body at
    /// several axial stations and angular positions. It never mutates model geometry or starts a
    /// transaction. If Inventor cannot provide a reliable measurement, the build fails closed.
    /// </summary>
    internal static class ThreadWallThicknessGuard
    {
        private const int AngularSamples = 16;
        private const int AxialSamples = 7;
        // Denser tapered sampling is intentionally separate so the protected cylindrical guard
        // keeps its established cost/behavior. Near-end probes help reveal wall/step changes that
        // a coarse 2%-98% grid could miss on a thin lip adjacent to a shoulder.
        private const int TaperedAngularSamples = 32;
        private const int TaperedAxialSamples = 9;
        private const double RayRadiusCm = 0.00001;
        private const double MinimumProbeOffsetCm = 0.0005;
        private const double MaximumProbeOffsetCm = 0.005;
        private const double MillimetresPerCentimetre = 10.0;
        private static readonly double[] AxialFractions = { 0.02, 0.17, 0.33, 0.50, 0.67, 0.83, 0.98 };
        private static readonly double[] TaperedAxialFractions = { 0.001, 0.02, 0.17, 0.33, 0.50, 0.67, 0.83, 0.98, 0.999 };

        public static void ValidateOrThrow(Application app, ThreadTarget target, ThreadParams parameters)
        {
            ThreadWallThicknessAssessment assessment = Assess(app, target, parameters);
            if (assessment == null || !assessment.IsSafe)
                throw new InvalidOperationException(assessment == null
                    ? "Построение запрещено: не удалось проверить толщину стенки. Модель не изменена."
                    : assessment.Message);
        }

        public static ThreadWallThicknessAssessment Assess(Application app, ThreadTarget target, ThreadParams parameters)
        {
            if (app == null || target == null || parameters == null)
                return Blocked("Не удалось проверить толщину стенки: отсутствуют документ, поверхность или параметры.");

            PartDocument doc = null;
            try
            {
                doc = app.ActiveDocument as PartDocument;
                if (doc == null)
                    return Blocked("Построение запрещено: для проверки толщины стенки требуется активная деталь Inventor (.ipt).");

                string activeName = null;
                try { activeName = doc.InternalName; } catch { }
                if (!string.IsNullOrWhiteSpace(target.SourceDocumentInternalName) &&
                    !string.Equals(activeName, target.SourceDocumentInternalName, StringComparison.OrdinalIgnoreCase))
                    return Blocked("Построение запрещено: выбранная поверхность относится к другой детали. Выберите её заново в активном IPT.");

                if (target.Body == null)
                    return Blocked("Построение запрещено: Inventor не предоставил твёрдое тело выбранной поверхности, поэтому толщину стенки нельзя проверить безопасно.");
                if (!target.Body.IsSolid)
                    return Blocked("Построение запрещено: выбранная поверхность не принадлежит замкнутому твёрдому телу; проверка стенки невозможна.");

                // Thread type must match the actual picked surface. Otherwise the radial direction
                // of the cut and the direction into the material are ambiguous.
                if (target.IsExternal != parameters.External)
                    return Blocked("Построение запрещено: тип резьбы не соответствует выбранной поверхности. Для наружной поверхности выберите «Наружная», для стенки отверстия — «Внутренняя». Модель не изменена.");

                if (target.Center == null || target.Center.Length < 3 || target.U == null || target.U.Length < 3 ||
                    !Finite(target.RadiusCm) || target.RadiusCm <= 0.0 || !Finite(target.LengthCm) || target.LengthCm <= 0.0)
                    return Blocked("Построение запрещено: геометрические данные выбранного цилиндра неполны, толщину стенки измерить нельзя.");

                if (parameters.Starts < 1 || parameters.Starts > 12 || !Finite(parameters.PitchMm) || parameters.PitchMm <= 0.0 ||
                    !Finite(parameters.NominalDiaMm) || parameters.NominalDiaMm <= 0.0 || !Finite(parameters.ClearanceMm) || parameters.ClearanceMm < 0.0 ||
                    !Finite(parameters.OffsetMm) || parameters.OffsetMm < 0.0 || !Finite(parameters.LengthMm) ||
                    (!parameters.FullLength && parameters.LengthMm <= 0.0) ||
                    parameters.ChamferMode < 0 || parameters.ChamferMode > 3 || !Finite(parameters.ChamferMm) || parameters.ChamferMm < 0.0)
                    return Blocked("Построение запрещено: проверьте диаметр, шаг, число заходов, длину и отступ перед измерением стенки.");

                double pitchCm = parameters.PitchMm / MillimetresPerCentimetre;
                double offsetCm = parameters.OffsetMm / MillimetresPerCentimetre;
                double threadLengthCm = parameters.FullLength
                    ? target.LengthCm - offsetCm
                    : parameters.LengthMm / MillimetresPerCentimetre;
                if (offsetCm >= target.LengthCm - 1e-9 || threadLengthCm <= 0.0 ||
                    offsetCm + threadLengthCm > target.LengthCm + 1e-6)
                    return Blocked("Построение запрещено: длина/отступ выходит за доступную цилиндрическую поверхность; толщину стенки для этой зоны проверить нельзя.");

                ThreadProfileSpec spec = ThreadStandards.Spec(parameters.Standard);
                double clearanceCm = parameters.ClearanceMm / MillimetresPerCentimetre;
                double leadCm = pitchCm * parameters.Starts;
                Groove groove = ThreadStandards.ComputeGroove(spec, parameters.External, pitchCm, clearanceCm, leadCm, MillimetresPerCentimetre);
                double calculatedRadiusCm = parameters.External
                    ? parameters.NominalDiaMm / 20.0
                    : parameters.NominalDiaMm / 20.0 - ThreadStandards.MinorOffset(spec, pitchCm, MillimetresPerCentimetre);
                if (!Finite(calculatedRadiusCm) || calculatedRadiusCm <= 0.0 || groove == null || !Finite(groove.Depth) || groove.Depth <= 0.0)
                    return Blocked("Построение запрещено: невозможно определить расчётную глубину резьбы для проверки стенки.");

                string chamferFitError = ThreadWallThicknessPolicy.ValidateChamferFit(
                    parameters.External, calculatedRadiusCm, target.LengthCm, parameters.ChamferMode,
                    parameters.ChamferMm / MillimetresPerCentimetre, target.StartIsShoulder, target.EndIsShoulder);
                if (!string.IsNullOrWhiteSpace(chamferFitError))
                    return Blocked(chamferFitError);

                // The thread and chamfer are separate subtractive tools measured from the original
                // stock. Along a radial ray their removed volumes form a union, so the local
                // radial removal is max(root depth, chamfer depth), not their arithmetic sum.
                double chamferDepthCm = parameters.ChamferMm / MillimetresPerCentimetre;
                double effectiveCutDepthCm = ThreadWallThicknessPolicy.EffectiveCutDepthCm(
                    groove.Depth, parameters.ChamferMode != 0, chamferDepthCm);
                if (!Finite(effectiveCutDepthCm) || effectiveCutDepthCm <= 0.0)
                    return Blocked("Построение запрещено: глубина профиля с учётом фаски некорректна. Модель не изменена.");

                double[] axis = Normalize(target.U);
                double[] helper = Math.Abs(axis[0]) < 0.9 ? new[] { 1.0, 0.0, 0.0 } : new[] { 0.0, 1.0, 0.0 };
                double[] radialA = Normalize(Cross(axis, Cross(helper, axis)));
                double[] radialB = Normalize(Cross(axis, radialA));
                double probeOffset = Math.Max(MinimumProbeOffsetCm, Math.Min(MaximumProbeOffsetCm, target.RadiusCm * 0.0005));
                double minimumThickness = double.PositiveInfinity;
                int measured = 0;

                // Sample the actual feature interval, not just the picked edge. Offset the ray
                // start a small amount into the solid so the selected cylindrical face is behind
                // the ray start and cannot be mistaken for the opposing wall.
                for (int axialIndex = 0; axialIndex < AxialSamples; axialIndex++)
                {
                    double axial = offsetCm + threadLengthCm * AxialFractions[axialIndex];
                    double[] axisPoint =
                    {
                        target.Center[0] + axis[0] * axial,
                        target.Center[1] + axis[1] * axial,
                        target.Center[2] + axis[2] * axial
                    };

                    for (int angularIndex = 0; angularIndex < AngularSamples; angularIndex++)
                    {
                        // Stagger the grid to avoid routinely landing exactly on orthogonal seams.
                        double angle = (angularIndex + 0.37) * (2.0 * Math.PI / AngularSamples);
                        double c = Math.Cos(angle), s = Math.Sin(angle);
                        double[] radial = Normalize(new[]
                        {
                            radialA[0] * c + radialB[0] * s,
                            radialA[1] * c + radialB[1] * s,
                            radialA[2] * c + radialB[2] * s
                        });
                        double materialSign = target.IsExternal ? -1.0 : 1.0;
                        double[] rayDirection = { radial[0] * materialSign, radial[1] * materialSign, radial[2] * materialSign };
                        double[] rayStart =
                        {
                            axisPoint[0] + radial[0] * target.RadiusCm + rayDirection[0] * probeOffset,
                            axisPoint[1] + radial[1] * target.RadiusCm + rayDirection[1] * probeOffset,
                            axisPoint[2] + radial[2] * target.RadiusCm + rayDirection[2] * probeOffset
                        };

                        Inventor.Point startPoint = app.TransientGeometry.CreatePoint(rayStart[0], rayStart[1], rayStart[2]);
                        UnitVector unitDirection = app.TransientGeometry.CreateUnitVector(rayDirection[0], rayDirection[1], rayDirection[2]);
                        ObjectsEnumerator foundEntities = null;
                        ObjectsEnumerator locationPoints = null;
                        target.Body.FindUsingRay(startPoint, unitDirection, RayRadiusCm,
                            out foundEntities, out locationPoints, true);

                        Inventor.Point hitPoint = null;
                        if (locationPoints != null)
                        {
                            foreach (object location in locationPoints)
                            {
                                hitPoint = location as Inventor.Point;
                                if (hitPoint != null) break;
                            }
                        }

                        if (foundEntities == null || foundEntities.Count == 0 || hitPoint == null)
                        {
                            return Blocked("Построение запрещено: Inventor не смог измерить стенку по одному из контрольных лучей. Геометрия не изменена; выберите более простую/однозначную поверхность или проверьте тело детали.");
                        }

                        double dx = hitPoint.X - rayStart[0];
                        double dy = hitPoint.Y - rayStart[1];
                        double dz = hitPoint.Z - rayStart[2];
                        double chordCm = Math.Sqrt(dx * dx + dy * dy + dz * dz) + probeOffset;
                        if (!Finite(chordCm) || chordCm <= 0.0)
                            return Blocked("Построение запрещено: измерение толщины стенки вернуло некорректное расстояние. Модель не изменена.");
                        if (chordCm < minimumThickness) minimumThickness = chordCm;
                        measured++;
                    }
                }

                if (measured != AngularSamples * AxialSamples || !Finite(minimumThickness))
                    return Blocked("Построение запрещено: проверка толщины стенки завершилась неполно. Модель не изменена.");

                double radiusAdjustment = ThreadWallThicknessPolicy.RadiusAdjustmentCm(
                    target.IsExternal, target.RadiusCm, calculatedRadiusCm);
                double remainingCm, requiredCm;
                bool safe = ThreadWallThicknessPolicy.HasSafeRemainingWall(minimumThickness,
                    radiusAdjustment, effectiveCutDepthCm, pitchCm, out remainingCm, out requiredCm);
                double remainingMm = remainingCm * MillimetresPerCentimetre;
                double requiredMm = requiredCm * MillimetresPerCentimetre;
                double measuredMm = minimumThickness * MillimetresPerCentimetre;

                double rootDepthMm = groove.Depth * MillimetresPerCentimetre;
                double chamferMm = parameters.ChamferMode != 0 ? chamferDepthCm * MillimetresPerCentimetre : 0.0;
                double effectiveDepthMm = effectiveCutDepthCm * MillimetresPerCentimetre;
                string cutDetails = string.Format(CultureInfo.InvariantCulture,
                    "Корень профиля ≈ {0:0.###} мм; фаска {1}; для оценки учтена максимальная локальная глубина {2:0.###} мм (глубины корня и фаски не складываются).",
                    rootDepthMm, parameters.ChamferMode != 0 ? chamferMm.ToString("0.###", CultureInfo.InvariantCulture) + " мм" : "выключена", effectiveDepthMm);

                var result = new ThreadWallThicknessAssessment
                {
                    IsSafe = safe,
                    MeasurementComplete = true,
                    SamplesMeasured = measured,
                    MinimumMeasuredWallCm = minimumThickness,
                    RootCutDepthCm = groove.Depth,
                    ChamferCutDepthCm = parameters.ChamferMode != 0 ? chamferDepthCm : 0.0,
                    EffectiveCutDepthCm = effectiveCutDepthCm,
                    RadiusAdjustmentCm = radiusAdjustment,
                    RemainingWallCm = remainingCm,
                    RequiredRemainingWallCm = requiredCm,
                    Message = safe
                        ? string.Format(CultureInfo.InvariantCulture,
                            "Толщина стенки проверена: минимум по {0} лучам ≈ {1:0.###} мм. {2} После резьбы останется ≈ {3:0.###} мм (минимум по политике {4:0.###} мм).",
                            measured, measuredMm, cutDetails, remainingMm, requiredMm)
                        : string.Format(CultureInfo.InvariantCulture,
                            "Построение запрещено: стенка для резьбы {0} слишком тонкая. Измерено ≈ {1:0.###} мм; после резьбы останется ≈ {3:0.###} мм, требуется ≥{4:0.###} мм. {2} Уменьшите шаг/фаску или выберите более толстую поверхность. Модель не изменена.",
                            parameters.SizeName ?? ThreadStandards.Title(parameters.Standard), measuredMm, cutDetails, remainingMm, requiredMm)
                };
                return result;
            }
            catch (Exception ex)
            {
                try
                {
                    TransactionLifecycleDiagnostics.Write("ThreadWallThicknessGuard", "measurement-failed", app,
                        doc, null, false, ex.ToString());
                }
                catch { }
                return Blocked("Построение запрещено: Inventor не смог надёжно проверить толщину стенки (" +
                    ex.Message + "). Модель не изменена; повторите выбор на более простой цилиндрической поверхности.");
            }
        }

        /// <summary>
        /// Conical preflight. The prepared cone changes diameter along the entire host interval,
        /// so the check samples that full interval and evaluates the local cone-to-stock radius
        /// adjustment together with the standard-table radial thread depth. No model mutation or
        /// transaction is opened by this method. Missing ray measurements fail closed.
        /// </summary>
        public static void ValidateTaperedOrThrow(Application app, ThreadTarget target, ThreadParams parameters,
            double hostLengthCm, double startRadiusCm, double endRadiusCm, double pitchMm, double depthMm)
        {
            ThreadWallThicknessAssessment assessment = AssessTapered(app, target, parameters,
                hostLengthCm, startRadiusCm, endRadiusCm, pitchMm, depthMm);
            bool safe = assessment != null && assessment.IsSafe && assessment.MeasurementComplete;
            TransactionLifecycleDiagnostics.Write("ThreadWallThicknessGuard", safe ? "taper-wall-preflight-passed" : "taper-wall-preflight-blocked",
                app, null, null, false,
                string.Format(CultureInfo.InvariantCulture,
                    "standard={0}; designation={1}; external={2}; rightHand={3}; startDiameterMm={4:0.######}; endDiameterMm={5:0.######}; hostLengthCm={6:0.######}; pitchMm={7:0.######}; depthMm={8:0.######}; samples={9}; measuredWallMm={10:0.######}; remainingWallMm={11:0.######}; requiredWallMm={12:0.######}; message={13}",
                    parameters == null ? "" : parameters.TaperStandard,
                    parameters == null ? "" : parameters.TaperDesignation,
                    parameters != null && parameters.External, parameters != null && parameters.RightHand,
                    startRadiusCm * 20.0, endRadiusCm * 20.0, hostLengthCm, pitchMm, depthMm,
                    assessment == null ? 0 : assessment.SamplesMeasured,
                    assessment == null ? double.NaN : assessment.MinimumMeasuredWallCm * MillimetresPerCentimetre,
                    assessment == null ? double.NaN : assessment.RemainingWallCm * MillimetresPerCentimetre,
                    assessment == null ? double.NaN : assessment.RequiredRemainingWallCm * MillimetresPerCentimetre,
                    assessment == null ? "assessment-null" : assessment.Message));
            if (!safe)
                throw new InvalidOperationException(assessment == null
                    ? "Построение конической резьбы запрещено: не удалось проверить остаточную стенку. Модель не изменена."
                    : assessment.Message);
        }

        private static ThreadWallThicknessAssessment AssessTapered(Application app, ThreadTarget target,
            ThreadParams parameters, double hostLengthCm, double startRadiusCm, double endRadiusCm,
            double pitchMm, double depthMm)
        {
            if (app == null || target == null || parameters == null)
                return Blocked("Построение конической резьбы запрещено: отсутствуют документ, поверхность или параметры.");

            PartDocument doc = null;
            try
            {
                doc = app.ActiveDocument as PartDocument;
                if (doc == null)
                    return Blocked("Построение конической резьбы запрещено: нужен активный документ Inventor (.ipt).");
                string activeName = null;
                try { activeName = doc.InternalName; } catch { }
                if (!string.IsNullOrWhiteSpace(target.SourceDocumentInternalName) &&
                    !string.Equals(activeName, target.SourceDocumentInternalName, StringComparison.OrdinalIgnoreCase))
                    return Blocked("Построение конической резьбы запрещено: выбранная поверхность относится к другой детали.");
                if (target.Body == null || !target.Body.IsSolid)
                    return Blocked("Построение конической резьбы запрещено: исходная поверхность не принадлежит замкнутому твёрдому телу.");
                if (target.IsExternal != parameters.External)
                    return Blocked("Построение конической резьбы запрещено: выбран тип резьбы, не совпадающий с исходной поверхностью.");
                if (target.Center == null || target.Center.Length < 3 || target.U == null || target.U.Length < 3 ||
                    !Finite(target.RadiusCm) || target.RadiusCm <= 0.0 ||
                    !Finite(hostLengthCm) || hostLengthCm <= 0.0 || hostLengthCm > target.LengthCm + 1e-6 ||
                    !Finite(startRadiusCm) || startRadiusCm <= 0.0 || !Finite(endRadiusCm) || endRadiusCm <= 0.0 ||
                    !Finite(pitchMm) || pitchMm <= 0.0 || !Finite(depthMm) || depthMm <= 0.0 || depthMm >= pitchMm)
                    return Blocked("Построение конической резьбы запрещено: параметры конуса, профиля или исходной поверхности некорректны.");

                double pitchCm = pitchMm / MillimetresPerCentimetre;
                double depthCm = depthMm / MillimetresPerCentimetre;
                bool chamferEnabled = parameters.ChamferMode != 0;
                double chamferDepthCm = parameters.ChamferMm / MillimetresPerCentimetre;
                double effectiveCutDepthCm = ThreadWallThicknessPolicy.EffectiveCutDepthCm(
                    depthCm, chamferEnabled, chamferEnabled ? chamferDepthCm : 0.0);
                if (!Finite(effectiveCutDepthCm) || effectiveCutDepthCm <= 0.0)
                    return Blocked("Построение конической резьбы запрещено: не удалось безопасно определить максимальную радиальную глубину профиля и фаски.");
                double requiredWallCm = ThreadWallThicknessPolicy.RequiredRemainingWallCm(pitchCm);
                if (!Finite(requiredWallCm) || requiredWallCm <= 0.0)
                    return Blocked("Построение конической резьбы запрещено: невозможно определить минимальную остаточную стенку.");

                double[] axis = Normalize(target.U);
                double[] helper = Math.Abs(axis[0]) < 0.9 ? new[] { 1.0, 0.0, 0.0 } : new[] { 0.0, 1.0, 0.0 };
                double[] radialA = Normalize(Cross(axis, Cross(helper, axis)));
                double[] radialB = Normalize(Cross(axis, radialA));
                double probeOffset = Math.Max(MinimumProbeOffsetCm, Math.Min(MaximumProbeOffsetCm, target.RadiusCm * 0.0005));
                double minimumMeasuredCm = double.PositiveInfinity;
                double minimumRemainingCm = double.PositiveInfinity;
                double worstAdjustmentCm = double.PositiveInfinity;
                int measured = 0;
                int unsafeSamples = 0;
                int total = TaperedAngularSamples * TaperedAxialSamples;

                // Include the complete host preparation interval, including an unthreaded offset:
                // it is still changed to the standard cone and therefore must be structurally safe.
                for (int axialIndex = 0; axialIndex < TaperedAxialSamples; axialIndex++)
                {
                    double fraction = TaperedAxialFractions[axialIndex];
                    double axial = hostLengthCm * fraction;
                    double coneRadiusCm = startRadiusCm + (endRadiusCm - startRadiusCm) * fraction;
                    double radiusAdjustmentCm = parameters.External
                        ? coneRadiusCm - target.RadiusCm
                        : target.RadiusCm - coneRadiusCm;
                    if (!Finite(coneRadiusCm) || coneRadiusCm <= 0.0 || !Finite(radiusAdjustmentCm))
                        return Blocked("Построение конической резьбы запрещено: локальный радиус конуса некорректен.");

                    for (int angularIndex = 0; angularIndex < TaperedAngularSamples; angularIndex++)
                    {
                        double angle = (angularIndex + 0.37) * (2.0 * Math.PI / TaperedAngularSamples);
                        double c = Math.Cos(angle), ss = Math.Sin(angle);
                        double[] radial = Normalize(new[]
                        {
                            radialA[0] * c + radialB[0] * ss,
                            radialA[1] * c + radialB[1] * ss,
                            radialA[2] * c + radialB[2] * ss
                        });
                        // Start on the material side of the selected cylindrical face in both
                        // modes. For an external shaft, the inward ray reaches either the bore
                        // (thin tube) or the opposite OD (solid shaft); the latter is clamped to
                        // the selected radius below. Starting outside the OD and demanding two
                        // intersections incorrectly rejects valid solid shafts when Inventor only
                        // returns one hit. For an internal bore, start just into the surrounding
                        // material and travel outward to the exterior boundary.
                        double materialSign = parameters.External ? -1.0 : 1.0;
                        double[] rayDirection = { radial[0] * materialSign, radial[1] * materialSign, radial[2] * materialSign };
                        double probeRadiusCm = target.RadiusCm + materialSign * probeOffset;
                        if (!Finite(probeRadiusCm) || probeRadiusCm <= 0.0)
                            return Blocked("Построение конической резьбы запрещено: смещение контрольного луча некорректно.");
                        double[] rayStart =
                        {
                            target.Center[0] + axis[0] * axial + radial[0] * probeRadiusCm,
                            target.Center[1] + axis[1] * axial + radial[1] * probeRadiusCm,
                            target.Center[2] + axis[2] * axial + radial[2] * probeRadiusCm
                        };

                        Inventor.Point startPoint = app.TransientGeometry.CreatePoint(rayStart[0], rayStart[1], rayStart[2]);
                        UnitVector unitDirection = app.TransientGeometry.CreateUnitVector(rayDirection[0], rayDirection[1], rayDirection[2]);
                        ObjectsEnumerator foundEntities = null;
                        ObjectsEnumerator locationPoints = null;
                        target.Body.FindUsingRay(startPoint, unitDirection, RayRadiusCm,
                            out foundEntities, out locationPoints, !parameters.External);
                        if (foundEntities == null || foundEntities.Count == 0 || locationPoints == null || locationPoints.Count == 0)
                        {
                            TransactionLifecycleDiagnostics.Write("ThreadWallThicknessGuard", "taper-wall-ray-no-hit",
                                app, doc, null, false,
                                string.Format(CultureInfo.InvariantCulture,
                                    "external={0}; axialIndex={1}; angularIndex={2}; targetRadiusCm={3:0.########}; probeOffsetCm={4:0.########}; probeRadiusCm={5:0.########}; foundEntities={6}; locationPoints={7}",
                                    parameters.External, axialIndex, angularIndex, target.RadiusCm, probeOffset, probeRadiusCm,
                                    foundEntities == null ? -1 : foundEntities.Count,
                                    locationPoints == null ? -1 : locationPoints.Count));
                            return Blocked("Построение конической резьбы запрещено: Inventor не смог измерить стенку по одному из контрольных лучей. Модель не изменена.");
                        }

                        double measuredWallCm;
                        if (parameters.External)
                        {
                            var hitDistancesCm = new List<double>();
                            foreach (object location in locationPoints)
                            {
                                Inventor.Point hit = location as Inventor.Point;
                                if (hit == null) continue;
                                double dx = hit.X - rayStart[0];
                                double dy = hit.Y - rayStart[1];
                                double dz = hit.Z - rayStart[2];
                                double distanceAlongRayCm = dx * rayDirection[0] + dy * rayDirection[1] + dz * rayDirection[2];
                                if (Finite(distanceAlongRayCm) && distanceAlongRayCm >= -1e-7)
                                    hitDistancesCm.Add(distanceAlongRayCm);
                            }
                            if (!ThreadWallThicknessPolicy.TryGetExternalRadialWallThicknessCm(
                                hitDistancesCm, probeOffset, target.RadiusCm, out measuredWallCm))
                            {
                                TransactionLifecycleDiagnostics.Write("ThreadWallThicknessGuard", "taper-wall-ray-invalid-hit",
                                    app, doc, null, false,
                                    string.Format(CultureInfo.InvariantCulture,
                                        "external=True; axialIndex={0}; angularIndex={1}; targetRadiusCm={2:0.########}; probeOffsetCm={3:0.########}; hitCount={4}; hitDistancesCm=[{5}]",
                                        axialIndex, angularIndex, target.RadiusCm, probeOffset, hitDistancesCm.Count,
                                        string.Join(",", hitDistancesCm.ConvertAll(v => v.ToString("0.########", CultureInfo.InvariantCulture)))));
                                return Blocked("Построение конической резьбы запрещено: внешний контрольный луч изнутри заготовки не дал однозначной следующей границы материала. Толщина стенки не определена; модель не изменена.");
                            }
                        }
                        else
                        {
                            Inventor.Point hitPoint = null;
                            foreach (object location in locationPoints)
                            {
                                hitPoint = location as Inventor.Point;
                                if (hitPoint != null) break;
                            }
                            if (hitPoint == null)
                                return Blocked("Построение конической резьбы запрещено: Inventor не вернул точку наружной стенки для контрольного луча.");
                            double dx = hitPoint.X - rayStart[0];
                            double dy = hitPoint.Y - rayStart[1];
                            double dz = hitPoint.Z - rayStart[2];
                            double measuredRayLengthCm = Math.Sqrt(dx * dx + dy * dy + dz * dz) + probeOffset;
                            measuredWallCm = ThreadWallThicknessPolicy.EffectiveRadialWallThicknessCm(
                                false, measuredRayLengthCm, target.RadiusCm);
                        }
                        if (!Finite(measuredWallCm) || measuredWallCm <= 0.0)
                            return Blocked("Построение конической резьбы запрещено: измерение стенки вернуло некорректное значение.");

                        double remainingCm, requiredFromPolicyCm;
                        bool localSafe = ThreadWallThicknessPolicy.HasSafeRemainingWall(measuredWallCm,
                            radiusAdjustmentCm, effectiveCutDepthCm, pitchCm, out remainingCm, out requiredFromPolicyCm);
                        measured++;
                        if (measuredWallCm < minimumMeasuredCm) minimumMeasuredCm = measuredWallCm;
                        if (remainingCm < minimumRemainingCm) minimumRemainingCm = remainingCm;
                        if (radiusAdjustmentCm < worstAdjustmentCm) worstAdjustmentCm = radiusAdjustmentCm;
                        if (!localSafe) unsafeSamples++;
                    }
                }

                if (measured != total || !Finite(minimumMeasuredCm) || !Finite(minimumRemainingCm) || !Finite(worstAdjustmentCm))
                    return Blocked("Построение конической резьбы запрещено: проверка остаточной стенки завершилась неполно.");

                double measuredMm = minimumMeasuredCm * MillimetresPerCentimetre;
                double remainingMm = minimumRemainingCm * MillimetresPerCentimetre;
                double requiredMm = requiredWallCm * MillimetresPerCentimetre;
                double depthMmEffective = effectiveCutDepthCm * MillimetresPerCentimetre;
                double chamferMmEffective = chamferEnabled ? chamferDepthCm * MillimetresPerCentimetre : 0.0;
                bool safe = unsafeSamples == 0 && minimumRemainingCm + 1e-7 >= requiredWallCm;
                string cutDescription = chamferEnabled
                    ? string.Format(CultureInfo.InvariantCulture,
                        "глубина профиля ≈ {0:0.###} мм, фаска ≈ {1:0.###} мм, для остаточной стенки учтён максимум локального удаления ≈ {2:0.###} мм (не сумма)",
                        depthCm * MillimetresPerCentimetre, chamferMmEffective, depthMmEffective)
                    : string.Format(CultureInfo.InvariantCulture,
                        "глубина табличного профиля ≈ {0:0.###} мм", depthMmEffective);
                string message = safe
                    ? string.Format(CultureInfo.InvariantCulture,
                        "Толщина стенки конической резьбы проверена по {0} лучам: минимум ≈ {1:0.###} мм; расчётная остаточная стенка ≈ {2:0.###} мм при минимуме {3:0.###} мм. Учёт вырезания: {4}.",
                        measured, measuredMm, remainingMm, requiredMm, cutDescription)
                    : string.Format(CultureInfo.InvariantCulture,
                        "Построение запрещено: исходная стенка слишком тонкая для конической резьбы {0} {1}. Минимальная измеренная стенка ≈ {2:0.###} мм; после приведения к конусу и вырезания останется ≈ {3:0.###} мм, требуется не менее {4:0.###} мм. {5}; наиболее неблагоприятное изменение радиуса ≈ {6:0.###} мм. Модель не изменена.",
                        parameters.TaperStandard, parameters.TaperDesignation, measuredMm, remainingMm, requiredMm,
                        cutDescription, worstAdjustmentCm * MillimetresPerCentimetre) +
                        (unsafeSamples > 0 ? " Небезопасных контрольных точек: " + unsafeSamples + " из " + measured + "." : string.Empty);

                return new ThreadWallThicknessAssessment
                {
                    IsSafe = safe,
                    MeasurementComplete = true,
                    SamplesMeasured = measured,
                    MinimumMeasuredWallCm = minimumMeasuredCm,
                    RootCutDepthCm = depthCm,
                    ChamferCutDepthCm = chamferEnabled ? chamferDepthCm : 0.0,
                    EffectiveCutDepthCm = effectiveCutDepthCm,
                    RadiusAdjustmentCm = worstAdjustmentCm,
                    RemainingWallCm = minimumRemainingCm,
                    RequiredRemainingWallCm = requiredWallCm,
                    Message = message
                };
            }
            catch (Exception ex)
            {
                try { TransactionLifecycleDiagnostics.Write("ThreadWallThicknessGuard", "taper-measurement-failed", app, doc, null, false, ex.ToString()); } catch { }
                return Blocked("Построение конической резьбы запрещено: Inventor не смог надёжно проверить остаточную стенку (" + ex.Message + "). Модель не изменена.");
            }
        }

        private static ThreadWallThicknessAssessment Blocked(string message)
        {
            return new ThreadWallThicknessAssessment
            {
                IsSafe = false,
                MeasurementComplete = false,
                SamplesMeasured = 0,
                MinimumMeasuredWallCm = double.NaN,
                RemainingWallCm = double.NaN,
                RequiredRemainingWallCm = double.NaN,
                Message = message
            };
        }

        private static bool Finite(double value) { return !double.IsNaN(value) && !double.IsInfinity(value); }
        private static double Dot(double[] a, double[] b) { return a[0] * b[0] + a[1] * b[1] + a[2] * b[2]; }
        private static double[] Cross(double[] a, double[] b)
        {
            return new[] { a[1] * b[2] - a[2] * b[1], a[2] * b[0] - a[0] * b[2], a[0] * b[1] - a[1] * b[0] };
        }
        private static double[] Normalize(double[] value)
        {
            double length = Math.Sqrt(Dot(value, value));
            if (!Finite(length) || length <= 1e-12) throw new InvalidOperationException("Ось или радиальное направление цилиндра некорректны.");
            return new[] { value[0] / length, value[1] / length, value[2] / length };
        }
    }
}
