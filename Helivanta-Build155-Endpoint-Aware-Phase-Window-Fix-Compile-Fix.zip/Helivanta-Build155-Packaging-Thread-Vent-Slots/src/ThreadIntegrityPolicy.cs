﻿using System;

namespace ThreadPro
{
    /// <summary>Pure, unit-testable axial interval policy used by the read-only integrity scan.</summary>
    internal static class ThreadIntegrityPolicy
    {
        internal static bool TryGetInterval(ThreadMetadataRecord record, double[] referenceAxis, out double start, out double end)
        {
            start = end = 0.0;
            if (record == null || record.Target == null || record.Parameters == null ||
                record.Target.Center == null || record.Target.Center.Length < 3 ||
                record.Target.Axis == null || record.Target.Axis.Length < 3 || referenceAxis == null || referenceAxis.Length < 3)
                return false;

            double[] center = record.Target.Center;
            double[] axis = record.Target.Axis;
            double origin = center[0] * referenceAxis[0] + center[1] * referenceAxis[1] + center[2] * referenceAxis[2];
            double offset = record.Parameters.OffsetMm / 10.0;
            double length = record.Parameters.FullLength
                ? record.Target.LengthCm - offset
                : record.Parameters.LengthMm / 10.0;
            double direction = axis[0] * referenceAxis[0] + axis[1] * referenceAxis[1] + axis[2] * referenceAxis[2];
            if (!Finite(origin) || !Finite(offset) || !Finite(length) || !Finite(direction) ||
                Math.Abs(direction) < 0.9999 || offset < 0.0 || length <= 0.0 ||
                offset + length > record.Target.LengthCm + 1e-6)
                return false;

            start = origin + direction * offset;
            end = start + direction * length;
            return Finite(start) && Finite(end);
        }

        internal static bool IntervalsOverlap(double a0, double a1, double b0, double b1, double tolerance = 1e-4)
        {
            return ThreadEditSafetyPolicy.IntervalsOverlap(a0, a1, b0, b1, tolerance);
        }

        private static bool Finite(double value) { return !double.IsNaN(value) && !double.IsInfinity(value); }
    }
}
