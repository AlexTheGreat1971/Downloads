﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace ThreadPro
{
    /// <summary>
    /// Builds pitch suggestions for a user-defined nominal diameter. Catalogue pitches for
    /// the active thread family are retained, and common metric pitches are offered as
    /// practical choices. The editable ComboBox still accepts values outside this list.
    /// All values are millimetres; the UI formats them according to the selected unit.
    /// </summary>
    public static class ThreadPitchSuggestionPolicy
    {
        private static readonly double[] CommonMetricPitchesMm =
        {
            0.5, 0.75, 1.0, 1.25, 1.5, 1.75, 2.0, 2.5,
            3.0, 3.5, 4.0, 4.5, 5.0, 6.0, 8.0, 10.0
        };

        public static List<double> ForCustomDiameter(IEnumerable<double> cataloguePitchesMm)
        {
            var values = new List<double>();
            if (cataloguePitchesMm != null)
                values.AddRange(cataloguePitchesMm);
            values.AddRange(CommonMetricPitchesMm);

            // Round only for menu de-duplication. The underlying catalogue values are
            // still used by exact-diameter standard-size selection and by thread geometry.
            return values
                .Where(p => p > 0.0 && !double.IsNaN(p) && !double.IsInfinity(p))
                .Select(p => Math.Round(p, 4, MidpointRounding.AwayFromZero))
                .Where(p => p > 0.0)
                .Distinct()
                .OrderByDescending(p => p)
                .ToList();
        }
    }
}
