﻿using System;
using System.Drawing;
using System.Windows.Forms;
using System.Reflection;
using System.IO;

namespace ThreadPro
{
    /// <summary>Fixed-size session palette for the phantom surface and its guide curves.</summary>
    internal sealed class PreviewControlsDialog : Form
    {
        private static Color UiSurface => HelivantaUiTheme.Surface;
        private static Color UiText => HelivantaUiTheme.Text;
        private static Color UiMuted => HelivantaUiTheme.Muted;
        private readonly Inventor.Application _app;
        private readonly TrackBar _transparencyTrack;
        private readonly Label _valueLabel;
        private readonly Label _statusLabel;
        private readonly Panel _legendPanel;
        private readonly ToolTip _toolTip;
        private TableLayoutPanel _rootLayout;
        private readonly Func<int, string> _transparencyChanged;
        private readonly Func<int, string> _thicknessChanged;
        private readonly Action _closeRequested;
        private readonly Func<ThreadEngineeringDiagramState> _diagramStateProvider;
        private ThreadEngineeringDiagram _engineeringDiagram;
        private PictureBox _brandLogo;
        private Timer _diagramRefreshTimer;
        private bool _syncing;
        private bool _allowClose;
        private Form _owner;

        public PreviewControlsDialog(Inventor.Application app, int transparencyPercent, int thicknessPercent,
            Func<int, string> transparencyChanged, Func<int, string> thicknessChanged,
            Action closeRequested, Func<ThreadEngineeringDiagramState> diagramStateProvider)
        {
            _app = app;
            _transparencyChanged = transparencyChanged;
            _thicknessChanged = thicknessChanged;
            _closeRequested = closeRequested;
            _diagramStateProvider = diagramStateProvider;
            _toolTip = new ToolTip { ShowAlways = true };
            AutoScaleMode = AutoScaleMode.Dpi;
            Load += (sender, args) => HelivantaLocalization.Apply(this);
            Text = "Управление предпросмотром";
            FormBorderStyle = FormBorderStyle.FixedToolWindow;
            StartPosition = FormStartPosition.Manual;
            ShowInTaskbar = false;
            ShowIcon = true;
            try { Icon = LoadEmbeddedIcon(); } catch { }
            MaximizeBox = MinimizeBox = false;
            TopMost = false;
            AutoSize = false;
            ClientSize = new Size(660, 576);
            BackColor = UiSurface;
            ForeColor = UiText;
            Font = new Font("Segoe UI", 9f, FontStyle.Regular, GraphicsUnit.Point);

            var root = new TableLayoutPanel { Dock = DockStyle.Fill, ColumnCount = 4, RowCount = 6,
                BackColor = UiSurface, Padding = new Padding(11, 8, 11, 8), Margin = Padding.Empty };
            root.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 25f));
            root.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 25f));
            root.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 25f));
            root.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 25f));
            root.RowStyles.Add(new RowStyle(SizeType.Absolute, 24f)); // phantom opacity label
            root.RowStyles.Add(new RowStyle(SizeType.Absolute, 38f)); // phantom opacity track
            root.RowStyles.Add(new RowStyle(SizeType.Absolute, 28f)); // line legend below the transparency slider
            root.RowStyles.Add(new RowStyle(SizeType.Percent, 100f)); // engineering drawing grows into the available area
            root.RowStyles.Add(new RowStyle(SizeType.AutoSize)); // collapsible status; hidden until there is a meaningful message
            root.RowStyles.Add(new RowStyle(SizeType.Absolute, 64f)); // compact wordmark and action button
            _rootLayout = root;
            Controls.Add(root);

            var transparencyLabel = MakeLabel("Прозрачность фантома"); transparencyLabel.AutoEllipsis = false;
            root.Controls.Add(transparencyLabel, 0, 0); root.SetColumnSpan(transparencyLabel, 3);
            _valueLabel = MakeLabel("45%"); _valueLabel.TextAlign = ContentAlignment.MiddleRight;
            root.Controls.Add(_valueLabel, 3, 0);
            _transparencyTrack = new TrackBar { Minimum = 0, Maximum = 100, Value = Clamp(transparencyPercent, 0, 100),
                TickFrequency = 10, SmallChange = 5, LargeChange = 10, TickStyle = TickStyle.None,
                AutoSize = false, Height = 34, Dock = DockStyle.Fill, BackColor = UiSurface, Margin = new Padding(0, 0, 0, 1) };
            root.Controls.Add(_transparencyTrack, 0, 1); root.SetColumnSpan(_transparencyTrack, 4);

            // The old helper note about phantom visibility is intentionally removed. This row now
            // carries the drawing legend requested for the engineering preview.
            _legendPanel = new Panel
            {
                Dock = DockStyle.Fill,
                BackColor = UiSurface,
                Margin = new Padding(0, 1, 0, 1),
                AccessibleRole = AccessibleRole.Grouping,
                AccessibleName = "Легенда линий инженерной схемы и фантома",
                AccessibleDescription = "Слева: профиль, размеры, ось инженерной схемы. Справа: голубые линии вершин фантома, белые линии впадин, янтарные линии фасок."
            };
            _legendPanel.Paint += (s, e) => DrawPreviewLegend(e.Graphics, _legendPanel);
            _toolTip.SetToolTip(_legendPanel, HelivantaLocalization.Translate("Инженерная схема: профиль / размеры / ось. Фантом: вершины / впадины / фаски."));
            root.Controls.Add(_legendPanel, 0, 2); root.SetColumnSpan(_legendPanel, 4);

            _engineeringDiagram = new ThreadEngineeringDiagram
            {
                Dock = DockStyle.Fill,
                Margin = new Padding(0, 4, 0, 4),
                MinimumSize = new Size(360, 260)
            };
            root.Controls.Add(_engineeringDiagram, 0, 3); root.SetColumnSpan(_engineeringDiagram, 4);

            // Keep the status control for actionable errors, but do not reserve space for the
            // old explanatory “phantom updates...” paragraph. It appears only when SetStatus
            // receives an actual warning/error/status from the preview pipeline.
            _statusLabel = new Label { Text = string.Empty, Dock = DockStyle.Fill,
                TextAlign = ContentAlignment.MiddleLeft, ForeColor = UiMuted, BackColor = UiSurface,
                Margin = new Padding(0, 2, 0, 0), AutoEllipsis = false, Visible = false, AutoSize = true };
            root.Controls.Add(_statusLabel, 0, 4); root.SetColumnSpan(_statusLabel, 4);
            // The action belongs to the preview palette, not the main dialog. Keep enough
            // width for the full Russian label and reserve the remaining area for the wordmark.
            var footer = new TableLayoutPanel
            {
                Dock = DockStyle.Fill,
                ColumnCount = 2,
                RowCount = 1,
                BackColor = UiSurface,
                Margin = Padding.Empty,
                Padding = Padding.Empty
            };
            footer.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 205f));
            footer.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100f));
            footer.RowStyles.Add(new RowStyle(SizeType.Percent, 100f));

            var buttonHost = new Panel
            {
                Dock = DockStyle.Fill,
                BackColor = UiSurface,
                Margin = Padding.Empty,
                Padding = Padding.Empty
            };
            var hidePreviewButton = new Button
            {
                Text = "Скрыть предпросмотр",
                AutoSize = false,
                Size = new Size(200, 36),
                Anchor = AnchorStyles.Left,
                AutoEllipsis = false,
                UseVisualStyleBackColor = false,
                FlatStyle = FlatStyle.Flat,
                BackColor = Color.FromArgb(31, 106, 158),
                ForeColor = UiText,
                Font = new Font("Segoe UI", 8.5f, FontStyle.Regular),
                TextAlign = ContentAlignment.MiddleCenter,
                Margin = Padding.Empty,
                Padding = new Padding(2, 0, 2, 0),
                MinimumSize = new Size(200, 36),
                TabStop = true
            };
            hidePreviewButton.FlatAppearance.BorderColor = Color.FromArgb(65, 132, 180);
            hidePreviewButton.FlatAppearance.BorderSize = 1;
            // Match the rounded action buttons used by the main dialog.
            hidePreviewButton.Resize += (s, e) => ApplyRoundedButtonRegion(hidePreviewButton, 8);
            hidePreviewButton.HandleCreated += (s, e) => ApplyRoundedButtonRegion(hidePreviewButton, 8);
            hidePreviewButton.AccessibleName = "Скрыть предпросмотр";
            _toolTip.SetToolTip(hidePreviewButton, HelivantaLocalization.Translate("Скрыть предпросмотр"));
            hidePreviewButton.Click += (s, e) => HidePreviewAndNotify();
            Action centerHideButton = () =>
            {
                if (!hidePreviewButton.IsDisposed)
                    hidePreviewButton.Location = new Point(0, Math.Max(0, (buttonHost.ClientSize.Height - hidePreviewButton.Height) / 2));
            };
            buttonHost.Resize += (s, e) => centerHideButton();
            buttonHost.HandleCreated += (s, e) => centerHideButton();
            buttonHost.Controls.Add(hidePreviewButton);
            footer.Controls.Add(buttonHost, 0, 0);

            var brand = new PictureBox
            {
                Dock = DockStyle.Right,
                Width = 230,
                SizeMode = PictureBoxSizeMode.Zoom,
                BackColor = Color.Transparent,
                Margin = new Padding(0),
                Padding = new Padding(0),
                Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Right
            };
            try { brand.Image = LoadBrandLogo(); } catch { }
            _brandLogo = brand;
            brand.AccessibleDescription = "Helivanta — Physical Thread Design";
            footer.Controls.Add(brand, 1, 0);
            root.Controls.Add(footer, 0, 5); root.SetColumnSpan(footer, 4);

            _syncing = true;
            _valueLabel.Text = _transparencyTrack.Value + "%";
            _syncing = false;
            _transparencyTrack.ValueChanged += (s, e) =>
            {
                _valueLabel.Text = _transparencyTrack.Value + "%";
                if (_syncing) return;
                try { string status = _transparencyChanged?.Invoke(_transparencyTrack.Value); if (!string.IsNullOrWhiteSpace(status)) SetStatus(status); }
                catch (Exception ex) { SetStatus("Не удалось изменить прозрачность: " + ex.Message); }
            };
            _diagramRefreshTimer = new Timer { Interval = 350 };
            _diagramRefreshTimer.Tick += (s, e) => RefreshEngineeringDiagramFromProvider();
            VisibleChanged += (s, e) =>
            {
                if (Visible)
                {
                    RefreshEngineeringDiagramFromProvider();
                    if (_diagramRefreshTimer != null && !_diagramRefreshTimer.Enabled) _diagramRefreshTimer.Start();
                }
                else if (_diagramRefreshTimer != null && _diagramRefreshTimer.Enabled) _diagramRefreshTimer.Stop();
            };
            RefreshEngineeringDiagramFromProvider();
            FormClosed += (s, e) =>
            {
                try { if (_diagramRefreshTimer != null) { _diagramRefreshTimer.Stop(); _diagramRefreshTimer.Dispose(); } } catch { }
                try { _toolTip.Dispose(); } catch { }
                try { if (brand.Image != null) brand.Image.Dispose(); } catch { }
            };
            FormClosing += (s, e) =>
            {
                if (_allowClose) return;
                e.Cancel = true;
                HidePreviewAndNotify();
            };
        }

        private static void ApplyRoundedButtonRegion(Control control, int radius)
        {
            if (control == null || control.Width < 2 || control.Height < 2) return;
            int d = Math.Max(2, Math.Min(radius * 2, Math.Min(control.Width, control.Height)));
            using (var path = new System.Drawing.Drawing2D.GraphicsPath())
            {
                var rect = new Rectangle(0, 0, control.Width, control.Height);
                path.AddArc(rect.Left, rect.Top, d, d, 180, 90);
                path.AddArc(rect.Right - d, rect.Top, d, d, 270, 90);
                path.AddArc(rect.Right - d, rect.Bottom - d, d, d, 0, 90);
                path.AddArc(rect.Left, rect.Bottom - d, d, d, 90, 90);
                path.CloseFigure();
                var old = control.Region;
                control.Region = new Region(path);
                if (old != null) old.Dispose();
            }
        }

        private void HidePreviewAndNotify()
        {
            // Capture activation before Hide(): once the foreground window is hidden, Windows
            // may otherwise activate an unrelated application instead of this palette's owner.
            Form positionOwner = _owner;
            IntPtr foregroundBefore = NativeWindowPositioning.GetForegroundWindowHandle();
            bool wasForeground = Handle != IntPtr.Zero && foregroundBefore == Handle;
            try { if (!IsDisposed && Visible) Hide(); } catch { }
            DetachOwnerEvents();
            RestorePositionOwnerFocusIfNeeded(positionOwner, wasForeground, "palette-close", foregroundBefore);
            LogFocusTransition("palette-hide-request", foregroundBefore, wasForeground,
                "positionOwnerHwnd=" + FormatHandle(positionOwner != null && positionOwner.IsHandleCreated ? positionOwner.Handle : IntPtr.Zero) +
                "; closeRequested=True");
            try { _closeRequested?.Invoke(); } catch { }
        }

        private static Icon LoadEmbeddedIcon()
        {
            Assembly asm = Assembly.GetExecutingAssembly();
            using (Stream stream = asm.GetManifestResourceStream("Helivanta.ico"))
            {
                if (stream == null) throw new FileNotFoundException("Embedded Helivanta icon not found.");
                return new Icon(stream);
            }
        }

        private static Image LoadBrandLogo()
        {
            Image image = HelivantaUiTheme.LoadWordmarkImage(true);
            if (image == null) throw new FileNotFoundException("Embedded cropped Helivanta wordmark for the active theme was not found.");
            return image;
        }

        internal void RefreshTheme()
        {
            if (IsDisposed) return;
            ApplyCurrentThemeToControls(this);
            if (_statusLabel != null && !_statusLabel.IsDisposed) _statusLabel.ForeColor = UiMuted;
            if (_valueLabel != null && !_valueLabel.IsDisposed) _valueLabel.ForeColor = UiText;
            if (_brandLogo != null && !_brandLogo.IsDisposed)
            {
                _brandLogo.BackColor = Color.Transparent;
                try
                {
                    Image next = LoadBrandLogo();
                    Image previous = _brandLogo.Image;
                    _brandLogo.Image = next;
                    if (previous != null) previous.Dispose();
                }
                catch { }
            }
            Invalidate(true);
        }

        private static void ApplyCurrentThemeToControls(Control root)
        {
            if (root == null) return;
            if (root is Form || root is Panel || root is TableLayoutPanel || root is FlowLayoutPanel)
                root.BackColor = UiSurface;
            else if (root is PictureBox)
                root.BackColor = Color.Transparent;
            if (root is Label label)
            {
                label.BackColor = UiSurface;
                label.ForeColor = UiText;
            }
            else if (root is TrackBar)
            {
                root.BackColor = UiSurface;
            }
            else if (root is Button button)
            {
                button.BackColor = HelivantaUiTheme.Accent;
                button.ForeColor = Color.White;
                button.FlatAppearance.BorderColor = HelivantaUiTheme.AccentHover;
                button.FlatAppearance.MouseOverBackColor = HelivantaUiTheme.AccentHover;
                button.FlatAppearance.MouseDownBackColor = HelivantaUiTheme.Accent;
            }
            foreach (Control child in root.Controls) ApplyCurrentThemeToControls(child);
        }

        protected override void OnHandleCreated(EventArgs e)
        {
            base.OnHandleCreated(e);
            try { int preference = 2; DwmSetWindowAttribute(Handle, 33, ref preference, sizeof(int)); } catch { }
        }
        [System.Runtime.InteropServices.DllImport("dwmapi.dll", PreserveSig = true)]
        private static extern int DwmSetWindowAttribute(IntPtr hwnd, int attribute, ref int value, int size);

        private Label MakeLabel(string text) => new Label { Text = text, Dock = DockStyle.Fill,
            TextAlign = ContentAlignment.MiddleLeft, ForeColor = UiText, BackColor = UiSurface,
            Margin = Padding.Empty, AutoEllipsis = true };
        private void RefreshEngineeringDiagramFromProvider()
        {
            if (_engineeringDiagram == null || _engineeringDiagram.IsDisposed || _diagramStateProvider == null) return;
            try
            {
                ThreadEngineeringDiagramState state = _diagramStateProvider();
                if (state != null)
                {
                    // The palette has a dedicated legend row directly under the transparency slider.
                    // Do not duplicate it under the drawing; standalone Help diagrams retain their own legend.
                    state.ShowLegend = false;
                    _engineeringDiagram.SetState(state);
                }
            }
            catch
            {
                // Do not silently replace a failed live selection with a fake ISO default profile.
                // Keep the last rendered state and make the refresh failure visible in the status line.
                SetStatus("Не удалось обновить инженерную схему. Проверьте выбор и повторите предпросмотр.");
            }
        }

        public void RefreshEngineeringDiagram() => RefreshEngineeringDiagramFromProvider();

        private static int Clamp(int value, int min, int max) => Math.Max(min, Math.Min(max, value));

        public void SetSessionValues(int transparencyPercent, int thicknessPercent)
        {
            _syncing = true;
            try
            {
                _transparencyTrack.Value = Clamp(transparencyPercent, 0, 100);
                _valueLabel.Text = _transparencyTrack.Value + "%";
            }
            finally { _syncing = false; }
        }
        public void SetStatus(string message)
        {
            if (IsDisposed || _statusLabel == null || _statusLabel.IsDisposed) return;
            string text = HelivantaLocalization.Translate(message ?? string.Empty);
            // Keep the model/Undo-Redo clarification on its own line when a caller supplies it.
            text = text.Replace(". Модель и история Undo/Redo", ".\r\n" + HelivantaLocalization.Translate("Модель и история Undo/Redo"));
            _statusLabel.Text = text;
            _statusLabel.Visible = !string.IsNullOrWhiteSpace(text);
            if (_rootLayout != null && !_rootLayout.IsDisposed) _rootLayout.PerformLayout();
        }
        // Kept for existing callers; visibility state belongs in the status line, not in the legend row.
        public void SetBodyVisibilityState(string message)
        { SetStatus(HelivantaLocalization.Translate(string.IsNullOrWhiteSpace(message) ? "Состояние тела не изменено" : message)); }

        private void DrawPreviewLegend(Graphics graphics, Control surface)
        {
            if (graphics == null || surface == null || surface.ClientSize.Width < 120 || surface.ClientSize.Height < 12) return;
            graphics.SmoothingMode = System.Drawing.Drawing2D.SmoothingMode.AntiAlias;
            float scale = Math.Max(1f, surface.DeviceDpi / 96f);
            using (var font = new Font("Segoe UI", 7.2f, FontStyle.Regular, GraphicsUnit.Point))
            using (var text = new SolidBrush(HelivantaUiTheme.Muted))
            using (var profile = new Pen(Color.FromArgb(84, 205, 245), Math.Max(1.8f, 2f * scale)))
            using (var dimension = new Pen(HelivantaUiTheme.Warning, Math.Max(1.3f, 1.4f * scale)))
            using (var axis = new Pen(Color.FromArgb(143, 166, 185), Math.Max(1f, scale)))
            using (var crest = new Pen(Color.FromArgb(35, 190, 250), Math.Max(1.8f, 2f * scale)))
            using (var root = new Pen(Color.FromArgb(238, 245, 255), Math.Max(1.5f, 1.7f * scale)))
            using (var chamfer = new Pen(HelivantaUiTheme.Warning, Math.Max(1.6f, 1.8f * scale)))
            using (var separator = new Pen(HelivantaUiTheme.Border, Math.Max(1f, scale)))
            using (var phantomTitle = new SolidBrush(Color.FromArgb(105, 204, 245)))
            {
                axis.DashPattern = new[] { 3f * scale, 2f * scale };
                bool chamferEnabled = false;
                try
                {
                    ThreadEngineeringDiagramState state = _diagramStateProvider == null ? null : _diagramStateProvider();
                    chamferEnabled = state != null && state.ChamferEnabled && state.ChamferLengthMm > 0.000001;
                }
                catch { }

                float y = surface.ClientSize.Height / 2f;
                float lineWidth = Math.Max(12f, 17f * scale);
                float itemGap = Math.Max(3f, 4f * scale);
                float groupGap = Math.Max(9f, 13f * scale);
                float textGap = Math.Max(3f, 4f * scale);
                float outerPad = Math.Max(2f, 3f * scale);
                float xLeft = outerPad;
                DrawLegendItem(graphics, font, text, profile, HelivantaLocalization.Translate("Профиль"), ref xLeft, y, lineWidth, textGap, itemGap, scale, 0);
                DrawLegendItem(graphics, font, text, dimension, HelivantaLocalization.Translate("Размеры"), ref xLeft, y, lineWidth, textGap, itemGap, scale, 0);
                DrawLegendItem(graphics, font, text, axis, HelivantaLocalization.Translate("Ось"), ref xLeft, y, lineWidth, textGap, itemGap, scale, 1);

                float phantomItemsWidth = MeasureLegendItem(graphics, font, HelivantaLocalization.Translate("Вершины"), lineWidth, textGap, itemGap)
                    + MeasureLegendItem(graphics, font, HelivantaLocalization.Translate("Впадины"), lineWidth, textGap, itemGap)
                    + MeasureLegendItem(graphics, font, HelivantaLocalization.Translate(chamferEnabled ? "Фаски" : "Фаски · выкл."), lineWidth, textGap, itemGap);
                float phantomTitleWidth = graphics.MeasureString(HelivantaLocalization.Translate("Фантом"), font).Width + groupGap * 0.65f;
                float rightWidth = phantomTitleWidth + phantomItemsWidth;
                float groupStart = Math.Max(xLeft + groupGap, surface.ClientSize.Width - outerPad - rightWidth);
                float separatorX = groupStart - groupGap * 0.55f;
                graphics.DrawLine(separator, separatorX, y - 7f * scale, separatorX, y + 7f * scale);
                graphics.DrawString(HelivantaLocalization.Translate("Фантом"), font, phantomTitle, groupStart, y - font.GetHeight(graphics) / 2f);
                float xRight = groupStart + phantomTitleWidth;
                DrawLegendItem(graphics, font, text, crest, HelivantaLocalization.Translate("Вершины"), ref xRight, y, lineWidth, textGap, itemGap, scale, 0);
                DrawLegendItem(graphics, font, text, root, HelivantaLocalization.Translate("Впадины"), ref xRight, y, lineWidth, textGap, itemGap, scale, 0);
                using (var chamferText = new SolidBrush(chamferEnabled ? HelivantaUiTheme.Text : HelivantaUiTheme.Muted))
                {
                    if (chamferEnabled)
                    {
                        graphics.DrawLine(chamfer, xRight, y + 2f * scale, xRight + lineWidth * 0.55f, y - 3f * scale);
                        graphics.DrawLine(chamfer, xRight + lineWidth * 0.55f, y - 3f * scale, xRight + lineWidth, y - 3f * scale);
                    }
                    else
                    {
                        using (var inactive = new Pen(HelivantaUiTheme.Muted, Math.Max(1f, scale)))
                            graphics.DrawLine(inactive, xRight, y, xRight + lineWidth, y);
                    }
                    xRight += lineWidth + textGap;
                    graphics.DrawString(HelivantaLocalization.Translate(chamferEnabled ? "Фаски" : "Фаски · выкл."), font, chamferText, xRight, y - font.GetHeight(graphics) / 2f);
                }
            }
        }

        private static float MeasureLegendItem(Graphics graphics, Font font, string label, float lineWidth, float textGap, float itemGap)
        {
            return lineWidth + textGap + graphics.MeasureString(label, font).Width + itemGap;
        }

        private static void DrawLegendItem(Graphics graphics, Font font, Brush text, Pen line, string label,
            ref float x, float y, float lineWidth, float textGap, float itemGap, float scale, int lineKind)
        {
            if (lineKind == 1)
            {
                using (var dashed = (Pen)line.Clone())
                {
                    dashed.DashPattern = new[] { 3f * scale, 2f * scale };
                    graphics.DrawLine(dashed, x, y, x + lineWidth, y);
                }
            }
            else graphics.DrawLine(line, x, y, x + lineWidth, y);
            x += lineWidth + textGap;
            graphics.DrawString(label, font, text, x, y - font.GetHeight(graphics) / 2f);
            x += graphics.MeasureString(label, font).Width + itemGap;
        }
        public void ShowBeside(Form positionOwner, IWin32Window nativeOwner = null)
        {
            if (positionOwner == null || positionOwner.IsDisposed) return;

            IntPtr foregroundBefore = NativeWindowPositioning.GetForegroundWindowHandle();
            IntPtr nativeOwnerHandle = IntPtr.Zero;
            try { nativeOwnerHandle = nativeOwner != null ? nativeOwner.Handle : positionOwner.Handle; } catch { }
            AttachOwnerEvents(positionOwner);
            RefreshEngineeringDiagramFromProvider();
            PositionBesideOwner();
            try
            {
                if (!Visible) Show(nativeOwner ?? (IWin32Window)positionOwner);
                else Activate();
            }
            catch (Exception ex)
            {
                LogFocusTransition("palette-show-failed", foregroundBefore, false,
                    "nativeOwnerHwnd=" + FormatHandle(nativeOwnerHandle) + "; exception=" + ex.GetType().Name + ": " + ex.Message);
                throw;
            }
            PositionBesideOwner();

            bool activationVerified = NativeWindowPositioning.IsForegroundWindow(Handle);
            if (!activationVerified)
            {
                try
                {
                    NativeWindowPositioning.ActivateWindowPreservingState(Handle);
                    activationVerified = NativeWindowPositioning.IsForegroundWindow(Handle);
                }
                catch { activationVerified = NativeWindowPositioning.IsForegroundWindow(Handle); }
            }
            LogFocusTransition("palette-shown", foregroundBefore, activationVerified,
                "positionOwnerHwnd=" + FormatHandle(positionOwner.Handle) +
                "; nativeOwnerHwnd=" + FormatHandle(nativeOwnerHandle));
        }

        public void HideForPreviewOff()
        {
            Form positionOwner = _owner;
            IntPtr ownerHandle = IntPtr.Zero;
            try { if (positionOwner != null && positionOwner.IsHandleCreated) ownerHandle = positionOwner.Handle; } catch { }
            IntPtr foregroundBefore = NativeWindowPositioning.GetForegroundWindowHandle();
            bool wasForeground = !IsDisposed && Visible && Handle != IntPtr.Zero && foregroundBefore == Handle;
            DetachOwnerEvents();
            try { if (!IsDisposed && Visible) Hide(); } catch { }
            RestorePositionOwnerFocusIfNeeded(positionOwner, wasForeground, "preview-off", foregroundBefore);
            LogFocusTransition("palette-hidden-for-preview-off", foregroundBefore, wasForeground,
                "positionOwnerHwnd=" + FormatHandle(ownerHandle));
        }

        public void CloseFromOwner() { _allowClose = true; DetachOwnerEvents(); if (!IsDisposed) Close(); }

        private void RestorePositionOwnerFocusIfNeeded(Form positionOwner, bool wasForeground,
            string reason, IntPtr foregroundBefore)
        {
            if (!wasForeground || positionOwner == null || positionOwner.IsDisposed ||
                positionOwner.Disposing || !positionOwner.Visible || !positionOwner.IsHandleCreated)
                return;

            bool activationVerified = false;
            try
            {
                NativeWindowPositioning.ActivateWindowPreservingState(positionOwner.Handle);
                activationVerified = NativeWindowPositioning.IsForegroundWindow(positionOwner.Handle);
            }
            catch { activationVerified = NativeWindowPositioning.IsForegroundWindow(positionOwner.Handle); }

            LogFocusTransition("palette-owner-focus-restored", foregroundBefore, activationVerified,
                "reason=" + reason + "; targetHwnd=" + FormatHandle(positionOwner.Handle));
        }

        private void LogFocusTransition(string stage, IntPtr foregroundBefore, bool activationVerified, string detail)
        {
            try
            {
                IntPtr foregroundAfter = NativeWindowPositioning.GetForegroundWindowHandle();
                string message = "palette=" + NativeWindowPositioning.DescribeWindowHandle(Handle) +
                    "; positionOwner=" + NativeWindowPositioning.DescribeWindowHandle(_owner != null && _owner.IsHandleCreated ? _owner.Handle : IntPtr.Zero) +
                    "; foregroundBefore=" + NativeWindowPositioning.DescribeWindowHandle(foregroundBefore) +
                    "; foregroundAfter=" + NativeWindowPositioning.DescribeWindowHandle(foregroundAfter) +
                    "; activationVerified=" + activationVerified +
                    (string.IsNullOrWhiteSpace(detail) ? string.Empty : "; " + detail);
                TransactionLifecycleDiagnostics.Write("PreviewControlsDialog", stage, _app, null, null, false, message);
            }
            catch { }
        }

        private static string FormatHandle(IntPtr handle)
        {
            return handle == IntPtr.Zero ? "0x0" : "0x" + handle.ToInt64().ToString("X");
        }
        private void AttachOwnerEvents(Form owner)
        { if (ReferenceEquals(_owner, owner)) return; DetachOwnerEvents(); _owner = owner; _owner.Move += OwnerGeometryChanged; _owner.Resize += OwnerGeometryChanged; }
        private void DetachOwnerEvents()
        { if (_owner != null) { try { _owner.Move -= OwnerGeometryChanged; } catch { } try { _owner.Resize -= OwnerGeometryChanged; } catch { } } _owner = null; }
        private void OwnerGeometryChanged(object sender, EventArgs e) { if (Visible) PositionBesideOwner(); }
        private void PositionBesideOwner()
        {
            if (_owner == null || _owner.IsDisposed) return;
            Rectangle workArea; try { workArea = Screen.FromControl(_owner).WorkingArea; } catch { workArea = SystemInformation.WorkingArea; }
            int margin = 8; int x = _owner.Left - Width - margin;
            if (x < workArea.Left + 4) x = _owner.Right + margin;
            if (x + Width > workArea.Right - 4) x = workArea.Right - Width - 4;
            x = Math.Max(workArea.Left + 4, x);
            int y = _owner.Top; if (y + Height > workArea.Bottom - 4) y = workArea.Bottom - Height - 4;
            y = Math.Max(workArea.Top + 4, y); Location = new Point(x, y);
        }
    }
}
