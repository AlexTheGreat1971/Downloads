﻿using System;

namespace ThreadPro
{
    /// <summary>Identifies Helivanta-managed top-level folders eligible for empty-folder cleanup.</summary>
    public static class ThreadBrowserFolderPolicy
    {
        public static bool IsManagedThreadFolder(string name)
        {
            if (string.IsNullOrWhiteSpace(name)) return false;
            return name.StartsWith("Резьба — ", StringComparison.OrdinalIgnoreCase) ||
                   name.StartsWith("Сбег — ", StringComparison.OrdinalIgnoreCase);
        }
    }
}
