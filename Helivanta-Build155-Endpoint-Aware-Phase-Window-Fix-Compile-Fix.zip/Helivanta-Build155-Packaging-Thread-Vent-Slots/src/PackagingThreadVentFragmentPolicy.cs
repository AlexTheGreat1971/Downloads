using System;

namespace ThreadPro
{
    /// <summary>
    /// Resolves short helical end fragments left beside longitudinal vent slots.
    /// It authorizes cleanup only for a fragment close to or below one quarter of the
    /// repeated slot-to-slot sector; a 1-degree allowance handles borderline CAD geometry.
    /// </summary>
    internal static class PackagingThreadVentFragmentPolicy
    {
        internal const double FragmentThresholdFraction = 0.25;
        internal const double SectorThresholdToleranceDegrees = 1.0;
        internal const double AngularOverlapDegrees = 0.02;
        internal const double AngularToleranceDegrees = 1e-7;
        internal const double StartSpacingSafetyDegrees = 0.25;

        internal sealed class Plan
        {
            public bool ShouldTrim { get; internal set; }
            public double EndpointPhaseDegrees { get; internal set; }
            public double SlotBoundaryDegrees { get; internal set; }
            public double SweepStartDegrees { get; internal set; }
            public double SweepWidthDegrees { get; internal set; }
            public double FragmentAngleDegrees { get; internal set; }
            public double GapAngleDegrees { get; internal set; }
            public double FractionOfGap { get; internal set; }
            public double SectorAngleDegrees { get; internal set; }
            public double FractionOfSector { get; internal set; }
            public double EffectiveThresholdDegrees { get; internal set; }
            public double AxialTravelMm { get; internal set; }
            public string Reason { get; internal set; }
        }

        /// <summary>
        /// Find the nearest edge of any vent-slot band from a finite thread endpoint. This is
        /// important at the start: selecting only the boundary in the direction of travel can
        /// measure 53 degrees when the actual adjacent tail to the other edge is only 23 degrees.
        /// The nominal quarter is based on the slot-to-slot centre spacing; the clear gap after
        /// subtracting slot width is logged independently. A 1-degree tolerance covers borderline
        /// generated geometry, including the observed 23-degree tail in a 90-degree sector.
        /// </summary>
        internal static bool TryResolve(double endpointPhaseDegrees, bool towardIncreasingAngle,
            int slotCount, double slotWidthDegrees, int starts, double leadMm, double profileWidthMm,
            out Plan plan, out string error)
        {
            plan = null;
            error = null;
            if (!Finite(endpointPhaseDegrees)) return Reject("Фаза конца резьбы должна быть конечным числом.", out error);
            if (slotCount < PackagingThreadVentSlotPolicy.MinimumSlotCount || slotCount > PackagingThreadVentSlotPolicy.MaximumSlotCount)
                return Reject("Недопустимое число вент-пропилов для очистки концов.", out error);
            if (!Finite(slotWidthDegrees) || slotWidthDegrees <= 0.0 || slotWidthDegrees >= 360.0 / slotCount)
                return Reject("Недопустимая ширина вент-пропила для очистки концов.", out error);
            if (starts < 1 || starts > PackagingThreadGeometryPolicy.MaxStarts)
                return Reject("Недопустимое число заходов для очистки концов.", out error);
            if (!Finite(leadMm) || leadMm <= 0.0 || !Finite(profileWidthMm) || profileWidthMm <= 0.0)
                return Reject("Ход резьбы и ширина профиля должны быть положительными.", out error);

            double spacing = 360.0 / slotCount;
            double gap = spacing - slotWidthDegrees;
            double phase = Normalize(endpointPhaseDegrees);
            var resolved = new Plan
            {
                ShouldTrim = false,
                EndpointPhaseDegrees = phase,
                GapAngleDegrees = gap,
                SectorAngleDegrees = spacing,
                Reason = "Концевой фрагмент не достигает порога очистки."
            };

            // If the endpoint already lies inside a slot band, no tail remains at that endpoint.
            for (int i = 0; i < slotCount; i++)
            {
                double centre = i * spacing;
                if (CircularDistance(phase, centre) <= slotWidthDegrees / 2.0 + AngularToleranceDegrees)
                {
                    resolved.Reason = "Конец резьбы уже находится в секторе существующего вент-пропила.";
                    plan = resolved;
                    return true;
                }
            }

            double bestDistance = double.PositiveInfinity;
            double boundary = 0.0;
            for (int i = 0; i < slotCount; i++)
            {
                double centre = i * spacing;
                double lowerEdge = Normalize(centre - slotWidthDegrees / 2.0);
                double upperEdge = Normalize(centre + slotWidthDegrees / 2.0);
                double lowerDistance = CircularDistance(phase, lowerEdge);
                if (lowerDistance > AngularToleranceDegrees && lowerDistance < bestDistance)
                {
                    bestDistance = lowerDistance;
                    boundary = lowerEdge;
                }
                double upperDistance = CircularDistance(phase, upperEdge);
                if (upperDistance > AngularToleranceDegrees && upperDistance < bestDistance)
                {
                    bestDistance = upperDistance;
                    boundary = upperEdge;
                }
            }
            if (!Finite(bestDistance) || bestDistance <= AngularToleranceDegrees)
                return Reject("Не удалось определить ближайшую границу вент-пропила.", out error);

            resolved.SlotBoundaryDegrees = boundary;
            resolved.FragmentAngleDegrees = bestDistance;
            resolved.FractionOfGap = bestDistance / gap;
            resolved.FractionOfSector = bestDistance / spacing;
            resolved.AxialTravelMm = leadMm * bestDistance / 360.0;

            double nominalQuarterSector = spacing * FragmentThresholdFraction;
            double threshold = nominalQuarterSector + SectorThresholdToleranceDegrees;
            resolved.EffectiveThresholdDegrees = threshold;
            if (bestDistance >= threshold - AngularToleranceDegrees)
            {
                resolved.Reason = string.Format(System.Globalization.CultureInfo.InvariantCulture,
                    "Фрагмент {0:0.###}% свободного сегмента / {1:0.###}% сектора между центрами пропилов; порог очистки = {2:0.###}° (1/4 от {3:0.###}° + допуск {4:0.###}°).",
                    resolved.FractionOfGap * 100.0, resolved.FractionOfSector * 100.0,
                    threshold, spacing, SectorThresholdToleranceDegrees);
                plan = resolved;
                return true;
            }

            // Do not remove a fragment if the cleanup sweep plus the axial profile footprint
            // could reach the neighboring helical start.
            double profileAngularFootprint = 360.0 * profileWidthMm / leadMm;
            double startPhaseSpacing = 360.0 / starts;
            double sweepWidth = bestDistance + 2.0 * AngularOverlapDegrees;
            if (sweepWidth + profileAngularFootprint + StartSpacingSafetyDegrees >= startPhaseSpacing)
            {
                resolved.Reason = string.Format(System.Globalization.CultureInfo.InvariantCulture,
                    "Фрагмент достигает порога очистки, но локальная операция затронула бы соседний заход (сектор={0:0.###}°, footprint профиля={1:0.###}°, интервал заходов={2:0.###}°). Пропуск во избежание повреждения полноценного захода.",
                    sweepWidth, profileAngularFootprint, startPhaseSpacing);
                plan = resolved;
                return true;
            }

            resolved.ShouldTrim = true;
            // AddByAngle sweeps toward decreasing angular phase in this sketch convention. Start
            // at the high-angle endpoint of the shorter circular arc between the edge and phase.
            double boundaryToPhase = PositiveAngularDistance(boundary, phase);
            double phaseToBoundary = PositiveAngularDistance(phase, boundary);
            double highEndpoint = boundaryToPhase <= phaseToBoundary ? phase : boundary;
            resolved.SweepStartDegrees = Normalize(highEndpoint + AngularOverlapDegrees);
            resolved.SweepWidthDegrees = sweepWidth;
            resolved.Reason = string.Format(System.Globalization.CultureInfo.InvariantCulture,
                "Фрагмент {0:0.###}° короче эффективного порога {1:0.###}° (четверть сектора {2:0.###}° с допуском {3:0.###}°); разрешена локальная очистка Delete Face + Heal.",
                bestDistance, threshold, nominalQuarterSector, SectorThresholdToleranceDegrees);
            plan = resolved;
            return true;
        }

        /// <summary>
        /// Selects the terminal-face angular window. The phase sign and window orientation
        /// must be changed together for the previously missed hand/endpoint combinations.
        /// This affects face selection only, not generated thread geometry.
        /// </summary>
        internal static bool UseForwardFacePhaseWindow(bool atStart, double helixPhaseSign)
        {
            if (!Finite(helixPhaseSign) || Math.Abs(helixPhaseSign) < 1e-12)
                throw new ArgumentOutOfRangeException(nameof(helixPhaseSign), "Helix phase sign must be finite and non-zero.");
            return atStart == (helixPhaseSign > 0.0);
        }

        internal static double GetFacePhaseCorrectionSign(bool atStart, double helixPhaseSign)
        {
            if (!Finite(helixPhaseSign) || Math.Abs(helixPhaseSign) < 1e-12)
                throw new ArgumentOutOfRangeException(nameof(helixPhaseSign), "Helix phase sign must be finite and non-zero.");
            double sign = helixPhaseSign > 0.0 ? 1.0 : -1.0;
            return UseForwardFacePhaseWindow(atStart, sign) ? -sign : sign;
        }

        /// <summary>
        /// Converts a measured face-point azimuth at an arbitrary axial station back to the
        /// corresponding phase at the finite thread endpoint. Inventor's PointOnFace is not
        /// guaranteed to lie at that endpoint; on a helix its azimuth includes station travel.
        /// stationCm/endpointStationCm use Inventor's internal centimetre unit; leadMm is mm.
        /// </summary>
        internal static double CorrectAngleToEndpoint(double measuredAngleDegrees, double stationCm,
            double endpointStationCm, double leadMm, double helixPhaseSign)
        {
            if (!Finite(measuredAngleDegrees) || !Finite(stationCm) || !Finite(endpointStationCm) ||
                !Finite(leadMm) || leadMm <= 0.0 || !Finite(helixPhaseSign))
                throw new ArgumentOutOfRangeException("Arguments must be finite and leadMm must be positive.");
            double leadCm = leadMm / 10.0;
            double stationPhase = helixPhaseSign * 360.0 * (stationCm - endpointStationCm) / leadCm;
            return Normalize(measuredAngleDegrees - stationPhase);
        }

        internal static double Normalize(double degrees)
        {
            double value = degrees % 360.0;
            if (value < 0.0) value += 360.0;
            return value;
        }

        private static double CircularDistance(double a, double b)
        {
            double forward = PositiveAngularDistance(a, b);
            double backward = PositiveAngularDistance(b, a);
            return Math.Min(forward, backward);
        }

        private static double PositiveAngularDistance(double from, double to) => Normalize(to - from);

        private static bool Reject(string message, out string error)
        {
            error = message;
            return false;
        }

        private static bool Finite(double value) => !double.IsNaN(value) && !double.IsInfinity(value);
    }
}
