using System;
using System.Collections.Generic;
using System.Reflection;
using Inventor;

namespace ThreadPro
{
    /// <summary>
    /// Temporary, non-transacting ClientGraphics preview of a schematic thread surface and its contours.
    /// The preview never writes source-body visibility, creates DesignView representations, or modifies
    /// B-Rep/features. BurnThrough makes the phantom visible through the host body without adding
    /// Show/Hide actions to Inventor's Undo/Redo history. ThreadBuilder's final B-Rep remains authoritative.
    /// </summary>
    internal sealed class ThreadPreviewOverlay
    {
        private const string GraphicsId = "Helivanta.ThreadPreview.2.0.0.Preview10";
        private const double TwoPi = Math.PI * 2.0;

        private readonly Inventor.Application _app;
        private PartDocument _document;
        private GraphicsDataSets _dataSets;
        private ClientGraphics _clientGraphics;
        private string _documentInternalName;
        private bool _visible;
        // Transparency is held by the overlay instance and intentionally survives Clear()/Show()
        // while the plugin dialog remains open.
        private double _surfaceOpacity = 0.20;
        private GraphicsColorSet _shadedColorSet;
        private GraphicsColorSet _chamferColorSet;
        private readonly List<GraphicsNode> _shadedNodes = new List<GraphicsNode>();
        private readonly List<LineStripGraphics> _lineStrips = new List<LineStripGraphics>();
        private readonly List<int> _lineColorIndices = new List<int>();
        private int _lineThicknessPercent = 100;
        public bool HasShadedMesh { get; private set; }
        public bool LastClearSucceeded { get; private set; } = true;
        public string ShadedMeshFallbackReason { get; private set; }
        public string TransparencyFallbackWarning { get; private set; }
        public string ChamferPreviewWarning { get; private set; }
        private sealed class PreviewCurve
        {
            public double[] Coordinates;
            public int ColorIndex; // 1 crest, 2 root, 3 extent, 4 chamfer boundary
        }

        private sealed class PreviewMesh
        {
            public double[] Coordinates;
            public double[] Normals;
            public int[] StripLengths;
            public bool IsChamfer;
        }

        public bool IsVisible { get { return _visible; } }

        /// <summary>
        /// Set the user-facing transparency percent (0..100). Inventor's OverrideOpacity
        /// uses the inverse: 1 is opaque, 0 is invisible. The setting persists for this
        /// overlay instance for the lifetime of the plugin dialog.
        /// </summary>
        public void SetTransparencyPercent(int transparencyPercent)
        {
            int value = Math.Max(0, Math.Min(100, transparencyPercent));
            _surfaceOpacity = 1.0 - value / 100.0;

            // Set alpha on the RGB color stored in GraphicsColorSet as well as on each
            // GraphicsNode. Some Inventor ClientGraphics backends honour Color.Opacity
            // on triangle-strip colors but do not visibly update from OverrideOpacity alone.
            ApplyShadedColorOpacity();
            foreach (GraphicsNode node in _shadedNodes)
            {
                try { node.OverrideOpacity = _surfaceOpacity; } catch { }
            }
            UpdateActiveView();
        }

        /// <summary>Scales all preview guide widths proportionally, preserving their hierarchy.</summary>
        public void SetLineThicknessPercent(int percent)
        {
            _lineThicknessPercent = Math.Max(50, Math.Min(200, percent));
            int applied = 0;
            Exception lastError = null;
            for (int i = 0; i < _lineStrips.Count; i++)
            {
                try
                {
                    double weight = BaseLineWeight(_lineColorIndices[i]);
                    _lineStrips[i].LineWeight = weight;
                    applied++;
                }
                catch (Exception ex) { lastError = ex; }
            }
            UpdateActiveView();
            if (_lineStrips.Count > 0 && applied == 0 && lastError != null)
                throw new InvalidOperationException("Inventor не применил толщину линий предпросмотра: " + lastError.Message, lastError);
        }

        private static double BaseLineWeight(int colorIndex)
        {
            if (colorIndex == 1) return 2.4;
            if (colorIndex == 2) return 1.5;
            if (colorIndex == 4) return 1.35;
            return 0.8;
        }

        private void ApplyShadedColorOpacity()
        {
            if (_shadedColorSet == null && _chamferColorSet == null) return;
            TransparencyFallbackWarning = null;
            var errors = new List<string>();
            ApplyColorSetOpacity(_shadedColorSet, 53, 128, 187, errors);
            // A contrasting warm tone makes the circular bevel visible against the blue thread
            // phantom while retaining the same user-controlled transparency percentage.
            ApplyColorSetOpacity(_chamferColorSet, 255, 137, 42, errors);
            if (errors.Count > 0)
            {
                // OverrideOpacity remains as a compatibility fallback in SetTransparencyPercent.
                TransparencyFallbackWarning = "Inventor не принял прозрачность через цвет одной из сеток; применяется резервный параметр прозрачности узла. " + string.Join(" | ", errors);
            }
        }

        private void ApplyColorSetOpacity(GraphicsColorSet colorSet, byte red, byte green, byte blue, List<string> errors)
        {
            if (colorSet == null) return;
            try
            {
                Inventor.Color color = _app.TransientObjects.CreateColor(red, green, blue, _surfaceOpacity);
                color.Opacity = _surfaceOpacity;
                bool assigned = false;
                try
                {
                    PropertyInfo property = typeof(GraphicsColorSet).GetProperty("Color");
                    if (property != null && property.CanWrite)
                    {
                        property.SetValue(colorSet, color, new object[] { 1 });
                        assigned = true;
                    }
                }
                catch { }

                if (!assigned)
                {
                    typeof(GraphicsColorSet).InvokeMember(
                        "Color",
                        BindingFlags.Instance | BindingFlags.Public | BindingFlags.SetProperty,
                        null,
                        colorSet,
                        new object[] { 1, color });
                }
            }
            catch (Exception ex)
            {
                errors.Add(ex.Message);
            }
        }

        private void UpdateActiveView()
        {
            try
            {
                PartDocument active = _app.ActiveDocument as PartDocument;
                if (active != null && !string.IsNullOrEmpty(_documentInternalName) &&
                    string.Equals(active.InternalName, _documentInternalName, StringComparison.OrdinalIgnoreCase))
                    _app.ActiveView.Update();
            }
            catch { }
        }

        public ThreadPreviewOverlay(Inventor.Application app)
        {
            _app = app ?? throw new ArgumentNullException("app");
        }

        public bool BelongsToActiveDocument()
        {
            try
            {
                var active = _app.ActiveDocument as PartDocument;
                return active != null && !string.IsNullOrEmpty(_documentInternalName) &&
                    string.Equals(active.InternalName, _documentInternalName, StringComparison.OrdinalIgnoreCase);
            }
            catch { return false; }
        }

        public bool BelongsToDocument(_Document document)
        {
            try
            {
                PartDocument candidate = document as PartDocument;
                return candidate != null && !string.IsNullOrEmpty(_documentInternalName) &&
                    string.Equals(candidate.InternalName, _documentInternalName, StringComparison.OrdinalIgnoreCase);
            }
            catch { return false; }
        }

        public void Show(PartDocument document, IList<ThreadTarget> targets, ThreadParams parameters)
        {
            Clear();
            if (!LastClearSucceeded)
                throw new InvalidOperationException("Предыдущую временную графику ещё не удалось удалить. Выключите предпросмотр и повторите действие.");
            if (document == null) throw new ArgumentNullException("document");
            if (targets == null || targets.Count == 0) throw new InvalidOperationException("Сначала выберите круговое ребро.");
            if (parameters == null) throw new ArgumentNullException("parameters");

            string internalName = document.InternalName;
            PartDocument activeDocument = _app.ActiveDocument as PartDocument;
            if (activeDocument == null || !string.Equals(activeDocument.InternalName, internalName, StringComparison.OrdinalIgnoreCase))
                throw new InvalidOperationException("Предпросмотр доступен только в активной детали, из которой выбраны рёбра.");

            foreach (ThreadTarget target in targets)
            {
                if (target != null && !string.IsNullOrEmpty(target.SourceDocumentInternalName) &&
                    !string.Equals(target.SourceDocumentInternalName, internalName, StringComparison.OrdinalIgnoreCase))
                    throw new InvalidOperationException("Выбранные рёбра относятся к другому документу. Повторно выберите рёбра в активной детали.");
            }

            ChamferPreviewWarning = null;
            if (!parameters.Tapered && parameters.ChamferMode > 0 && parameters.ChamferMm > 0.0)
            {
                try
                {
                    ThreadProfileSpec previewSpec = ThreadStandards.Spec(parameters.Standard);
                    double previewPitch = parameters.PitchMm / 10.0;
                    double previewRadius = parameters.External
                        ? parameters.NominalDiaMm / 20.0
                        : parameters.NominalDiaMm / 20.0 - ThreadStandards.MinorOffset(previewSpec, previewPitch, 10.0);
                    double requestedDepth = parameters.ChamferMm / 10.0;
                    foreach (ThreadTarget target in targets)
                    {
                        if (target == null) continue;
                        double visualDepth = ThreadPreviewChamferPolicy.ResolveVisualDepthCm(
                            requestedDepth, previewRadius, target.LengthCm, parameters.ChamferMode);
                        if (ThreadPreviewChamferPolicy.WasVisualDepthCapped(requestedDepth, visualDepth))
                        {
                            ChamferPreviewWarning = "Размер фаски превышает доступный радиус/длину: фантом показывает ограниченную схематичную фаску. Реальное построение проверит исходный размер и при необходимости будет отклонено.";
                            break;
                        }
                    }
                }
                catch { /* Optional display-only chamfer assessment must never block preview. */ }
            }

            var curves = BuildCurves(targets, parameters);
            if (curves.Count == 0) throw new InvalidOperationException("Не удалось рассчитать контуры предпросмотра для выбранных параметров.");
            // Build a lightweight, faceted surface mesh from the same basic profile parameters.
            // Any mesh-generation failure falls back to the already validated contours, rather
            // than preventing Preview from opening.
            List<PreviewMesh> meshes;
            try { meshes = BuildMeshes(targets, parameters); }
            catch (Exception ex)
            {
                meshes = new List<PreviewMesh>();
                ShadedMeshFallbackReason = ex.Message;
            }

            _document = document;
            _documentInternalName = internalName;
            try
            {
                // Use Inventor's explicitly non-transacting collections for the phantom geometry.
                // All preview primitives burn through model occlusion. This keeps the ghost visible
                // when it lies inside the source solid without touching SurfaceBody.Visible or
                // creating any DesignView/Show-Hide entries in the user's Undo/Redo history.
                _dataSets = document.NonTransactingGraphicsDataSetsCollection.Add(GraphicsId);
                _clientGraphics = document.NonTransactingClientGraphicsCollection.Add(GraphicsId);

                GraphicsColorSet crestColor = _dataSets.CreateColorSet(1);
                crestColor.Add(1, 35, 190, 250);     // crest: bright cyan, visually prominent
                GraphicsColorSet rootColor = _dataSets.CreateColorSet(2);
                rootColor.Add(1, 255, 255, 255);     // root: white, as requested for clear profile reading
                GraphicsColorSet limitColor = _dataSets.CreateColorSet(3);
                limitColor.Add(1, 202, 215, 228);   // legacy color set retained for stable graphics IDs
                GraphicsColorSet chamferEdgeColor = _dataSets.CreateColorSet(4);
                chamferEdgeColor.Add(1, 255, 191, 64); // bevel boundaries: amber

                int id = 1;
                foreach (PreviewCurve curve in curves)
                {
                    GraphicsCoordinateSet coordinateSet = _dataSets.CreateCoordinateSet(id);
                    coordinateSet.PutCoordinates(curve.Coordinates);

                    GraphicsNode node = _clientGraphics.AddNode(id);
                    LineStripGraphics strip = node.AddLineStripGraphics();
                    strip.CoordinateSet = coordinateSet;
                    strip.ColorSet = curve.ColorIndex == 1 ? crestColor :
                        (curve.ColorIndex == 2 ? rootColor : (curve.ColorIndex == 4 ? chamferEdgeColor : limitColor));
                    // Keep color plus line-weight hierarchy so the crest remains easy to track,
                    // the root line is secondary, and endpoint limits do not clutter the view.
                    strip.BurnThrough = PreviewGraphicsPolicy.BurnThroughModel;
                    strip.DepthPriority = PreviewGraphicsPolicy.DepthPriority + (curve.ColorIndex == 4 ? 1 : 0);
                    try
                    {
                        // Deliberate visual hierarchy: crest is the boldest guide, root is thinner,
                        // and endpoint rings stay subtle. The values are Inventor graphics weights.
                        strip.LineWeight = BaseLineWeight(curve.ColorIndex);
                    }
                    catch { }
                    _lineStrips.Add(strip);
                    _lineColorIndices.Add(curve.ColorIndex);
                    id++;
                }

                int shadedCount = 0;
                GraphicsColorSet shadedColor = _dataSets.CreateColorSet(5);
                shadedColor.Add(1, 53, 128, 187); // blue tint; alpha is set independently below
                GraphicsColorSet chamferSurfaceColor = _dataSets.CreateColorSet(6);
                chamferSurfaceColor.Add(1, 255, 137, 42); // bevel surface: contrasting warm tint
                _shadedColorSet = shadedColor;
                _chamferColorSet = chamferSurfaceColor;
                ApplyShadedColorOpacity();
                foreach (PreviewMesh previewMesh in meshes)
                {
                    GraphicsNode meshNode = null;
                    try
                    {
                        GraphicsCoordinateSet meshCoordinates = _dataSets.CreateCoordinateSet(id);
                        meshCoordinates.PutCoordinates(previewMesh.Coordinates);
                        GraphicsNormalSet meshNormals = _dataSets.CreateNormalSet(id);
                        meshNormals.PutNormals(previewMesh.Normals);

                        meshNode = _clientGraphics.AddNode(id);
                        try { meshNode.Selectable = false; } catch { }
                        TriangleStripGraphics surface = meshNode.AddTriangleStripGraphics();
                        surface.CoordinateSet = meshCoordinates;
                        surface.PutStripLengths(previewMesh.StripLengths);
                        surface.ColorSet = previewMesh.IsChamfer ? chamferSurfaceColor : shadedColor;
                        surface.ColorBinding = ColorBindingEnum.kOverallColor;
                        surface.NormalSet = meshNormals;
                        surface.NormalBinding = NormalBindingEnum.kPerVertexNormals;
                        surface.BackFaceCulling = BackFaceCullingEnum.kCullNone;
                        // The filled phantom must also remain visible where the host solid would
                        // otherwise occlude it. BurnThrough is a graphics-only render setting;
                        // it does not change the source body, browser or model transaction history.
                        surface.BurnThrough = PreviewGraphicsPolicy.BurnThroughModel;
                        surface.DepthPriority = PreviewGraphicsPolicy.DepthPriority + (previewMesh.IsChamfer ? 1 : 0);
                        try { meshNode.OverrideOpacity = _surfaceOpacity; } catch { }
                        _shadedNodes.Add(meshNode);
                        shadedCount++;
                        id++;
                    }
                    catch (Exception ex)
                    {
                        // Remove a partially created node and continue with contours. Some
                        // Inventor graphics backends can reject transparent triangle strips.
                        if (string.IsNullOrEmpty(ShadedMeshFallbackReason))
                            ShadedMeshFallbackReason = ex.Message;
                        try { if (meshNode != null) meshNode.Delete(); } catch { }
                        id++;
                    }
                }

                HasShadedMesh = shadedCount > 0;
                if (!HasShadedMesh && string.IsNullOrEmpty(ShadedMeshFallbackReason))
                    ShadedMeshFallbackReason = "Не удалось создать затенённую сетку для выбранных параметров.";
                _visible = true;
                try { _app.ActiveView.Update(); } catch { }
            }
            catch (Exception ex)
            {
                Clear();
                throw new InvalidOperationException("Inventor не смог показать предпросмотр. Построение резьбы не выполнялось. Причина: " + ex.Message, ex);
            }
        }

        public void Clear()
        {
            // Only NonTransactingClientGraphics / NonTransactingGraphicsDataSets are owned by
            // preview. Keep references if Inventor refuses deletion so a later Clear can retry.
            bool hadGraphics = _clientGraphics != null || _dataSets != null || _visible;
            bool graphicsDeleted = true;
            bool dataSetsDeleted = true;

            if (_clientGraphics != null)
            {
                try
                {
                    _clientGraphics.Delete();
                    _clientGraphics = null;
                }
                catch (Exception ex)
                {
                    graphicsDeleted = false;
                    TransactionLifecycleDiagnostics.Write("ThreadPreviewOverlay", "client-graphics-delete-failed",
                        _app, _document, null, false, ex.ToString());
                }
            }

            if (graphicsDeleted)
            {
                _shadedNodes.Clear();
                _lineStrips.Clear();
                _lineColorIndices.Clear();
                _shadedColorSet = null;
                _chamferColorSet = null;
            }

            if (graphicsDeleted && _dataSets != null)
            {
                try
                {
                    _dataSets.Delete();
                    _dataSets = null;
                }
                catch (Exception ex)
                {
                    dataSetsDeleted = false;
                    TransactionLifecycleDiagnostics.Write("ThreadPreviewOverlay", "graphics-datasets-delete-failed",
                        _app, _document, null, false, ex.ToString());
                }
            }

            LastClearSucceeded = graphicsDeleted && dataSetsDeleted && _clientGraphics == null && _dataSets == null;
            if (LastClearSucceeded)
            {
                PartDocument previousDocument = _document;
                _visible = false;
                HasShadedMesh = false;
                ShadedMeshFallbackReason = null;
                TransparencyFallbackWarning = null;
                _document = null;
                _documentInternalName = null;

                if (hadGraphics)
                {
                    try
                    {
                        PartDocument active = _app.ActiveDocument as PartDocument;
                        if (active != null && previousDocument != null &&
                            string.Equals(active.InternalName, previousDocument.InternalName, StringComparison.OrdinalIgnoreCase))
                            _app.ActiveView.Update();
                    }
                    catch { }
                }
            }
            else
            {
                // Keep IsVisible true while client graphics might still exist. Callers can retry
                // cleanup and prevent a second overlay being created over an orphaned preview.
                _visible = _clientGraphics != null;
                TransactionLifecycleDiagnostics.Write("ThreadPreviewOverlay", "graphics-cleanup-pending",
                    _app, _document, null, false,
                    "clientGraphicsDeleted=" + graphicsDeleted + "; dataSetsDeleted=" + dataSetsDeleted);
            }
        }

        private static Groove CreateTaperedPreviewGroove(ThreadParams p)
        {
            if (p == null || !p.Tapered || p.PitchMm <= 0.0 || p.TaperThreadDepthMm <= 0.0)
                throw new InvalidOperationException("Табличные шаг и высота конического профиля недоступны для предпросмотра.");
            double angle;
            if (!TaperedThreadGeometryPolicy.TryGetThreadAngleDegrees(p.TaperStandard, out angle))
                throw new InvalidOperationException("Угол профиля выбранного стандарта конической резьбы не определён.");
            double topWidthMm, rootWidthMm;
            string error;
            if (!TaperedThreadGeometryPolicy.TryGetPhysicalGrooveDimensionsMm(p.PitchMm,
                p.TaperThreadDepthMm, angle, out topWidthMm, out rootWidthMm, out error))
                throw new InvalidOperationException(error ?? "Не удалось рассчитать конический профиль.");
            double pitchCm = p.PitchMm / 10.0;
            double depthCm = p.TaperThreadDepthMm / 10.0;
            double topWidthCm = topWidthMm / 10.0;
            double rootWidthCm = rootWidthMm / 10.0;
            double extensionCm = pitchCm * 0.04;
            return new Groove
            {
                TopWidth = topWidthCm,
                BottomWidth = rootWidthCm,
                Depth = depthCm,
                Ext = extensionCm,
                ExtWidth = topWidthCm + 2.0 * extensionCm,
                CrestRemain = Math.Max(0.0, pitchCm - topWidthCm),
                X0L = -topWidthCm / 2.0,
                X0R = topWidthCm / 2.0,
                X1L = -rootWidthCm / 2.0,
                X1R = rootWidthCm / 2.0,
                CapDepth = 0.0,
                RingDepth = 0.0
            };
        }

        private static List<PreviewCurve> BuildCurves(IList<ThreadTarget> targets, ThreadParams p)
        {
            var result = new List<PreviewCurve>();
            if (p.Starts < 1 || p.Starts > 12 || p.PitchMm <= 0.0 || p.NominalDiaMm <= 0.0)
                throw new InvalidOperationException("Проверьте диаметр, шаг и число заходов.");

            double pitch = p.PitchMm / 10.0;       // Inventor API uses centimetres
            double lead = pitch * p.Starts;
            double clearance = p.ClearanceMm / 10.0;
            Groove groove;
            double referenceRadius;
            double taperRadiusSlope = 0.0; // d(radius cm) / d(axial station cm)
            double radialSign = p.External ? -1.0 : 1.0;
            if (p.Tapered)
            {
                groove = CreateTaperedPreviewGroove(p);
                referenceRadius = p.TaperStartDiameterMm / 20.0;
                taperRadiusSlope = (p.External ? 1.0 : -1.0) * p.TaperRatio / 2.0;
            }
            else
            {
                ThreadProfileSpec spec = ThreadStandards.Spec(p.Standard);
                groove = ThreadStandards.ComputeGroove(spec, p.External, pitch, clearance, lead, 10.0);
                referenceRadius = p.External
                    ? p.NominalDiaMm / 20.0
                    : p.NominalDiaMm / 20.0 - ThreadStandards.MinorOffset(spec, pitch, 10.0);
            }
            // The profile's crest plateau is at D = CapDepth - Ext (the builder's dtop),
            // while the root is at D = Depth. Keep the preview on those same radial levels.
            double crestRoundRadius, rootRoundRadius;
            double crestTangentLeft, crestTangentRight, rootTangentLeft, rootTangentRight;
            ResolvePreviewFillets(p, groove, pitch, out crestRoundRadius, out rootRoundRadius,
                out crestTangentLeft, out crestTangentRight, out rootTangentLeft, out rootTangentRight);
            double crestLevelDepth = crestRoundRadius > 0.0 ? groove.CapDepth : Math.Max(0.0, groove.CapDepth - groove.Ext);
            double crestRadius = referenceRadius + radialSign * crestLevelDepth;
            double rootRadius = referenceRadius + radialSign * groove.Depth;
            if (referenceRadius <= 0.0 || crestRadius <= 0.0 || rootRadius <= 0.0)
                throw new InvalidOperationException("Расчётный радиус слишком мал для предпросмотра.");

            double xwHalf = groove.ExtWidth / 2.0;
            foreach (ThreadTarget target in targets)
            {
                if (target == null || target.Center == null || target.Center.Length < 3 || target.U == null || target.U.Length < 3)
                    continue;
                double offset = p.OffsetMm / 10.0;
                // Resolve the finite/full-length policy in one tested helper shared with the mesh.
                double length = ThreadPreviewLengthPolicy.ResolveLengthCm(
                    p.FullLength, target.LengthCm, p.OffsetMm, p.LengthMm);
                double chamferDepthCm = ThreadPreviewChamferPolicy.ResolveVisualDepthCm(
                    p.ChamferMm / 10.0, referenceRadius, target.LengthCm, p.ChamferMode);

                double[] u = Normalize(target.U);
                double[] helper = Math.Abs(u[0]) < 0.9 ? new[] { 1.0, 0.0, 0.0 } : new[] { 0.0, 1.0, 0.0 };
                double[] radial = Normalize(Cross(u, Cross(helper, u)));
                double[] tangent = Cross(u, radial);

                bool startShoulder = target.StartIsShoulder && offset <= 1e-6;
                bool endShoulder = target.EndIsShoulder && p.FullLength;
                bool smoothStart = p.Smooth && offset > 1e-6 && !startShoulder;
                bool smoothEnd = p.Smooth && (!p.FullLength || endShoulder);
                double runLength = Math.Min(p.RunSteps * pitch, 0.45 * length);
                double threadStart = offset;
                double threadEnd = offset + length;
                double smoothEndZ = endShoulder ? threadEnd - xwHalf * 1.02 : threadEnd;
                double visibleStart = startShoulder ? threadStart + xwHalf * 1.02 : threadStart;
                double visibleEnd = endShoulder ? threadEnd - xwHalf * 1.02 : threadEnd;
                if (visibleEnd <= visibleStart + 1e-5)
                    throw new InvalidOperationException("Недостаточно осевой длины для предпросмотра у плеча.");

                if (smoothStart || smoothEnd)
                {
                    if (smoothEndZ <= threadStart + 0.5 * pitch)
                        throw new InvalidOperationException("Недостаточно места для сбега у выбранной поверхности.");
                    runLength = Math.Min(runLength, 0.45 * Math.Max(1e-6, smoothEndZ - threadStart));
                    if (smoothStart && smoothEnd && runLength * 2.0 >= smoothEndZ - threadStart - 1e-6)
                        throw new InvalidOperationException("Между двумя зонами сбега недостаточно места для основной резьбы.");
                }

                // Keep start phase consistent with the feature builder: each Coil begins from
                // its profile plane, shifted by one pitch for adjacent starts.
                double pre = groove.ExtWidth / 2.0 * 1.05 + 1e-4;
                double mainStartBase = smoothStart ? threadStart + runLength : (startShoulder ? threadStart + xwHalf * 1.02 : threadStart - pre);
                double phaseOrigin = startShoulder ? mainStartBase : mainStartBase - (p.Starts - 1) * pitch;
                int samples = SampleCount((visibleEnd - visibleStart) / Math.Max(lead, 1e-6));
                double ringRadius = crestRadius + (p.External ? 0.001 : -0.001);

                for (int startIndex = 0; startIndex < p.Starts; startIndex++)
                {
                    // Curves follow the actual profile transition phases used by the shaded mesh.
                    // Previously they followed the helix centreline (phase 0), so the cyan/orange
                    // guides drifted away from the visible groove edges, especially on multi-starts.
                    double crestLeftPhase, crestRightPhase, rootLeftPhase, rootRightPhase;
                    if (p.Mirror)
                    {
                        // The mesh evaluates f(-phase) in mirror mode. Swap asymmetric S tangencies
                        // and reflect the root landmarks so guide lines follow the same silhouette.
                        crestLeftPhase = crestRoundRadius > 0.0 ? groove.X0L - crestTangentRight : groove.X0L;
                        crestRightPhase = crestRoundRadius > 0.0 ? groove.X0R + crestTangentLeft : groove.X0R;
                        rootLeftPhase = rootRoundRadius > 0.0 ? -groove.X1R + rootTangentRight : -groove.X1R;
                        rootRightPhase = rootRoundRadius > 0.0 ? -groove.X1L - rootTangentLeft : -groove.X1L;
                    }
                    else
                    {
                        crestLeftPhase = crestRoundRadius > 0.0 ? groove.X0L - crestTangentLeft : groove.X0L;
                        crestRightPhase = crestRoundRadius > 0.0 ? groove.X0R + crestTangentRight : groove.X0R;
                        rootLeftPhase = rootRoundRadius > 0.0 ? groove.X1L + rootTangentLeft : groove.X1L;
                        rootRightPhase = rootRoundRadius > 0.0 ? groove.X1R - rootTangentRight : groove.X1R;
                    }
                    double[] crestLeft = CreateHelix(target.Center, u, radial, tangent, visibleStart, visibleEnd,
                        crestRadius, rootRadius, threadStart, smoothStart, smoothEnd,
                        smoothEndZ, runLength, phaseOrigin, startIndex, p.Starts, p.RightHand, lead, samples, false, crestLeftPhase, taperRadiusSlope);
                    double[] crestRight = CreateHelix(target.Center, u, radial, tangent, visibleStart, visibleEnd,
                        crestRadius, rootRadius, threadStart, smoothStart, smoothEnd,
                        smoothEndZ, runLength, phaseOrigin, startIndex, p.Starts, p.RightHand, lead, samples, false, crestRightPhase, taperRadiusSlope);
                    double[] rootLeft = CreateHelix(target.Center, u, radial, tangent, visibleStart, visibleEnd,
                        crestRadius, rootRadius, threadStart, smoothStart, smoothEnd,
                        smoothEndZ, runLength, phaseOrigin, startIndex, p.Starts, p.RightHand, lead, samples, true, rootLeftPhase, taperRadiusSlope);
                    double[] rootRight = CreateHelix(target.Center, u, radial, tangent, visibleStart, visibleEnd,
                        crestRadius, rootRadius, threadStart, smoothStart, smoothEnd,
                        smoothEndZ, runLength, phaseOrigin, startIndex, p.Starts, p.RightHand, lead, samples, true, rootRightPhase, taperRadiusSlope);
                    ApplyChamferToCurve(crestLeft, target.Center, u, radialSign, target.LengthCm, p.ChamferMode, chamferDepthCm);
                    ApplyChamferToCurve(crestRight, target.Center, u, radialSign, target.LengthCm, p.ChamferMode, chamferDepthCm);
                    ApplyChamferToCurve(rootLeft, target.Center, u, radialSign, target.LengthCm, p.ChamferMode, chamferDepthCm);
                    ApplyChamferToCurve(rootRight, target.Center, u, radialSign, target.LengthCm, p.ChamferMode, chamferDepthCm);
                    result.Add(new PreviewCurve { Coordinates = crestLeft, ColorIndex = 1 });
                    result.Add(new PreviewCurve { Coordinates = crestRight, ColorIndex = 1 });
                    result.Add(new PreviewCurve { Coordinates = rootLeft, ColorIndex = 2 });
                    result.Add(new PreviewCurve { Coordinates = rootRight, ColorIndex = 2 });
                }

                // Endpoint boundary rings are intentionally omitted: the extent is conveyed by the preview geometry itself.

                // Outline schematic bevels at the original cylinder ends. They can lie outside a
                // limited/offset thread extent because the real builder chamfers source-body edges.
                if (chamferDepthCm > 1e-9 && ThreadPreviewChamferPolicy.IncludesStart(p.ChamferMode))
                {
                    double edgeRadius = referenceRadius + radialSign * chamferDepthCm;
                    if (edgeRadius > 1e-6)
                    {
                        result.Add(new PreviewCurve { Coordinates = CreateRing(target.Center, u, radial, tangent, 0.0, edgeRadius, 72), ColorIndex = 4 });
                        result.Add(new PreviewCurve { Coordinates = CreateRing(target.Center, u, radial, tangent, chamferDepthCm, referenceRadius, 72), ColorIndex = 4 });
                    }
                }
                if (chamferDepthCm > 1e-9 && ThreadPreviewChamferPolicy.IncludesEnd(p.ChamferMode))
                {
                    double edgeRadius = referenceRadius + radialSign * chamferDepthCm;
                    if (edgeRadius > 1e-6)
                    {
                        result.Add(new PreviewCurve { Coordinates = CreateRing(target.Center, u, radial, tangent, target.LengthCm, edgeRadius, 72), ColorIndex = 4 });
                        result.Add(new PreviewCurve { Coordinates = CreateRing(target.Center, u, radial, tangent, target.LengthCm - chamferDepthCm, referenceRadius, 72), ColorIndex = 4 });
                    }
                }
            }
            return result;
        }

        private static List<PreviewMesh> BuildMeshes(IList<ThreadTarget> targets, ThreadParams p)
        {
            var result = new List<PreviewMesh>();
            if (targets == null || targets.Count == 0) return result;
            if (targets.Count > 256)
                throw new InvalidOperationException("Для затенённого предпросмотра выбрано слишком много рёбер. Оставлены только контуры; уменьшите выбор и повторите предпросмотр.");
            if (p.Starts < 1 || p.Starts > 12 || p.PitchMm <= 0.0 || p.NominalDiaMm <= 0.0)
                throw new InvalidOperationException("Проверьте диаметр, шаг и число заходов.");

            double pitch = p.PitchMm / 10.0;
            double lead = pitch * p.Starts;
            double clearance = p.ClearanceMm / 10.0;
            Groove groove;
            double referenceRadius;
            double taperRadiusSlope = 0.0;
            if (p.Tapered)
            {
                groove = CreateTaperedPreviewGroove(p);
                referenceRadius = p.TaperStartDiameterMm / 20.0;
                taperRadiusSlope = (p.External ? 1.0 : -1.0) * p.TaperRatio / 2.0;
            }
            else
            {
                ThreadProfileSpec spec = ThreadStandards.Spec(p.Standard);
                groove = ThreadStandards.ComputeGroove(spec, p.External, pitch, clearance, lead, 10.0);
                referenceRadius = p.External
                    ? p.NominalDiaMm / 20.0
                    : p.NominalDiaMm / 20.0 - ThreadStandards.MinorOffset(spec, pitch, 10.0);
            }
            if (referenceRadius <= 0.0 || (p.Tapered && referenceRadius + taperRadiusSlope * (p.OffsetMm + p.LengthMm) / 10.0 <= 0.0)) return result;
            double crestRoundRadius, rootRoundRadius;
            double crestTangentLeft, crestTangentRight, rootTangentLeft, rootTangentRight;
            ResolvePreviewFillets(p, groove, pitch, out crestRoundRadius, out rootRoundRadius,
                out crestTangentLeft, out crestTangentRight, out rootTangentLeft, out rootTangentRight);
            bool roundedProfile = crestRoundRadius > 0.0 && rootRoundRadius > 0.0;

            foreach (ThreadTarget target in targets)
            {
                if (target == null || target.Center == null || target.Center.Length < 3 || target.U == null || target.U.Length < 3)
                    continue;

                double offset = p.OffsetMm / 10.0;
                // Must match BuildCurves exactly; otherwise the shaded phantom and contours
                // could disagree about the requested axial interval.
                double length = ThreadPreviewLengthPolicy.ResolveLengthCm(
                    p.FullLength, target.LengthCm, p.OffsetMm, p.LengthMm);
                double chamferDepthCm = ThreadPreviewChamferPolicy.ResolveVisualDepthCm(
                    p.ChamferMm / 10.0, referenceRadius, target.LengthCm, p.ChamferMode);

                double[] u = Normalize(target.U);
                double[] helper = Math.Abs(u[0]) < 0.9 ? new[] { 1.0, 0.0, 0.0 } : new[] { 0.0, 1.0, 0.0 };
                double[] radial = Normalize(Cross(u, Cross(helper, u)));
                double[] tangent = Cross(u, radial);
                bool startShoulder = target.StartIsShoulder && offset <= 1e-6;
                bool endShoulder = target.EndIsShoulder && p.FullLength;
                bool smoothStart = p.Smooth && offset > 1e-6 && !startShoulder;
                bool smoothEnd = p.Smooth && (!p.FullLength || endShoulder);
                double runLength = Math.Min(p.RunSteps * pitch, 0.45 * length);
                double threadStart = offset;
                double threadEnd = offset + length;
                double halfWidth = groove.ExtWidth / 2.0;
                double smoothEndZ = endShoulder ? threadEnd - halfWidth * 1.02 : threadEnd;
                double visibleStart = startShoulder ? threadStart + halfWidth * 1.02 : threadStart;
                double visibleEnd = endShoulder ? threadEnd - halfWidth * 1.02 : threadEnd;
                if (visibleEnd <= visibleStart + 1e-5) continue;
                if (smoothStart || smoothEnd)
                {
                    if (smoothEndZ <= threadStart + 0.5 * pitch) continue;
                    runLength = Math.Min(runLength, 0.45 * Math.Max(1e-6, smoothEndZ - threadStart));
                    if (smoothStart && smoothEnd && runLength * 2.0 >= smoothEndZ - threadStart - 1e-6) continue;
                }

                double pre = groove.ExtWidth / 2.0 * 1.05 + 1e-4;
                double mainStartBase = smoothStart ? threadStart + runLength :
                    (startShoulder ? threadStart + halfWidth * 1.02 : threadStart - pre);
                double phaseOrigin = startShoulder ? mainStartBase : mainStartBase - (p.Starts - 1) * pitch;
                // Bound the total preview mesh budget across all selected edges. Preview must
                // remain lightweight if the user selects many cylinders at once.
                int targetBudget = Math.Max(624, 180000 / Math.Max(1, targets.Count));
                int angleSteps = 96;
                // About eight axial samples per pitch, capped for long cylinders.
                int zSteps = Math.Max(12, Math.Min(256,
                    (int)Math.Ceiling((visibleEnd - visibleStart) / Math.Max(pitch / 8.0, 1e-5))));
                while (angleSteps * 2 * (zSteps + 1) > targetBudget && zSteps > 12)
                    zSteps = Math.Max(12, zSteps - 8);
                while (angleSteps * 2 * (zSteps + 1) > targetBudget && angleSteps > 24)
                    angleSteps = Math.Max(24, angleSteps - 8);
                int stripVertexCount = 2 * (zSteps + 1);
                var stripLengths = new int[angleSteps];
                for (int i = 0; i < stripLengths.Length; i++) stripLengths[i] = stripVertexCount;
                int vertexCount = angleSteps * stripVertexCount;
                var coordinates = new double[vertexCount * 3];
                var normals = new double[vertexCount * 3];
                double sign = p.RightHand ? 1.0 : -1.0;
                double radialSign = p.External ? -1.0 : 1.0;
                double normalSign = -radialSign;
                double topDepth = Math.Max(0.0, groove.CapDepth - groove.Ext);
                int vertex = 0;

                for (int a = 0; a < angleSteps; a++)
                {
                    double theta0 = TwoPi * a / angleSteps;
                    double theta1 = TwoPi * (a + 1) / angleSteps;
                    for (int zIndex = 0; zIndex <= zSteps; zIndex++)
                    {
                        double z = visibleStart + (visibleEnd - visibleStart) * zIndex / zSteps;
                        WriteMeshVertex(coordinates, normals, vertex++, target.Center, u, radial, tangent,
                            z, theta0, referenceRadius, radialSign, normalSign, topDepth, groove,
                            roundedProfile, crestRoundRadius, rootRoundRadius,
                            crestTangentLeft, crestTangentRight, rootTangentLeft, rootTangentRight,
                            pitch, lead, sign, phaseOrigin, p.Mirror, threadStart, smoothStart,
                            smoothEnd, smoothEndZ, runLength, p.ChamferMode, chamferDepthCm, target.LengthCm, taperRadiusSlope);
                        WriteMeshVertex(coordinates, normals, vertex++, target.Center, u, radial, tangent,
                            z, theta1, referenceRadius, radialSign, normalSign, topDepth, groove,
                            roundedProfile, crestRoundRadius, rootRoundRadius,
                            crestTangentLeft, crestTangentRight, rootTangentLeft, rootTangentRight,
                            pitch, lead, sign, phaseOrigin, p.Mirror, threadStart, smoothStart,
                            smoothEnd, smoothEndZ, runLength, p.ChamferMode, chamferDepthCm, target.LengthCm, taperRadiusSlope);
                    }
                }

                result.Add(new PreviewMesh { Coordinates = coordinates, Normals = normals, StripLengths = stripLengths });

                // Schematic 45-degree cone band for each selected circular end. This is temporary
                // BurnThrough geometry only; ThreadBuilder still creates the authoritative B-Rep.
                if (chamferDepthCm > 1e-9)
                {
                    if (ThreadPreviewChamferPolicy.IncludesStart(p.ChamferMode))
                        result.Add(BuildChamferMesh(target.Center, u, radial, tangent, 0.0, chamferDepthCm,
                            referenceRadius, radialSign, true));
                    if (ThreadPreviewChamferPolicy.IncludesEnd(p.ChamferMode))
                        result.Add(BuildChamferMesh(target.Center, u, radial, tangent, target.LengthCm, chamferDepthCm,
                            referenceRadius, radialSign, false));
                }
            }
            return result;
        }

        private static PreviewMesh BuildChamferMesh(double[] center, double[] u, double[] radial, double[] tangent,
            double edgeZ, double chamferDepthCm, double referenceRadius, double radialSign, bool startEdge)
        {
            const int angleSteps = 72;
            var coordinates = new double[angleSteps * 4 * 3];
            var normals = new double[coordinates.Length];
            var stripLengths = new int[angleSteps];
            for (int i = 0; i < angleSteps; i++) stripLengths[i] = 4;

            double insideZ = startEdge ? edgeZ + chamferDepthCm : edgeZ - chamferDepthCm;
            double edgeRadius = referenceRadius + radialSign * chamferDepthCm - radialSign * 0.0005;
            double insideRadius = referenceRadius - radialSign * 0.0005;
            double axialNormal = startEdge ? radialSign : -radialSign;
            for (int i = 0; i < angleSteps; i++)
            {
                double theta0 = TwoPi * i / angleSteps;
                double theta1 = TwoPi * (i + 1) / angleSteps;
                WriteChamferVertex(coordinates, normals, i * 4, center, u, radial, tangent, edgeZ, edgeRadius, theta0, axialNormal);
                WriteChamferVertex(coordinates, normals, i * 4 + 1, center, u, radial, tangent, insideZ, insideRadius, theta0, axialNormal);
                WriteChamferVertex(coordinates, normals, i * 4 + 2, center, u, radial, tangent, edgeZ, edgeRadius, theta1, axialNormal);
                WriteChamferVertex(coordinates, normals, i * 4 + 3, center, u, radial, tangent, insideZ, insideRadius, theta1, axialNormal);
            }
            return new PreviewMesh { Coordinates = coordinates, Normals = normals, StripLengths = stripLengths, IsChamfer = true };
        }

        private static void WriteChamferVertex(double[] coordinates, double[] normals, int vertex,
            double[] center, double[] u, double[] radial, double[] tangent, double z, double radius,
            double theta, double axialNormal)
        {
            double ca = Math.Cos(theta), sa = Math.Sin(theta);
            double er0 = radial[0] * ca + tangent[0] * sa;
            double er1 = radial[1] * ca + tangent[1] * sa;
            double er2 = radial[2] * ca + tangent[2] * sa;
            int at = vertex * 3;
            coordinates[at] = center[0] + u[0] * z + radius * er0;
            coordinates[at + 1] = center[1] + u[1] * z + radius * er1;
            coordinates[at + 2] = center[2] + u[2] * z + radius * er2;
            double norm = Math.Sqrt(1.0 + axialNormal * axialNormal);
            normals[at] = (er0 + axialNormal * u[0]) / norm;
            normals[at + 1] = (er1 + axialNormal * u[1]) / norm;
            normals[at + 2] = (er2 + axialNormal * u[2]) / norm;
        }

        private static void WriteMeshVertex(double[] coordinates, double[] normals, int vertex,
            double[] center, double[] u, double[] radial, double[] tangent, double z, double theta,
            double referenceRadius, double radialSign, double normalSign, double topDepth, Groove groove,
            bool roundedProfile, double crestRoundRadius, double rootRoundRadius,
            double crestTangentLeft, double crestTangentRight, double rootTangentLeft, double rootTangentRight,
            double pitch, double lead, double handSign, double phaseOrigin, bool mirror,
            double threadStart, bool smoothStart, bool smoothEnd, double smoothEndZ, double runLength,
            int chamferMode, double chamferDepthCm, double targetLengthCm, double radiusSlope)
        {
            double phase = z - phaseOrigin - handSign * lead * theta / TwoPi;
            phase = WrapCentered(phase, pitch);
            if (mirror) phase = WrapCentered(-phase, pitch);
            double depth = ProfileDepth(phase, groove, topDepth, roundedProfile, crestRoundRadius, rootRoundRadius,
                crestTangentLeft, crestTangentRight, rootTangentLeft, rootTangentRight);
            double fade = 1.0;
            if (smoothStart && runLength > 1e-6 && z < threadStart + runLength)
                fade = Math.Min(fade, SmoothStep((z - threadStart) / runLength));
            if (smoothEnd && runLength > 1e-6 && z > smoothEndZ - runLength)
                fade = Math.Min(fade, SmoothStep((smoothEndZ - z) / runLength));
            depth = topDepth + (depth - topDepth) * fade;
            depth += chamferDepthCm * ThreadPreviewChamferPolicy.DepthFactor(
                z, targetLengthCm, chamferMode, chamferDepthCm);

            // Lift the temporary surface only slightly off the nominal stock to reduce z-fighting.
            // The translucent mesh uses normal scene depth so unrelated foreground geometry remains visible.
            // Root contour guides still provide the schematic indication of valleys inside the stock.
            double radius = referenceRadius + radiusSlope * z + radialSign * depth - radialSign * 0.0005;
            double ca = Math.Cos(theta), sa = Math.Sin(theta);
            double er0 = radial[0] * ca + tangent[0] * sa;
            double er1 = radial[1] * ca + tangent[1] * sa;
            double er2 = radial[2] * ca + tangent[2] * sa;
            int at = vertex * 3;
            coordinates[at] = center[0] + u[0] * z + radius * er0;
            coordinates[at + 1] = center[1] + u[1] * z + radius * er1;
            coordinates[at + 2] = center[2] + u[2] * z + radius * er2;
            normals[at] = normalSign * er0;
            normals[at + 1] = normalSign * er1;
            normals[at + 2] = normalSign * er2;
        }

        private static void ResolvePreviewFillets(ThreadParams p, Groove groove, double pitch,
            out double crestRadius, out double rootRadius,
            out double crestTangentLeft, out double crestTangentRight,
            out double rootTangentLeft, out double rootTangentRight)
        {
            crestRadius = rootRadius = 0.0;
            crestTangentLeft = crestTangentRight = rootTangentLeft = rootTangentRight = 0.0;
            if (p == null || !p.Round || p.Tapered || pitch <= 1e-9) return;

            ThreadProfileSpec spec = ThreadStandards.Spec(p.Standard);
            ThreadStandards.Radii(p.Standard, spec, p.External, pitch, 10.0, out crestRadius, out rootRadius);
            double dxLeft = groove.X1L - groove.X0L;
            double dxRight = groove.X0R - groove.X1R;
            double dy = groove.Depth - groove.CapDepth;
            if (dxLeft <= 1e-9 || dxRight <= 1e-9 || dy <= 1e-9 ||
                crestRadius <= 1e-9 || rootRadius <= 1e-9)
            {
                crestRadius = rootRadius = 0.0;
                return;
            }

            // DIN 513 / S is asymmetric: calculate tangent distance separately for each flank.
            double betaLeft = Math.Atan2(dy, dxLeft);
            double betaRight = Math.Atan2(dy, dxRight);
            double factorLeft = Math.Tan(betaLeft / 2.0);
            double factorRight = Math.Tan(betaRight / 2.0);
            double maxTangentFactor = Math.Max(factorLeft, factorRight);
            double crestLand = Math.Max(0.0, pitch - (groove.X0R - groove.X0L));
            double rootLand = Math.Max(0.0, groove.X1R - groove.X1L);
            double flankLeftLength = Math.Sqrt(dxLeft * dxLeft + dy * dy);
            double flankRightLength = Math.Sqrt(dxRight * dxRight + dy * dy);
            if (factorLeft <= 1e-9 || factorRight <= 1e-9 || maxTangentFactor <= 1e-9 ||
                crestLand <= 1e-9 || rootLand <= 1e-9 || flankLeftLength <= 1e-9 || flankRightLength <= 1e-9)
            {
                crestRadius = rootRadius = 0.0;
                return;
            }

            // Cap radii so paired corners do not consume an entire crest/root land.
            crestRadius = Math.Min(crestRadius, 0.45 * crestLand / maxTangentFactor);
            rootRadius = Math.Min(rootRadius, 0.45 * rootLand / maxTangentFactor);
            double sum = crestRadius + rootRadius;
            if (sum > 1e-9)
            {
                double scale = 1.0;
                scale = Math.Min(scale, 0.90 * flankLeftLength / (sum * factorLeft));
                scale = Math.Min(scale, 0.90 * flankRightLength / (sum * factorRight));
                if (scale < 1.0)
                {
                    crestRadius *= scale;
                    rootRadius *= scale;
                }
            }

            if (crestRadius <= 1e-9 || rootRadius <= 1e-9)
            {
                crestRadius = rootRadius = 0.0;
                return;
            }
            crestTangentLeft = crestRadius * factorLeft;
            crestTangentRight = crestRadius * factorRight;
            rootTangentLeft = rootRadius * factorLeft;
            rootTangentRight = rootRadius * factorRight;
        }

        private static double ProfileDepth(double phase, Groove groove, double topDepth,
            bool roundedProfile, double crestRadius, double rootRadius,
            double crestTangentLeft, double crestTangentRight,
            double rootTangentLeft, double rootTangentRight)
        {
            double x0L = groove.X0L, x0R = groove.X0R;
            double x1L = groove.X1L, x1R = groove.X1R;
            if (roundedProfile && crestRadius > 1e-9 && rootRadius > 1e-9)
            {
                double dxLeft = x1L - x0L;
                double dxRight = x0R - x1R;
                double dy = groove.Depth - groove.CapDepth;
                if (dxLeft > 1e-9 && dxRight > 1e-9 && dy > 1e-9)
                {
                    double cosLeft = Math.Cos(Math.Atan2(dy, dxLeft));
                    double cosRight = Math.Cos(Math.Atan2(dy, dxRight));
                    double xw = groove.ExtWidth / 2.0;

                    // Follow the same cap flats, flanks, root land and corner radii as the builder.
                    // Independent left/right tangent projections are necessary for asymmetric S.
                    if (phase < -xw || phase > xw) return topDepth;
                    if (phase < x0L - crestTangentLeft) return groove.CapDepth;
                    if (phase <= x0L + crestTangentLeft * cosLeft)
                    {
                        double centerX = x0L - crestTangentLeft;
                        double offset = phase - centerX;
                        double radicand = Math.Max(0.0, crestRadius * crestRadius - offset * offset);
                        return groove.CapDepth + crestRadius - Math.Sqrt(radicand);
                    }
                    if (phase < x1L - rootTangentLeft * cosLeft)
                    {
                        double span = x1L - x0L;
                        double t = span <= 1e-9 ? 1.0 : (phase - x0L) / span;
                        return groove.CapDepth + (groove.Depth - groove.CapDepth) * Math.Max(0.0, Math.Min(1.0, t));
                    }
                    if (phase <= x1L + rootTangentLeft)
                    {
                        double centerX = x1L + rootTangentLeft;
                        double offset = phase - centerX;
                        double radicand = Math.Max(0.0, rootRadius * rootRadius - offset * offset);
                        return groove.Depth - rootRadius + Math.Sqrt(radicand);
                    }
                    if (phase < x1R - rootTangentRight) return groove.Depth;
                    if (phase <= x1R + rootTangentRight * cosRight)
                    {
                        double centerX = x1R - rootTangentRight;
                        double offset = phase - centerX;
                        double radicand = Math.Max(0.0, rootRadius * rootRadius - offset * offset);
                        return groove.Depth - rootRadius + Math.Sqrt(radicand);
                    }
                    if (phase < x0R - crestTangentRight * cosRight)
                    {
                        double span = x0R - x1R;
                        double t = span <= 1e-9 ? 1.0 : (x0R - phase) / span;
                        return groove.CapDepth + (groove.Depth - groove.CapDepth) * Math.Max(0.0, Math.Min(1.0, t));
                    }
                    if (phase <= x0R + crestTangentRight)
                    {
                        double centerX = x0R + crestTangentRight;
                        double offset = phase - centerX;
                        double radicand = Math.Max(0.0, crestRadius * crestRadius - offset * offset);
                        return groove.CapDepth + crestRadius - Math.Sqrt(radicand);
                    }
                    if (phase <= xw) return groove.CapDepth;
                    return topDepth;
                }
            }

            // Keep the original sharp-preview path when rounding is off.
            if (phase < x0L || phase > x0R) return topDepth;
            if (phase < x1L)
            {
                double span = x1L - x0L;
                double t = span <= 1e-9 ? 1.0 : (phase - x0L) / span;
                return groove.CapDepth + (groove.Depth - groove.CapDepth) * Math.Max(0.0, Math.Min(1.0, t));
            }
            if (phase <= x1R) return groove.Depth;
            double rightSpan = x0R - x1R;
            double rightT = rightSpan <= 1e-9 ? 1.0 : (x0R - phase) / rightSpan;
            return groove.CapDepth + (groove.Depth - groove.CapDepth) * Math.Max(0.0, Math.Min(1.0, rightT));
        }

        private static double WrapCentered(double value, double pitch)
        {
            if (pitch <= 1e-12) return 0.0;
            return value - Math.Floor((value + pitch * 0.5) / pitch) * pitch;
        }

        private static double[] CreateHelix(double[] center, double[] u, double[] radial, double[] tangent,
            double zStart, double zEnd, double crestRadius, double rootRadius, double threadStart,
            bool smoothStart, bool smoothEnd, double smoothEndZ, double runLength,
            double phaseOrigin, int startIndex, int starts, bool rightHand, double lead, int samples, bool rootCurve, double profilePhase,
            double radiusSlope)
        {
            var coordinates = new double[(samples + 1) * 3];
            double sign = rightHand ? 1.0 : -1.0;
            for (int i = 0; i <= samples; i++)
            {
                double z = zStart + (zEnd - zStart) * i / samples;
                // Builder profiles are placed one pitch apart and the phase advances by one
                // full revolution per lead. This gives the preview the same hand and start spacing.
                double angle = sign * TwoPi * ((z - phaseOrigin - profilePhase) / Math.Max(lead, 1e-6) - (double)startIndex / starts);
                double factor = 1.0;
                if (smoothStart && runLength > 1e-6 && z < threadStart + runLength)
                    factor = Math.Min(factor, SmoothStep((z - threadStart) / runLength));
                double endFade = smoothEnd ? smoothEndZ : zEnd;
                if (smoothEnd && runLength > 1e-6 && z > endFade - runLength)
                    factor = Math.Min(factor, SmoothStep((endFade - z) / runLength));
                double radius = crestRadius + radiusSlope * z +
                    (rootCurve ? (rootRadius - crestRadius) * factor : 0.0);
                double ca = Math.Cos(angle), sa = Math.Sin(angle);
                double x = center[0] + u[0] * z + radius * (radial[0] * ca + tangent[0] * sa);
                double y = center[1] + u[1] * z + radius * (radial[1] * ca + tangent[1] * sa);
                double zz = center[2] + u[2] * z + radius * (radial[2] * ca + tangent[2] * sa);
                int at = i * 3;
                coordinates[at] = x;
                coordinates[at + 1] = y;
                coordinates[at + 2] = zz;
            }
            return coordinates;
        }

        private static void ApplyChamferToCurve(double[] coordinates, double[] center, double[] u,
            double radialSign, double targetLengthCm, int chamferMode, double chamferDepthCm)
        {
            if (coordinates == null || chamferMode == 0 || chamferDepthCm <= 1e-9) return;
            for (int at = 0; at + 2 < coordinates.Length; at += 3)
            {
                double dx = coordinates[at] - center[0];
                double dy = coordinates[at + 1] - center[1];
                double dz = coordinates[at + 2] - center[2];
                double axial = dx * u[0] + dy * u[1] + dz * u[2];
                double factor = ThreadPreviewChamferPolicy.DepthFactor(axial, targetLengthCm, chamferMode, chamferDepthCm);
                if (factor <= 0.0) continue;
                double px = dx - u[0] * axial;
                double py = dy - u[1] * axial;
                double pz = dz - u[2] * axial;
                double radius = Math.Sqrt(px * px + py * py + pz * pz);
                if (radius <= 1e-9) continue;
                double scale = (radius + radialSign * chamferDepthCm * factor) / radius;
                coordinates[at] = center[0] + u[0] * axial + px * scale;
                coordinates[at + 1] = center[1] + u[1] * axial + py * scale;
                coordinates[at + 2] = center[2] + u[2] * axial + pz * scale;
            }
        }

        private static double[] CreateRing(double[] center, double[] u, double[] radial, double[] tangent, double z, double radius, int samples)
        {
            var coords = new double[(samples + 1) * 3];
            for (int i = 0; i <= samples; i++)
            {
                double angle = TwoPi * i / samples;
                double ca = Math.Cos(angle), sa = Math.Sin(angle);
                int at = i * 3;
                coords[at] = center[0] + u[0] * z + radius * (radial[0] * ca + tangent[0] * sa);
                coords[at + 1] = center[1] + u[1] * z + radius * (radial[1] * ca + tangent[1] * sa);
                coords[at + 2] = center[2] + u[2] * z + radius * (radial[2] * ca + tangent[2] * sa);
            }
            return coords;
        }

        private static int SampleCount(double turns)
        {
            return Math.Max(72, Math.Min(1600, (int)Math.Ceiling(Math.Max(1.0, turns) * 48.0)));
        }

        private static double SmoothStep(double value)
        {
            double x = Math.Max(0.0, Math.Min(1.0, value));
            return x * x * (3.0 - 2.0 * x);
        }

        private static double[] Normalize(double[] vector)
        {
            double length = Math.Sqrt(vector[0] * vector[0] + vector[1] * vector[1] + vector[2] * vector[2]);
            if (length <= 1e-12) throw new InvalidOperationException("Направление выбранной оси некорректно.");
            return new[] { vector[0] / length, vector[1] / length, vector[2] / length };
        }

        private static double[] Cross(double[] a, double[] b)
        {
            return new[] { a[1] * b[2] - a[2] * b[1], a[2] * b[0] - a[0] * b[2], a[0] * b[1] - a[1] * b[0] };
        }
    }
}
