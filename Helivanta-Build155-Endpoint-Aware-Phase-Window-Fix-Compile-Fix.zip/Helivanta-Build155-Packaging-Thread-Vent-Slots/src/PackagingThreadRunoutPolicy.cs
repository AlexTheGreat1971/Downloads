using System;

namespace ThreadPro
{
    /// <summary>
    /// Pure planning for packaging-thread run-outs. All public dimensions are millimetres.
    /// The plan preserves a minimum core Coil length and bounds Loft section count.
    /// </summary>
    internal static class PackagingThreadRunoutPolicy
    {
        internal const double TerminalCrestFactor = 0.02;
        internal const double MinimumCoreLeadFraction = 0.25;
        // Run-out length is specified as a fraction of one actual helix revolution (lead),
        // not a fraction of pitch. External thread: 1/12 turn; internal positive rib: 1/6.
        internal const double ExternalRunoutTurnFraction = 1.0 / 12.0;
        internal const double InternalRunoutTurnFraction = 1.0 / 6.0;
        internal const int MinimumSectionCount = 7;
        internal const int MaximumSectionCount = 49;
        internal const double SectionsPerTurn = 24.0;

        internal sealed class Plan
        {
            public double TotalLengthMm { get; internal set; }
            public double StartLengthMm { get; internal set; }
            public double EndLengthMm { get; internal set; }
            public double CoreLengthMm { get; internal set; }
            public double TerminalCrestFactorValue { get; internal set; }
            public double TargetTurnFraction { get; internal set; }
            public double EffectiveTurnFraction { get; internal set; }
            public bool IsInternalThread { get; internal set; }
            public int StartSectionCount { get; internal set; }
            public int EndSectionCount { get; internal set; }
            public bool HasStart => StartLengthMm > 0.0;
            public bool HasEnd => EndLengthMm > 0.0;
        }

        internal static bool TryResolve(
            double totalLengthMm, double pitchMm, double leadMm, double heightMm,
            double embedMm, double profileWidthMm, bool internalThread, bool smoothStart, bool smoothEnd,
            out Plan plan, out string error)
        {
            plan = null;
            error = null;
            if (!Finite(totalLengthMm) || totalLengthMm <= 0.0 ||
                !Finite(pitchMm) || pitchMm <= 0.0 ||
                !Finite(leadMm) || leadMm <= 0.0 ||
                !Finite(heightMm) || heightMm <= 0.0 ||
                !Finite(embedMm) || embedMm <= 0.0 ||
                !Finite(profileWidthMm) || profileWidthMm <= 0.0)
                return Reject("Длина и размеры профиля для сбега должны быть конечными положительными числами.", out error);

            double minimumCoreMm = Math.Max(leadMm * MinimumCoreLeadFraction, pitchMm * 0.25);
            if (totalLengthMm + 1e-9 < minimumCoreMm)
                return Reject("Недостаточная длина для минимального рабочего участка резьбы.", out error);

            double targetTurnFraction = internalThread ? InternalRunoutTurnFraction : ExternalRunoutTurnFraction;
            int enabledRunoutCount = (smoothStart ? 1 : 0) + (smoothEnd ? 1 : 0);
            double eachRunoutMm = leadMm * targetTurnFraction;
            double availableForRunoutsMm = Math.Max(0.0, totalLengthMm - minimumCoreMm);
            bool runoutsShortened = enabledRunoutCount > 0 &&
                eachRunoutMm * enabledRunoutCount > availableForRunoutsMm + 1e-9;
            if (runoutsShortened)
            {
                // Preserve both requested ends and the minimum working coil by shortening
                // each runout equally instead of rejecting an otherwise usable short thread.
                eachRunoutMm = availableForRunoutsMm / enabledRunoutCount;
                const double minimumUsefulRunoutTurnFraction = 1.0 / 24.0;
                if (eachRunoutMm + 1e-9 < leadMm * minimumUsefulRunoutTurnFraction)
                    return Reject(string.Format(System.Globalization.CultureInfo.InvariantCulture,
                        "Недостаточно осевой длины даже для минимальных плавных сбегов по {0:0.###} оборота и рабочего участка не короче {1:0.###} мм. Увеличьте длину или отключите один из сбегов.",
                        minimumUsefulRunoutTurnFraction, minimumCoreMm), out error);
            }
            double startLength = smoothStart ? eachRunoutMm : 0.0;
            double endLength = smoothEnd ? eachRunoutMm : 0.0;
            double coreLength = totalLengthMm - startLength - endLength;
            if (!Finite(coreLength) || coreLength + 1e-8 < minimumCoreMm)
                return Reject("Недостаточно осевой длины для минимального рабочего участка резьбы после размещения сбегов.", out error);
            double effectiveTurnFraction = enabledRunoutCount > 0 ? eachRunoutMm / leadMm : 0.0;

            plan = new Plan
            {
                TotalLengthMm = totalLengthMm,
                StartLengthMm = startLength,
                EndLengthMm = endLength,
                CoreLengthMm = coreLength,
                TerminalCrestFactorValue = TerminalCrestFactor,
                TargetTurnFraction = targetTurnFraction,
                EffectiveTurnFraction = effectiveTurnFraction,
                IsInternalThread = internalThread,
                StartSectionCount = smoothStart ? GetSectionCount(startLength, leadMm) : 0,
                EndSectionCount = smoothEnd ? GetSectionCount(endLength, leadMm) : 0
            };
            return true;
        }

        internal static double SmoothStep(double t)
        {
            if (!Finite(t)) throw new ArgumentOutOfRangeException(nameof(t));
            t = Math.Max(0.0, Math.Min(1.0, t));
            return t * t * (3.0 - 2.0 * t);
        }

        /// <summary>Fade factor along a runout: 0.02 near the free end, 1 at the full-depth core.</summary>
        internal static double GetCrestFactor(double t, bool runoutAtStart)
        {
            double eased = SmoothStep(t);
            return runoutAtStart
                ? TerminalCrestFactor + (1.0 - TerminalCrestFactor) * eased
                : 1.0 - (1.0 - TerminalCrestFactor) * eased;
        }

        /// <summary>
        /// Smoothly fades root penetration while retaining a small overlap with the stock.
        /// Unlike max(crestFactor, minimumFactor), this has zero slope at both ends and
        /// avoids a derivative kink where the root penetration would otherwise change regimes.
        /// </summary>
        internal static double GetRootFactor(double t, bool runoutAtStart, double embedMm)
        {
            if (!Finite(t) || !Finite(embedMm) || embedMm <= 0.0)
                throw new ArgumentOutOfRangeException();
            double minimumFactor = Math.Max(0.10, Math.Min(0.40, 0.015 / embedMm));
            double eased = SmoothStep(runoutAtStart ? t : 1.0 - t);
            return minimumFactor + (1.0 - minimumFactor) * eased;
        }

        internal static int GetSectionCount(double runoutLengthMm, double leadMm)
        {
            if (!Finite(runoutLengthMm) || runoutLengthMm <= 0.0 || !Finite(leadMm) || leadMm <= 0.0)
                throw new ArgumentOutOfRangeException();
            int count = (int)Math.Ceiling(runoutLengthMm / leadMm * SectionsPerTurn) + 1;
            return Math.Max(MinimumSectionCount, Math.Min(MaximumSectionCount, count));
        }

        private static bool Reject(string message, out string error)
        {
            error = message;
            return false;
        }

        private static bool Finite(double value) => !double.IsNaN(value) && !double.IsInfinity(value);
    }
}
