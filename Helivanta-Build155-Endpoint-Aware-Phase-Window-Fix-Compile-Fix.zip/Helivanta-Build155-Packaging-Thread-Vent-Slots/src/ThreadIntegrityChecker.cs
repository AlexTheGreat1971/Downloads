﻿using System;
using System.Collections.Generic;
using System.Globalization;
using Inventor;

namespace ThreadPro
{
    internal enum ThreadIntegritySeverity
    {
        Info,
        Warning,
        Error
    }

    internal sealed class ThreadIntegrityFinding
    {
        internal ThreadIntegritySeverity Severity;
        internal string ThreadId;
        internal string DisplayLabel;
        internal string StandardLabel;
        internal string Designation;
        internal string ParameterSummary;
        internal string Message;
        internal string Recommendation;
    }

    internal sealed class ThreadIntegrityReport
    {
        internal readonly List<ThreadIntegrityFinding> Findings = new List<ThreadIntegrityFinding>();
        internal int ValidGroups;
        internal int NativeThreads;
        internal bool ScanComplete = true;

        internal int Errors
        {
            get { return Findings.FindAll(f => f.Severity == ThreadIntegritySeverity.Error).Count; }
        }

        internal int Warnings
        {
            get { return Findings.FindAll(f => f.Severity == ThreadIntegritySeverity.Warning).Count; }
        }

        internal string RiskLabel
        {
            get
            {
                if (!ScanComplete) return "НЕПОЛНАЯ ПРОВЕРКА";
                if (Errors > 0) return "КРИТИЧЕСКИЙ РИСК";
                if (Warnings > 0) return "ТРЕБУЕТ ВНИМАНИЯ";
                return "НИЗКИЙ РИСК";
            }
        }

        internal string NextAction
        {
            get
            {
                if (!ScanComplete) return "Сначала устраните ошибки доступа/перечисления; отсутствие конфликтов пока не доказано.";
                if (Errors > 0) return "Не строить новые резьбы в отмеченных зонах до устранения пересечений или повреждённых данных.";
                if (Warnings > 0) return "Проверьте предупреждения: стандарт, исходная поверхность и параметры требуют подтверждения.";
                return "Критических конфликтов не обнаружено. Перед производством всё равно проверьте модель и требования чертежа.";
            }
        }
    }

    /// <summary>Read-only diagnostics for Helivanta metadata, standards, source cylinders and native cosmetic threads.</summary>
    internal static class ThreadIntegrityChecker
    {
        internal static ThreadIntegrityReport Check(PartDocument doc, Inventor.Application app)
        {
            var report = new ThreadIntegrityReport();
            if (doc == null)
            {
                report.ScanComplete = false;
                Add(report, ThreadIntegritySeverity.Error, "", "Не открыт документ детали Inventor.");
                return report;
            }

            var groups = new List<ThreadMetadataGroup>();
            var seenIds = new HashSet<string>(StringComparer.Ordinal);
            try
            {
                ObjectCollection owners = doc.AttributeManager.FindObjects(ThreadMetadataStore.AttributeSetName, "ThreadId", null);
                if (owners != null)
                {
                    foreach (object owner in owners)
                    {
                        string id;
                        if (!ThreadMetadataStore.TryGetThreadId(owner, out id) || string.IsNullOrWhiteSpace(id))
                        {
                            report.ScanComplete = false;
                            Add(report, ThreadIntegritySeverity.Error, "", "Найден объект с набором метаданных Helivanta, но идентификатор группы отсутствует или повреждён.");
                            continue;
                        }
                        if (!seenIds.Add(id)) continue;
                        ThreadMetadataGroup group;
                        string groupError;
                        if (!ThreadMetadataStore.TryLoadGroup(doc, id, out group, out groupError))
                        {
                            report.ScanComplete = false;
                            Add(report, ThreadIntegritySeverity.Error, id, groupError ?? "Группа не прошла проверку целостности.");
                            continue;
                        }
                        groups.Add(group);
                    }
                }
            }
            catch (Exception ex)
            {
                report.ScanComplete = false;
                Add(report, ThreadIntegritySeverity.Error, "", "Не удалось перечислить метаданные Helivanta: " + ex.Message);
            }

            foreach (ThreadMetadataGroup group in groups)
            {
                report.ValidGroups++;
                ThreadMetadataRecord record = group.Record;
                string id = record.ThreadId;
                string standardLabel = ThreadStandards.Title((ThreadStandard)record.Parameters.Standard);
                bool catalogueMatch = MatchesCatalogue(record.Parameters);
                string message = catalogueMatch
                    ? "Группа целая. Диаметр и шаг совпадают с табличным типоразмером выбранного стандарта."
                    : "Группа целая, но диаметр/шаг не найдены в таблице стандартных типоразмеров. Возможно, используется пользовательский размер или шаг; соответствие таблице не подтверждено.";
                Add(report, catalogueMatch ? ThreadIntegritySeverity.Info : ThreadIntegritySeverity.Warning,
                    id, message, record, standardLabel);

                string expectedName = null;
                try
                {
                    expectedName = ThreadSizeNamePolicy.Build((ThreadStandard)record.Parameters.Standard,
                        ThreadStandards.Sizes((ThreadStandard)record.Parameters.Standard),
                        record.Parameters.NominalDiaMm, record.Parameters.PitchMm);
                }
                catch { }
                if (!string.IsNullOrWhiteSpace(expectedName) &&
                    !string.Equals(expectedName, record.Parameters.SizeName, StringComparison.OrdinalIgnoreCase))
                {
                    Add(report, ThreadIntegritySeverity.Warning, id,
                        "Сохранённое обозначение «" + record.Parameters.SizeName + "» отличается от обозначения, рассчитанного по текущему стандарту: «" + expectedName + "».",
                        record, standardLabel);
                }

                string sourceError;
                if (!SourceCylinderExists(doc, record, out sourceError))
                    Add(report, ThreadIntegritySeverity.Warning, id, sourceError, record, standardLabel);
            }

            // Compare all intact Helivanta groups to one another in a shared axis frame.
            for (int i = 0; i < groups.Count; i++)
            {
                for (int j = i + 1; j < groups.Count; j++)
                {
                    ThreadMetadataRecord a = groups[i].Record;
                    ThreadMetadataRecord b = groups[j].Record;
                    if (!ThreadTargetIsolationPolicy.SameCylinder(a.Target, b.Target)) continue;
                    double a0, a1, b0, b1;
                    if (!TryGetThreadInterval(a, a.Target.Axis, out a0, out a1) || !TryGetThreadInterval(b, a.Target.Axis, out b0, out b1))
                    {
                        Add(report, ThreadIntegritySeverity.Error, a.ThreadId,
                            "Не удалось безопасно вычислить осевой интервал для сравнения с группой " + b.ThreadId + ".", a);
                        Add(report, ThreadIntegritySeverity.Error, b.ThreadId,
                            "Не удалось безопасно вычислить осевой интервал для сравнения с группой " + a.ThreadId + ".", b);
                        continue;
                    }
                    if (ThreadIntegrityPolicy.IntervalsOverlap(a0, a1, b0, b1))
                    {
                        Add(report, ThreadIntegritySeverity.Error, a.ThreadId,
                            "Осевой интервал пересекается с группой Helivanta " + b.ThreadId + " на том же цилиндре.", a);
                        Add(report, ThreadIntegritySeverity.Error, b.ThreadId,
                            "Осевой интервал пересекается с группой Helivanta " + a.ThreadId + " на том же цилиндре.", b);
                    }
                }
            }

            // Native Inventor cosmetic threads are enumerated read-only, then compared against
            // Helivanta groups. Only the hidden, exact-match tapered ThreadFeature tagged as a
            // Helivanta group member is omitted from the human-facing report.
            bool nativeScanComplete;
            string nativeScanError;
            List<NativeThreadOverlapSnapshot> nativeThreads = NativeThreadOverlapGuard.Enumerate(
                app, doc, out nativeScanComplete, out nativeScanError);
            // Helivanta creates a hidden TaperedThreadInfo ThreadFeature only as a standards/
            // callout support feature; the physical helical groove is a separate CoilFeature.
            // Exclude only the hidden native feature carrying the same persisted ThreadId and
            // exact tapered designation. Unrelated native tapered threads remain reportable.
            var reportableNativeThreads = new List<NativeThreadOverlapSnapshot>();
            foreach (NativeThreadOverlapSnapshot native in nativeThreads)
            {
                if (IsHelivantaTaperSupportFeature(native, groups)) continue;
                reportableNativeThreads.Add(native);
            }
            report.NativeThreads = reportableNativeThreads.Count;
            if (!nativeScanComplete)
            {
                report.ScanComplete = false;
                Add(report, ThreadIntegritySeverity.Error, "", nativeScanError ?? "Не удалось полностью перечислить штатные косметические резьбы Inventor.");
            }

            int nativeIndex = 0;
            foreach (NativeThreadOverlapSnapshot native in reportableNativeThreads)
            {
                nativeIndex++;
                if (native == null) continue;
                string nativeId = "INV:" + (native.Name ?? "ThreadFeature") + "#" + nativeIndex.ToString(CultureInfo.InvariantCulture);
                ThreadIntegritySeverity nativeSeverity = ThreadIntegritySeverity.Info;
                string nativeMessage;
                if (!native.IntervalKnown)
                {
                    nativeSeverity = ThreadIntegritySeverity.Warning;
                    nativeMessage = "Штатная косметическая резьба Inventor обнаружена, но её интервал нельзя подтвердить: " + native.InspectionMessage;
                }
                else if (!native.StandardMatched)
                {
                    nativeSeverity = ThreadIntegritySeverity.Warning;
                    nativeMessage = "Интервал штатной косметической резьбы определён, но её профиль/обозначение не удалось уверенно сопоставить со стандартом Helivanta. Соответствие стандарту не подтверждено.";
                }
                else if (!native.CatalogueMatched)
                {
                    nativeSeverity = ThreadIntegritySeverity.Warning;
                    nativeMessage = "Профиль штатной косметической резьбы распознан как «" + native.StandardLabel + "», но диаметр/шаг не найдены в таблице типоразмеров. Возможно, это пользовательский размер; соответствие таблице не подтверждено.";
                }
                else
                {
                    nativeMessage = "Штатная косметическая резьба Inventor определена; профиль, табличный типоразмер и осевой интервал распознаны.";
                }
                AddNative(report, nativeSeverity, nativeId, native, nativeMessage);

                if (native.Target == null) continue;
                foreach (ThreadMetadataGroup group in groups)
                {
                    ThreadMetadataRecord record = group.Record;
                    ThreadTargetSnapshot expectedSource = ExpectedSourceTarget(record);
                    ThreadTargetSnapshot nativeTarget = new ThreadTargetSnapshot
                    {
                        Center = (double[])native.Target.Center.Clone(),
                        Axis = (double[])native.Target.U.Clone(),
                        RadiusCm = native.Target.RadiusCm,
                        LengthCm = native.Target.LengthCm,
                        IsExternal = native.Target.IsExternal,
                        BodyName = native.Target.BodyName ?? string.Empty
                    };
                    if (!ThreadTargetIsolationPolicy.SameCylinder(expectedSource, nativeTarget)) continue;

                    double physicalStart = 0.0, physicalEnd = 0.0, nativeStart = 0.0, nativeEnd = 0.0;
                    bool intervalsKnown = native.IntervalKnown &&
                        TryGetThreadInterval(record, record.Target.Axis, out physicalStart, out physicalEnd) &&
                        NativeThreadOverlapPolicy.TryGetInterval(native.Target.Center, native.Target.U,
                            native.Target.LengthCm, native.FullDepth, native.LengthMm, native.OffsetMm,
                            new[] { 0.0, 0.0, 0.0 }, record.Target.Axis, out nativeStart, out nativeEnd);
                    bool overlapsOrUnknown = NativeThreadOverlapPolicy.ShouldBlock(true, intervalsKnown,
                        intervalsKnown ? physicalStart : 0.0, intervalsKnown ? physicalEnd : 0.0,
                        intervalsKnown ? nativeStart : 0.0, intervalsKnown ? nativeEnd : 0.0);
                    if (!overlapsOrUnknown) continue;

                    string overlapMessage = intervalsKnown
                        ? "Пересекается со штатной косметической резьбой Inventor «" + native.Name + "». Построение физической резьбы в этой зоне запрещено."
                        : "На том же цилиндре найдена штатная косметическая резьба Inventor «" + native.Name + "», но её интервал не подтверждён. Отсутствие пересечения установить нельзя; требуется ручная проверка.";
                    Add(report, ThreadIntegritySeverity.Error, record.ThreadId, overlapMessage, record,
                        ThreadStandards.Title((ThreadStandard)record.Parameters.Standard));
                    AddNative(report, ThreadIntegritySeverity.Error, nativeId, native,
                        "Пересекается с физической резьбой Helivanta «" + record.Parameters.SizeName + "» (ThreadId=" + record.ThreadId + ").");
                }
            }

            if (groups.Count == 0 && report.Findings.Count == 0)
                Add(report, ThreadIntegritySeverity.Info, "", "Группы физической резьбы Helivanta и штатные косметические резьбы Inventor не найдены.");
            else if (groups.Count == 0 && reportableNativeThreads.Count > 0)
                Add(report, ThreadIntegritySeverity.Info, "", "Физические резьбы Helivanta с распознаваемыми метаданными не найдены. Обнаружено штатных косметических резьб Inventor: " + reportableNativeThreads.Count.ToString(CultureInfo.InvariantCulture) + ".");

            if (report.ScanComplete && report.Errors == 0 && report.Warnings == 0)
                Add(report, ThreadIntegritySeverity.Info, "", "Проверка завершена: ошибок целостности, несоответствий табличным размерам и пересечений не обнаружено.");
            else if (!report.ScanComplete)
                Add(report, ThreadIntegritySeverity.Warning, "", "Проверка неполная: повреждённые или недоступные объекты перечислены отдельно; результаты остаются предварительными.");
            else
                Add(report, ThreadIntegritySeverity.Info, "", "Проверка завершена. См. предупреждения и ошибки по каждой резьбе выше.");
            return report;
        }

        private static bool IsHelivantaTaperSupportFeature(NativeThreadOverlapSnapshot native,
            IList<ThreadMetadataGroup> groups)
        {
            if (native == null || native.Feature == null || groups == null || groups.Count == 0)
                return false;

            // Do not hide regular visible Inventor cosmetic threads, even when they happen to
            // share a designation with a Helivanta group.
            try { if (native.Feature.DisplayInModel) return false; }
            catch { return false; }

            TaperedThreadInfo taperedInfo;
            try { taperedInfo = native.Feature.ThreadInfo as TaperedThreadInfo; }
            catch { return false; }
            if (taperedInfo == null) return false;

            string taggedThreadId;
            bool hasMetadataTag = ThreadMetadataStore.TryGetThreadId(native.Feature, out taggedThreadId);
            string nativeStandard = string.Empty;
            string nativeDesignation = string.Empty;
            try { nativeStandard = taperedInfo.ThreadTypeIdentifier ?? string.Empty; } catch { }
            try { nativeDesignation = taperedInfo.ThreadDesignation ?? string.Empty; } catch { }

            foreach (ThreadMetadataGroup group in groups)
            {
                ThreadMetadataRecord record = group == null ? null : group.Record;
                ThreadParametersSnapshot parameters = record == null ? null : record.Parameters;
                if (record == null || parameters == null ||
                    !string.Equals(record.ThreadId, taggedThreadId, StringComparison.Ordinal))
                    continue;
                return TaperedThreadSupportPolicy.IsMatchingHiddenSupportFeature(
                    displayInModel: false,
                    hasTaperedInfo: taperedInfo != null,
                    hasMetadataTag: hasMetadataTag,
                    taggedThreadId: taggedThreadId,
                    metadataThreadId: record.ThreadId,
                    metadataIsTapered: parameters.Tapered,
                    metadataStandard: parameters.TaperStandard,
                    nativeStandard: nativeStandard,
                    metadataDesignation: parameters.TaperDesignation,
                    metadataDisplayDesignation: parameters.TaperDisplayDesignation,
                    nativeDesignation: nativeDesignation);
            }
            return false;
        }

        private static bool MatchesCatalogue(ThreadParametersSnapshot parameters)
        {
            if (parameters == null || parameters.Standard < 0 || parameters.Standard > 5) return false;
            try
            {
                foreach (ThreadSize size in ThreadStandards.Sizes((ThreadStandard)parameters.Standard))
                {
                    if (Math.Abs(size.DiameterMm - parameters.NominalDiaMm) <= 0.001 &&
                        Math.Abs(size.PitchMm - parameters.PitchMm) <= 0.001)
                        return true;
                }
            }
            catch { }
            return false;
        }

        private static string ParameterSummary(ThreadParametersSnapshot p)
        {
            if (p == null) return HelivantaLocalization.Translate("Параметры недоступны.");
            string hand = HelivantaLocalization.Translate(p.RightHand ? "правая" : "левая");
            string threadType = HelivantaLocalization.Translate(p.External ? "наружная" : "внутренняя");
            string mm = HelivantaLocalization.Translate("мм");
            string length = p.FullLength ? HelivantaLocalization.Translate("на всю поверхность") : p.LengthMm.ToString("0.###", CultureInfo.InvariantCulture) + " " + mm;
            string lead = (p.PitchMm * p.Starts).ToString("0.###", CultureInfo.InvariantCulture);
            return "Ø " + p.NominalDiaMm.ToString("0.###", CultureInfo.InvariantCulture) + " " + mm + " · P " +
                p.PitchMm.ToString("0.###", CultureInfo.InvariantCulture) + " " + mm + " · " + HelivantaLocalization.Translate("ход") + " " + lead + " " + mm + " · " + HelivantaLocalization.Translate("заходов") + " " +
                p.Starts.ToString(CultureInfo.InvariantCulture) + " · " + threadType + " · " + hand + " · " + HelivantaLocalization.Translate("длина") + " " + length +
                " · " + HelivantaLocalization.Translate("отступ") + " " + p.OffsetMm.ToString("0.###", CultureInfo.InvariantCulture) + " " + mm + " · " + HelivantaLocalization.Translate("зазор") + " " +
                p.ClearanceMm.ToString("0.###", CultureInfo.InvariantCulture) + " " + mm;
        }

        private static bool SourceCylinderExists(PartDocument doc, ThreadMetadataRecord record, out string error)
        {
            error = null;
            ThreadTargetSnapshot target = record == null ? null : record.Target;
            if (doc == null || target == null || record.Parameters == null)
            {
                error = "Снимок исходного цилиндра отсутствует; проверить геометрию невозможно.";
                return false;
            }

            double expectedRadius;
            if (!TryCalculateExpectedSourceRadius(record, out expectedRadius, out error)) return false;

            try
            {
                PartComponentDefinition definition = doc.ComponentDefinition;
                foreach (SurfaceBody body in definition.SurfaceBodies)
                {
                    string bodyName;
                    try { bodyName = body.Name; } catch { bodyName = null; }
                    if (!string.Equals(bodyName, target.BodyName, StringComparison.OrdinalIgnoreCase)) continue;
                    foreach (Face face in body.Faces)
                    {
                        if (face.SurfaceType != SurfaceTypeEnum.kCylinderSurface) continue;
                        Cylinder cylinder;
                        try { cylinder = (Cylinder)face.Geometry; } catch { continue; }
                        if (CylinderMatchesSnapshot(cylinder, target, expectedRadius)) return true;
                    }
                }
            }
            catch (Exception ex)
            {
                error = "Не удалось проверить исходный цилиндр по текущей геометрии: " + ex.Message;
                return false;
            }

            error = "Исходный цилиндр не найден по имени тела, оси и расчётному радиусу для сохранённых параметров. Геометрия могла измениться после построения резьбы.";
            return false;
        }

        private static ThreadTargetSnapshot ExpectedSourceTarget(ThreadMetadataRecord record)
        {
            if (record == null || record.Target == null) return null;
            var target = new ThreadTargetSnapshot
            {
                Center = (double[])record.Target.Center.Clone(),
                Axis = (double[])record.Target.Axis.Clone(),
                RadiusCm = record.Target.RadiusCm,
                LengthCm = record.Target.LengthCm,
                IsExternal = record.Target.IsExternal,
                BodyName = record.Target.BodyName
            };
            double expectedRadius;
            string error;
            if (TryCalculateExpectedSourceRadius(record, out expectedRadius, out error))
                target.RadiusCm = expectedRadius;
            return target;
        }

        private static bool TryCalculateExpectedSourceRadius(ThreadMetadataRecord record, out double expectedRadius, out string error)
        {
            expectedRadius = 0.0;
            error = null;
            if (record == null || record.Target == null || record.Parameters == null)
            {
                error = "Снимок исходного цилиндра или параметры отсутствуют.";
                return false;
            }
            try
            {
                ThreadProfileSpec spec = ThreadStandards.Spec((ThreadStandard)record.Parameters.Standard);
                double pitchCm = record.Parameters.PitchMm / 10.0;
                expectedRadius = record.Parameters.External
                    ? record.Parameters.NominalDiaMm / 20.0
                    : record.Parameters.NominalDiaMm / 20.0 - ThreadStandards.MinorOffset(spec, pitchCm, 10.0);
                if (!Finite(expectedRadius) || expectedRadius <= 0.0)
                {
                    error = "Параметры не задают допустимый расчётный радиус исходного цилиндра.";
                    return false;
                }
                return true;
            }
            catch (Exception ex)
            {
                error = "Не удалось рассчитать ожидаемый радиус исходного цилиндра: " + ex.Message;
                return false;
            }
        }

        private static bool CylinderMatchesSnapshot(Cylinder cylinder, ThreadTargetSnapshot target, double expectedRadius)
        {
            if (cylinder == null || target == null || target.Center == null || target.Center.Length < 3 || target.Axis == null || target.Axis.Length < 3)
                return false;
            if (!Finite(cylinder.Radius) || cylinder.Radius <= 0.0 || Math.Abs(cylinder.Radius - expectedRadius) > 0.0005) return false;
            double[] axis = { cylinder.AxisVector.X, cylinder.AxisVector.Y, cylinder.AxisVector.Z };
            double[] basePoint = { cylinder.BasePoint.X, cylinder.BasePoint.Y, cylinder.BasePoint.Z };
            double dot = axis[0] * target.Axis[0] + axis[1] * target.Axis[1] + axis[2] * target.Axis[2];
            if (!Finite(dot) || Math.Abs(dot) < 0.9999) return false;
            double dx = target.Center[0] - basePoint[0];
            double dy = target.Center[1] - basePoint[1];
            double dz = target.Center[2] - basePoint[2];
            double axial = dx * axis[0] + dy * axis[1] + dz * axis[2];
            double rx = dx - axial * axis[0];
            double ry = dy - axial * axis[1];
            double rz = dz - axial * axis[2];
            double radial = Math.Sqrt(rx * rx + ry * ry + rz * rz);
            return Finite(radial) && radial <= Math.Max(0.01, target.RadiusCm * 0.0005);
        }

        private static bool TryGetThreadInterval(ThreadMetadataRecord record, double[] referenceAxis, out double start, out double end)
        {
            return ThreadIntegrityPolicy.TryGetInterval(record, referenceAxis, out start, out end);
        }

        private static bool Finite(double value) { return !double.IsNaN(value) && !double.IsInfinity(value); }

        private static void Add(ThreadIntegrityReport report, ThreadIntegritySeverity severity, string threadId,
            string message, ThreadMetadataRecord record = null, string standardLabel = null)
        {
            ThreadParametersSnapshot parameters = record == null ? null : record.Parameters;
            report.Findings.Add(new ThreadIntegrityFinding
            {
                Severity = severity,
                ThreadId = threadId ?? "",
                DisplayLabel = parameters == null ? (threadId ?? "") : parameters.SizeName,
                StandardLabel = standardLabel ?? (parameters == null ? "" : ThreadStandards.Title((ThreadStandard)parameters.Standard)),
                Designation = parameters == null ? "" : parameters.SizeName,
                ParameterSummary = ParameterSummary(parameters),
                Message = message ?? "",
                Recommendation = Recommend(severity, message)
            });
        }

        private static void AddNative(ThreadIntegrityReport report, ThreadIntegritySeverity severity,
            string threadId, NativeThreadOverlapSnapshot native, string message)
        {
            report.Findings.Add(new ThreadIntegrityFinding
            {
                Severity = severity,
                ThreadId = threadId ?? "",
                DisplayLabel = native == null ? "Штатная резьба Inventor" : native.Name,
                StandardLabel = native == null ? "" : native.StandardLabel,
                Designation = native == null ? "" : native.Designation,
                ParameterSummary = native == null ? "" : native.ParameterSummary,
                Message = message ?? "",
                Recommendation = Recommend(severity, message)
            });
        }

        private static string Recommend(ThreadIntegritySeverity severity, string message)
        {
            string m = message ?? string.Empty;
            if (m.IndexOf("пересека", StringComparison.OrdinalIgnoreCase) >= 0)
                return "Сравните осевые интервалы на одной цилиндрической поверхности; устраните конфликт до построения.";
            if (m.IndexOf("интервал", StringComparison.OrdinalIgnoreCase) >= 0 &&
                (m.IndexOf("нельзя", StringComparison.OrdinalIgnoreCase) >= 0 || m.IndexOf("не удалось", StringComparison.OrdinalIgnoreCase) >= 0))
                return "Проверьте исходную операцию и геометрию вручную: интервал не подтверждён.";
            if (m.IndexOf("таблиц", StringComparison.OrdinalIgnoreCase) >= 0 || m.IndexOf("стандарт", StringComparison.OrdinalIgnoreCase) >= 0 || m.IndexOf("типоразмер", StringComparison.OrdinalIgnoreCase) >= 0)
                return "Сверьте обозначение, номинальный диаметр и шаг с чертежом или таблицей выбранного стандарта.";
            if (m.IndexOf("исходн", StringComparison.OrdinalIgnoreCase) >= 0 || m.IndexOf("цилиндр", StringComparison.OrdinalIgnoreCase) >= 0 || m.IndexOf("поверхност", StringComparison.OrdinalIgnoreCase) >= 0)
                return "Убедитесь, что исходная цилиндрическая поверхность существует и относится к ожидаемому телу.";
            if (severity == ThreadIntegritySeverity.Error)
                return "Не продолжайте автоматическое построение, пока причина ошибки не выяснена.";
            if (severity == ThreadIntegritySeverity.Warning)
                return "Подтвердите параметры по модели и производственному чертежу.";
            return "Дополнительных действий по этому пункту не требуется.";
        }
    }
}
