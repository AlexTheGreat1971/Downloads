﻿using System;
using System.Collections.Generic;
using Inventor;

namespace ThreadPro
{
    /// <summary>
    /// Continuous selection of circular edges in the Inventor graphics window while the dialog stays open.
    /// Edges of one diameter can be added; a second click on an edge removes it. Selected edges are highlighted.
    /// </summary>
    public sealed class EdgeSelector : IDisposable
    {
        private readonly Inventor.Application _app;
        private InteractionEvents _ie;
        private SelectEvents _se;
        private HighlightSet _hs;
        private PartDocument _pdoc;
        private readonly List<ThreadTarget> _targets = new List<ThreadTarget>();
        private readonly List<Edge> _edges = new List<Edge>();

        /// <summary>The set of selected edges changed.</summary>
        public event Action Changed;
        /// <summary>Short message for the user (rejected edge, error).</summary>
        public event Action<string> Message;
        /// <summary>The interactive selection was ended by Inventor (Esc, another command).</summary>
        public event Action Terminated;

        public bool Active { get; private set; }
        public IList<ThreadTarget> Targets { get { return _targets; } }

        /// <summary>
        /// True only when the logical edge selection still belongs to the active part.
        /// The dialog uses this in addition to Changed notifications because Start() can
        /// discard stale targets when the user switches documents without raising Changed.
        /// </summary>
        public bool HasTargetsForActiveDocument
        {
            get
            {
                if (_targets.Count == 0 || _pdoc == null) return false;
                try
                {
                    PartDocument active = _app.ActiveDocument as PartDocument;
                    return active != null && string.Equals(
                        _pdoc.InternalName, active.InternalName, StringComparison.OrdinalIgnoreCase);
                }
                catch { return false; }
            }
        }

        public EdgeSelector(Inventor.Application app) { _app = app; }

        public bool Start()
        {
            if (Active) return true;
            PartDocument pd = _app.ActiveDocument as PartDocument;
            if (pd == null) return false;

            bool sameDocument = false;
            try
            {
                sameDocument = _pdoc != null &&
                    string.Equals(_pdoc.InternalName, pd.InternalName, StringComparison.OrdinalIgnoreCase);
            }
            catch { }
            if (!sameDocument)
            {
                // another document: the old selection is meaningless
                _targets.Clear(); _edges.Clear();
                DeleteHighlight();
                _pdoc = pd;
            }
            else
            {
                // Keep the current RCW for the same logical document. A second RCW must
                // not make a resumed selection look like a document switch.
                _pdoc = pd;
            }
            if (_hs == null) CreateHighlightSet(pd);

            _ie = _app.CommandManager.CreateInteractionEvents();
            _ie.InteractionDisabled = false;
            _se = _ie.SelectEvents;
            _se.AddSelectionFilter(SelectionFilterEnum.kPartEdgeCircularFilter);
            // This command owns a logical multi-edge list and a separate HighlightSet. Do not
            // let Inventor's transient SelectedEntities list behave as a second source of truth.
            // OnSelect resets that ledger after each click, so a second click on the same edge
            // raises OnSelect again and can toggle the logical target off in one click.
            _se.SingleSelectEnabled = false;
            _se.OnPreSelect += new SelectEventsSink_OnPreSelectEventHandler(OnPreSelect);
            _se.OnSelect += new SelectEventsSink_OnSelectEventHandler(OnSelectEvent);
            _ie.OnTerminate += new InteractionEventsSink_OnTerminateEventHandler(OnInteractionTerminate);
            _ie.StatusBarText = "Helivanta: выберите круговые рёбра начала резьбы";
            _ie.Start();
            Active = true;
            RefreshHighlight();
            return true;
        }

        public void Stop()
        {
            InteractionEvents ie = _ie;
            SelectEvents se = _se;

            // Unsubscribe BEFORE Stop(). Inventor can synchronously fire OnTerminate while
            // stopping an InteractionEvents object; the dialog may already be closing.
            try { if (se != null) se.OnPreSelect -= new SelectEventsSink_OnPreSelectEventHandler(OnPreSelect); } catch { }
            try { if (se != null) se.OnSelect -= new SelectEventsSink_OnSelectEventHandler(OnSelectEvent); } catch { }
            try { if (ie != null) ie.OnTerminate -= new InteractionEventsSink_OnTerminateEventHandler(OnInteractionTerminate); } catch { }

            _se = null;
            _ie = null;
            Active = false;

            try { if (ie != null) ie.Stop(); } catch { }

            // These RCWs are owned by the selector. Release them after event handlers are gone,
            // so Inventor shutdown is not left with a live COM event sink into the WinForms form.
            try { if (se != null) System.Runtime.InteropServices.Marshal.FinalReleaseComObject(se); } catch { }
            try { if (ie != null) System.Runtime.InteropServices.Marshal.FinalReleaseComObject(ie); } catch { }
        }

        /// <summary>
        /// Restarts edge picking after a modeless palette has taken focus, but only if the
        /// selected document is still the same part. Stop() preserves _targets/_edges.
        /// </summary>
        public bool RestartIfSameDocument()
        {
            try
            {
                PartDocument active = _app.ActiveDocument as PartDocument;
                if (active == null || _pdoc == null ||
                    !string.Equals(active.InternalName, _pdoc.InternalName, StringComparison.OrdinalIgnoreCase))
                    return false;
                Stop();
                return Start();
            }
            catch { return false; }
        }

        public void Clear()
        {
            Clear(true);
        }

        public void Clear(bool notify)
        {
            _targets.Clear();
            _edges.Clear();
            RefreshHighlight();
            if (notify)
            {
                Action h = Changed;
                if (h != null) h();
            }
        }

        /// <summary>
        /// Restores a previously saved selection after an Inventor transaction was undone.
        /// The original Edge COM references can become stale after Undo, therefore the method
        /// re-finds the circular edges in the current model using the saved geometric identity.
        /// No user parameters are touched here; the caller decides when to raise Changed.
        /// </summary>
        public bool RestoreTargets(IList<ThreadTarget> snapshots)
        {
            Clear(false);
            if (snapshots == null || snapshots.Count == 0) return false;

            PartDocument pd = null;
            try { pd = _app.ActiveDocument as PartDocument; } catch { }
            if (pd == null) return false;

            var restoredTargets = new List<ThreadTarget>();
            var restoredEdges = new List<Edge>();

            foreach (ThreadTarget snapshot in snapshots)
            {
                Edge edge = FindMatchingEdge(pd, snapshot);
                if (edge == null)
                {
                    Clear(false);
                    return false;
                }

                ThreadTarget target;
                try { target = ThreadBuilder.Analyze(_app, edge); }
                catch
                {
                    Clear(false);
                    return false;
                }

                if (restoredTargets.Count > 0 && !IsCompatibleWithSelection(target))
                {
                    Clear(false);
                    return false;
                }

                restoredTargets.Add(target);
                restoredEdges.Add(edge);
            }

            _targets.AddRange(restoredTargets);
            _edges.AddRange(restoredEdges);
            RefreshHighlight();
            return true;
        }

        private Edge FindMatchingEdge(PartDocument pd, ThreadTarget snapshot)
        {
            if (snapshot == null || snapshot.Center == null || snapshot.Center.Length < 3) return null;

            IEnumerable<SurfaceBody> bodies = null;
            try
            {
                var list = new List<SurfaceBody>();
                if (snapshot.Body != null)
                {
                    try { list.Add(snapshot.Body); } catch { }
                }

                // Always inspect the current document bodies as a fallback. The body COM
                // reference captured before Undo can itself become stale.
                PartComponentDefinition def = pd.ComponentDefinition;
                foreach (SurfaceBody body in def.SurfaceBodies)
                {
                    if (!string.IsNullOrEmpty(snapshot.BodyName) &&
                        !string.Equals(body.Name, snapshot.BodyName, StringComparison.OrdinalIgnoreCase))
                        continue;

                    bool duplicate = false;
                    foreach (SurfaceBody existing in list)
                    {
                        try
                        {
                            if (object.ReferenceEquals(existing, body)) { duplicate = true; break; }
                        }
                        catch { }
                    }
                    if (!duplicate) list.Add(body);
                }
                bodies = list;
            }
            catch
            {
                bodies = null;
            }

            if (bodies == null) return null;

            foreach (SurfaceBody body in bodies)
            {
                try
                {
                    foreach (Face face in body.Faces)
                    {
                        if (face.SurfaceType != SurfaceTypeEnum.kCylinderSurface) continue;

                        foreach (Edge edge in face.Edges)
                        {
                            double[] center = EdgeCenter(edge);
                            if (center == null) continue;
                            if (Distance3(center, snapshot.Center) > 0.001) continue;

                            double radius = EdgeRadius(edge);
                            if (radius <= 0 || Math.Abs(radius - snapshot.RadiusCm) > 0.001) continue;

                            ThreadTarget candidate;
                            try { candidate = ThreadBuilder.Analyze(_app, edge); }
                            catch { continue; }

                            if (candidate.IsExternal != snapshot.IsExternal) continue;
                            if (Math.Abs(candidate.RadiusCm - snapshot.RadiusCm) > 0.001) continue;
                            if (Math.Abs(candidate.LengthCm - snapshot.LengthCm) > 0.01) continue;

                            if (snapshot.U != null && snapshot.U.Length >= 3 && candidate.U != null && candidate.U.Length >= 3)
                            {
                                double dot = candidate.U[0] * snapshot.U[0] +
                                             candidate.U[1] * snapshot.U[1] +
                                             candidate.U[2] * snapshot.U[2];
                                if (dot < 0.999) continue;
                            }

                            return edge;
                        }
                    }
                }
                catch
                {
                    // One invalid/consumed body must not prevent trying the remaining bodies.
                }
            }

            return null;
        }

        private static double[] EdgeCenter(Edge edge)
        {
            try
            {
                switch (edge.GeometryType)
                {
                    case CurveTypeEnum.kCircleCurve:
                        {
                            Circle c = (Circle)edge.Geometry;
                            return new[] { c.Center.X, c.Center.Y, c.Center.Z };
                        }
                    case CurveTypeEnum.kCircularArcCurve:
                        {
                            Arc3d a = (Arc3d)edge.Geometry;
                            return new[] { a.Center.X, a.Center.Y, a.Center.Z };
                        }
                }
            }
            catch { }
            return null;
        }

        private static double EdgeRadius(Edge edge)
        {
            try
            {
                if (edge.GeometryType == CurveTypeEnum.kCircleCurve)
                    return ((Circle)edge.Geometry).Radius;
                if (edge.GeometryType == CurveTypeEnum.kCircularArcCurve)
                    return ((Arc3d)edge.Geometry).Radius;
            }
            catch { }
            return 0.0;
        }

        private static double Distance3(double[] a, double[] b)
        {
            double dx = a[0] - b[0];
            double dy = a[1] - b[1];
            double dz = a[2] - b[2];
            return Math.Sqrt(dx * dx + dy * dy + dz * dz);
        }

        public void Dispose()
        {
            Stop();
            _targets.Clear(); _edges.Clear();
            DeleteHighlight();
        }

        private void Say(string text)
        {
            Action<string> h = Message;
            if (h != null) h(text);
        }

        private bool IsCompatibleWithSelection(ThreadTarget t)
        {
            if (_targets.Count == 0 || t == null) return true;
            ThreadTarget first = _targets[0];
            if (Math.Abs(first.RadiusCm - t.RadiusCm) > 0.0005) return false;
            if (first.IsExternal != t.IsExternal) return false;
            return true;
        }

        // PreSelect is intentionally non-invasive: do not show warnings while the cursor merely
        // passes over an edge. Validation and user-facing warnings happen only from OnSelect, i.e.
        // after the user actually clicks the edge. This avoids distracting status messages during hover.
        private void OnPreSelect(
            ref object preSelectEntity,
            out bool doHighlight,
            ref ObjectCollection morePreSelectEntities,
            SelectionDeviceEnum selectionDevice,
            Point modelPosition,
            Point2d viewPosition,
            View view)
        {
            morePreSelectEntities = morePreSelectEntities ?? _app.TransientObjects.CreateObjectCollection();

            Edge e = preSelectEntity as Edge;
            doHighlight = e != null;
        }

        private void OnSelectEvent(ObjectsEnumerator just, SelectionDeviceEnum device, Point modelPosition, Point2d viewPosition, View view)
        {
            OnSelect(just);
        }

        private void OnInteractionTerminate()
        {
            // Inventor may terminate InteractionEvents when another owned WinForms window
            // takes focus. Detach this ended event sink and release our fields so a later
            // Start() cannot overwrite stale COM references. Keep _targets, _edges and the
            // custom HighlightSet: termination is not a request to clear the user's selection.
            InteractionEvents ie = _ie;
            SelectEvents se = _se;
            try { if (se != null) se.OnPreSelect -= new SelectEventsSink_OnPreSelectEventHandler(OnPreSelect); } catch { }
            try { if (se != null) se.OnSelect -= new SelectEventsSink_OnSelectEventHandler(OnSelectEvent); } catch { }
            try { if (ie != null) ie.OnTerminate -= new InteractionEventsSink_OnTerminateEventHandler(OnInteractionTerminate); } catch { }
            _se = null;
            _ie = null;
            Active = false;
            Action h = Terminated;
            if (h != null) h();
        }

        private void OnSelect(ObjectsEnumerator just)
        {
            bool changed = false;
            foreach (object o in just)
            {
                Edge e = o as Edge;
                if (e == null) continue;

                ThreadTarget t;
                try { t = ThreadBuilder.Analyze(_app, e); }
                catch (Exception ex) { Say(ex.Message); continue; }

                int idx = IndexOf(t);
                if (idx >= 0)
                {
                    _targets.RemoveAt(idx);
                    _edges.RemoveAt(idx);
                    changed = true;
                    continue;
                }
                if (_targets.Count > 0)
                {
                    ThreadTarget f = _targets[0];
                    if (Math.Abs(f.RadiusCm - t.RadiusCm) > 0.0005)
                    {
                        Say(string.Format("Ребро Ø {0:0.###} мм не добавлено: выбраны рёбра Ø {1:0.###} мм.",
                            t.RadiusCm * 20.0, f.RadiusCm * 20.0));
                        continue;
                    }
                    if (f.IsExternal != t.IsExternal)
                    {
                        Say("Ребро не добавлено: нельзя смешивать наружную и внутреннюю резьбу.");
                        continue;
                    }
                }
                _targets.Add(t);
                _edges.Add(e);
                changed = true;
            }
            // Reset Inventor's per-interaction selection record after consuming this click.
            // Without this, Inventor natively unselects the edge on the first repeated click
            // without firing our OnSelect toggle, leaving _targets (and the Preview button)
            // stale until a second click. The custom HighlightSet below remains the visible
            // representation of our own _edges list.
            try
            {
                SelectEvents selectEvents = _se;
                if (selectEvents != null) selectEvents.ResetSelections();
            }
            catch { }

            if (changed)
            {
                RefreshHighlight();
                try { _app.ActiveView.Update(); } catch { }
                Action h = Changed;
                if (h != null) h();
            }
        }

        // A cylindrical surface may legitimately have two independent thread operations,
        // one starting at each end (for example right-hand on one side and left-hand on
        // the other). Therefore the logical selection key is the PICKED CIRCULAR EDGE,
        // not the whole cylindrical face. The edge centre plus axis direction identifies
        // the selected end; the same edge can still be clicked again to toggle it off.
        private int IndexOf(ThreadTarget t)
        {
            for (int i = 0; i < _targets.Count; i++)
            {
                ThreadTarget a = _targets[i];
                if (Math.Abs(a.RadiusCm - t.RadiusCm) > 1e-4) continue;
                if (!string.IsNullOrEmpty(a.BodyName) && !string.IsNullOrEmpty(t.BodyName) &&
                    !string.Equals(a.BodyName, t.BodyName, StringComparison.OrdinalIgnoreCase)) continue;

                // The picked circular-edge centre is the most important identity here:
                // opposite ends of the same cylinder have different centres.
                if (a.Center == null || t.Center == null ||
                    Distance3(a.Center, t.Center) > 1e-3) continue;

                // Keep the local surface orientation in the key as an additional guard
                // against coincident geometry in multi-body/derived cases.
                if (a.U == null || t.U == null || a.U.Length < 3 || t.U.Length < 3) continue;
                double dot = a.U[0] * t.U[0] + a.U[1] * t.U[1] + a.U[2] * t.U[2];
                if (dot < 0.999) continue;

                return i;
            }
            return -1;
        }

        /// <summary>
        /// Reassert the user's visual edge selection after Inventor redraws the view or the
        /// preview temporarily changes source-body visibility. Logical targets are untouched.
        /// </summary>
        public void RefreshVisualSelection(bool recreateHighlightSet = false)
        {
            try
            {
                PartDocument active = _app.ActiveDocument as PartDocument;
                if (active == null || _pdoc == null || _edges.Count == 0) return;
                string activeName = active.InternalName;
                string selectedName = _pdoc.InternalName;
                if (!string.Equals(activeName, selectedName, StringComparison.OrdinalIgnoreCase)) return;

                // Some Inventor redraws keep a valid COM HighlightSet but discard its rendered
                // overlay. After preview teardown, recreate the set instead of trusting Clear()
                // and AddItem() on a stale visual cache. The target/edge lists are not changed.
                if (recreateHighlightSet)
                {
                    DeleteHighlight();
                    CreateHighlightSet(active);
                }
                RefreshHighlight();
                try { _app.ActiveView.Update(); } catch { }
            }
            catch { }
        }

        private void RefreshHighlight()
        {
            PartDocument pd = _pdoc;
            if (pd == null) return;

            // Always clear even when the logical selection is now empty; otherwise toggling
            // off the last edge could leave a stale orange highlight on the model.
            try
            {
                if (_hs == null)
                {
                    if (_edges.Count == 0) return;
                    CreateHighlightSet(pd);
                }
                if (_hs == null) return;
                _hs.Clear();
                foreach (Edge e in _edges)
                {
                    try { if (e != null) _hs.AddItem(e); } catch { }
                }
            }
            catch
            {
                DeleteHighlight();
                if (_edges.Count == 0) return;
                try
                {
                    CreateHighlightSet(pd);
                    if (_hs == null) return;
                    foreach (Edge e in _edges)
                    {
                        try { if (e != null) _hs.AddItem(e); } catch { }
                    }
                }
                catch { }
            }
        }

        private void CreateHighlightSet(PartDocument pd)
        {
            if (pd == null) return;
            try
            {
                _hs = pd.CreateHighlightSet();
                _hs.Color = _app.TransientObjects.CreateColor(255, 128, 0);
            }
            catch { _hs = null; }
        }

        private void DeleteHighlight()
        {
            if (_hs != null)
            {
                try { _hs.Clear(); _hs.Delete(); } catch { }
                _hs = null;
            }
        }
    }
}
