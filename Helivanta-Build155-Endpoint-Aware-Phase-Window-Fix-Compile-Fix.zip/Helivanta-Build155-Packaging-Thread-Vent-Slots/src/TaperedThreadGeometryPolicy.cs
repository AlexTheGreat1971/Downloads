﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Text.RegularExpressions;

namespace ThreadPro
{
    /// <summary>Conical host geometry mode. StrictStandard uses the chosen Inventor table dimensions;
    /// FreeGeometry preserves the selected host-cylinder diameter at the far end and derives the entry diameter from the 1:16 taper.</summary>
    public enum TaperGeometryModeKind
    {
        StrictStandard = 0,
        FreeGeometry = 1
    }

    /// <summary>
    /// Pure, testable rules for preparing a tapered host from the selected circular edge.
    /// Taper ratios are diametral ratios (delta-D / axial-length), as used by pipe-thread standards.
    /// </summary>
    internal static class TaperedThreadGeometryPolicy
    {
        internal static bool TryGetDiameterRatio(string standard, out double ratio)
        {
            ratio = 0.0;
            if (string.IsNullOrWhiteSpace(standard)) return false;
            string key = standard.Trim();
            if (string.Equals(key, "NPT", StringComparison.OrdinalIgnoreCase) ||
                string.Equals(key, "JIS Taper", StringComparison.OrdinalIgnoreCase))
            {
                ratio = 1.0 / 16.0;
                return true;
            }
            return false;
        }

        /// <summary>
        /// Computes how far the host cone must extend from the original picked edge.
        /// The thread offset is included in the cone length once; ThreadFeature will apply the offset.
        /// All dimensions returned/received by this method use millimetres except selectedLengthCm.
        /// </summary>
        internal static bool TryGetHostLengthCm(bool fullLength, double selectedLengthCm,
            double lengthMm, double offsetMm, out double hostLengthCm, out string error)
        {
            hostLengthCm = 0.0;
            error = null;
            if (!Finite(selectedLengthCm) || selectedLengthCm <= 0.0 ||
                !Finite(lengthMm) || !Finite(offsetMm) || offsetMm < 0.0)
            {
                error = "Длина исходной поверхности, длина резьбы или отступ имеют некорректные значения.";
                return false;
            }

            double offsetCm = offsetMm / 10.0;
            if (offsetCm >= selectedLengthCm - 1e-6)
            {
                error = "Отступ должен быть меньше длины выбранной цилиндрической поверхности.";
                return false;
            }

            double threadLengthCm = fullLength ? selectedLengthCm - offsetCm : lengthMm / 10.0;
            if (!Finite(threadLengthCm) || threadLengthCm <= 1e-6)
            {
                error = "Ограниченная длина конической резьбы должна быть больше нуля.";
                return false;
            }

            hostLengthCm = offsetCm + threadLengthCm;
            if (!Finite(hostLengthCm) || hostLengthCm <= 1e-6 || hostLengthCm > selectedLengthCm + 1e-6)
            {
                error = "Длина будущего конического участка вместе с отступом выходит за пределы выбранной поверхности.";
                hostLengthCm = 0.0;
                return false;
            }
            if (hostLengthCm > selectedLengthCm) hostLengthCm = selectedLengthCm;
            return true;
        }

        /// <summary>
        /// Converts standard-table diameters to the radius at the selected start edge.
        /// Exterior threads start at their small/free end and grow toward the nominal major diameter;
        /// interior threads start at the large mouth and shrink inward. The length includes the offset.
        /// Table values are mm for metric rows and inches for imperial rows.
        /// </summary>
        internal static bool TryGetStandardStartRadiusCm(bool external, bool metric,
            double outsidePipeDiameter, double nominalExternalDiameter, double basicMinorDiameter,
            double hostLengthCm, double offsetMm, double diameterRatio, out double startRadiusCm)
        {
            startRadiusCm = 0.0;
            if (!Finite(hostLengthCm) || hostLengthCm <= 0.0 ||
                !Finite(offsetMm) || offsetMm < 0.0 || offsetMm > hostLengthCm * 10.0 + 1e-6 ||
                !Finite(diameterRatio) || diameterRatio <= 0.0 || diameterRatio >= 1.0)
                return false;

            // For external tapered pipe threads the stock/major envelope follows OutsidePipeDiameter.
            // NominalExternalDiameter is a separate thread-table value and can be smaller than the
            // pipe OD (for example NPT). Prefer the physical pipe OD, falling back only if absent.
            // External male threads begin at the small/free end and grow toward the shoulder.
            // Internal female threads begin at the large mouth and narrow inward.
            double tableDiameter = external
                ? (Finite(outsidePipeDiameter) && outsidePipeDiameter > 0.0 ? outsidePipeDiameter : nominalExternalDiameter)
                : basicMinorDiameter;
            if (!Finite(tableDiameter) || tableDiameter <= 0.0) return false;

            double diameterMm = metric ? tableDiameter : tableDiameter * 25.4;
            if (external)
                diameterMm -= hostLengthCm * 10.0 * diameterRatio;
            else
                diameterMm += hostLengthCm * 10.0 * diameterRatio;
            startRadiusCm = diameterMm / 20.0;
            return Finite(startRadiusCm) && startRadiusCm > 1e-6;
        }

        /// <summary>
        /// Resolves the real model pitch and radial thread height from TaperedThreadInfo values.
        /// Pitch/height are mm for metric rows and inches for imperial rows. ThreadsPerInch is
        /// preferred for imperial entries because some Thread.xls rows leave Pitch unset.
        /// </summary>
        internal static bool TryResolvePitchAndDepthMm(bool metric, double pitchValue, string threadsPerInch,
            double threadHeightValue, out double pitchMm, out double depthMm, out string error)
        {
            pitchMm = 0.0;
            depthMm = 0.0;
            error = null;
            if (!Finite(threadHeightValue) || threadHeightValue <= 0.0)
            {
                error = "Таблица Inventor не вернула положительную высоту профиля ThreadHeight.";
                return false;
            }

            if (metric)
            {
                if (!Finite(pitchValue) || pitchValue <= 0.0)
                {
                    error = "Таблица Inventor не вернула положительный метрический шаг Pitch.";
                    return false;
                }
                pitchMm = pitchValue;
                depthMm = threadHeightValue;
            }
            else
            {
                double tpi = 0.0;
                Match match = Regex.Match(threadsPerInch ?? string.Empty, @"[-+]?\d+(?:[\.,]\d+)?", RegexOptions.CultureInvariant);
                if (match.Success)
                {
                    string number = match.Value.Replace(',', '.');
                    double.TryParse(number, NumberStyles.Float, CultureInfo.InvariantCulture, out tpi);
                }
                if (Finite(tpi) && tpi > 0.0)
                    pitchMm = 25.4 / tpi;
                else if (Finite(pitchValue) && pitchValue > 0.0)
                    pitchMm = pitchValue * 25.4;
                else
                {
                    error = "Таблица Inventor не вернула корректный ThreadsPerInch или Pitch для дюймовой конической резьбы.";
                    return false;
                }
                depthMm = threadHeightValue * 25.4;
            }

            if (!Finite(pitchMm) || pitchMm <= 0.0 || !Finite(depthMm) || depthMm <= 0.0 || depthMm >= pitchMm)
            {
                error = string.Format(CultureInfo.InvariantCulture,
                    "Непригодные размеры физического профиля из таблицы: P={0:0.###} мм, H={1:0.###} мм.", pitchMm, depthMm);
                pitchMm = depthMm = 0.0;
                return false;
            }
            return true;
        }

        /// <summary>
        /// Resolves Inventor CoilFeature taper sign from the intended axial cone direction.
        /// The selected edge is station zero and the sketch axis runs from that edge toward the shoulder/deeper bore.
        /// Male (external) geometry must increase in radius along that axis; female (internal) geometry must decrease.
        /// </summary>
        internal static bool TryGetCoilTaperAngleRadians(double diameterRatio, bool external, out double angleRadians)
        {
            angleRadians = 0.0;
            if (!Finite(diameterRatio) || diameterRatio <= 0.0 || diameterRatio >= 1.0) return false;
            double magnitude = Math.Atan(diameterRatio / 2.0);
            // Build84's live Inventor result showed the physical groove taper opposite to the
            // prepared cone. Reverse that observed sign convention for this sketch-axis setup:
            // external grows from the picked small end; internal shrinks from the wide mouth.
            angleRadians = external ? magnitude : -magnitude;
            return Finite(angleRadians) && Math.Abs(angleRadians) > 0.0;
        }

        internal static bool TryGetThreadAngleDegrees(string standard, out double angleDegrees)
        {
            angleDegrees = 0.0;
            if (string.Equals((standard ?? string.Empty).Trim(), "NPT", StringComparison.OrdinalIgnoreCase))
            {
                angleDegrees = 60.0;
                return true;
            }
            if (string.Equals((standard ?? string.Empty).Trim(), "JIS Taper", StringComparison.OrdinalIgnoreCase))
            {
                angleDegrees = 55.0;
                return true;
            }
            return false;
        }

        /// <summary>
        /// Produces a truncated trapezoidal cutter profile using the included flank angle of the
        /// selected standard. The two known families are NPT 60° and JIS Taper 55°. The cutter
        /// occupies 96.2% of pitch at the host surface, leaving approximately 3.8% pitch for the
        /// crest land; the table-provided depth determines the bottom width. This improves on the
        /// former 98%-pitch cutter, which left only 2% pitch for the crest. This remains a physical
        /// geometry prototype, not a full standards-tolerance or gaging implementation.
        /// </summary>
        internal static bool TryGetPhysicalGrooveDimensionsMm(double pitchMm, double depthMm,
            double threadAngleDegrees, out double topWidthMm, out double rootWidthMm, out string error)
        {
            topWidthMm = rootWidthMm = 0.0;
            error = null;
            if (!Finite(pitchMm) || pitchMm <= 0.0 || !Finite(depthMm) || depthMm <= 0.0 || depthMm >= pitchMm ||
                !Finite(threadAngleDegrees) || threadAngleDegrees < 45.0 || threadAngleDegrees > 75.0)
            {
                error = "Шаг, высота и угол профиля конической резьбы имеют недопустимые значения.";
                return false;
            }
            topWidthMm = pitchMm * 0.962;
            rootWidthMm = topWidthMm - 2.0 * depthMm * Math.Tan(threadAngleDegrees * Math.PI / 360.0);
            if (!Finite(rootWidthMm) || rootWidthMm < pitchMm * 0.025 || rootWidthMm >= topWidthMm)
            {
                error = string.Format(CultureInfo.InvariantCulture,
                    "Высота профиля таблицы не помещается в шаг: P={0:0.###} мм, H={1:0.###} мм, угол={2:0.###}°, ширина впадины={3:0.###} мм.", pitchMm, depthMm, threadAngleDegrees, rootWidthMm);
                topWidthMm = rootWidthMm = 0.0;
                return false;
            }
            return true;
        }

        // Backward-compatible helper retained for existing 60-degree profile tests/callers.
        internal static bool TryGetPhysicalGrooveDimensionsMm(double pitchMm, double depthMm,
            out double topWidthMm, out double rootWidthMm, out string error)
        {
            return TryGetPhysicalGrooveDimensionsMm(pitchMm, depthMm, 60.0,
                out topWidthMm, out rootWidthMm, out error);
        }

        /// <summary>
        /// Selects the closest available table designation for the selected stock diameter.
        /// This is only a suggestion: the UI must still show the computed geometry-change
        /// confirmation before mutating the model.
        /// </summary>
        internal static string FindClosestDesignation(double sourceDiameterMm, IList<Tuple<string, double>> candidates)
        {
            if (!Finite(sourceDiameterMm) || sourceDiameterMm <= 0.0 || candidates == null || candidates.Count == 0)
                return null;
            string best = null;
            double bestDelta = double.PositiveInfinity;
            foreach (Tuple<string, double> candidate in candidates)
            {
                if (candidate == null || string.IsNullOrWhiteSpace(candidate.Item1) ||
                    !Finite(candidate.Item2) || candidate.Item2 <= 0.0) continue;
                double delta = Math.Abs(sourceDiameterMm - candidate.Item2);
                if (delta < bestDelta)
                {
                    bestDelta = delta;
                    best = candidate.Item1;
                }
            }
            return best;
        }

        /// <summary>Rejects clearly unrelated stock diameters before any cone/coil modifies the model.</summary>
        internal static bool IsStartingDiameterCompatible(double sourceDiameterMm, double standardDiameterMm,
            out double toleranceMm)
        {
            toleranceMm = 0.0;
            if (!Finite(sourceDiameterMm) || sourceDiameterMm <= 0.0 ||
                !Finite(standardDiameterMm) || standardDiameterMm <= 0.0) return false;
            toleranceMm = Math.Max(0.5, standardDiameterMm * 0.05);
            return Math.Abs(sourceDiameterMm - standardDiameterMm) <= toleranceMm;
        }

        /// <summary>
        /// Free-geometry mode: preserve the radius at the far/end station and derive the selected-edge
        /// radius using the standard diametral taper. The selected edge is the small end for external
        /// threads and the wide mouth for internal threads. Length/radii are Inventor centimetres.
        /// </summary>
        internal static bool TryGetStartRadiusFromEndCm(bool external, double endRadiusCm,
            double hostLengthCm, double diameterRatio, out double startRadiusCm)
        {
            startRadiusCm = 0.0;
            if (!Finite(endRadiusCm) || endRadiusCm <= 1e-6 ||
                !Finite(hostLengthCm) || hostLengthCm <= 0.0 ||
                !Finite(diameterRatio) || diameterRatio <= 0.0 || diameterRatio >= 1.0)
                return false;

            double deltaRadiusCm = hostLengthCm * diameterRatio / 2.0;
            // External cone expands along the axis; internal cone contracts along the axis.
            startRadiusCm = external ? endRadiusCm - deltaRadiusCm : endRadiusCm + deltaRadiusCm;
            return Finite(startRadiusCm) && startRadiusCm > 1e-6;
        }

        /// <summary>Legacy large-end-first calculation retained for existing callers and tests.</summary>
        internal static bool TryGetEndRadiusCm(double startRadiusCm, double hostLengthCm,
            double diameterRatio, out double endRadiusCm)
        {
            return TryGetEndRadiusCm(startRadiusCm, hostLengthCm, diameterRatio,
                false, out endRadiusCm);
        }

        /// <summary>
        /// Computes the end radius in either cone direction. Exterior pipe threads begin at the
        /// small/free end and increase in diameter toward the shoulder; interior threads begin at
        /// the large mouth and decrease inward. The ratio is diametral (delta-D / length).
        /// </summary>
        internal static bool TryGetEndRadiusCm(double startRadiusCm, double hostLengthCm,
            double diameterRatio, bool diameterIncreasesAlongAxis, out double endRadiusCm)
        {
            endRadiusCm = 0.0;
            if (!Finite(startRadiusCm) || startRadiusCm <= 0.0 ||
                !Finite(hostLengthCm) || hostLengthCm <= 0.0 ||
                !Finite(diameterRatio) || diameterRatio <= 0.0 || diameterRatio >= 1.0)
                return false;

            double deltaRadius = hostLengthCm * diameterRatio / 2.0;
            endRadiusCm = diameterIncreasesAlongAxis ? startRadiusCm + deltaRadius : startRadiusCm - deltaRadius;
            return Finite(endRadiusCm) && endRadiusCm > 1e-6 &&
                (diameterIncreasesAlongAxis ? endRadiusCm > startRadiusCm : endRadiusCm < startRadiusCm);
        }

        /// <summary>
        /// Chooses one Boolean operation when the existing cylinder is consistently outside or
        /// inside the desired taper over the whole interval, regardless of taper direction. If the
        /// linear profiles cross, a single Boolean would modify only one side correctly, so fail closed.
        /// </summary>
        internal static bool TryChooseJoinOperation(bool external, double stockRadiusCm,
            double desiredStartRadiusCm, double desiredEndRadiusCm, out bool join, out string error)
        {
            join = false;
            error = null;
            if (!Finite(stockRadiusCm) || stockRadiusCm <= 0.0 ||
                !Finite(desiredStartRadiusCm) || desiredStartRadiusCm <= 0.0 ||
                !Finite(desiredEndRadiusCm) || desiredEndRadiusCm <= 0.0 ||
                Math.Abs(desiredEndRadiusCm - desiredStartRadiusCm) <= 1e-9)
            {
                error = "Исходный радиус или расчётные радиусы конической поверхности недопустимы.";
                return false;
            }

            const double toleranceCm = 1e-5; // 0.0001 mm in Inventor's centimetre database units.
            double minTargetRadius = Math.Min(desiredStartRadiusCm, desiredEndRadiusCm);
            double maxTargetRadius = Math.Max(desiredStartRadiusCm, desiredEndRadiusCm);
            if (stockRadiusCm >= maxTargetRadius - toleranceCm)
            {
                join = !external; // outside stock: cut; inside bore: fill material to make the bore smaller.
                return true;
            }
            if (stockRadiusCm <= minTargetRadius + toleranceCm)
            {
                join = external; // undersized shaft: add material; undersized bore: cut material to enlarge it.
                return true;
            }

            error = "Исходная цилиндрическая поверхность пересекает расчётный профиль конуса по длине: одной булевой операции недостаточно. Подберите заготовку, которая целиком снаружи или внутри конуса.";
            return false;
        }


        /// <summary>
        /// Finds an interior station where a constant-radius stock/bore crosses the linear target cone.
        /// When true, geometry must be prepared as two operations: one Cut and one Join. Distances are cm.
        /// </summary>
        internal static bool TryGetStockCrossingStationCm(double stockRadiusCm,
            double targetStartRadiusCm, double targetEndRadiusCm, double lengthCm,
            out bool crosses, out double crossingStationCm, out string error)
        {
            crosses = false;
            crossingStationCm = 0.0;
            error = null;
            if (!Finite(stockRadiusCm) || stockRadiusCm <= 0.0 ||
                !Finite(targetStartRadiusCm) || targetStartRadiusCm <= 0.0 ||
                !Finite(targetEndRadiusCm) || targetEndRadiusCm <= 0.0 ||
                !Finite(lengthCm) || lengthCm <= 0.0 ||
                Math.Abs(targetEndRadiusCm - targetStartRadiusCm) <= 1e-10)
            {
                error = "Радиусы заготовки и расчётного конуса должны быть конечными, положительными и образовывать конус ненулевого уклона.";
                return false;
            }

            double startDelta = targetStartRadiusCm - stockRadiusCm;
            double endDelta = targetEndRadiusCm - stockRadiusCm;
            const double radiusToleranceCm = 1e-7; // 0.001 micrometre in Inventor's centimetre units.
            if (Math.Abs(startDelta) <= radiusToleranceCm || Math.Abs(endDelta) <= radiusToleranceCm ||
                Math.Sign(startDelta) == Math.Sign(endDelta))
                return true;

            double station = -startDelta * lengthCm / (targetEndRadiusCm - targetStartRadiusCm);
            if (!Finite(station) || station <= 1e-6 || station >= lengthCm - 1e-6)
            {
                error = "Точка пересечения заготовки и конуса не находится строго внутри подготовительного участка.";
                return false;
            }
            crosses = true;
            crossingStationCm = station;
            return true;
        }

        /// <summary>
        /// Plans the full-depth helical core and its start/end fade zones. Coordinates are cm,
        /// while pitch is also passed in cm. This is a mathematical policy only; it does not
        /// establish that Inventor's Loft B-rep was accepted or cut the intended body.
        /// </summary>
        internal static bool TryGetRunoutStationsCm(double physicalStartCm, double physicalEndCm,
            double pitchCm, double runoutSteps, bool smoothStart, bool smoothEnd,
            out double coreStartCm, out double coreEndCm, out double runLengthCm, out string error)
        {
            coreStartCm = coreEndCm = runLengthCm = 0.0;
            error = null;
            if (!Finite(physicalStartCm) || !Finite(physicalEndCm) ||
                !Finite(pitchCm) || pitchCm <= 0.0 || !Finite(runoutSteps) || runoutSteps < 0.0 ||
                physicalEndCm <= physicalStartCm)
            {
                error = "Некорректные границы участка или шаг при расчёте конического сбега.";
                return false;
            }

            double intervalCm = physicalEndCm - physicalStartCm;
            if (intervalCm <= pitchCm * 0.5)
            {
                error = "После учёта плеча не осталось достаточной длины для физической конической резьбы.";
                return false;
            }

            bool requested = smoothStart || smoothEnd;
            if (requested && runoutSteps <= 0.0)
            {
                error = "Количество шагов конического сбега должно быть больше нуля.";
                return false;
            }

            runLengthCm = requested ? Math.Min(runoutSteps * pitchCm, 0.45 * intervalCm) : 0.0;
            if (requested && (!Finite(runLengthCm) || runLengthCm <= 1e-6))
            {
                error = "Не удалось рассчитать положительную длину конического сбега.";
                return false;
            }

            coreStartCm = physicalStartCm + (smoothStart ? runLengthCm : 0.0);
            coreEndCm = physicalEndCm - (smoothEnd ? runLengthCm : 0.0);
            if (!Finite(coreStartCm) || !Finite(coreEndCm) || coreEndCm - coreStartCm <= pitchCm * 0.5)
            {
                error = "Слишком короткая длина для конического сбега: между началами и концами сбега должна оставаться полная винтовая часть длиной более половины шага.";
                coreStartCm = coreEndCm = runLengthCm = 0.0;
                return false;
            }
            return true;
        }

        /// <summary>
        /// Estimates run-out Loft section density from a chord-sagitta target. The returned count
        /// is intentionally bounded to keep the Inventor Loft solver below the previously rejected
        /// high-complexity conical case. This is sampling policy only, not B-rep validation.
        /// </summary>
        internal static bool TryGetRunoutSectionsPerTurn(double localRadiusCm, double overhangCm,
            out int sectionsPerTurn, out string error)
        {
            sectionsPerTurn = 0;
            error = null;
            if (!Finite(localRadiusCm) || localRadiusCm <= 0.0 || !Finite(overhangCm) || overhangCm <= 0.0)
            {
                error = "Некорректный локальный радиус или вынос профиля при расчёте плотности сечений сбега.";
                return false;
            }

            double chordRadiusCm = Math.Max(1e-4, localRadiusCm + overhangCm);
            double targetSagittaCm = overhangCm * 0.90;
            double cosHalfSection = 1.0 - targetSagittaCm / chordRadiusCm;
            cosHalfSection = Math.Max(-1.0, Math.Min(1.0, cosHalfSection));
            double maxSectionAngle = 2.0 * Math.Acos(cosHalfSection);
            double recommendedValue = maxSectionAngle > 1e-6
                ? Math.Ceiling(2.0 * Math.PI / maxSectionAngle)
                : 18.0;
            // Clamp in floating-point before converting to Int32, so tiny positive overhangs
            // cannot overflow the cast even when this policy is called independently in tests.
            int recommended = recommendedValue >= 18.0 ? 18 : Math.Max(1, (int)recommendedValue);
            sectionsPerTurn = Math.Max(14, Math.Min(18, recommended));
            return true;
        }

        /// <summary>
        /// Selects a bounded number of Coil segments when Inventor rejects a conical run-out Loft.
        /// This is a conservative fallback policy, not proof of visual smoothness.
        /// Length and pitch are in Inventor centimetres.
        /// </summary>
        internal static bool TryGetFallbackRunoutSegmentCount(double runoutLengthCm, double pitchCm,
            out int segmentCount, out string error)
        {
            segmentCount = 0;
            error = null;
            if (!Finite(runoutLengthCm) || runoutLengthCm <= 0.0 || !Finite(pitchCm) || pitchCm <= 0.0)
            {
                error = "Некорректная длина сбега или шаг для резервного сегментного Coil.";
                return false;
            }

            double turns = runoutLengthCm / pitchCm;
            if (!Finite(turns) || turns <= 0.0)
            {
                error = "Невозможно вычислить число оборотов резервного сбега.";
                return false;
            }
            double recommended = turns * 12.0;
            if (!Finite(recommended) || recommended <= 0.0)
            {
                error = "Расчёт количества сегментов резервного сбега вышел за допустимый диапазон.";
                return false;
            }
            segmentCount = recommended >= 32.0 ? 32 : Math.Max(10, (int)Math.Ceiling(recommended));
            return true;
        }

        /// <summary>
        /// Validates the requested start/end chamfer before any model mutation. Units are cm for
        /// stations/radii and mm for the chamfer size. This is a conservative fit policy, not B-rep proof.
        /// </summary>
        internal static bool TryValidateChamfer(int chamferMode, double chamferMm,
            double startStationCm, double endStationCm, double startRadiusCm, double endRadiusCm,
            bool external, bool startIsShoulder, bool endIsShoulder, out string error)
        {
            error = null;
            if (chamferMode == 0) return true;
            if (chamferMode < 1 || chamferMode > 3)
            {
                error = "Построение запрещено: неизвестное положение фаски конической резьбы.";
                return false;
            }
            if (!Finite(chamferMm) || chamferMm <= 0.0 || !Finite(startStationCm) ||
                !Finite(endStationCm) || endStationCm <= startStationCm ||
                !Finite(startRadiusCm) || startRadiusCm <= 0.0 || !Finite(endRadiusCm) || endRadiusCm <= 0.0)
            {
                error = "Построение запрещено: размеры фаски или участок конической резьбы некорректны.";
                return false;
            }
            double chamferCm = chamferMm / 10.0;
            double spanCm = endStationCm - startStationCm;
            if (!Finite(chamferCm) || chamferCm <= 0.0 || chamferCm >= spanCm ||
                (chamferMode == 3 && 2.0 * chamferCm >= spanCm))
            {
                error = "Построение запрещено: фаска не помещается на выбранной длине конической резьбы.";
                return false;
            }
            if (external && chamferCm >= Math.Min(startRadiusCm, endRadiusCm))
            {
                error = "Построение запрещено: радиальная глубина фаски достигает радиуса конуса.";
                return false;
            }
            bool includesStart = chamferMode == 1 || chamferMode == 3;
            bool includesEnd = chamferMode == 2 || chamferMode == 3;
            if (includesStart && startIsShoulder)
            {
                error = "Построение запрещено: фаска у начала не допускается на выбранном упорном/вогнутом ребре.";
                return false;
            }
            if (includesEnd && endIsShoulder)
            {
                error = "Построение запрещено: фаска у конца не допускается рядом с плечом.";
                return false;
            }
            return true;
        }

        /// <summary>Determines whether the volume between stock radius and target radius is additive.</summary>
        internal static bool RequiresJoinForRadialChange(bool external, double stockRadiusCm, double targetRadiusCm)
        {
            // External shaft: a larger target radius adds material. Internal bore: a smaller target
            // radius fills material and narrows the hole.
            return external ? targetRadiusCm > stockRadiusCm : targetRadiusCm < stockRadiusCm;
        }

        private static bool Finite(double value) => !double.IsNaN(value) && !double.IsInfinity(value);
    }
}
