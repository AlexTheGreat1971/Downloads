﻿using System;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Windows.Forms;

namespace ThreadPro
{
    /// <summary>
    /// Compact, DPI-aware slider bound to an existing NumericUpDown. The numeric control
    /// remains the authoritative value/model; this control only provides an alternate editor.
    /// </summary>
    internal sealed class GlowSlider : Control
    {
        private NumericUpDown _numeric;
        private decimal _minimum;
        private decimal _maximum = 100m;
        private decimal _step = 1m;
        private bool _dragging;
        private bool _hovered;
        private bool _syncing;

        internal GlowSlider()
        {
            SetStyle(ControlStyles.UserPaint | ControlStyles.AllPaintingInWmPaint |
                     ControlStyles.OptimizedDoubleBuffer | ControlStyles.ResizeRedraw |
                     ControlStyles.Selectable, true);
            BackColor = HelivantaUiTheme.Panel;
            TabStop = true;
            AccessibleRole = AccessibleRole.Slider;
            Height = 28;
        }

        internal void SetRange(decimal minimum, decimal maximum, decimal step)
        {
            if (maximum < minimum) maximum = minimum;
            _minimum = minimum;
            _maximum = maximum;
            _step = step > 0m ? step : 1m;
            Invalidate();
        }

        internal void Bind(NumericUpDown numeric)
        {
            if (ReferenceEquals(_numeric, numeric))
            {
                RefreshBoundState();
                Invalidate();
                return;
            }

            if (_numeric != null && !_numeric.IsDisposed)
            {
                _numeric.ValueChanged -= BoundNumericValueChanged;
                _numeric.EnabledChanged -= BoundNumericEnabledChanged;
                _numeric.Disposed -= BoundNumericDisposed;
            }

            _numeric = numeric;
            if (_numeric != null)
            {
                _numeric.ValueChanged += BoundNumericValueChanged;
                _numeric.EnabledChanged += BoundNumericEnabledChanged;
                _numeric.Disposed += BoundNumericDisposed;
                AccessibleName = string.IsNullOrWhiteSpace(_numeric.AccessibleName)
                    ? "Ползунок параметра" : "Ползунок: " + _numeric.AccessibleName;
            }
            RefreshBoundState();
            Invalidate();
        }

        internal void RefreshBoundState()
        {
            bool canEdit = _numeric != null && !_numeric.IsDisposed && _numeric.Enabled && !_numeric.ReadOnly;
            if (Enabled != canEdit) Enabled = canEdit;
            Invalidate();
        }

        private void BoundNumericValueChanged(object sender, EventArgs e)
        {
            if (!_syncing) Invalidate();
        }

        private void BoundNumericEnabledChanged(object sender, EventArgs e)
        {
            RefreshBoundState();
        }

        private void BoundNumericDisposed(object sender, EventArgs e)
        {
            if (ReferenceEquals(_numeric, sender)) _numeric = null;
            Enabled = false;
            Invalidate();
        }

        public override Size GetPreferredSize(Size proposedSize)
        {
            float scale = Math.Max(1f, DeviceDpi / 96f);
            int width = proposedSize.Width > 0 ? proposedSize.Width : (int)Math.Round(150 * scale);
            return new Size(width, Math.Max((int)Math.Round(27 * scale), (int)Math.Round(Height * scale)));
        }

        protected override void OnMouseEnter(EventArgs e)
        {
            _hovered = true;
            Invalidate();
            base.OnMouseEnter(e);
        }

        protected override void OnMouseLeave(EventArgs e)
        {
            _hovered = false;
            if (!_dragging) Invalidate();
            base.OnMouseLeave(e);
        }

        protected override void OnMouseDown(MouseEventArgs e)
        {
            base.OnMouseDown(e);
            if (!Enabled || e.Button != MouseButtons.Left) return;
            Focus();
            _dragging = true;
            Capture = true;
            SetValueFromPosition(e.X);
        }

        protected override void OnMouseMove(MouseEventArgs e)
        {
            base.OnMouseMove(e);
            if (_dragging && Enabled) SetValueFromPosition(e.X);
        }

        protected override void OnMouseUp(MouseEventArgs e)
        {
            base.OnMouseUp(e);
            if (e.Button == MouseButtons.Left && _dragging)
            {
                SetValueFromPosition(e.X);
                _dragging = false;
                Capture = false;
                Invalidate();
            }
        }

        protected override void OnMouseCaptureChanged(EventArgs e)
        {
            if (!Capture) _dragging = false;
            base.OnMouseCaptureChanged(e);
        }

        protected override void OnKeyDown(KeyEventArgs e)
        {
            base.OnKeyDown(e);
            if (!Enabled || _numeric == null || _numeric.IsDisposed || _numeric.ReadOnly) return;
            decimal current = _numeric.Value;
            decimal delta = _step;
            if (e.Shift) delta *= 5m;

            switch (e.KeyCode)
            {
                case Keys.Left:
                case Keys.Down:
                    SetBoundValue(current - delta);
                    break;
                case Keys.Right:
                case Keys.Up:
                    SetBoundValue(current + delta);
                    break;
                case Keys.PageDown:
                    SetBoundValue(current - delta * 10m);
                    break;
                case Keys.PageUp:
                    SetBoundValue(current + delta * 10m);
                    break;
                case Keys.Home:
                    SetBoundValue(_minimum);
                    break;
                case Keys.End:
                    SetBoundValue(_maximum);
                    break;
                default:
                    return;
            }
            e.Handled = true;
            e.SuppressKeyPress = true;
        }

        protected override void OnGotFocus(EventArgs e)
        {
            Invalidate();
            base.OnGotFocus(e);
        }

        protected override void OnLostFocus(EventArgs e)
        {
            Invalidate();
            base.OnLostFocus(e);
        }

        protected override void OnEnabledChanged(EventArgs e)
        {
            if (!Enabled)
            {
                _hovered = false;
                _dragging = false;
                if (Capture) Capture = false;
            }
            base.OnEnabledChanged(e);
            Invalidate();
        }

        protected override void OnPaintBackground(PaintEventArgs e)
        {
            Color background = Parent != null ? Parent.BackColor : BackColor;
            using (var brush = new SolidBrush(background)) e.Graphics.FillRectangle(brush, ClientRectangle);
        }

        protected override void OnPaint(PaintEventArgs e)
        {
            Graphics g = e.Graphics;
            g.SmoothingMode = SmoothingMode.AntiAlias;
            g.PixelOffsetMode = PixelOffsetMode.HighQuality;
            g.Clear(Parent != null ? Parent.BackColor : BackColor);

            float scale = Math.Max(1f, DeviceDpi / 96f);
            int thumbDiameter = Math.Max(12, (int)Math.Round(15 * scale));
            // Leave room for the complete hover/focus glow, not merely the thumb circle.
            // The previous half-thumb inset clipped the glow at minimum/maximum positions.
            int inset = thumbDiameter + (int)Math.Round(4 * scale);
            int left = inset;
            int right = Math.Max(left + 1, Width - inset - 1);
            int centerY = Math.Max(thumbDiameter / 2, Height / 2);
            float ratio = GetValueRatio();
            int thumbX = left + (int)Math.Round((right - left) * ratio);
            int trackThickness = Math.Max(3, (int)Math.Round(4 * scale));
            bool highContrast = SystemInformation.HighContrast;
            Color inactive = highContrast ? SystemColors.ControlDark : HelivantaUiTheme.Field;
            Color accent = highContrast ? SystemColors.Highlight :
                (!Enabled ? HelivantaUiTheme.Border : (_hovered || _dragging || Focused ? HelivantaUiTheme.AccentHover : HelivantaUiTheme.Accent));
            Color border = highContrast ? SystemColors.WindowText :
                (!Enabled ? HelivantaUiTheme.Border : (_hovered || Focused ? HelivantaUiTheme.AccentHover : HelivantaUiTheme.ControlBorder));

            using (var track = new Pen(inactive, trackThickness))
            using (var active = new Pen(Enabled ? accent : SystemColors.ControlDark, trackThickness))
            {
                track.StartCap = track.EndCap = LineCap.Round;
                active.StartCap = active.EndCap = LineCap.Round;
                g.DrawLine(track, left, centerY, right, centerY);
                g.DrawLine(active, left, centerY, thumbX, centerY);
            }

            if (Enabled && !highContrast && (_hovered || _dragging || Focused))
            {
                using (var glow = new SolidBrush(Color.FromArgb(_dragging ? 48 : 28, accent)))
                    g.FillEllipse(glow, thumbX - thumbDiameter, centerY - thumbDiameter,
                        thumbDiameter * 2, thumbDiameter * 2);
            }

            Rectangle thumb = new Rectangle(thumbX - thumbDiameter / 2,
                centerY - thumbDiameter / 2, thumbDiameter, thumbDiameter);
            using (var fill = new SolidBrush(!Enabled ? SystemColors.Control :
                highContrast ? SystemColors.Control : HelivantaUiTheme.Field))
            using (var outline = new Pen(border, Math.Max(1f, scale)))
            using (var ring = new Pen(Enabled ? accent : SystemColors.ControlDark, Math.Max(1.5f, 2f * scale)))
            {
                g.FillEllipse(fill, thumb);
                g.DrawEllipse(outline, thumb);
                g.DrawEllipse(ring, Rectangle.Inflate(thumb, -1, -1));
            }

            if (Focused && ShowFocusCues && Enabled)
            {
                Rectangle focus = Rectangle.Inflate(ClientRectangle, -1, -1);
                ControlPaint.DrawFocusRectangle(g, focus,
                    highContrast ? SystemColors.HighlightText : HelivantaUiTheme.Text,
                    Parent != null ? Parent.BackColor : BackColor);
            }
        }

        private float GetValueRatio()
        {
            decimal span = _maximum - _minimum;
            if (span <= 0m || _numeric == null || _numeric.IsDisposed) return 0f;
            decimal value = _numeric.Value;
            if (value < _minimum) value = _minimum;
            if (value > _maximum) value = _maximum;
            return (float)((value - _minimum) / span);
        }

        private void SetValueFromPosition(int x)
        {
            float scale = Math.Max(1f, DeviceDpi / 96f);
            int thumbDiameter = Math.Max(12, (int)Math.Round(15 * scale));
            // Keep mouse-to-value mapping identical to OnPaint so endpoints are not clipped.
            int left = thumbDiameter + (int)Math.Round(4 * scale);
            int right = Math.Max(left + 1, Width - left - 1);
            decimal ratio = Math.Max(0m, Math.Min(1m, (decimal)(x - left) / (right - left)));
            decimal steps = (_maximum - _minimum) / _step;
            if (steps > 100000m) steps = 100000m;
            decimal index = Math.Round(ratio * steps, 0, MidpointRounding.AwayFromZero);
            SetBoundValue(_minimum + index * _step);
        }

        private void SetBoundValue(decimal value)
        {
            if (_numeric == null || _numeric.IsDisposed || _numeric.ReadOnly || !_numeric.Enabled) return;
            decimal effectiveMinimum = Math.Max(_numeric.Minimum, _minimum);
            decimal effectiveMaximum = Math.Min(_numeric.Maximum, _maximum);
            if (effectiveMaximum < effectiveMinimum) return;
            if (value < effectiveMinimum) value = effectiveMinimum;
            if (value > effectiveMaximum) value = effectiveMaximum;
            value = Math.Round(value, _numeric.DecimalPlaces, MidpointRounding.AwayFromZero);

            _syncing = true;
            try
            {
                if (_numeric.Value != value) _numeric.Value = value;
            }
            finally
            {
                _syncing = false;
                Invalidate();
            }
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing && _numeric != null && !_numeric.IsDisposed)
            {
                _numeric.ValueChanged -= BoundNumericValueChanged;
                _numeric.EnabledChanged -= BoundNumericEnabledChanged;
                _numeric.Disposed -= BoundNumericDisposed;
            }
            _numeric = null;
            base.Dispose(disposing);
        }
    }
}
