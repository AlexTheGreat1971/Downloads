﻿using System;

namespace ThreadPro
{
    /// <summary>
    /// Guards the standard selector against transient native ComboBox states.
    /// Committed selection is authoritative; popup-close resolution restores the visible field.
    /// </summary>
    internal static class ThreadStandardSelectionPolicy
    {
        internal static bool IsValidIndex(int selectedIndex, int itemCount)
        {
            return itemCount > 0 && selectedIndex >= 0 && selectedIndex < itemCount;
        }

        /// <summary>
        /// The closed ComboBox face can briefly expose stale/empty native Text even after the
        /// committed selection is already authoritative. When the popup is closed, render the
        /// committed label instead of trusting that transient field text. While open, retain the
        /// native text so the active selection gesture is not visually overridden.
        /// </summary>
        internal static string ResolveFieldDisplayText(
            string committedText, string nativeText, bool popupOpen)
        {
            if (!popupOpen && !string.IsNullOrWhiteSpace(committedText)) return committedText;
            return nativeText ?? string.Empty;
        }

        internal static bool ShouldApplyChange(bool selectionCommitted, bool loading, int selectedIndex, int itemCount)
        {
            return selectionCommitted && !loading && IsValidIndex(selectedIndex, itemCount);
        }

        internal static int ResolveStableIndex(int selectedIndex, int lastCommittedIndex, int itemCount)
        {
            if (itemCount <= 0) return -1;
            if (IsValidIndex(selectedIndex, itemCount)) return selectedIndex;
            if (IsValidIndex(lastCommittedIndex, itemCount)) return lastCommittedIndex;
            return 0;
        }

        /// <summary>
        /// Resolves the user's committed choice before the popup-close notifications finish.
        /// A valid current index wins; if the native ComboBox already cleared it, use the
        /// candidate captured during SelectedIndexChanged, then the prior committed value.
        /// </summary>
        internal static int ResolveCommittedIndex(
            int selectedIndex, int pendingIndex, int lastCommittedIndex, int itemCount)
        {
            if (itemCount <= 0) return -1;
            // A late native notification can still expose the previous selected row even
            // though SelectedIndexChanged already captured the user's newer candidate.
            // Prefer that candidate when the current field is still at the prior committed row.
            if (IsValidIndex(pendingIndex, itemCount) && pendingIndex != lastCommittedIndex &&
                (!IsValidIndex(selectedIndex, itemCount) || selectedIndex == lastCommittedIndex))
                return pendingIndex;
            if (IsValidIndex(selectedIndex, itemCount)) return selectedIndex;
            if (IsValidIndex(pendingIndex, itemCount)) return pendingIndex;
            if (IsValidIndex(lastCommittedIndex, itemCount)) return lastCommittedIndex;
            return 0;
        }

        /// <summary>
        /// Resolves the standard after the native owner-drawn popup has closed. Some WinForms
        /// versions briefly report SelectedIndex == -1 even after the user commits an item.
        /// A committed candidate therefore wins over the closed field; without a commit
        /// notification, a real stable selection wins, otherwise the prior value is restored.
        /// </summary>
        internal static int ResolveAfterDropdownClose(
            bool commitObserved, int pendingIndex, int selectedIndex,
            int lastCommittedIndex, int itemCount)
        {
            if (itemCount <= 0) return -1;
            if (commitObserved && IsValidIndex(pendingIndex, itemCount)) return pendingIndex;
            if (IsValidIndex(selectedIndex, itemCount) && selectedIndex != lastCommittedIndex)
                return selectedIndex;
            if (IsValidIndex(lastCommittedIndex, itemCount)) return lastCommittedIndex;
            if (IsValidIndex(selectedIndex, itemCount)) return selectedIndex;
            return 0;
        }
    }
}
