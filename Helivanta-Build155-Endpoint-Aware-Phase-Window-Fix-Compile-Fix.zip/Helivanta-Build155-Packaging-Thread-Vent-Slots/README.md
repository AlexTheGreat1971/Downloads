﻿# Helivanta 2.5.155 — Packaging Thread engineering prototype

Helivanta is an Autodesk Inventor 2027 add-in for creating and editing physical thread geometry. This source-only candidate focuses on localization, in-plugin documentation, About text, and package cleanup.

## Current features
- Cylindrical thread geometry from the supported standards tables: ISO metric, BSW, ANSI Unified, Tr, S, and Rd.
- Tapered NPT and JIS Taper workflows, including strict table-driven mode and free 1:16 taper mode; minimum-wall-thickness safety checks remain active.
- Editing supported Helivanta thread groups while preserving the group ID; supported conversion paths for native cylindrical cosmetic threads.
- Temporary approximate preview with a tapered side view, vertical parameter table, and larger profile area.
- Dark/Light themes, Amber/Blue/Gray accents, RU/EN interface and ribbon-caption localization.
- Target & Status operation summaries, safety warnings, diagnostic logs, and synchronized Undo/Redo behavior.

## Build / installer
On Windows with the required .NET SDK and Autodesk Inventor SDK package, run `PROJECT\build.bat`. The script reports Standard Geometry and Metadata/Policy test counts. Build the installer separately with `PROJECT\installer\make-installer.bat`.

This archive has not been compiled in the authoring environment. Before treating it as a stable release, verify Build PASS, 135 Standard Geometry tests and 274 Metadata/Policy tests, build the installer, and inspect the localization and preview in Inventor. Build143 remains the confirmed stable rollback source until Build154 passes that verification.


## Build155 status

Build155 currently contains a pure parameter-policy prototype for the new Packaging / Bottle Thread family, not a complete CAD feature. See `PROJECT/docs/BUILD155-PACKAGING-THREAD-DESIGN.md`. UI, Inventor additive CoilFeature geometry, metadata/edit reconstruction, and Inventor transaction validation remain pending. Do not install as a feature-complete release.
