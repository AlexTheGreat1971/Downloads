# Helivanta Wordmark SVG — Build129 manual vector refinement

The main dialog uses `src/HelivantaVectorWordmark.cs` to render vector geometry directly. `Helivanta-Wordmark-Dark.svg` mirrors those hand-authored paths for inspection/export. The original transparent PNG assets remain unchanged as reference resources and are not used by the main header renderer.

Build129 refinement: the blue ribbon is wider, the two single-storey `a` glyphs use matching smooth geometry with different optical widths, the `e` counter is open to the right and no longer clips at the terminal, and the `PHYSICAL THREAD DESIGN` tagline has a larger target height.

The editable designer master and exact original brand font were not supplied, so the wordmark is a clean manual vector reconstruction based on the official PNG rather than a claim of byte-for-byte recovery of the designer's source file. Review `EVIDENCE/BUILD129-LOGO-VECTOR-COMPARISON.jpg` and the header-sized preview at multiple Windows DPI values.
