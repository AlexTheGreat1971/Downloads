﻿# Builds (unless -NoBuild) and installs Helivanta for Inventor 2027 (current user, no admin rights needed).
param([switch]$NoBuild)
$ErrorActionPreference = 'Stop'
$root = $PSScriptRoot
if (-not $NoBuild) { & (Join-Path $root 'build.ps1') }

$dllSource = Join-Path $root 'dist\Helivanta.dll'
if (-not (Test-Path -LiteralPath $dllSource)) { throw 'dist\Helivanta.dll not found' }

# Never replace a DLL while Inventor may have the add-in loaded.
$runningInventor = Get-Process -Name 'Inventor' -ErrorAction SilentlyContinue | Select-Object -First 1
if ($null -ne $runningInventor) { throw 'Close all Autodesk Inventor windows before installing or upgrading Helivanta. No installed files were changed.' }

$localAppData = $env:LOCALAPPDATA
$dest = Join-Path $localAppData 'Helivanta'
$dll = Join-Path $dest 'Helivanta.dll'
function Get-HelivantaBuildLabel([string]$Path) {
    if ([string]::IsNullOrWhiteSpace($Path) -or -not (Test-Path -LiteralPath $Path)) { return $null }
    $v = $null
    try { $v = [System.Reflection.AssemblyName]::GetAssemblyName($Path).Version } catch {}
    if ($null -ne $v -and $v.Build -gt 0) { return ('Build {0}' -f $v.Build) }
    try {
        $product = [System.Diagnostics.FileVersionInfo]::GetVersionInfo($Path).ProductVersion
        if ($product -match '(?i)fix\D*(\d+)') { return ('Build {0}' -f [int]$Matches[1]) }
        if ($product -match '^\d+\.\d+\.(\d+)(?:\.\d+)?$' -and [int]$Matches[1] -gt 0) { return ('Build {0}' -f [int]$Matches[1]) }
    } catch {}
    if ($null -ne $v) { return ('legacy {0}' -f $v.ToString(4)) }
    return 'не определена'
}
$targetBuildLabel = Get-HelivantaBuildLabel $dllSource
$installedBuildLabel = Get-HelivantaBuildLabel $dll
if ($installedBuildLabel) {
    Write-Host ("Установлена сборка: {0}. Целевая сборка: {1}." -f $installedBuildLabel, $targetBuildLabel)
} else {
    Write-Host ("Плагин не найден. Целевая сборка: {0}." -f $targetBuildLabel)
}
$legacyDirs = @((Join-Path $localAppData 'ATG-ThreadPro'), (Join-Path $localAppData 'ThreadPro'))
$addinDir = Join-Path $env:APPDATA 'Autodesk\Inventor 2027\Addins'
$addinFile = Join-Path $addinDir 'Helivanta.addin'
$legacyAddin = Join-Path $addinDir 'ThreadPro.addin'
New-Item -ItemType Directory -Force $dest | Out-Null
New-Item -ItemType Directory -Force $addinDir | Out-Null

$tempDll = $dll + '.new'
$tempAddin = $addinFile + '.new'
try {
    # Probe existing and legacy DLLs before changing registration; a locked file means stop safely.
    foreach ($candidate in @($dll) + @($legacyDirs | ForEach-Object { Join-Path $_ 'Helivanta.dll' })) {
        if (Test-Path -LiteralPath $candidate) {
            $probe = [System.IO.File]::Open($candidate, [System.IO.FileMode]::Open, [System.IO.FileAccess]::ReadWrite, [System.IO.FileShare]::None)
            $probe.Dispose()
        }
    }

    [System.IO.File]::WriteAllBytes($tempDll, [System.IO.File]::ReadAllBytes($dllSource))
    if (Test-Path -LiteralPath $dll) { [System.IO.File]::Replace($tempDll, $dll, $null) }
    else { [System.IO.File]::Move($tempDll, $dll) }

    $templatePath = Join-Path $root 'Helivanta.addin.template'
    if (-not (Test-Path -LiteralPath $templatePath)) { throw 'Helivanta.addin.template not found' }
    $template = [System.IO.File]::ReadAllText($templatePath, [System.Text.Encoding]::UTF8)
    $addinText = $template.Replace('__ASSEMBLY__', $dll)
    [System.IO.File]::WriteAllText($tempAddin, $addinText, [System.Text.UTF8Encoding]::new($false))
    if (Test-Path -LiteralPath $addinFile) { [System.IO.File]::Replace($tempAddin, $addinFile, $null) }
    else { [System.IO.File]::Move($tempAddin, $addinFile) }

    # The new registration is live before old registrations/install directories are removed.
    Remove-Item -LiteralPath $legacyAddin -Force -ErrorAction SilentlyContinue
    foreach ($oldDir in $legacyDirs) { Remove-Item -LiteralPath $oldDir -Recurse -Force -ErrorAction SilentlyContinue }
    Write-Host ("Helivanta updated/installed to {0}: {1}" -f $targetBuildLabel, $dll)
    Write-Host 'Restart Inventor 2027. Button: Part > Helivanta tab.'
}
finally {
    foreach ($temp in @($tempDll, $tempAddin)) {
        if (Test-Path -LiteralPath $temp) { Remove-Item -LiteralPath $temp -Force -ErrorAction SilentlyContinue }
    }
}
