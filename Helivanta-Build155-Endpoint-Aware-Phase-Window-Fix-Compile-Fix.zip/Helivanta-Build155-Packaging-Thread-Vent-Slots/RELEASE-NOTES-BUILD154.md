# Helivanta Build154 — Release candidate

Version: 2.5.154 / 2.5.154.0

## Changes
- Fixed mixed-language runtime Edit messages in Target & Status, including “Edit completed”, “Edit started”, and parameter fragments left in Russian by partial translation.
- Updated searchable in-plugin Instructions in Russian and English: tapered/cylindrical preview layouts, Edit group identity preservation, settings, language switching, safety warnings, and diagnostic logs.
- Updated About in both languages with current preview, themes, accents, language/ribbon localization, Target & Status and diagnostic log maintenance.
- Removed stale validation outputs, compiled outputs and historical per-build scratch files from the distribution ZIP. Source, tests, installer scripts, assets and current design/rollback documents remain.

## Validation status
Static source and localization checks only. The Windows/.NET build, installer, 135 Standard Geometry tests, 274 Metadata/Policy tests, and Inventor runtime check must be run on the target workstation.

Run `PROJECT\build.bat`, then `PROJECT\installer\make-installer.bat`. Keep Build143 as the confirmed stable rollback source until Build154 passes validation.
