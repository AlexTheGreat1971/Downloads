﻿- Follow-up candidate: invert only the `PointOnFace` phase-correction sign, leaving actual coil handedness unchanged. User observation showed the prior cleanup's success switched ends with handedness (RH=end, LH=start); diagnostics now print the correction sign for each candidate. Added matching RH-start/LH-end phase-mapping regressions. Inventor runtime validation still required.

## Build155 experimental follow-up — endpoint-aware Delete Face phase window (2026-10-21)

- Fixed the regression introduced by applying the inverted face-phase correction sign to every endpoint. The face selector now pairs phase correction sign and angular-window direction based on the observed right/left-hand × start/end outcomes.
- Intended mapping: RH/start and LH/end use inverse phase correction with a forward phase window; RH/end and LH/start retain the previously observed successful correction with a reverse phase window. This affects only candidate selection; generated coil geometry and the quarter-sector cleanup threshold are unchanged.
- Added policy checks for all four handedness/endpoint combinations and expanded ambiguous-selection diagnostics with the selected window orientation and correction sign.
- Requires Windows build/tests and Inventor 2027 geometric verification; no runtime claim is made by this source-only patch.
## 2.5.155 — Start-side vent-tail cleanup adjustment (experimental, 2026-10-21)

- Terminal tail planning now measures the nearest vent-slot boundary on either angular side. This fixes the start-side phase=120° case previously reported as 53° even though the nearer boundary is 23° away.
- The cleanup threshold is one quarter of the nominal slot-centre sector plus a 1° angular allowance (23.5° for four evenly spaced slots). The clear-gap ratio is still logged to make this interpretation visible.
- The 23° start tails are now eligible for Delete Face + Heal; long residuals remain protected, and the sector-cut fallback stays disabled.
- This source change has not been compiled or exercised inside Inventor 2027 in the current environment.

## Build155 — 2.5.155 (experimental geometry prototype, not release-qualified)

- Added isolated Packaging / Bottle Thread policy and ribbon/dialog path to an experimental additive builder. The current branch supports external ridges and an internal positive rib into a bore, plus start/end Loft run-outs. Persistent thread metadata/edit integration remains incomplete.
- Added pitch/lead, bounded diameter-scaled profile height, separate print clearance, turn-count, and start-phase policy tests.
- Corrected finite-length multi-start placement: all start profiles share the selected-edge-relative axial interval, while radial sketch planes are rotated by 360°/N. Helix pitch is the lead (P × starts).
- Corrected start-from-edge behavior to direct the coil axis inward from the selected toroidal/circular end edge and compensate handedness when the axis direction is reversed.
- Added per-start Coil health/body/volume checks and diagnostic context around `AddByPitchAndRevolution` failures.
- Autodesk Inventor 2027 runtime geometry remains an explicit validation gate; this experimental prototype is not release-qualified. Existing ISO/Tr/BSW/NPT/JIS families are kept isolated and intentionally unchanged.

# Helivanta changelog

## Build154 — 2.5.154
- Fixed mixed-language Edit start/completion/failure status strings and dynamic parameter-label fragments.
- Updated searchable in-plugin Instructions and About in Russian and English.
- Removed stale validation logs, generated outputs, and historical build scratch files from the distribution package.
- No geometry builders, standards tables, tapered-thread construction, metadata schema, wall-thickness/overlap guard, transaction, conversion or Undo/Redo logic intentionally changed.

## User-validated historical builds
- Build149 / 2.5.149 — user reported Build PASS, Standard Geometry 135/135 and Metadata/Policy 274/274.
- Build145 / 2.5.145 — user reported Build PASS, Standard Geometry 135/135 and Metadata/Policy 274/274.
- Build143 / 2.5.143 — user-confirmed stable source baseline.


## Build155 follow-up — diameter-dependent E_FAIL (2026-10-19)

- Added pitch-relative safety envelope for ridge depth, keeping diameter-based height scaling active until the pitch limit is reached.
- Adapted base width to the radial depth (clamped to 55–80% of pitch) and narrowed the crest to 25% of base width to avoid an unnecessarily steep section at larger diameters.
- Extended the coil axis sketch line past the section's full axial envelope.
- Added diagnostic context for post-Coil update, health, volume and solid-body validation failures.
- Added regression policy cases for Ø22/Ø31/Ø52 mm at P=2.7 mm. Inventor geometry still requires Windows runtime validation.


## Build155 follow-up — packaging-thread error diagnostics (2026-10-19)

- Added a copyable detailed error window for packaging-thread failures, including exception type/message, HRESULT, full exception chain and stack trace.
- Added persistent `packaging-thread-diagnostics.log` at `%LOCALAPPDATA%\Helivanta\Logs`, using existing bounded log rotation/retention.
- Added parameter context and builder phase breadcrumbs before edge/cylinder resolution, per-start plane/sketch/profile/Coil creation, verification, commit, and rollback.
- Logging is best-effort and designed not to mask the original Inventor exception. Runtime behavior still requires testing in Inventor 2027.

## Build155 follow-up — separate thread hand from selected end (2026-10-19)

- Diagnostic log proved the prior edge-compensation formula returned `ClockwiseRotation=false` for both RH selected from the high end and LH selected from the low end. This explained why both generated helices looked right-handed.
- Mapped the requested thread hand directly to the Inventor `ClockwiseRotation` flag based on the observed model: RH => `false`; LH => `true`. End-edge selection continues to control inward axial build direction independently. Autodesk's API flag is a rotation sense and must be calibrated to this sketch/axis convention, not treated as an RH/LH designation by itself.
- Added explicit diagnostic values for requested hand, selected end, build-axis direction, and the boolean sent to Coil; updated regression checks for opposite RH/LH mapping.
- Static regression/source checks and archive integrity are checked; .NET compilation and Inventor 2027 geometry remain unverified in this environment.

## Build155 follow-up — internal positive rib and smooth run-outs (2026-10-19)

- Implemented internal thread as a positive inward helical rib joined to the bore wall. The feature profile reverses the radial relation (`root = bore radius + embed`, `crest = bore radius - height`) and continues to use `kJoinOperation`; it does not cut the bore.
- Added independent start/end smooth-runout checkboxes, enabled by default. The builder divides the requested length into a full-depth core Coil and additive `LoftFeature` run-ins/run-outs through helix-phased radial/axial profiles, with smoothstep crest fade and maintained root overlap.
- Added pure regression checks for internal/external radial directions, runout planning, minimum core length, bounded Loft profile counts and fade factors.
- Actual Inventor 2027 geometry and Windows compilation remain a required validation gate; no runtime PASS is claimed here.


## Build155 follow-up — concise run-outs and automatic surface type (2026-10-20)

- Set the external run-in/run-out target length to exactly 1/12 of the helix turn (`lead / 12`) and the internal positive-rib target to 1/6 turn (`lead / 6`). Multi-start threads use lead `pitch × starts`, not pitch, to measure a full revolution.
- The run-out planner no longer silently shortens these target lengths to fit. If the enabled run-outs plus the minimum full-depth Coil core do not fit in the requested length, preflight rejects the operation with an explanatory error.
- Removed the manual outer/inner thread selector. The selected circular edge's adjacent cylindrical face is classified using `Face.IsParamReversed` (same convention as the existing `ThreadBuilder.Analyze` code), reported in the selection label, used by parameter policy, and checked again by the geometry builder.
- Added regression checks for face-type classification, external 1/12 and internal 1/6 turn run-outs, and insufficient-length rejection. Windows compilation and Inventor 2027 runtime remain unrun in this environment.

## Build155 follow-up — optional PCO-style vent slots (2026-10-20)

- Added an off-by-default checkbox to create axial angular-sector cuts through the raised packaging-thread ridge, down to the original cylindrical surface. The cuts are partial Revolve cut features generated after all Coil cores and run-out Lofts inside the same transaction.
- Added editable slot count and angular width. External defaults use 4 slots and 28 degrees based on the supplied PCO1881 neck drawing. Internal defaults use 8 slots as a user-requested, editable hypothesis—not a verified requirement for a matching closure.
- Added preflight policy for count/width ranges, even angular spacing and non-overlap, plus per-slot feature-health/volume/body-count checks and diagnostics. If any slot fails, the complete thread operation is rolled back.
- See `docs/BUILD155-VENT-SLOTS.md` for drawing interpretation, geometric method and the Inventor runtime acceptance matrix.
- Source-level validation only in this environment; .NET compilation and Inventor 2027 geometry were not run here.


## Build155 vent-slot drawing-angle correction (2026-10-20)

- Corrected the drawing interpretation: 28° is the half-angle from the slot reference, and the included reference sector is (56°). The external default is 4 × 56°.
- Internal default remains 8 × 28° only as an editable hypothesis because PCO1881's neck drawing does not specify matching cap slots.
- The dialog auto-selects type-specific widths with the detected cylindrical surface, while preserving user-edited values.

### Build155 — ventilation-slot compile fix (2026-10-20)
- Corrected the backward-compatible builder overload to use `DefaultExternalSlotWidthDegrees` (56°), the existing policy constant.
- Kept default inner settings (8 × 28°) in the dialog's auto-detected internal-thread path.
- Static references and archive integrity checked; Windows compilation/runtime not available in this environment.


## Build155 follow-up — cancellable build and ventilation-cut reach (2026-10-20)

- Added a dedicated “Отменить построение” button. The geometry builder checks cancellation between Coil, Loft sections, vent cutters and transaction commit; cancellation aborts the single feature transaction and leaves the modeless parameter window open. A single Inventor API call cannot be interrupted mid-call, so the request is honored at the next safe checkpoint.
- Fixed the modeless window's “Закрыть” button by calling `Close()` explicitly. Close/Alt+F4 during an active build requests cancellation and keeps the window alive until the transaction is safely aborted.
- Set the default vent-slot width to 14° for both external and internal configurations; users can still change it. The 56° PCO1881 drawing reference is retained as a drawing-derived value, not a modelling default.
- Extended each longitudinal vent cutter by at least one complete thread lead before the initial axial edge and after the final axial end, with `max(1 mm, lead)` overrun. The radial bounds remain restricted to the protruding rib so the cylinder wall is not intended to be cut.
- Added policy coverage for the 14° defaults and the dynamic axial cutter overrun. Static checks only; Windows/.NET 10 and Inventor 2027 execution remain unverified in this environment.

- Follow-up geometry correction: start and end cutter overrun are calculated independently. The cutter begins just before the selected edge and reaches beyond the last ridge as far as the selected cylinder allows, with a 0.25 mm safety extension beyond its far boundary.

- Follow-up after user geometry QA: made cutter start/end travel independent. Start is extended just 0.25 mm outside the selected circular edge after accounting for the thread-origin inset; end prefers one full lead after the thread but stops at 0.25 mm beyond the selected cylinder's far boundary. Tests cover start offset and the far-boundary safety cap.


## Build155 usability and ventilation cut follow-up (2026-10-20)

- Hardened idle modeless-dialog Close: logs the request, calls `Close()`, and falls back to Hide/Dispose if another handler cancels closing. During active building, Close remains a cancellation request; the dedicated cancel button continues to poll between Inventor COM operations and lets the builder abort its one transaction, leaving the dialog open.
- Current external/internal ventilation-slot width defaults remain 14° (the historic PCO1881 56° included sector is drawing reference, not the active modelling default).
- Refined axial cutter reach: start extends exactly to 0.25 mm before the selected physical edge after accounting for the builder inset. Far-end overrun prefers `max(1 mm, lead)` but is capped at 0.25 mm beyond the chosen cylinder boundary, preventing a full-lead sweep across an adjacent shoulder. Added source-level tests for this policy.
- Static checks only; Windows/.NET 10 and Inventor runtime were not available here.


## Build155 follow-up — terminal vent-fragment cleanup and cancellation UX (2026-10-20)

- Added a pure angular/helix policy for terminal ridge fragments beside vent slots. If the fragment is strictly shorter than 25% of the free segment between adjacent slot bands, add a local sector cut through only the raised ridge and just the associated axial terminal region, overlapping the existing slot by 0.02° to avoid a residual seam. The policy protects adjacent starts using the angular footprint of the profile; potentially unsafe cleanups are skipped with diagnostics rather than risk cutting valid thread.
- Per cleanup cut, validate feature health, measurable volume removal, and unchanged solid-body count within the common Inventor transaction. Failures abort the operation and include the end/start index, phase, angle fraction, and sweep. Added four policy regression checks.
- Removed the post-build modal success message that blocked the modeless window’s idle/cancel state. During construction, cancellation is polled at more intermediate checkpoints after Inventor API operations; the button displays “Ожидание отмены…” until rollback completes, and Escape requests cancellation while building. After a completed/committed build, use Inventor Undo (Ctrl+Z); cancel is not an undo button.
- Source-level checks only; Windows/.NET compilation, actual cancel responsiveness, and Inventor 2027 trim-cut geometry still need runtime validation.

## Build155 Delete Face + Heal experiment (2026-10-20)

- Added a guarded attempt to remove each short terminal fragment with Inventor `DeleteFaceFeatures.Add(FaceCollection, true)`, matching the manual Delete Face + Heal workflow.
- The probe only attempts deletion when its terminal-sector filter returns exactly three candidate faces; ambiguous cases log the count and retain the previous sector-cut fallback.
- A successful delete-face feature is checked for healthy status, measurable volume change, and unchanged solid-body count. Failed attempts are logged and rolled back before fallback.
- Cancel button is now explicitly styled amber while building and refreshes its visual state when cancellation is requested. Cancellation remains cooperative between Inventor API calls; a long kernel call cannot be interrupted mid-call.
- Requires Windows build and Inventor 2027 model validation. This environment has no `dotnet` executable, so compilation/runtime are not verified here.


## Build155 follow-up — quarter-sector tail selection correction (2026-10-21)

- Parsed the latest user Gist for the D=22 mm, P=2.7 mm, 3-start external case with 4 × 14° vent slots. The end-2 fragment is 17.444° out of a 76° free sector (22.953%), so it qualifies for removal under the strict <25% rule. The other reported 23° fragments are 30.263% and must remain.
- Found why Delete Face + Heal never ran: all five faces in the local axial/angular window were rejected by a crest-radius filter, even though their PointOnFace/vertex radii are around the 11.0 mm stock radius.
- Replaced that incorrect crest-radius gate with the observed topology for this target tail: the local window contains two planar slot/end walls plus exactly three `kBSplineSurface` faces. Only the three spline faces are offered to `DeleteFaceFeatures.Add(faceCollection, true)`; the operation is still gated by the `<25%` fragment policy and an exact-three-candidate check.
- Diagnostic output now reports `splineTopSurfaceCandidates`, accepted spline faces with station/point-radius/vertex-radius range/angle, and non-spline faces excluded from the window. The risky legacy sector-cut fallback remains disabled.
- Updated the policy test description. Source inspection and arithmetic reviewed; .NET compilation and Inventor 2027 runtime remain unverified in this environment.

## Build155 follow-up — adaptive short-thread runouts (2026-10-20)
- Fixed a parameter-policy rejection for short internal-positive-rib threads when both smooth runouts were enabled.
- When nominal runouts do not fit, both enabled runouts are shortened equally to preserve the minimum quarter-turn working core. A runout shorter than 1/24 turn is rejected with a clearer message rather than silently creating a near-zero fade.
- Diagnostic event `runout-policy-resolved` now records both nominal target and effective runout turn fractions.
- Added a policy regression case for the reported D=45 mm, P=2.7 mm, 3-start, lead=8.1 mm, length=4.05 mm scenario, plus rejection below minimum core length.
- This is a source-level change only; Windows build and Inventor 2027 runtime validation remain required.


## Build155 follow-up — crest-face Delete Face + Heal and guarded post-build undo (2026-10-21)

- Tightened automatic terminal-tail face selection: face interior points must be within the terminal axial window, within a bounded radial band around the thread crest, and inside the intended angular sector. Diagnostic entries include candidate-stage counts and per-face station/radius/angle/surface details.
- Disabled the legacy angular-sector cleanup cut so ambiguous face selection no longer creates the same fragile cut that could fail with `kDriverLostHealth`. If Delete Face + Heal is not safe, the optional cleanup is skipped explicitly and the residual tail may remain for diagnosis.
- Added a unique transaction name for packaging-thread builds and a guarded **Отменить последнее построение** action. It only calls Inventor undo when the exact packaging transaction is still the newest committed action and the same part is active; otherwise the action is disabled/refused. During a build, the button remains the cancellation request.
- Static source checks only. The .NET compiler and Inventor 2027 runtime are unavailable in this environment; this candidate is not build-verified and requires the user's runtime test. See `docs/BUILD155-DELETE-FACE-HEAL-UNDO-FOLLOWUP.md`.


## Build155 follow-up — use face boundary vertices for crest detection (2026-10-21)

- Reviewed the user's runtime diagnostic: the last Delete Face attempt had 26 axial faces, 5 angular-sector faces, and zero crest candidates because `PointOnFace` sampled near radius 11.0 mm while the designed crest radius was 11.55 mm. No Delete Face API call was made.
- Corrected the radial filter to measure each candidate face's maximum radial extent from its topological vertices, rather than treating the interior sample point as the face's crest radius. Diagnostics now include PointOnFace radius, face vertex radial range, vertex count, and delta from crest radius.
- This is a targeted selection correction based on observed log evidence. It is not yet Inventor-runtime verified; selection must still resolve to exactly the three user-identified top faces before Heal is invoked.


## Build155 experimental follow-up — start-side terminal face selection (2026-10-21)

- Corrected `Face.PointOnFace` azimuth to the thread endpoint phase using axial station, helix hand sign, and lead before selecting the 3 top faces for Delete Face + Heal.
- Changed the candidate-sector direction to match the actual decreasing-phase direction of the generated revolve cleanup. This targets the opposite-end mismatch without changing the cancel/guarded-undo paths.
- Added 2 pure regression checks for axial phase compensation at the start and end. This is a source candidate only: compile and Inventor 2027 model validation are pending.
