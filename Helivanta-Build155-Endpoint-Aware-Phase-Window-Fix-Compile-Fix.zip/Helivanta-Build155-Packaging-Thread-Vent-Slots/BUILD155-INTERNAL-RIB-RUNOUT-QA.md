# Build155 — Internal positive rib and smooth run-outs: QA note

## Scope

This candidate extends the isolated Packaging/Bottle Thread experiment only. It does not change the ISO, Tr, BSW, NPT, JIS thread families or native tapered-thread builder.

## Geometry implementation

- External thread: the existing user-validated additive multi-start Coil core remains in place.
- Internal thread: the root radius is bore radius + embed and the crest radius is bore radius − height. The builder uses `kJoinOperation` for both core Coil and run-out Loft; the internal variant is not a cut groove.
- Smooth run-in/run-out: two independent checkboxes default to on. Each selected end uses ordered rotating radial/axial closed profiles in an additive Loft. Crest and root-overlap envelopes use smoothstep factors so both have zero first derivative at the end stations; a small root overlap remains at the terminal station to preserve fusion to the source wall.
- Run-out lengths are now fixed by the actual helical lead, not a pitch/height heuristic: external = 1/12 turn (`lead / 12`), internal positive rib = 1/6 turn (`lead / 6`). If those exact lengths plus the enabled minimum core do not fit, preflight rejects the request instead of silently shortening the run-out. Core length remains at least one quarter of the lead; Loft section counts are bounded from 7 through 49.
- Thread type is automatically resolved from the selected edge's adjacent cylindrical face orientation. In line with the existing Helivanta `ThreadBuilder.Analyze` convention, `Face.IsParamReversed == true` means outside shaft; false means inside bore. The UI's manual type dropdown was removed. The builder repeats this classification and verifies it matches the preflight result.
- Coil and Loft feature creation remains within one Inventor transaction. Each feature is checked for up-to-date health, measurable volume increase and unchanged body count. Failures should abort the transaction and retain stage-specific diagnostic details.

## Source-level checks performed in this package preparation

- XML parse: `src/Helivanta.csproj` and `tests/ThreadMetadataTest/ThreadMetadataTest.csproj`.
- Lexical delimiter balance: all touched C# files.
- Internal radial geometry policy: root/crest values must lie on opposite sides of the bore radius in the correct order.
- Internal operation assertion: the packaging builder uses `kJoinOperation`, with no `kCutOperation` in this builder.
- Dialog wiring: auto-detected inner/outer mode and both independent run-out checkboxes are passed through to the generic builder.
- Run-out profile policy: start/end factors remain monotonic and have smoothstep endpoints; core length/section-count limits are exercised by policy tests.
- The numerical example D=31 mm, P=2.7 mm, 3 starts, total L=10 mm resolves H=0.775 mm, embed=0.155 mm, base width=1.674 mm and lead=8.1 mm. External run-outs are 0.675 mm each with 8.650 mm core; internal run-outs are 1.350 mm each with 7.300 mm core.

## 2026-10-20 adjustments from user review

- Shortened run-outs from roughly one-third of a turn to the requested fixed fractions: external 1/12 turn and internal 1/6 turn, both measured along the actual helix lead `P × starts`.
- Removed manual inner/outer selection. The adjacent cylinder's `IsParamReversed` flag is read and shown in the dialog; the builder rechecks it before constructing. This matches the existing `ThreadBuilder.Analyze` convention for external shafts vs internal bores.
- Added policy tests for both exact fractions, core-length rejection when the requested lengths do not fit, and face-orientation classification.

## Not run here

This environment has no `dotnet`, MSBuild or Autodesk Inventor runtime. Therefore no C# compilation, Windows policy tests or Inventor CAD runtime geometry test is claimed PASS. The source-level checks do not prove that Inventor's feature kernel accepts the Loft blend in every inner/outer, handedness, starts and edge combination.

## Required Windows / Inventor 2027 acceptance matrix

Use a disposable part before production use. Test:

1. Internal positive rib in a bore: it projects into the hole, joins the wall, does not cut the bore and creates no additional solid body.
2. Both end edges, RH and LH, with one, two and three starts.
3. Run-in only, run-out only, both and neither.
4. Visible smooth approach to near-flush at both free ends and no geometric gap where the Loft meets the full-depth Coil.
5. Feature health and positive volume change after every Coil/Loft, unchanged solid-body count, successful transaction rollback on forced invalid geometry and a single Undo removing the full build operation.
6. Repeat external thread cases to ensure no regression from the user-validated external behavior.
7. On any failure, include `packaging-thread-diagnostics.log` and the copied error report. Inspect the exact stage and per-section parameters before altering the algorithm.

## 2026-10-20 optional vent-slot addition

- Added an off-by-default checkbox to cut axial openings through the positive helical ridge, reaching the nominal cylindrical surface. Slot cuts are partial revolved cuts after the main Coil and run-outs, with a 0.02 mm overrun on the free side of the ridge and 0.05 mm axial extension inside the existing edge margins.
- External default: 4 slots at 28° angular width based on the supplied PCO1881 neck drawing. Internal default: 8, clearly treated as an adjustable hypothesis, because the supplied neck drawing does not specify the matching cap's internal slot count. The count and width remain editable.
- Each slot must keep the cut in the selected body, reach `kUpToDateHealth`, remove measurable volume, and preserve solid-body count. Failure aborts the whole transaction.
- New pure policy tests cover defaults, angular spacing, disabled behavior, invalid count/width and overlapping slots.
