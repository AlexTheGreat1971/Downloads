﻿# Helivanta — source map, invariants and guardrails

## Platform and status

- Autodesk Inventor Professional 2027, Windows x64, C# WinForms, .NET 10, Inventor COM Interop.
- Last user-reported Windows build/test baseline in this handoff: Build95 / 2.0.95.0 (build 2.2 s; Standard Geometry Test 1.4.43 = 135 PASS / 0 FAIL / 0 SKIP; extended policy tests = 273 PASS / 0 FAIL). These results apply to Build95 only.
- Build101 / 2.0.101.0: the user confirmed tapered edit works with smooth run-out; simplified run-out still failed.
- Current candidate: Build102 / 2.0.102.0. Source-only, not compiled or validated in Inventor here. It removes the simplified run-out option, resolves localized JIS table names and adds persisted strict-table/free-geometry mode.

## Source map

| File | Responsibility | Guardrail |
|---|---|---|
| src/ThreadDialog.cs | Main UI, tapered mode, lengths, edit confirmation and preview | No silent designation substitution; geometry consent before destructive edit; stable bounds after initial layout |
| src/NativeTaperedThreadBuilder.cs | Prepared cone, native tapered callout, physical Coil groove, smooth run-out Loft/fallback, chamfer | Check HealthStatus, volume change and body count; one transaction and folder; full rollback on failure |
| src/ThreadBuilder.cs | Build transaction entry and browser feature folder | Preserve Build101 full-tree folder reuse; cylindrical branch protected |
| src/TaperedThreadGeometryPolicy.cs | Taper ratio, start/end radius, run-out stations, chamfer fit | Pure policy tests supplement but do not replace Inventor B-rep tests |
| src/TaperThreadTableResolver.cs | Resolves UI display names to actual Thread.xls type identifiers | Must use correct internal/external type and record query diagnostics; don't invent table rows |
| src/ThreadWallThicknessGuard.cs, src/ThreadWallThicknessPolicy.cs | Wall-thickness preflight | Fail closed on incomplete measurement; never weaken the guard to get a green build |
| src/ThreadEditService.cs, src/ThreadEditSafetyPolicy.cs | Safe edit/replacement and rollback | Prove original group restoration after replacement failure; never save uncertain IPT |
| src/ThreadMetadataRecord.cs, src/ThreadMetadataStore.cs | Persistent thread group metadata | Legacy missing `TaperGeometryMode` defaults to strict; verify save/close/reopen |
| src/ThreadIntegrityChecker.cs, src/ThreadIntegrityPolicy.cs, src/ThreadIntegrityDialog.cs | Read-only integrity report | No geometry, visibility, transaction or Undo/Redo mutation |
| src/ThreadStandards.cs | Standard tables and profile formulas | Protected; change only with measured reproducible defect and regression |
| tests/StandardGeometryTest/ | Standard geometry regression checks | Run for each candidate on Windows |
| tests/ThreadMetadataTest/ | Metadata and policy tests | Run for each candidate; not evidence of CAD B-rep correctness |
| installer/make-installer.ps1 | Installer publishing/package validation | Version must match Directory.Build.props; verify Windows publish logs and installer behavior |

## Non-negotiable invariants

1. Increment central release version for every build; never reuse a version. Build102 candidate is 2.0.102.0; Build95 remains the last user-reported test-count baseline.
2. Keep rollback archives unchanged and exclude bin, obj, dist, generated test output and stale binaries from source packages.
3. `src/ThreadStandards.cs` and core cylindrical B-rep logic in `src/ThreadBuilder.cs` are protected.
4. Generic technological clearance for NPT/JIS tapered threads stays zero.
5. Simplified run-out is no longer user-selectable; older `SimplifiedRunout` metadata remains readable for compatibility and is forced off during new builds/edits.
6. Strict mode is table-dimension mode; entering it restores the table length. If the user manually overrides that length later, the existing UI warning must remain visible. Free mode preserves the far-end stock diameter and derives the input diameter using the 1:16 taper.
7. Tapered run-out and chamfer remain in one named folder and the same encompassing transaction; failure rolls back the complete group.
8. Automated/policy test success does not certify Inventor COM runtime or B-rep. Do not claim results absent from actual logs.
9. Destructive geometry experiments only on disposable IPTs. If Abort/Undo/Redo cannot be verified, do not save.
10. Thread integrity diagnostics remain read-only.

## Current validation plan

On Windows, from `PROJECT`, run `build.ps1`; only after successful compilation, run the standard/extended tests and then installer creation if needed. In Inventor 2027: verify Build101 smooth edit stability, JIS table lookup on outer/internal Ø45/Ø52 mm stock, strict/free mode on disposable IPTs, wall guard, no-op and changed-parameter edit, fallback runout B-rep, rollback, Undo/Redo and save/reopen. Never claim a build or test result without its actual log.
