@echo off
cd /d "%~dp0.."
if not exist "dist\Helivanta.dll" call build.bat
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0make-installer.ps1" -Method dotnet
pause
