﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Diagnostics;
using System.IO;
using System.Text;
using System.Reflection;
using System.Windows.Forms;
using System.Text.Json.Nodes;
using System.Threading.Tasks;

internal static class Program
{
    [STAThread]
    private static int Main()
    {
        ApplicationConfiguration.Initialize();
        Application.SetHighDpiMode(HighDpiMode.PerMonitorV2);
        using (var form = new SetupForm())
        {
            Application.Run(form);
            return form.ResultCode;
        }
    }
}

internal sealed class SetupForm : Form
{
    private static readonly Color Surface = Color.FromArgb(248, 249, 250);
    private static readonly Color Panel = Color.White;
    private static readonly Color ForegroundText = Color.FromArgb(45, 45, 48);
    private static readonly Color Muted = Color.FromArgb(91, 96, 101);
    private static readonly Color Border = Color.FromArgb(214, 217, 221);
    private static readonly Color Accent = Color.FromArgb(0, 114, 181);
    private static readonly Color Warning = Color.FromArgb(175, 92, 0);
    private static readonly Color Success = Color.FromArgb(26, 125, 73);

    private readonly string _addinDir;
    private readonly string _addinFile;
    private readonly string _dest;
    private readonly string _dll;
    private readonly bool _inventorInstalled;
    private readonly Version _setupVersion;
    private readonly string _setupDisplayVersion;
    private bool _installed;
    private Version _installedVersion;
    private Label _title, _subtitle, _status, _details, _description;
    private ComboBox _language;
    private bool _english;
    private Button _delete, _upgrade, _close;
    private PictureBox _icon;
    private Panel _card;
    private HelivantaProgressBar _progressBar;
    private bool _operationInProgress;

    public int ResultCode { get; private set; }

    public SetupForm()
    {
        this.Text = "Helivanta Setup";
        StartPosition = FormStartPosition.CenterScreen;
        FormBorderStyle = FormBorderStyle.FixedDialog;
        MaximizeBox = false;
        MinimizeBox = false;
        ShowInTaskbar = true;
        AutoScaleMode = AutoScaleMode.Dpi;
        Font = new Font("Segoe UI", 9f, FontStyle.Regular, GraphicsUnit.Point);
        BackColor = Surface;
        ForeColor = ForegroundText;
        ClientSize = new Size(Dpi(660), Dpi(410));
        try { Icon = LoadIcon(); } catch { }

        _addinDir = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData), "Autodesk", "Inventor 2027", "Addins");
        _addinFile = Path.Combine(_addinDir, "Helivanta.addin");
        _dest = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "Helivanta");
        _dll = Path.Combine(_dest, "Helivanta.dll");
        string pf = Environment.GetFolderPath(Environment.SpecialFolder.ProgramFiles);
        _inventorInstalled = Directory.Exists(Path.Combine(pf, "Autodesk", "Inventor 2027"));
        Assembly setupAssembly = Assembly.GetExecutingAssembly();
        Version rawSetupVersion = setupAssembly.GetName().Version;
        _setupVersion = NormalizeVersion(rawSetupVersion) ?? new Version(2, 0, 0);
        _setupDisplayVersion = GetSetupDisplayVersion(setupAssembly, _setupVersion);
        RefreshInstalledState();

        BuildUi();
        UpdateState();
        ApplyInstallerLanguage();
    }


    private Image LoadFullLogo()
    {
        using (Stream stream = Assembly.GetExecutingAssembly().GetManifestResourceStream("Helivanta-Wordmark-Light.png"))
        {
            if (stream == null) return IconToBitmap(LoadIcon());
            using (Image image = Image.FromStream(stream)) return new Bitmap(image);
        }
    }

    private int Dpi(int n) { return (int)Math.Round(n * DeviceDpi / 96.0); }

    private void BuildUi()
    {
        var root = new TableLayoutPanel { Dock = DockStyle.Fill, ColumnCount = 1, RowCount = 4, Padding = new Padding(Dpi(14)), BackColor = Surface };
        root.RowStyles.Add(new RowStyle(SizeType.Absolute, Dpi(76)));
        root.RowStyles.Add(new RowStyle(SizeType.AutoSize));
        root.RowStyles.Add(new RowStyle(SizeType.Percent, 100));
        root.RowStyles.Add(new RowStyle(SizeType.AutoSize));
        Controls.Add(root);

        var header = new Panel { Dock = DockStyle.Fill, Height = Dpi(72), BackColor = Surface };
        // Use the approved horizontal wordmark at a legible size instead of shrinking it
        // into a square icon; the adjacent text carries the installer purpose/version.
        _icon = new PictureBox { Size = new Size(Dpi(230), Dpi(64)), Location = new Point(0, Dpi(2)), SizeMode = PictureBoxSizeMode.Zoom, BackColor = Color.Transparent, Image = LoadFullLogo() };
        header.Controls.Add(_icon);
        _title = new Label { AutoSize = true, Location = new Point(Dpi(244), Dpi(7)), Font = new Font("Segoe UI Semibold", 13.5f, FontStyle.Bold), ForeColor = ForegroundText, Text = "Установка и обновление" };
        header.Controls.Add(_title);
        _subtitle = new Label { AutoSize = false, Location = new Point(Dpi(245), Dpi(35)), Size = new Size(Dpi(270), Dpi(36)), Font = new Font("Segoe UI", 9.0f), ForeColor = Muted, Text = "Физическая геометрия резьбы для Autodesk Inventor 2027\r\nИнсталлятор " + _setupDisplayVersion };
        header.Controls.Add(_subtitle);
        _language = new ComboBox { DropDownStyle = ComboBoxStyle.DropDownList, Location = new Point(Dpi(520), Dpi(34)), Size = new Size(Dpi(100), Dpi(26)), Font = new Font("Segoe UI", 8.5f) };
        _language.Items.AddRange(new object[] { "Русский", "English" });
        _english = ReadSavedLanguage() == "en";
        _language.SelectedIndex = _english ? 1 : 0;
        _language.SelectedIndexChanged += (s, e) => { _english = _language.SelectedIndex == 1; SaveSelectedLanguage(); ApplyInstallerLanguage(); };
        header.Controls.Add(_language);
        root.Controls.Add(header, 0, 0);

        var line = new Panel { Dock = DockStyle.Fill, Height = 1, BackColor = Border, Margin = new Padding(0, Dpi(2), 0, Dpi(7)) };
        root.Controls.Add(line, 0, 1);

        _card = new Panel { Dock = DockStyle.Fill, BackColor = Panel, Padding = new Padding(Dpi(12)), Margin = Padding.Empty };
        _card.Paint += (s, e) => { using (var pen = new Pen(Border)) e.Graphics.DrawRectangle(pen, 0, 0, _card.Width - 1, _card.Height - 1); };
        var body = new TableLayoutPanel { Dock = DockStyle.Fill, ColumnCount = 1, RowCount = 4, BackColor = Panel };
        body.RowStyles.Add(new RowStyle(SizeType.Absolute, Dpi(30)));
        body.RowStyles.Add(new RowStyle(SizeType.Absolute, Dpi(60)));
        body.RowStyles.Add(new RowStyle(SizeType.Percent, 100));
        body.RowStyles.Add(new RowStyle(SizeType.AutoSize));
        _card.Controls.Add(body);

        _details = new Label
        {
            AutoSize = false,
            Dock = DockStyle.Fill,
            Font = new Font("Segoe UI Semibold", 10.5f, FontStyle.Bold),
            ForeColor = ForegroundText,
            Margin = Padding.Empty,
            Text = "",
            TextAlign = ContentAlignment.MiddleLeft
        };
        body.Controls.Add(_details, 0, 0);
        _description = new Label
        {
            AutoSize = false,
            Dock = DockStyle.Fill,
            ForeColor = Muted,
            Text = "Поддерживаются физические резьбы ISO, BSW, ANSI/UN, Tr, S и Rd. Установка выполняется только для текущего пользователя и не требует прав администратора.",
            TextAlign = ContentAlignment.MiddleLeft,
            Margin = Padding.Empty
        };
        body.Controls.Add(_description, 0, 1);
        var statusBox = new Panel { Dock = DockStyle.Fill, BackColor = Color.FromArgb(244, 246, 248), Padding = new Padding(Dpi(14)), Margin = Padding.Empty };
        var statusLayout = new TableLayoutPanel { Dock = DockStyle.Fill, ColumnCount = 1, RowCount = 2, BackColor = Color.Transparent, Margin = Padding.Empty, Padding = Padding.Empty };
        statusLayout.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100f));
        statusLayout.RowStyles.Add(new RowStyle(SizeType.Percent, 100f));
        statusLayout.RowStyles.Add(new RowStyle(SizeType.Absolute, Dpi(18)));
        _status = new Label
        {
            AutoSize = false,
            Dock = DockStyle.Fill,
            ForeColor = ForegroundText,
            Text = "",
            TextAlign = ContentAlignment.TopLeft,
            Padding = new Padding(Dpi(2)),
            Margin = Padding.Empty
        };
        _progressBar = new HelivantaProgressBar
        {
            Dock = DockStyle.Fill,
            Minimum = 0,
            Maximum = 100,
            Value = 0,
            Margin = new Padding(0, Dpi(4), 0, 0),
            AccessibleName = "Прогресс установки Helivanta",
            AccessibleDescription = "Показывает этапы проверки, копирования и регистрации плагина."
        };
        statusLayout.Controls.Add(_status, 0, 0);
        statusLayout.Controls.Add(_progressBar, 0, 1);
        statusBox.Controls.Add(statusLayout);
        body.Controls.Add(statusBox, 0, 2);
        root.Controls.Add(_card, 0, 2);

        var footer = new TableLayoutPanel { Dock = DockStyle.Fill, ColumnCount = 2, AutoSize = true, BackColor = Surface, Padding = new Padding(0, Dpi(8), 0, 0) };
        footer.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100f));
        footer.ColumnStyles.Add(new ColumnStyle(SizeType.AutoSize));
        _delete = Secondary("Удалить");
        _delete.Size = new Size(Dpi(96), Dpi(34));
        _delete.Click += (s, e) => PerformDelete();
        _upgrade = Primary("Установить " + FormatVersion(_setupVersion));
        _upgrade.Size = new Size(Dpi(178), Dpi(34));
        _upgrade.Click += (s, e) => PerformUpgradeOrInstall();
        _close = Secondary("Закрыть");
        _close.Size = new Size(Dpi(94), Dpi(34));
        _close.Click += (s, e) => Close();
        var actions = new FlowLayoutPanel { AutoSize = true, FlowDirection = FlowDirection.LeftToRight, WrapContents = false, Margin = Padding.Empty, Padding = Padding.Empty, BackColor = Surface };
        actions.Controls.Add(_delete);
        actions.Controls.Add(_upgrade);
        actions.Controls.Add(_close);
        footer.Controls.Add(new Label { AutoSize = true, Text = "", Margin = Padding.Empty }, 0, 0);
        footer.Controls.Add(actions, 1, 0);
        root.Controls.Add(footer, 0, 3);
    }

    private Button Primary(string text)
    {
        var b = new Button { Text = text, AutoSize = false, Size = new Size(Dpi(125), Dpi(34)), FlatStyle = FlatStyle.Flat, BackColor = Accent, ForeColor = Color.White, UseVisualStyleBackColor = false, Margin = new Padding(Dpi(6), 0, 0, 0) };
        b.FlatAppearance.BorderSize = 0;
        return b;
    }

    private Button Secondary(string text)
    {
        var b = new Button { Text = text, AutoSize = false, Size = new Size(Dpi(110), Dpi(34)), FlatStyle = FlatStyle.Flat, BackColor = Panel, ForeColor = ForegroundText, UseVisualStyleBackColor = false, Margin = new Padding(Dpi(6), 0, 0, 0) };
        b.FlatAppearance.BorderSize = 1;
        b.FlatAppearance.BorderColor = Border;
        return b;
    }

    private string LegacyAtgInstallDir => Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "ATG-ThreadPro");

    private string LegacyThreadProInstallDir => Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "ThreadPro");

    private string[] GetAllInstallDllCandidates() => new[]
    {
        _dll,
        Path.Combine(LegacyAtgInstallDir, "Helivanta.dll"),
        Path.Combine(LegacyThreadProInstallDir, "Helivanta.dll")
    };

    private string[] GetLegacyInstallDirectories() => new[] { LegacyAtgInstallDir, LegacyThreadProInstallDir };

    private void RefreshInstalledState()
    {
        string legacyAddin = Path.Combine(_addinDir, "ThreadPro.addin");
        string[] dllCandidates = GetAllInstallDllCandidates();
        bool anyDllExists = false;
        foreach (string candidate in dllCandidates)
            if (File.Exists(candidate)) { anyDllExists = true; break; }
        _installed = File.Exists(_addinFile) || File.Exists(legacyAddin) || anyDllExists;
        _installedVersion = ReadInstalledVersion(dllCandidates);
    }

    private static Version NormalizeVersion(Version version)
    {
        if (version == null || version.Major < 0) return null;
        int minor = Math.Max(0, version.Minor);
        int build = Math.Max(0, version.Build);
        int revision = Math.Max(0, version.Revision);
        return new Version(version.Major, minor, build, revision);
    }

    private static int CompareReleaseVersion(Version left, Version right)
    {
        if (left == null) return right == null ? 0 : -1;
        if (right == null) return 1;
        int c = left.Major.CompareTo(right.Major); if (c != 0) return c;
        c = left.Minor.CompareTo(right.Minor); if (c != 0) return c;
        c = Math.Max(0, left.Build).CompareTo(Math.Max(0, right.Build)); if (c != 0) return c;
        return Math.Max(0, left.Revision).CompareTo(Math.Max(0, right.Revision));
    }

    private static string FormatVersion(Version version)
    {
        Version normalized = NormalizeVersion(version);
        if (normalized == null) return "не определена";
        if (normalized.Build > 0) return "Build " + normalized.Build.ToString();
        return "legacy " + normalized.ToString(4);
    }

    private static Version ReadInstalledVersion(string[] candidateFiles)
    {
        foreach (string candidate in candidateFiles)
        {
            if (string.IsNullOrWhiteSpace(candidate) || !File.Exists(candidate)) continue;
            Version assemblyVersion = null;
            try { assemblyVersion = NormalizeVersion(AssemblyName.GetAssemblyName(candidate).Version); } catch { }
            // New numeric builds encode the build number in the third numeric component: 2.0.N.0.
            if (assemblyVersion != null && assemblyVersion.Build > 0) return assemblyVersion;

            // Legacy Fix builds kept AssemblyVersion at 2.0.0.15. Recover the actual Fix number
            // from ProductVersion when possible, so an existing Fix43 installation is displayed
            // as Build 43 and can be upgraded to the current numeric build without a misleading version comparison.
            try
            {
                FileVersionInfo info = FileVersionInfo.GetVersionInfo(candidate);
                Version fromProduct = ParseBuildVersion(info.ProductVersion);
                if (fromProduct != null) return fromProduct;
                Version fromFile = ParseBuildVersion(info.FileVersion);
                if (fromFile != null) return fromFile;
                Version parsed;
                if (Version.TryParse(info.FileVersion, out parsed)) return NormalizeVersion(parsed);
            }
            catch { }
            if (assemblyVersion != null) return assemblyVersion;
        }
        return null;
    }

    private static Version ParseBuildVersion(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;
        string text = value.Trim();
        // Current format is fully numeric (2.0.N or 2.0.N.0).
        Version numeric;
        if (Version.TryParse(text, out numeric) && numeric.Build > 0)
            return new Version(2, 0, numeric.Build, 0);

        // Migration support for previously shipped labels such as ...-fix43-... or Fix43.
        string lower = text.ToLowerInvariant();
        int marker = lower.IndexOf("fix", StringComparison.Ordinal);
        if (marker >= 0)
        {
            int i = marker + 3;
            while (i < lower.Length && !char.IsDigit(lower[i])) i++;
            int begin = i;
            while (i < lower.Length && char.IsDigit(lower[i])) i++;
            int build;
            if (i > begin && int.TryParse(lower.Substring(begin, i - begin), out build) && build > 0)
                return new Version(2, 0, build, 0);
        }
        return null;
    }

    private static string GetSetupDisplayVersion(Assembly assembly, Version fallbackVersion)
    {
        return FormatVersion(fallbackVersion);
    }

    private string ReadSavedLanguage()
    {
        try
        {
            string path = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "Helivanta", "settings.json");
            if (File.Exists(path)) { JsonNode node = JsonNode.Parse(File.ReadAllText(path)); return (string)node?["Language"] ?? "ru"; }
        }
        catch { }
        return "ru";
    }

    private void SaveSelectedLanguage()
    {
        try
        {
            string dir = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "Helivanta");
            Directory.CreateDirectory(dir);
            string path = Path.Combine(dir, "settings.json");
            JsonObject obj = new JsonObject();
            try { if (File.Exists(path)) obj = JsonNode.Parse(File.ReadAllText(path)) as JsonObject ?? new JsonObject(); } catch { }
            if (obj["Theme"] == null) obj["Theme"] = "Dark";
            if (obj["Accent"] == null) obj["Accent"] = "Amber";
            obj["Language"] = _english ? "en" : "ru";
            if (obj["PreviewOpacity"] == null) obj["PreviewOpacity"] = 80;
            if (obj["PreviewLineScale"] == null) obj["PreviewLineScale"] = 100;
            if (obj["AutoPreview"] == null) obj["AutoPreview"] = true;
            if (obj["RememberPreview"] == null) obj["RememberPreview"] = true;
            if (obj["DefaultStandard"] == null) obj["DefaultStandard"] = "ISO";
            if (obj["DefaultTechnology"] == null) obj["DefaultTechnology"] = "Metal";
            if (obj["DefaultExternal"] == null) obj["DefaultExternal"] = true;
            if (obj["DefaultRightHand"] == null) obj["DefaultRightHand"] = true;
            if (obj["Tooltips"] == null) obj["Tooltips"] = true;
            File.WriteAllText(path, obj.ToJsonString(new System.Text.Json.JsonSerializerOptions { WriteIndented = true }));
        }
        catch { }
    }

    private string T(string ru, string en) { return _english ? en : ru; }

    private void ApplyInstallerLanguage()
    {
        Text = T("Установка Helivanta", "Helivanta Setup");
        if (_title != null) _title.Text = T("Установка и обновление", "Install and update");
        if (_subtitle != null) _subtitle.Text = T("Физическая геометрия резьбы для Autodesk Inventor 2027\r\nИнсталлятор ", "Physical thread geometry for Autodesk Inventor 2027\r\nInstaller ") + _setupDisplayVersion;
        if (_description != null) _description.Text = T("Поддерживаются физические резьбы ISO, BSW, ANSI/UN, Tr, S и Rd. Установка выполняется только для текущего пользователя и не требует прав администратора.", "Supports ISO, BSW, ANSI/UN, Tr, S and Rd physical threads. Installs for the current user only; administrator rights are not required.");
        if (_close != null) _close.Text = T("Закрыть", "Close");
        if (_delete != null) _delete.Text = T("Удалить", "Uninstall");
        if (_upgrade != null) _upgrade.Text = TranslateInstallerText(_upgrade.Text);
        if (_details != null) _details.Text = TranslateInstallerText(_details.Text);
        if (_status != null) _status.Text = TranslateInstallerText(_status.Text);
    }

    private string TranslateInstallerText(string text)
    {
        if (string.IsNullOrEmpty(text)) return text;
        string[,] pairs = {
            {"Установить ", "Install "}, {"Обновить на ", "Update to "}, {"Переустановить ", "Reinstall "},
            {"Установлена более новая", "A newer version is installed"}, {"Целевая сборка:", "Target build:"},
            {"Установленная сборка: не определена", "Installed build: unknown"}, {"Установлена сборка:", "Installed build:"},
            {"Обновление до сборки:", "Update to build:"}, {"Целевая сборка:", "Target build:"}, {" (откат запрещён)", " (downgrade blocked)"},
            {"Autodesk Inventor 2027 не найден", "Autodesk Inventor 2027 was not found"},
            {"Плагин не найден. Будет установлена сборка ", "Add-in not found. Build "},
            {". Установка выполняется для текущего пользователя. После установки перезапустите Inventor 2027.", ". will be installed for the current user. Restart Inventor 2027 after installation."},
            {"Установка невозможна: в папке Program Files не найден Autodesk Inventor 2027.", "Installation is unavailable: Autodesk Inventor 2027 was not found in Program Files."},
            {"Файлы Helivanta найдены, но номер установленной сборки определить не удалось. ", "Helivanta files were found, but the installed build could not be determined. "},
            {"Можно обновить файлы до сборки ", "Files can be updated to build "}, {". Перед операцией закройте Inventor 2027.", ". Close Inventor 2027 before continuing."},
            {"Обнаружена более старая сборка ", "An older build "}, {". Нажмите «Обновить на ", ". Click “Update to "},
            {"», чтобы заменить DLL и add-in-файл без отдельного удаления. Перед обновлением закройте Inventor 2027.", "” to replace the DLL and add-in file without uninstalling first. Close Inventor 2027 before updating."},
            {"Установленная сборка совпадает со сборкой этого инсталлятора. Можно переустановить файлы, если требуется восстановление. Перед операцией закройте Inventor 2027.", "The installed build matches this installer. Reinstall the files to repair the installation if needed. Close Inventor 2027 before continuing."},
            {"Установлена сборка ", "Installed build "}, {", она новее сборки инсталлятора ", ", which is newer than installer build "},
            {". Обновление заблокировано, чтобы не выполнить откат. При необходимости можно удалить плагин.", ". Update is blocked to prevent a downgrade. You can uninstall the add-in if needed."},
            {"Установить / обновить", "Install / update"}, {"Удалить", "Uninstall"}, {"Обновить на", "Update to"}, {"Переустановить", "Reinstall"},
            {"Установка завершена. Установленная сборка: ", "Installation completed. Installed build: "},
            {". Перезапустите Inventor 2027, чтобы загрузить изменения.", ". Restart Inventor 2027 to load the changes."},
            {"Установка завершена. Теперь можно установить ", "Uninstallation completed. You can now install "},
            {" в этом же окне. Перезапустите Inventor 2027 после завершения.", " in this window. Restart Inventor 2027 when finished."},
            {"Обновление не выполнено: ", "Update failed: "},
            {"Обновление не выполнено: обнаружен запущенный Autodesk Inventor 2027.", "Update failed: Autodesk Inventor 2027 is running."},
            {"Установка/обновление не выполнено.", "Installation/update failed."},
            {"Установка не выполнено.", "Installation failed."},
            {"Удаление не выполнено:", "Uninstallation failed:"},
            {"Удаление заблокировано: обнаружен запущенный Autodesk Inventor 2027.", "Uninstallation blocked: Autodesk Inventor 2027 is running."},
            {"Inventor может использовать Helivanta.dll. Закройте все окна Inventor и нажмите «Обновить» ещё раз.", "Inventor may be using Helivanta.dll. Close all Inventor windows and click Update again."},
            {"Файлы установленной версии не изменены.", "Installed files have not been changed."},
            {"Операция установки ещё выполняется. Дождитесь итогового статуса; закрытие сейчас отменено, чтобы не прервать замену файлов.", "The installation is still in progress. Wait for the final status; closing is disabled to avoid interrupting file replacement."},
            {"Проверка доступности файлов перед удалением...", "Checking file availability before uninstalling..."},
            {"Удаление регистрации дополнения...", "Removing add-in registration..."},
            {"Удаление файлов текущей версии...", "Removing current-version files..."},
            {"Очистка файлов предыдущих версий...", "Cleaning up files from previous versions..."},
            {"Проверка доступности файлов перед удалением...", "Checking file availability before uninstalling..."},
            {"Подготовка установки и проверка каталогов...", "Preparing installation and checking directories..."},
            {"Windows не разрешила заменить файл плагина.", "Windows did not allow the add-in file to be replaced."},
            {"Вероятно, DLL ещё используется Autodesk Inventor 2027 или файл занят другим процессом. Закройте Inventor и повторите обновление.", "The DLL may still be in use by Autodesk Inventor 2027 or another process. Close Inventor and try updating again."},
            {"Проверьте доступ к папке текущего пользователя и повторите.", "Check access to the current user's folder and try again."},
            {"Удаление завершено.", "Uninstallation completed."},
            {"Установка и обновление", "Install and update"},
            {"Закройте все окна Inventor перед удалением. Файлы не изменены.", "Close all Inventor windows before uninstalling. No files were changed."},
            {"Установка невозможна: в папке Program Files не найден Autodesk Inventor 2027.", "Installation is unavailable: Autodesk Inventor 2027 was not found in Program Files."}
        };
        // Prefer the longest source phrases first. Otherwise a short prefix such as
        // "Обновление не выполнено: " would be translated before the full failure message,
        // leaving the rest of the line in Russian in English mode.
        IEnumerable<int> replacementOrder = Enumerable.Range(0, pairs.GetLength(0))
            .OrderByDescending(i => (_english ? pairs[i,0] : pairs[i,1]).Length);
        foreach (int i in replacementOrder)
        {
            string from = _english ? pairs[i,0] : pairs[i,1];
            string to = _english ? pairs[i,1] : pairs[i,0];
            text = text.Replace(from,to);
        }
        return text;
    }

    private void UpdateState()
    {
        RefreshInstalledState();
        _delete.Visible = _installed;
        _delete.Enabled = _installed;
        _upgrade.Enabled = _inventorInstalled;
        _upgrade.Text = "Установить " + FormatVersion(_setupVersion);
        _status.ForeColor = ForegroundText;

        if (!_installed)
        {
            _details.Text = _inventorInstalled
                ? "Целевая сборка: " + _setupDisplayVersion
                : "Autodesk Inventor 2027 не найден";
            _upgrade.Text = "Установить " + FormatVersion(_setupVersion);
            _status.ForeColor = _inventorInstalled ? ForegroundText : Warning;
            _status.Text = _inventorInstalled
                ? "Плагин не найден. Будет установлена сборка " + _setupDisplayVersion + ". Установка выполняется для текущего пользователя. После установки перезапустите Inventor 2027."
                : "Установка невозможна: в папке Program Files не найден Autodesk Inventor 2027.";
            ApplyInstallerLanguage();
            return;
        }

        string installedText = FormatVersion(_installedVersion);
        if (_installedVersion == null)
        {
            _details.Text = "Установленная сборка: не определена     ·     Целевая сборка: " + _setupDisplayVersion;
            _upgrade.Text = "Обновить на " + FormatVersion(_setupVersion);
            _status.Text = "Файлы Helivanta найдены, но номер установленной сборки определить не удалось. " +
                           "Можно обновить файлы до сборки " + FormatVersion(_setupVersion) + ". Перед операцией закройте Inventor 2027.";
            ApplyInstallerLanguage();
            return;
        }

        int comparison = CompareReleaseVersion(_installedVersion, _setupVersion);
        if (comparison < 0)
        {
            _details.Text = "Установлена сборка: " + installedText + "     ·     Обновление до сборки: " + _setupDisplayVersion;
            _upgrade.Text = "Обновить на " + FormatVersion(_setupVersion);
            _status.Text = "Обнаружена более старая сборка " + installedText + ". Нажмите «Обновить на " +
                           FormatVersion(_setupVersion) + 
                           "», чтобы заменить DLL и add-in-файл без отдельного удаления. Перед обновлением закройте Inventor 2027.";
        }
        else if (comparison == 0)
        {
            _details.Text = "Установлена сборка: " + installedText + "     ·     Целевая сборка: " + _setupDisplayVersion;
            _upgrade.Text = "Переустановить " + FormatVersion(_setupVersion);
            _status.Text = "Установленная сборка совпадает со сборкой этого инсталлятора. Можно переустановить файлы, если требуется восстановление. Перед операцией закройте Inventor 2027.";
        }
        else
        {
            _details.Text = "Установлена сборка: " + installedText + "     ·     Целевая сборка: " + _setupDisplayVersion + " (откат запрещён)";
            _upgrade.Text = "Установлена более новая";
            _upgrade.Enabled = false; // never silently downgrade a newer installed build
            _status.ForeColor = Warning;
            _status.Text = "Установлена сборка " + installedText + ", она новее сборки инсталлятора " +
                           FormatVersion(_setupVersion) + ". Обновление заблокировано, чтобы не выполнить откат. При необходимости можно удалить плагин.";
        }
        ApplyInstallerLanguage();
    }

    private void SetProgress(int percent, string statusText = null)
    {
        if (_progressBar != null && !_progressBar.IsDisposed)
        {
            int value = Math.Max(_progressBar.Minimum, Math.Min(_progressBar.Maximum, percent));
            _progressBar.Value = value;
            _progressBar.Refresh();
        }
        if (!string.IsNullOrWhiteSpace(statusText) && _status != null && !_status.IsDisposed)
        {
            _status.Text = TranslateInstallerText(statusText);
            _status.Refresh();
        }
        // Install/upgrade work is dispatched to a worker; refresh paints this stage without
        // re-entering arbitrary click handlers as Application.DoEvents would.
    }

    private void PerformDelete()
    {
        if (!_installed || _operationInProgress) return;
        if (IsInventorRunning())
        {
            ResultCode = 1;
            _status.ForeColor = Warning;
            _status.Text = "Удаление заблокировано: обнаружен запущенный Autodesk Inventor 2027.\r\n\r\nЗакройте все окна Inventor перед удалением. Файлы не изменены.";
            return;
        }
        try
        {
            SetActionsEnabled(false);
            SetProgress(5, "Проверка доступности файлов перед удалением...");
            // Fail before deleting registration if the active DLL cannot be replaced/removed.
            foreach (string file in GetAllInstallDllCandidates())
            {
                if (!File.Exists(file)) continue;
                using (new FileStream(file, FileMode.Open, FileAccess.ReadWrite, FileShare.None)) { }
            }

            SetProgress(35, "Удаление регистрации дополнения...");
            File.Delete(_addinFile);
            File.Delete(Path.Combine(_addinDir, "ThreadPro.addin"));
            SetProgress(60, "Удаление файлов текущей версии...");
            if (Directory.Exists(_dest)) Directory.Delete(_dest, true);
            SetProgress(82, "Очистка файлов предыдущих версий...");
            foreach (string oldDir in GetLegacyInstallDirectories())
                if (Directory.Exists(oldDir)) Directory.Delete(oldDir, true);
            UpdateState();
            SetActionsEnabled(true);
            _status.ForeColor = Success;
            SetProgress(100, "Удаление завершено. Теперь можно установить " + FormatVersion(_setupVersion) + " в этом же окне. Перезапустите Inventor 2027 после завершения.");
            ResultCode = 0;
        }
        catch (Exception ex)
        {
            _status.ForeColor = Color.Firebrick;
            _status.Text = TranslateInstallerText("Удаление не выполнено:\r\n\r\n") + ex.Message + TranslateInstallerText("\r\n\r\nЗакройте Inventor 2027 и повторите.");
            SetActionsEnabled(true);
            ResultCode = 1;
        }
    }

    private async void PerformUpgradeOrInstall()
    {
        if (_operationInProgress || !_inventorInstalled) return;
        RefreshInstalledState();
        if (_installed && _installedVersion != null && CompareReleaseVersion(_installedVersion, _setupVersion) > 0) return;

        // Never replace add-in files while Inventor is running, whether this is an update,
        // reinstall, or first registration of a residual/partially removed install.
        if (IsInventorRunning())
        {
            ResultCode = 1;
            _status.ForeColor = Warning;
            _status.Text = TranslateInstallerText("Обновление не выполнено: обнаружен запущенный Autodesk Inventor 2027.\r\n\r\n") +
                           TranslateInstallerText("Inventor может использовать Helivanta.dll. Закройте все окна Inventor и нажмите «Обновить» ещё раз.") + "\r\n\r\n" +
                           TranslateInstallerText("Файлы установленной версии не изменены.");
            return;
        }

        _operationInProgress = true;
        string failureMessage = null;
        try
        {
            SetActionsEnabled(false);
            SetProgress(2, "Подготовка установки и проверка каталогов...");

            // Read embedded resources before starting the worker. The worker only performs file
            // operations; it never accesses WinForms controls or COM APIs.
            byte[] installerDll = ResourceBytes("Helivanta.dll");
            string addinTemplate = ResourceText("Helivanta.addin.template");
            string addinText = addinTemplate.Replace("__ASSEMBLY__", _dll);
            string[] candidates = GetAllInstallDllCandidates();
            IProgress<Tuple<int, string>> progress = new Progress<Tuple<int, string>>(item =>
            {
                if (item != null) SetProgress(item.Item1, item.Item2);
            });
            Action<int, string> report = (percent, text) => progress.Report(Tuple.Create(percent, text));

            // Give WinForms a message-loop turn before doing filesystem work. Progress callbacks
            // continue to update the bar/status while the worker is running.
            await Task.Yield();
            await Task.Run(() => InstallFilesWorker(installerDll, addinText, candidates, report));
            ResultCode = 0;
        }
        catch (Exception ex)
        {
            ResultCode = 1;
            failureMessage = FormatUpgradeFailure(ex);
        }
        finally
        {
            _operationInProgress = false;
            SetActionsEnabled(true);
            UpdateState();

            // UpdateState refreshes version metadata and writes its own status text. Only display
            // 100% after the worker has reported success and all replacement/registration steps ended.
            if (ResultCode == 0)
            {
                _status.ForeColor = Success;
                SetProgress(100, "Установка завершена. Установленная сборка: " + FormatVersion(_installedVersion) +
                               ". Перезапустите Inventor 2027, чтобы загрузить изменения.");
            }
            else if (!string.IsNullOrWhiteSpace(failureMessage))
            {
                _status.ForeColor = Warning;
                SetProgress(_progressBar == null ? 0 : Math.Min(95, _progressBar.Value), failureMessage);
            }
        }
    }

    private void InstallFilesWorker(byte[] installerDll, string addinText,
        string[] dllCandidates, Action<int, string> report)
    {
        string tempDll = _dll + ".new";
        string tempAddin = _addinFile + ".new";
        string backupDll = _dll + ".rollback-" + Guid.NewGuid().ToString("N");
        string backupAddin = _addinFile + ".rollback-" + Guid.NewGuid().ToString("N");
        string legacyAddin = Path.Combine(_addinDir, "ThreadPro.addin");
        bool hadDll = File.Exists(_dll);
        bool hadAddin = File.Exists(_addinFile);
        bool backupDllCreated = false;
        bool backupAddinCreated = false;
        bool dllReplaced = false;
        bool addinReplaced = false;
        bool rollbackCompleted = true;
        bool success = false;

        try
        {
            report(8, "Подготовка каталогов установки...");
            Directory.CreateDirectory(_dest);
            Directory.CreateDirectory(_addinDir);

            report(20, "Проверка, что DLL и регистрация не используются другим процессом...");
            var pathsToProbe = new List<string>();
            if (dllCandidates != null) pathsToProbe.AddRange(dllCandidates);
            pathsToProbe.Add(_addinFile);
            pathsToProbe.Add(legacyAddin);
            foreach (string candidate in pathsToProbe.Distinct(StringComparer.OrdinalIgnoreCase))
            {
                if (!File.Exists(candidate)) continue;
                using (new FileStream(candidate, FileMode.Open, FileAccess.ReadWrite, FileShare.None)) { }
            }

            report(38, "Подготовка временных файлов новой версии...");
            File.WriteAllBytes(tempDll, installerDll);
            File.WriteAllText(tempAddin, addinText, new UTF8Encoding(false));

            // Save exact rollback copies before touching active files. Backups use unique names so
            // a previous failed rollback is never overwritten accidentally.
            if (hadDll) { File.Copy(_dll, backupDll, false); backupDllCreated = true; }
            if (hadAddin) { File.Copy(_addinFile, backupAddin, false); backupAddinCreated = true; }

            report(58, "Замена Helivanta.dll с резервной копией текущей версии...");
            File.Move(tempDll, _dll, true);
            dllReplaced = true;

            report(73, "Регистрация новой сборки в Autodesk Inventor 2027...");
            File.Move(tempAddin, _addinFile, true);
            addinReplaced = true;

            report(88, "Очистка устаревших регистраций и предыдущих версий...");
            File.Delete(legacyAddin);
            foreach (string oldDir in GetLegacyInstallDirectories())
            {
                try { if (Directory.Exists(oldDir)) Directory.Delete(oldDir, true); }
                catch { /* Legacy cleanup must not invalidate a successful current-version install. */ }
            }

            success = true;
        }
        catch (Exception installException)
        {
            var rollbackErrors = new List<string>();
            try
            {
                if (addinReplaced)
                {
                    if (hadAddin && backupAddinCreated && File.Exists(backupAddin))
                    {
                        string restore = _addinFile + ".restore-" + Guid.NewGuid().ToString("N");
                        File.Copy(backupAddin, restore, false);
                        File.Move(restore, _addinFile, true);
                    }
                    else if (!hadAddin) File.Delete(_addinFile);
                }
            }
            catch (Exception rollbackException) { rollbackErrors.Add("registration: " + rollbackException.Message); }
            try
            {
                if (dllReplaced)
                {
                    if (hadDll && backupDllCreated && File.Exists(backupDll))
                    {
                        string restore = _dll + ".restore-" + Guid.NewGuid().ToString("N");
                        File.Copy(backupDll, restore, false);
                        File.Move(restore, _dll, true);
                    }
                    else if (!hadDll) File.Delete(_dll);
                }
            }
            catch (Exception rollbackException) { rollbackErrors.Add("DLL: " + rollbackException.Message); }

            rollbackCompleted = rollbackErrors.Count == 0;
            if (!rollbackCompleted)
                throw new IOException("Установка не завершилась, а автоматический откат выполнен не полностью. Резервные копии оставлены рядом с целевыми файлами. Исходная ошибка: " +
                    installException.Message + ". Ошибки отката: " + string.Join("; ", rollbackErrors), installException);
            throw;
        }
        finally
        {
            try { if (File.Exists(tempDll)) File.Delete(tempDll); } catch { }
            try { if (File.Exists(tempAddin)) File.Delete(tempAddin); } catch { }
            if (success || rollbackCompleted)
            {
                try { if (File.Exists(backupDll)) File.Delete(backupDll); } catch { }
                try { if (File.Exists(backupAddin)) File.Delete(backupAddin); } catch { }
            }
            // The UI displays 100% only after this worker has returned successfully and the
            // final installed-version state has been refreshed on the UI thread.
        }
    }

    protected override void OnFormClosing(FormClosingEventArgs e)
    {
        if (_operationInProgress)
        {
            e.Cancel = true;
            if (_status != null && !_status.IsDisposed)
            {
                _status.ForeColor = Warning;
                _status.Text = "Операция установки ещё выполняется. Дождитесь итогового статуса; закрытие сейчас отменено, чтобы не прервать замену файлов.";
            }
            return;
        }
        base.OnFormClosing(e);
    }

    private static bool IsInventorRunning()
    {
        Process[] processes = null;
        try
        {
            processes = Process.GetProcessesByName("Inventor");
            return processes != null && processes.Length > 0;
        }
        catch { return false; }
        finally
        {
            if (processes != null)
                foreach (Process process in processes)
                    try { process.Dispose(); } catch { }
        }
    }

    private static string FormatUpgradeFailure(Exception ex)
    {
        string details = ex == null ? "Неизвестная ошибка." : ex.Message;
        if (ex is IOException || ex is UnauthorizedAccessException)
        {
            return "Обновление не выполнено: Windows не разрешила заменить файл плагина.\r\n\r\n" +
                   "Вероятно, DLL ещё используется Autodesk Inventor 2027 или файл занят другим процессом. Закройте Inventor и повторите обновление.\r\n\r\n" +
                   "Подробности: " + details;
        }
        return "Установка/обновление не выполнено.\r\n\r\n" + details +
               "\r\n\r\nПроверьте доступ к папке текущего пользователя и повторите.";
    }

    private void SetActionsEnabled(bool enabled)
    {
        if (_delete != null) _delete.Enabled = enabled && _installed;
        if (_upgrade != null) _upgrade.Enabled = enabled && _inventorInstalled &&
            !(_installedVersion != null && CompareReleaseVersion(_installedVersion, _setupVersion) > 0);
        if (_close != null) _close.Enabled = enabled;
    }

    private byte[] ResourceBytes(string suffix)
    {
        foreach (string n in Assembly.GetExecutingAssembly().GetManifestResourceNames())
        {
            if (!n.EndsWith(suffix, StringComparison.OrdinalIgnoreCase)) continue;
            using (Stream s = Assembly.GetExecutingAssembly().GetManifestResourceStream(n))
            using (var ms = new MemoryStream()) { s.CopyTo(ms); return ms.ToArray(); }
        }
        throw new FileNotFoundException("Ресурс не найден: " + suffix);
    }

    private string ResourceText(string suffix)
    {
        return System.Text.Encoding.UTF8.GetString(ResourceBytes(suffix)).TrimStart('\uFEFF');
    }

    private Icon LoadIcon()
    {
        foreach (string n in Assembly.GetExecutingAssembly().GetManifestResourceNames())
        {
            if (!n.EndsWith("Helivanta.ico", StringComparison.OrdinalIgnoreCase)) continue;
            using (Stream s = Assembly.GetExecutingAssembly().GetManifestResourceStream(n)) return new Icon(s);
        }
        return SystemIcons.Application;
    }

    private Image IconToBitmap(Icon icon)
    {
        using (var bmp = icon.ToBitmap())
        {
            return new Bitmap(bmp);
        }
    }

}


/// <summary>A lightweight, owner-painted progress bar using the cyan wave from the Helivanta logo.</summary>
internal sealed class HelivantaProgressBar : Control
{
    private int _minimum;
    private int _maximum = 100;
    private int _value;
    private static readonly Color TrackColor = Color.FromArgb(224, 233, 241);
    private static readonly Color WaveStart = Color.FromArgb(67, 211, 255);
    private static readonly Color WaveEnd = Color.FromArgb(0, 142, 242);

    [Browsable(false)]
    [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
    public int Minimum
    {
        get { return _minimum; }
        set { _minimum = Math.Max(0, Math.Min(value, _maximum)); if (_value < _minimum) _value = _minimum; Invalidate(); }
    }
    [Browsable(false)]
    [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
    public int Maximum
    {
        get { return _maximum; }
        set { _maximum = Math.Max(_minimum + 1, value); if (_value > _maximum) _value = _maximum; Invalidate(); }
    }
    [Browsable(false)]
    [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
    public int Value
    {
        get { return _value; }
        set { _value = Math.Max(_minimum, Math.Min(_maximum, value)); Invalidate(); }
    }

    public HelivantaProgressBar()
    {
        SetStyle(ControlStyles.UserPaint | ControlStyles.AllPaintingInWmPaint |
            ControlStyles.OptimizedDoubleBuffer | ControlStyles.ResizeRedraw, true);
        BackColor = Color.FromArgb(244, 246, 248);
        MinimumSize = new Size(60, 12);
        Height = 14;
        TabStop = false;
    }

    protected override void OnPaint(PaintEventArgs e)
    {
        base.OnPaint(e);
        e.Graphics.SmoothingMode = SmoothingMode.AntiAlias;
        int inset = Math.Max(1, DeviceDpi / 96);
        Rectangle bounds = new Rectangle(inset, inset, Math.Max(1, ClientSize.Width - inset * 2), Math.Max(1, ClientSize.Height - inset * 2));
        float radius = Math.Min(bounds.Height, 8f);
        using (GraphicsPath track = Rounded(bounds, radius))
        using (var trackBrush = new SolidBrush(TrackColor))
            e.Graphics.FillPath(trackBrush, track);

        double ratio = (double)(_value - _minimum) / Math.Max(1, _maximum - _minimum);
        int width = (int)Math.Round(bounds.Width * ratio);
        if (width <= 0) return;
        Rectangle fillBounds = new Rectangle(bounds.Left, bounds.Top, Math.Min(bounds.Width, width), bounds.Height);
        using (GraphicsPath fill = Rounded(fillBounds, Math.Min(radius, fillBounds.Width / 2f)))
        using (var brush = new LinearGradientBrush(fillBounds, WaveStart, WaveEnd, LinearGradientMode.Horizontal))
            e.Graphics.FillPath(brush, fill);
    }

    private static GraphicsPath Rounded(Rectangle rectangle, float radius)
    {
        var path = new GraphicsPath();
        float d = Math.Max(1f, Math.Min(radius * 2f, Math.Min(rectangle.Width, rectangle.Height)));
        path.AddArc(rectangle.Left, rectangle.Top, d, d, 180, 90);
        path.AddArc(rectangle.Right - d, rectangle.Top, d, d, 270, 90);
        path.AddArc(rectangle.Right - d, rectangle.Bottom - d, d, d, 0, 90);
        path.AddArc(rectangle.Left, rectangle.Bottom - d, d, d, 90, 90);
        path.CloseFigure();
        return path;
    }
}
