﻿# Build the compact IExpress installer for Helivanta.
# Default: framework-dependent .NET WinForms installer (uses the .NET runtime required by Inventor 2027).
# Optional: -Method iexpress to build the compact PowerShell fallback installer.
param([ValidateSet('dotnet','iexpress')][string]$Method = 'dotnet')

# The .NET SDK emits UTF-8 diagnostics. Configure PowerShell's native-process decoding
# explicitly; otherwise Russian text can be decoded using the OEM code page (mojibake).
$script:Utf8NoBom = [System.Text.UTF8Encoding]::new($false)
try {
    [Console]::InputEncoding = $script:Utf8NoBom
    [Console]::OutputEncoding = $script:Utf8NoBom
    $OutputEncoding = $script:Utf8NoBom
    if (Test-Path variable:PSApplicationOutputEncoding) {
        $PSApplicationOutputEncoding = $script:Utf8NoBom
    }
}
catch {
    # DOTNET_CLI_UI_LANGUAGE below also requests UTF-8 output from supported .NET SDKs.
    Write-Warning 'Could not set all PowerShell console encodings; requesting UTF-8 from the .NET SDK.'
}

# NETSDK1176: EnableCompressionInSingleFile is supported only for self-contained single-file apps.
# This installer is intentionally framework-dependent to keep the EXE compact.

$ErrorActionPreference = 'Stop'
$root = Split-Path -Parent $PSScriptRoot
$out  = Join-Path $PSScriptRoot 'Helivanta-Setup.exe'
$dll  = Join-Path $root 'dist\Helivanta.dll'
$versionProps = Join-Path $root 'Directory.Build.props'
if (-not (Test-Path -LiteralPath $versionProps)) { throw 'Directory.Build.props is missing; installer version cannot be verified.' }
[xml]$versionXml = Get-Content -LiteralPath $versionProps -Raw
$releaseVersion = [string]$versionXml.Project.PropertyGroup.Version
if ([string]::IsNullOrWhiteSpace($releaseVersion)) { throw 'Version is missing from Directory.Build.props.' }
try { $expectedAssemblyVersion = [Version]([string]$versionXml.Project.PropertyGroup.AssemblyVersion) } catch { throw 'AssemblyVersion in Directory.Build.props is invalid.' }
try { $actualAssemblyVersion = [System.Reflection.AssemblyName]::GetAssemblyName($dll).Version } catch { throw ('Cannot read add-in assembly version from {0}: {1}' -f $dll, $_.Exception.Message) }
if ($actualAssemblyVersion -ne $expectedAssemblyVersion) {
    throw ('Version mismatch: source of truth is {0} ({1}), but dist\Helivanta.dll is {2}. Run build.ps1/build.bat before creating the installer.' -f $releaseVersion, $expectedAssemblyVersion, $actualAssemblyVersion)
}
Write-Host ('Helivanta release version: {0} (assembly {1})' -f $releaseVersion, $actualAssemblyVersion)

if (-not (Test-Path -LiteralPath $dll)) {
    throw 'dist\Helivanta.dll not found - run build.bat first'
}
if (Test-Path -LiteralPath $out) {
    Remove-Item -LiteralPath $out -Force
}

function Build-IExpress {
    $stage = Join-Path $PSScriptRoot 'stage'
    if (Test-Path -LiteralPath $stage) { Remove-Item -LiteralPath $stage -Recurse -Force }
    New-Item -ItemType Directory -Path $stage -Force | Out-Null

    # Only files actually needed by the fallback installer are packaged.
    # The large PNG/JPG assets are deliberately excluded: the setup UI uses the ICO.
    Copy-Item -LiteralPath $dll -Destination (Join-Path $stage 'Helivanta.dll') -Force
    Copy-Item -LiteralPath (Join-Path $root 'Helivanta.addin.template') -Destination (Join-Path $stage 'Helivanta.addin.template') -Force
    Copy-Item -LiteralPath (Join-Path $PSScriptRoot 'setup.ps1') -Destination (Join-Path $stage 'setup.ps1') -Force
    Copy-Item -LiteralPath (Join-Path $PSScriptRoot 'setup.cmd') -Destination (Join-Path $stage 'setup.cmd') -Force
    Copy-Item -LiteralPath (Join-Path $root 'Assets\Helivanta.ico') -Destination (Join-Path $stage 'Helivanta.ico') -Force

    $files = Get-ChildItem -LiteralPath $stage -File | Sort-Object Name
    $fileLines = New-Object System.Text.StringBuilder
    $sourceLines = New-Object System.Text.StringBuilder
    for ($i=0; $i -lt $files.Count; $i++) {
        [void]$fileLines.AppendLine(('FILE{0}={1}' -f $i, $files[$i].Name))
        [void]$sourceLines.AppendLine(('%FILE{0}%=' -f $i))
    }

    $sed = @()
    $sed += '[Version]'
    $sed += 'Class=IEXPRESS'
    $sed += 'SEDVersion=3'
    $sed += '[Options]'
    $sed += 'PackagePurpose=InstallApp'
    $sed += 'ShowInstallProgramWindow=0'
    $sed += 'HideExtractAnimation=1'
    $sed += 'UseLongFileName=1'
    $sed += 'InsideCompressed=1'
    $sed += 'CAB_FixedSize=0'
    $sed += 'CAB_ResvCodeSigning=0'
    $sed += 'RebootMode=N'
    $sed += 'InstallPrompt=%InstallPrompt%'
    $sed += 'DisplayLicense=%DisplayLicense%'
    $sed += 'FinishMessage=%FinishMessage%'
    $sed += 'TargetName=%TargetName%'
    $sed += 'FriendlyName=%FriendlyName%'
    $sed += 'AppLaunched=%AppLaunched%'
    $sed += 'PostInstallCmd=%PostInstallCmd%'
    $sed += 'AdminQuietInstCmd=%AdminQuietInstCmd%'
    $sed += 'UserQuietInstCmd=%UserQuietInstCmd%'
    $sed += 'SourceFiles=SourceFiles'
    $sed += '[Strings]'
    $sed += 'InstallPrompt='
    $sed += 'DisplayLicense='
    $sed += 'FinishMessage='
    $sed += ('TargetName={0}' -f $out)
    $sed += 'FriendlyName=Helivanta Setup'
    $sed += 'AppLaunched=cmd.exe /d /c setup.cmd'
    $sed += 'PostInstallCmd=<None>'
    $sed += 'AdminQuietInstCmd='
    $sed += 'UserQuietInstCmd='
    $sed += $fileLines.ToString().TrimEnd("`r","`n")
    $sed += '[SourceFiles]'
    $sed += ('SourceFiles0={0}' -f $stage)
    $sed += '[SourceFiles0]'
    $sed += $sourceLines.ToString().TrimEnd("`r","`n")

    $sedPath = Join-Path $PSScriptRoot 'Helivanta.sed'
    [System.IO.File]::WriteAllText($sedPath, (($sed -join "`r`n") + "`r`n"), [System.Text.Encoding]::Default)

    $iexpress = Join-Path $env:WINDIR 'System32\iexpress.exe'
    if (-not (Test-Path -LiteralPath $iexpress)) { throw 'IExpress is not available on this Windows installation.' }

    Write-Host 'Building compact IExpress installer...'
    $proc = Start-Process -FilePath $iexpress -ArgumentList @('/N','/Q',(Split-Path -Leaf $sedPath)) -WorkingDirectory $PSScriptRoot -Wait -PassThru -WindowStyle Hidden
    if ($proc.ExitCode -ne 0) { throw ('IExpress exited with code {0}.' -f $proc.ExitCode) }
    if (-not (Test-Path -LiteralPath $out)) { throw 'IExpress did not create the installer EXE.' }

    $size = (Get-Item -LiteralPath $out).Length
    if ($size -lt 100KB) { throw ('Installer EXE is unexpectedly small: {0} bytes.' -f $size) }
    if ($size -gt 5MB) { Write-Warning ('Installer is larger than expected: {0:N1} MB.' -f ($size/1MB)) }
    Write-Host ('Created compact installer: {0} ({1:N1} KB)' -f $out, ($size/1KB))
    Write-Host 'If the package fails to start, the launcher writes diagnostics to %TEMP%\Helivanta-Setup.log.'
}

function Build-DotNet {
    $proj = Join-Path $PSScriptRoot 'Setup\Setup.csproj'
    $pub = Join-Path $PSScriptRoot 'Setup\publish'
    if (Test-Path -LiteralPath $pub) { Remove-Item -LiteralPath $pub -Recurse -Force }
    # .NET 8+ switches its console encoding to UTF-8 when DOTNET_CLI_UI_LANGUAGE is set.
    # Keep this override local to publish and restore the caller's previous environment.
    $hadUiLanguage = Test-Path Env:\DOTNET_CLI_UI_LANGUAGE
    $oldUiLanguage = $env:DOTNET_CLI_UI_LANGUAGE
    try {
        $env:DOTNET_CLI_UI_LANGUAGE = 'ru-RU'
        & dotnet publish $proj -c Release -r win-x64 -p:PublishSingleFile=true -p:SelfContained=false -p:PublishTrimmed=false -p:PublishReadyToRun=false ("-p:SetupDll={0}" -f $dll) -o $pub | Out-Host
        $publishExitCode = $LASTEXITCODE
        if ($publishExitCode -ne 0) { throw 'dotnet publish failed.' }
    }
    finally {
        if ($hadUiLanguage) {
            $env:DOTNET_CLI_UI_LANGUAGE = $oldUiLanguage
        }
        else {
            Remove-Item Env:\DOTNET_CLI_UI_LANGUAGE -ErrorAction SilentlyContinue
        }
    }
    $built = Join-Path $pub 'Helivanta-Setup.exe'
    if (-not (Test-Path -LiteralPath $built)) { throw 'The .NET installer EXE was not created.' }
    Copy-Item -LiteralPath $built -Destination $out -Force
    Write-Host ('Created compact framework-dependent .NET single-file installer: {0}' -f $out)
    $size = (Get-Item -LiteralPath $out).Length
    Write-Host ('Installer size: {0:N1} KB' -f ($size/1KB))
    if ($size -gt 5MB) { Write-Warning ('Installer is larger than expected: {0:N1} MB.' -f ($size/1MB)) }
}

if ($Method -eq 'iexpress') { Build-IExpress } else { Build-DotNet }

$summaryPath = Join-Path $root 'test-results\build-summary.txt'
Write-Host ''
Write-Host '========== HELIVANTA RELEASE SUMMARY =========='
Write-Host ('Installer: PASS ({0})' -f $out)
if (Test-Path -LiteralPath $summaryPath) {
    $summaryLines = Get-Content -LiteralPath $summaryPath
    $summaryVersion = ($summaryLines | Where-Object { $_ -match '^Version:\s*(.+)$' } | Select-Object -First 1) -replace '^Version:\s*', ''
    if ($summaryVersion -eq $releaseVersion) {
        $summaryLines | ForEach-Object { Write-Host $_ }
    } else {
        Write-Host ('Tests: UNKNOWN — build summary version does not match installer version {0}; rerun build.ps1.' -f $releaseVersion)
    }
} else {
    Write-Host 'Tests: UNKNOWN — no build-summary.txt found; run build.ps1 before packaging for verified test counts.'
}
Write-Host '==============================================='
exit 0
