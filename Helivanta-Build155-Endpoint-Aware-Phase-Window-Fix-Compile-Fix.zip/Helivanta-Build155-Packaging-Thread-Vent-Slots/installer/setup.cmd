@echo off
setlocal EnableExtensions
cd /d "%~dp0"
set "LOG=%TEMP%\Helivanta-Setup.log"

del /q "%LOG%" >nul 2>&1

echo Helivanta Setup started >"%LOG%"
echo.>>"%LOG%"

"%SystemRoot%\System32\WindowsPowerShell\v1.0\powershell.exe" -NoLogo -NoProfile -STA -ExecutionPolicy Bypass -File "%~dp0setup.ps1" >>"%LOG%" 2>&1
set "RC=%ERRORLEVEL%"

if not "%RC%"=="0" (
    "%SystemRoot%\System32\WindowsPowerShell\v1.0\powershell.exe" -NoLogo -NoProfile -STA -ExecutionPolicy Bypass -Command "Add-Type -AssemblyName System.Windows.Forms; $m=[IO.File]::ReadAllText($env:TEMP + '\\Helivanta-Setup.log'); [Windows.Forms.MessageBox]::Show($m,'Helivanta Setup - error',[Windows.Forms.MessageBoxButtons]::OK,[Windows.Forms.MessageBoxIcon]::Error)" >nul 2>&1
    exit /b %RC%
)

del /q "%LOG%" >nul 2>&1
exit /b 0
