﻿param(
    [switch]$SkipGeometryTests
)

$ErrorActionPreference = 'Stop'
# Keep Russian compiler/MSBuild output readable in legacy Windows console hosts.
# build.bat also switches cmd.exe to code page 65001 before launching PowerShell.
$script:HelivantaUtf8 = [System.Text.UTF8Encoding]::new($false)
try { [Console]::InputEncoding = $script:HelivantaUtf8 } catch { }
try { [Console]::OutputEncoding = $script:HelivantaUtf8 } catch { }
try { $OutputEncoding = $script:HelivantaUtf8 } catch { }
$root = $PSScriptRoot
$out = Join-Path $root 'dist'
$results = Join-Path $root 'test-results'
New-Item -ItemType Directory -Path $results -Force | Out-Null
$summary = [System.Collections.Generic.List[string]]::new()
[xml]$versionXml = Get-Content -LiteralPath (Join-Path $root 'Directory.Build.props') -Raw
$releaseVersion = [string]$versionXml.Project.PropertyGroup.Version
$summary.Add(('Version: {0}' -f $releaseVersion))
$summary.Add(('Built at: {0}' -f (Get-Date -Format 'yyyy-MM-dd HH:mm:ss')))
$summaryPath = Join-Path $results 'build-summary.txt'
if (Test-Path -LiteralPath $summaryPath) { Remove-Item -LiteralPath $summaryPath -Force }
$buildLog = Join-Path $results 'build.log'

function Invoke-LoggedCommand([string]$Label, [string]$File, [string[]]$Arguments, [string]$LogPath) {
    Write-Host ("RUN: {0}" -f $Label)
    & $File @Arguments 2>&1 | Tee-Object -FilePath $LogPath | Out-Host
    $code = $LASTEXITCODE
    if ($code -ne 0) { throw ("{0} failed with exit code {1}. Full log: {2}" -f $Label, $code, $LogPath) }
}

try {
    Invoke-LoggedCommand 'Helivanta build' 'dotnet' @('build', (Join-Path $root 'src\Helivanta.csproj'), '-c', 'Release', '-o', $out) $buildLog
    $summary.Add('Build: PASS')
    Write-Host "Build finished: $out\Helivanta.dll"

    if (-not $SkipGeometryTests) {
        $geometryLog = Join-Path $results 'standard-geometry-test-console.log'
        $testProject = Join-Path $root 'tests\StandardGeometryTest\StandardGeometryTest.csproj'
        Invoke-LoggedCommand 'Standard Geometry Test' 'dotnet' @('run', '--project', $testProject, '-c', 'Release', '--', '--out', $results) $geometryLog
        $geometryTextPath = Join-Path $results 'standard-geometry-test-report.txt'
        if (-not (Test-Path -LiteralPath $geometryTextPath)) { throw 'Standard Geometry Test text report was not created.' }
        $geometryText = Get-Content -LiteralPath $geometryTextPath -Raw
        $geometryMatch = [regex]::Match($geometryText, '(?m)^PASS:\s*(\d+)\s+FAIL:\s*(\d+)\s+SKIP:\s*(\d+)')
        if (-not $geometryMatch.Success) { throw 'Could not parse Standard Geometry Test counts; refusing to report an unverified summary.' }
        $geometryPass = [int]$geometryMatch.Groups[1].Value
        $geometryFail = [int]$geometryMatch.Groups[2].Value
        $geometrySkip = [int]$geometryMatch.Groups[3].Value
        $summary.Add(('Standard Geometry: PASS={0} FAIL={1} SKIP={2}' -f $geometryPass, $geometryFail, $geometrySkip))
        if ($geometryFail -gt 0) { throw 'Standard Geometry Test reported failures.' }

        $metadataLog = Join-Path $results 'metadata-policy-test-console.log'
        $metadataProject = Join-Path $root 'tests\ThreadMetadataTest\ThreadMetadataTest.csproj'
        Invoke-LoggedCommand 'Metadata and policy tests' 'dotnet' @('run', '--project', $metadataProject, '-c', 'Release') $metadataLog
        $metadataText = Get-Content -LiteralPath $metadataLog -Raw
        $match = [regex]::Match($metadataText, '(?m)^PASS:\s*(\d+)\s+FAIL:\s*(\d+)')
        if (-not $match.Success) { throw 'Could not parse Metadata and policy test summary; refusing to report an unverified count.' }
        $metadataPass = [int]$match.Groups[1].Value
        $metadataFail = [int]$match.Groups[2].Value
        $summary.Add(('Metadata/Policy: PASS={0} FAIL={1} SKIP=0' -f $metadataPass, $metadataFail))
        if ($metadataFail -gt 0) { throw 'Metadata and policy tests reported failures.' }
    }
    else {
        $summary.Add('Tests: SKIP (requested by -SkipGeometryTests)')
    }

    $summary.Add('Installer: NOT BUILT by build.ps1 (run installer\make-installer.bat after this script)')
    Write-Host ''
    Write-Host '========== HELIVANTA BUILD SUMMARY =========='
    foreach ($line in $summary) { Write-Host $line }
    Write-Host ("Detailed logs: {0}" -f $results)
    Write-Host '============================================='
    $summary -join [Environment]::NewLine | Set-Content -LiteralPath (Join-Path $results 'build-summary.txt') -Encoding UTF8
}
catch {
    $summary.Add(('FAILED: ' + $_.Exception.Message))
    Write-Host ''
    Write-Host '========== HELIVANTA BUILD SUMMARY =========='
    foreach ($line in $summary) { Write-Host $line }
    Write-Host ("Detailed logs: {0}" -f $results)
    Write-Host '============================================='
    $summary -join [Environment]::NewLine | Set-Content -LiteralPath (Join-Path $results 'build-summary.txt') -Encoding UTF8
    throw
}
