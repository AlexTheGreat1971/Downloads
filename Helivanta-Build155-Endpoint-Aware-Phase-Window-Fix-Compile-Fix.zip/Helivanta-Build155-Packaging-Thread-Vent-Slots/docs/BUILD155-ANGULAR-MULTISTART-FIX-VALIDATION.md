# Build155 — angular multi-start correction validation

## Source checks performed

- Confirmed that the former `i * pitch` axial profile/axis shift is removed.
- Confirmed that each start uses a rotated radial direction at `360° * i / starts`, with a common axial origin and the same requested axial extent.
- Confirmed that coil pitch uses the lead (`P * starts`) and revolutions use `axialLength / lead`.
- Confirmed that selecting the opposite circular end reverses the coil axis direction and the clockwise flag is compensated.
- Added per-start Coil health, volume-delta, and solid-body-count checks and contextual exceptions around the Inventor Coil call.
- Added a pure vector rotation helper to the policy test project and a regression test for 0°/120°/240° radial start directions.
- C# delimiter/source-contract checks and independent numerical phase tests passed in the editing environment.

## Not run / not claimed

The environment has no .NET SDK/compiler and no Autodesk Inventor 2027 runtime. Therefore Windows compilation, Standard Geometry tests, Metadata/Policy test executable, and actual solid-model generation were **not run** here. The source-level numerical tests do not substitute for Inventor's CAD kernel.

## Required Inventor acceptance matrix

1. Create a disposable part with a straight cylindrical face and two circular end edges.
2. Build 1, 2, and 3 starts from each end edge, with `P = 2.7 mm`, `L = 10 mm`, diameter about `28 mm`.
3. For 3 starts confirm the phase planes are 0°/120°/240°, the strands share axial start/end stations, their axial spacing at a fixed azimuth is the pitch, and every coil reports UpToDate.
4. Compare part volume and body count before/after each start; all starts must add positive volume and remain fused into one body.
5. Confirm the right/left-hand selection remains physically consistent when switching the selected end.
6. Save, Undo, and Redo on a disposable part; inspect the thread at both ends and in a side view.

Do not treat this prototype as release-qualified until this matrix and the Windows build/test scripts pass.
