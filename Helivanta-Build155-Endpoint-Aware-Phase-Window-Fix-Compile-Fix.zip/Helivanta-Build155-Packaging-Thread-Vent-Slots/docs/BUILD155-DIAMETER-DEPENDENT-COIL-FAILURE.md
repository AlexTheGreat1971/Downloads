# Build155 — diameter-dependent Coil failure (E_FAIL)

## Source-level diagnosis

The preflight policy originally made profile height proportional to diameter but constrained it only by an absolute 2.5 mm cap. The Coil section width, however, stayed at 0.55 × pitch and the crest width stayed at 0.62 × the root half-width. With P=2.7 mm and the default 0.025 ratio:

| Diameter | Height H | Embedded root | Total radial depth | Old root width |
|---:|---:|---:|---:|---:|
| 22 mm | 0.55 mm | 0.11 mm | 0.66 mm | 1.485 mm |
| 31 mm | 0.775 mm | 0.155 mm | 0.93 mm | 1.485 mm |
| 52 mm | 1.30 mm | 0.26 mm | 1.56 mm | 1.485 mm |

So increasing diameter made the section deeper without changing its base width, while leaving very little axial flank run (crest width 62% of root width). This is a plausible source of the diameter-dependent `E_FAIL` in the sweep/Boolean kernel. It is a source-based diagnosis, not a claim that the Inventor runtime stack was captured in this environment.

## Changes

- Added a pitch-relative maximum total radial depth (0.80 × P, including the embedded root) while keeping the diameter ratio active within that safe envelope.
- Added a dynamic root width: clamped to 0.55–0.80 × pitch and widened toward 1.8 × total radial depth, so larger sections have a longer flank run without consuming the full adjacent-start pitch.
- Narrowed the crest to 25% of the root width (half-width multiplier 0.25) instead of 62%.
- Extended the Coil axis sketch line beyond both axial ends of the section profile.
- Reduced the end margin multiplier to track the actual half-width rather than 1.5 × the full width.
- Wrapped the post-Coil update/health/volume/body-count checks with per-start dimensions and stage context, so any remaining COM failure should identify where it occurred.
- Added policy regression cases for D22/D31/D52 at P=2.7 mm and for the pitch-relative height limit.

## Verification limits

Static source/manifest/ZIP checks only. No Inventor 2027 runtime or .NET SDK is available in this environment, so successful Coil regeneration still requires an on-Windows Inventor test. If E_FAIL persists, capture the expanded dialog message; it now includes the start number, diameter, pitch, height, embed, profile width, depth/pitch ratio, and whether the failure happened at Coil creation or post-creation verification.
