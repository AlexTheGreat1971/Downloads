# Build155 — Delete Face + Heal experiment

## 2026-10-21 follow-up: paired endpoint phase window

The all-inverted-sign experiment regressed all four combinations. `PackagingThreadGeometryBuilder.TryDeleteTerminalFacesWithHeal` now selects phase-correction sign and angular-window direction as a pair: forward window/inverse correction for RH-start and LH-end; reverse window/original hand sign for RH-end and LH-start. This preserves the previously observed working pair while attempting the two missing combinations. The local quarter-sector threshold is unchanged. Confirm actual face selection and Heal results in Inventor 2027; candidate selection remains a heuristic until validated against the real model.

## Goal
Replace the fragile local angular end-cut when possible with Inventor's native Delete Face operation using `Heal = true`, matching the manual workflow reported by the user.

## Current strategy
- For each planned short terminal fragment, probe face interior points in the fragment's axial range and angular sector.
- Attempt the native Delete Face feature only when exactly three faces match. The count guard is intentional: ambiguous selection must not delete a broader region of the thread.
- Call `DeleteFaceFeatures.Add(faceCollection, true)` and update the document.
- Verify healthy feature status, measurable volume change, and unchanged solid-body count.
- The follow-up constrains candidate faces to a narrow radial band around the thread crest and logs scan/candidate counts plus each accepted face's station/radius/angle/type.
- The legacy sector-cut fallback is disabled in the current candidate. If the three faces cannot be identified or Heal fails safely, the main thread is retained and the residual tail is logged. This avoids recreating the prior `kDriverLostHealth` failure path while validating native Heal selection.

## Cancellation
The action button is explicitly amber/enabled during the build and requests cancellation. After success it changes to `Отменить последнее построение`, enabled only while the exact packaging transaction is still the newest committed transaction in the same active part. The geometry builder pumps UI messages at checkpoints between Inventor calls. A single long synchronous Inventor kernel call still cannot be forcibly interrupted; cancellation is honored at the next checkpoint and the active transaction is rolled back. See `BUILD155-DELETE-FACE-HEAL-UNDO-FOLLOWUP.md`.

## Validation status
- Source-level edits and archive checksums are verified in the follow-up package.
- .NET build: not run here (`dotnet` executable unavailable in this environment).
- Inventor 2027 runtime test: not run here. User validation is required, especially whether the three-face probe matches the three manually selected faces on each tail and whether undo safety behaves as described.
