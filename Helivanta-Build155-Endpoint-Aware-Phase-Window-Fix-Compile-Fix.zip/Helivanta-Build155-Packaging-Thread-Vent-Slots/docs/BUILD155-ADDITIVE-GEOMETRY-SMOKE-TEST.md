# Build155 — smoke test: experimental additive packaging thread

> Experimental only. Run on a disposable copy of a simple part. Not release-qualified.

## 1. Build and install
1. Extract the archive to a new folder; do not overlay an older build.
2. On Windows with the Inventor 2027 SDK/package restore available, run the repository's normal `build.ps1` from the project root.
3. Record the complete build log. Do not treat a previous installer as proof the current source was packaged.
4. Install the build using the project's normal installer workflow, then start Inventor 2027.

## 2. First geometry case
1. Create a new simple cylindrical solid with a straight outside cylindrical face, e.g. Ø28 mm and at least 18 mm of straight cylindrical length. Avoid chamfers, grooves and thin walls for the first test.
2. Save a copy under a disposable filename.
3. Select exactly one circular end edge bounding the outside cylindrical face. Open **Helivanta → Упаковочная резьба (эксперимент)**. The dialog auto-detects outer shaft vs inner bore from the oriented cylindrical face (`Face.IsParamReversed`); there is no manual type selector.
4. Use one start, right-hand, pitch 2.7 mm, height ratio 0.025, axial length 8 mm. Keep clearance at 0.0 mm for this nominal-geometry test.
5. Leave both **Плавный сбег в начале** and **Плавный сбег в конце** enabled for the first pass. Click **Проверить**; it should show resolved dimensions and inferred type. Then click **Построить резьбу**. With P=2.7 mm and 3 starts (lead=8.1 mm), each enabled external run-out should be 0.675 mm (1/12 turn), while each internal run-out should be 1.350 mm (1/6 turn).
6. Inspect the feature tree and model. Verify the coil is a positive external ridge and both ends fade smoothly, the solid-body count did not change, volume increased, and Undo removes the operation as one transaction.
7. Repeat on a fresh copy with left-hand direction, then 2 and 3 starts; verify the hand stays correct from both end edges.
8. Create a new part with a through-bore or blind cylindrical bore. Select its circular end edge and confirm the dialog auto-identifies it as an **internal bore**. Build one start first. Confirm the ridge projects inward into the bore and fuses with its wall; do not accept a cut groove, a separate body, or a sharp end lip. Repeat with both run-out checkboxes independently enabled/disabled and then test 2/3 starts.

## 3. Expected safe failure
- Select a non-cylindrical face or more than one object: command must refuse to build.
- Use a cylindrical face too short for the requested helix: command must report the limitation and leave the model unchanged.
- Trigger a Coil failure: the operation should abort its transaction; confirm the model is unchanged.
- Choose an inner profile with invalid radial geometry or an insufficient wall: policy must reject it before creating geometry. It must never cut a groove in the internal mode.

## 4. Capture evidence
For each run record Inventor version, build log, selected-face diameter/length, parameters, result/error text, before/after solid-body count, before/after volume, feature-tree screenshot, and Undo result. The previous external RH/LH/end-edge combinations were user-confirmed via the attached diagnostic log. Internal-rib fusion, Loft runout continuity, and transaction rollback for the new Loft features are still unverified until this smoke test passes in Inventor.


## Internal rib and smooth run-out acceptance matrix (current source)

1. Start from a disposable part with a simple through-hole / bore and enough axial cylinder length. Select the circular edge at one end of the *bore wall*. The measured wall must be at least 0.6 mm, and the embed must be no greater than half the entered wall thickness.
2. Build a one-start internal thread with both smooth run-outs enabled. The result must be an additive helical rib projecting **into** the hole, with its root fused to the bore wall. Verify the bore was not cut larger, no separate body was created, and undo removes the entire operation in one step.
3. Repeat with 2 and 3 starts and with RH/LH from both bore ends. Handedness must not depend on selected end.
4. Repeat with start run-out only, end run-out only, both disabled and both enabled. Each enabled end should taper crest height to nearly flush with the bore wall; both ends must connect to the full-depth core without a gap.
5. Repeat external construction as a regression test. Confirm the existing external RH/LH / edge-end behavior still matches the user's accepted result.
6. Capture a log for any failure. The log should identify the stage (core Coil, individual run-out Loft, final model health/body/volume or transaction) and include phase, direction, dimensions and internal/external mode.

This checklist is a release gate, not a statement that these Inventor runtime tests have already passed.
