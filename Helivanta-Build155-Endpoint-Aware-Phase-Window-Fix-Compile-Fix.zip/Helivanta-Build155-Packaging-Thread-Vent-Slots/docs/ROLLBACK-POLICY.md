﻿# Rollback policy — Helivanta

## Package policy

Each release/candidate ZIP is a standalone source package with one root folder. Keep rollback ZIPs outside the ordinary source package; do not embed old ZIPs inside a new release and do not overwrite them. `rollback/` paths mentioned in older handoffs were historical references and are not expected to be included in the current package.

## Baselines and known status

- Build95 / 2.0.95.0 is the last user-reported Windows build/test-count baseline in the available handoff. It is not a fully accepted tapered-edit release.
- Build96 / 2.0.96.0 did not fix no-op external NPT 1/2 editing.
- Build97 / 2.0.97.0 introduced a normal-build regression according to the user's Inventor log; keep it for evidence only.
- Build98 / 2.0.98.0 removed the regression-triggering postcondition but did not establish the edit fix.
- Build99 / 2.0.99.0 failed Windows compilation with three CS0104 errors.
- Build100 / 2.0.100.0 compiled sufficiently for the user to perform Inventor build/edit tests: ordinary conical construction worked but edit still failed folder mapping.
- Build101 / 2.0.101.0 was then confirmed by the user to restore tapered edit with smooth run-out; simplified run-out still failed. This is a user-reported functional result, not a comprehensive release acceptance.
- Build102 / 2.0.102.0 adds smooth-only run-out, localized JIS type resolution, and strict/free taper modes. It has not been compiled or validated in this environment.

Separately preserved historical rollback archives include Build44, Build43 and Fix38 UI3 per the prior project handoff; confirm their exact bytes by SHA-256 against the archived handoff before restoring. Do not replace or rename them in place.

## Package contents

Exclude generated `bin/`, `obj/`, `dist/`, `test-results/`, installer `publish/`/`stage/` outputs and generated DLL/EXE files. Each ZIP must have one root folder and a `MANIFEST-SHA256.txt` covering all packaged files except the manifest itself.

## Rollback safety

Never save a disposable Inventor document after an edit failure unless `Transaction.Abort`, original metadata restoration, feature count, and End-of-Part restoration are all confirmed. If Abort or verification is uncertain, close the test copy without saving and preserve the full diagnostics.
