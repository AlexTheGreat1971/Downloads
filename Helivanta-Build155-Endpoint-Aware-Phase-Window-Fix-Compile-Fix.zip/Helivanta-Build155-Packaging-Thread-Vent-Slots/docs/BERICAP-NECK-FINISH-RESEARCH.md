# BERICAP neck finishes — research note for a future Helivanta family

Research date: 2026-10-18. This note is preparatory only: no BERICAP geometry, standard tables, or UI options are implemented in Build148.

## Main conclusion

“BERICAP thread” should not be modeled as one universal thread profile. BERICAP's catalog references multiple neck-finish families. Its official pages distinguish, for example, PCO 1881, PCO 1810, and GME 30.40. A future Helivanta implementation must identify the exact neck finish and use a dimensioned drawing/specification for that family, rather than derive a generic thread from the brand name.

## What the reviewed sources establish

- BERICAP's product pages identify PCO 1881 closures intended for a 28 mm PET neck finish. One specific PUP NG 28/34 1881 MIB page explicitly calls it a **2-start thread neck**. This supports treating thread starts as a real family parameter, but it does not provide the complete profile dimensions needed to build a standards-accurate thread. Source: https://bericap.com/product/pup-ng-28-34-1881-mib/
- A separate BERICAP page describes PCO 1810 compatibility for a 28 mm PET neck. PCO 1810 is therefore a distinct selectable finish, not simply an alias for PCO 1881. Source: https://bericap.com/product/pup-ng-28-38-1810-mib/
- BERICAP's GME 30.40 article describes a neck-finish design with a 26 mm thread diameter and states that CETIE was in the process of defining the neck standard at the time of publication. It also discusses neck-support-ring diameter changes. Those statements are useful context, but the article is not a substitute for the current dimensioned drawing or current specification status. Source: https://bericap.com/2021/02/03/bericap-tethered-solution-available-for-the-gme-30-40-neck-finish/
- BERICAP's product catalogue exposes a “Neck Finish” classification with multiple families, including PCO 1810, PCO 1881, GME 30.40, and other neck finishes. Source: https://bericap.com/capfinder/
- A general packaging-industry guide describes the common drawing dimensions T, E, I, H, and S: T is thread outside diameter; E is the neck outside diameter at the thread-root region; I is the neck bore diameter; H describes neck-finish height; S locates the first thread relative to the top of the finish. These names are a useful reading aid, not BERICAP dimensions and not sufficient by themselves to reconstruct every thread profile. Source: https://www.berlinpackaging.com/neck-finish-guide/

## Engineering implications for Helivanta

1. Make a family such as **Bottle neck finish** separate from ISO metric, Tr, BSW, S, Rd, NPT, and JIS taper threads. The selectable designation should be an explicit finish code, for example PCO 1881 or PCO 1810, not merely “BERICAP”.
2. Before implementation, obtain and archive the current official dimensioned drawing/specification for the exact targeted finish. Record its source, revision/date, units, datums, dimensions, tolerances, thread starts/lead, lead-in/relief, and any sealing/bead geometry shown. Do not infer pitch, flank form, starts, or tolerances from the nominal neck diameter.
3. Distinguish the **external bottle/preform neck** from the **mating internal closure/cap**. They are complementary designs but not the same geometry. For printed parts, decide whether the target is a cap fitting an existing commercial bottle or a printed bottle neck intended to accept a commercial closure.
4. Model only geometric features supported by the drawing. Bottle closure performance may depend on the seal land/bore seal, top sealing surface, support ring, tamper-evident band, and closure skirt—not only on the helix. Do not claim liquid-tightness, pressure suitability, or food-contact suitability from thread fit alone.
5. Keep documented nominal geometry and manufacturing compensation separate. Add 3D-printing clearance as an explicitly named process preset with editable values, not by silently altering nominal finish dimensions. Validate with a physical mating part or gauge and account for printer/material variation.
6. Preserve source attribution and avoid implying BERICAP endorsement. Brand/product naming, technical drawings, and standards documents may have usage restrictions; review the applicable terms before redistributing drawings or embedding proprietary dimensional tables.

## Proposed next-stage scope

Start by choosing one concrete use case and exact finish code. Acquire its current official dimensioned drawing. Create a source-backed parameter table with units and tolerances; review the mating cap/bottle side before coding; implement the geometry in a separate family with explicit external/internal mating roles; add fit-clearance presets only after the nominal profile is independently validated; then add unit tests for dimensions and build tests against representative physical models. Do not implement any BERICAP profile until the exact reference drawing is available.
