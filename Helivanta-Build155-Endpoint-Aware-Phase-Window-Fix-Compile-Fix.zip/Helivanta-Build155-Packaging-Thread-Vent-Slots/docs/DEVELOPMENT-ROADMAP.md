﻿# Helivanta development roadmap — 2026-10-16

## Active candidate: Build106 / 2.5.106.0 — main dialog engineering layout

Build104 / 2.0.104.0 is the user-confirmed rollback/release baseline. Build105 established shared palette tokens and help/About improvements. Build106 adds a visible main-dialog layout redesign: a branded engineering header, numbered section headings and stronger grouping. Build106 is source-only here; Windows compilation, tests, installer and Inventor UI validation remain pending. Build107 is planned for secondary dialogs, taper/profile visuals and final DPI adaptation.

The geometry validation work below remains an independent outstanding track; UI changes must not disturb the tapered builder, strict/free modes, wall guard or browser-folder reuse.

### P0 — validate tapered geometry modes and table lookup

1. Build on Windows/.NET 10 and run the actual standard and extended policy suites; the Build95 result counts do not carry forward.
2. Confirm normal build and no-op edit for external NPT 1/2 with smooth run-out, then check chamfer edits, rollback, End-of-Part, Undo/Redo and save/reopen. Keep Build101 tree-based folder reuse unchanged.
3. Test JIS designations on external Ø45 mm and Ø52 mm and internal Ø45 mm and Ø52 mm. Capture `taper-thread-table-type-resolved`, `taper-designations-refreshed` or `taper-designations-empty`. Confirm that the correct localized external/internal Thread.xls identifier is used and that a table row is not silently substituted.
4. Test `StrictStandard` versus `FreeGeometry` on disposable IPT copies. Strict mode should start from table-derived dimensions and the table length is applied when entering strict mode; later manual length overrides still show the existing nonstandard-length warning. Free mode preserves the far-end stock radius and calculates the selected-edge radius using the 1:16 diametral taper. Verify outer and inner geometry, wall-thickness guard, and pre-mutation confirmation.
5. Test only the smooth tapered run-out path. Confirm Loft success and the segmented Coil fallback separately; visually inspect the fallback B-rep. The simplified run-out control is removed, while old metadata remains readable.

### P1 — diagnostics and robustness

- Keep BrowserNode diagnostics passive: no extra Update/Refresh for logging and no new postcondition using `GetBrowserNodeFromObject` as the only ownership test.
- Classify empty catches around table reading, edit transactions and folder grouping before changing them.
- Check `ThreadParams` mutation and static `Last*` references with targeted reproduction tests; do not mass-release COM references.
- Improve installer backup/restore around replacement of old folders as a separate change.

### P2 — later features

- Add standard-conformity dimensions/gaging only after the reference planes and actual table fields have been verified in Inventor.
- Consider metadata schema migration only with concrete new fields requiring it; the additive geometry mode currently defaults missing legacy values to strict mode.
- Simplify installer/version paths only after identifying all supported distribution channels.

## Guardrails

- `ThreadStandards.cs` and the cylindrical B-rep core remain protected without reproducible defect plus regression.
- Tapered technological clearance remains zero. Diagnostics stay read-only.
- Any incomplete edit or folder repair must abort; never save a test IPT when rollback or End-of-Part restoration is uncertain.
- Each candidate gets a unique incremented version; rollback archives are never overwritten.
