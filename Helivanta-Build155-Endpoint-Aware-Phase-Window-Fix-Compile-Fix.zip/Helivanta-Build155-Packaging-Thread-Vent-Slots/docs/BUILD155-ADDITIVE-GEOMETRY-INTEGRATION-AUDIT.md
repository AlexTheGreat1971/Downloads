# Build155 — Additive Packaging Thread Integration Audit

Date: 2026-10-19

## Findings from source inspection

- The add-in registers its ribbon commands in `src/ThreadProAddIn.cs` (`BuildRibbonUi`) and opens the main form through `ThreadDialog`.
- The existing physical helical groove implementation is in `src/NativeTaperedThreadBuilder.cs`.
- That builder uses `PartComponentDefinition.Features.CoilFeatures.AddByPitchAndRevolution(...)` with `PartFeatureOperationEnum.kCutOperation`, then calls `SetAffectedBodies`, updates the document, checks `HealthStatus`, verifies volume change, and checks solid-body count.
- This is useful precedent for a separate Packaging builder, but it is not evidence that an additive inner rib works. The existing builder's profiles, runouts, and guards are designed for subtractive tapered-standard threads.
- Transactions are already used in `src/ThreadProAddIn.cs`, `src/ThreadBuilder.cs`, `src/NativeThreadConversionService.cs`, and `src/ThreadEditService.cs`; the Packaging path should follow the narrowest existing transaction lifecycle rather than invent a parallel undo mechanism.

## Implementation decision

Do not wire an unvalidated `kJoinOperation` into the production thread command. The next safe implementation slice is a separate ribbon command and a separate Packaging dialog/builder, initially constrained to a test part and one external single-start rib. It must:
1. Require an active part document and a selected cylindrical face.
2. Validate diameter, pitch, lead, starts, hand, length/turn count, profile ratio, radial overlap and minimum remaining wall.
3. Build a closed sketch profile on a plane normal to the helix start, then create a `CoilFeature` using `kJoinOperation`.
4. Explicitly target the source solid body, update, and verify `HealthStatus`, solid-body count, positive volume change and that the resulting feature belongs to the expected body.
5. Roll back the entire transaction on any failure. No fallback to cut or separate-body creation is allowed.
6. Add the internal variant only after an external prototype succeeds. The internal profile must project radially into the bore and have a controlled base overlap with the lid wall.
7. Add tests for parameter policy and failure cases, while treating Inventor B-rep validation as a separate integration test.

## User-visible status

Build155 source currently contains parameter policy and policy tests, but no user-facing Packaging command and no verified additive helical rib builder. Build PASS and Metadata/Policy PASS counts do not demonstrate that geometry exists. No Inventor 2027 geometry test is claimed by this audit.

## Incremental UI integration (2026-10-19)

A dedicated ribbon command `Helivanta.Cmd.PackagingThread` and `PackagingThreadDialog` were added after the original audit. The dialog exposes pitch, starts, profile-height/diameter ratio, length-vs-turns, print clearance, wall-thickness input, external/internal positive-rib intent, and handedness. It reads the selected cylindrical face radius and runs the existing pure policy checks. The UI explicitly tells the user that the CAD geometry builder is not connected yet; clicking validation does not create or modify model geometry. Wall thickness is a user-entered preflight value and is not measured automatically.

Verification limitation: this editing environment has no `dotnet` executable and no Inventor runtime. The change has not been compiled or exercised inside Inventor. Do not treat this as a geometry-capable release.
