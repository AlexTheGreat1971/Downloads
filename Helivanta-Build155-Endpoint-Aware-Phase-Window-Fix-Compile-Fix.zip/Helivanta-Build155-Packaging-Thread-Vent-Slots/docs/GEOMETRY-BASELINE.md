﻿# Geometry and behavior baseline

This document describes invariants that new work must preserve unless a dedicated geometry change is planned and tested.

- Runtime target: Autodesk Inventor Professional 2027, .NET 10, Windows x64.
- Actual thread features are persistent Inventor geometry; previews, if added, must remain non-persistent graphics.
- Smooth run-out is the default; simplified mode remains selectable.
- Preserve the existing shoulder/run-out safeguard and the overlap guard for thread zones built by Helivanta. When a thread is set to the full length of a cylindrical face, do not add run-out at the free/open end; a run-out may still be used at a shoulder termination or the end of a length-limited thread.
- The dedicated collapsed `Сбег — ...` folder hides technical run-out operations. Keep it even when general thread-folder sorting is off.
- The thread folder and run-out folder use batched `BrowserNodes` grouping, with a fallback when the batch API operation fails. Do not revert to one COM `folder.Add` call per node without measurement.
- The wheel-guard behavior for closed combo boxes and numeric fields is a usability invariant. Open combo lists must remain scrollable.
- Keep the main Information panel compact. Detailed timings belong in `%LOCALAPPDATA%\Helivanta\Logs\build-diagnostics.log` and its rotated archives.
- Never silently suppress a geometry warning that indicates an actual mismatch between the source surface and requested thread dimensions.

Before altering geometry algorithms, capture baseline build time and inspect the last quarter of run-out, thin material remnants, shoulder termination and fallback usage on the known user test parts.
