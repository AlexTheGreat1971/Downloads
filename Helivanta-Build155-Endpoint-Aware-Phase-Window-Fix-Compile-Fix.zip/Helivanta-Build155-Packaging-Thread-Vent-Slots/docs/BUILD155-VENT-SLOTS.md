# Build155 — Optional longitudinal ventilation slots

## Intent

The option creates straight axial openings through the raised helical ridge. It is not a thread-root groove, a chamfer, or an interruption by pitch. Each slot follows one angular sector around the cylindrical axis over the generated thread interval; all thread turns crossing that sector are cut back to the original cylindrical stock surface.

## Drawing basis and defaults

- The supplied PCO1881 top view calls out **28° (+0°/−1°) at 4 places** from the slot symmetry/radial reference; the drawing also labels the full included sector as reference **(56°)**. The reference sector is drawing-derived, but the user selected a narrower practical modelling default of **14°** after inspecting the first implementation.
- The PCO1881 neck drawing does not define slots in the inside of a matching closure/cap. The current editable internal default is **8 inner slots × 14°**, reflecting the provisional hypothesis that the inner count is twice the outer count. It is not presented as a PCO1881 requirement.
- The checkbox is off by default. Count and angular width are user-editable; defaults are 4 × 14° for an external shaft and 8 × 14° for an internal bore. If the user edits a value, the dialog preserves that edited value when selection type is refreshed.
- The policy validates count 1–20, width 0.5–120 degrees, and requires the width to be strictly smaller than the angular spacing `360° / count` so adjacent slots do not overlap.

## Geometry

- Each slot is made as a partial revolve cut (`RevolveFeatures.AddByAngle`) from a closed rectangular section that sits in a plane containing the cylinder axis and a radial direction.
- The external radial cut range starts at the original shaft radius and extends a small amount past the thread crest; it removes the outside ridge but should not cut the stock cylinder.
- The internal radial cut range starts slightly past the bore-facing crest and ends at the original bore radius; it removes the positive inward rib but should not cut the body wall.
- The current cutter is deliberately asymmetric axially. Its start station extends the thread-origin inset plus 0.25 mm, so the rectangular cutting profile begins 0.25 mm before the selected physical circular edge. At the far end the preferred overrun is `max(1 mm, lead)` beyond the nominal thread interval, capped at 0.25 mm beyond the far boundary of the selected cylindrical face to avoid a long unintended cut into a shoulder. The radial overrun is 0.02 mm into the free side of the ridge.
- Cuts are issued after the core Coils and run-out Lofts, inside the same transaction. Each cut is expected to reach `kUpToDateHealth`, remove measurable volume, and preserve the existing solid-body count. Failure aborts the entire thread operation.
- The selected cylindrical face's owning body is scoped with `SetAffectedBodies` to avoid cutting unrelated solids.

## Verification status

Source-level checks cover defaults (outer 4 × 14°; inner 8 × 14° provisional), uniform angular spacing, input bounds, overlap rejection, the disabled path, and edge-aware cutter travel. Autodesk documents `RevolveFeatures.AddByAngle` as a partial revolved feature; a numeric `Angle` is supplied in radians, with a sketch line in the profile sketch or a work axis as the axis entity. See [Autodesk Inventor API: RevolveFeatures.AddByAngle](https://help.autodesk.com/cloudhelp/2027/ENU/Inventor-API/files/RevolveFeatures_AddByAngle.htm).

This packaging experiment requires a Windows build and Inventor 2027 runtime verification. Test the checkbox off/on, external 4×14°, internal 8×14°, both ends selected, RH/LH, 1/2/3 starts, cancellation during each feature stage, close after cancellation, and the small-/large-diameter cases. Confirm the cuts reach the base cylinder without damaging the stock wall or making a separate solid body. No Inventor runtime PASS is claimed by source inspection alone.


## Terminal fragment clean-up (2026-10-20)

After the full-length slot cuts, the builder examines the start and far-end phase of each helical start. It finds the next slot boundary along the helix path. The angular remainder divided by the free slot-to-slot angular gap is the same fraction as the corresponding helical path length, because both use the same constant lead. If that fraction is strictly below 0.25, a narrow, finite axial/angular Revolve cut removes the small end stub. The cut overlaps the established slot by 0.02° and its axial extent includes half the profile width, so it clears the whole end section rather than only the mathematical centreline. The radial range remains limited to the raised ridge / inward rib outside the stock cylinder.

A guard compares the cleanup-sector width and the mapped angular footprint of the profile against the phase spacing between starts. If a cleanup might touch the next full-size start, it is logged and skipped instead of risking damage to valid geometry. Every created cleanup cut must remain `kUpToDateHealth`, remove measurable volume, and preserve the solid-body count. It shares the operation transaction, so an actual failed cleanup rolls back the whole operation. Review log stages named `start-N-terminal-fragment-plan` / `end-N-terminal-fragment-plan` and `*-terminal-fragment-verified`.

## Cancel UX correction (2026-10-20)

The success MessageBox was removed because its modal state could block the modeless dialog after a build and make cancellation appear unresponsive. During a build the button now stays enabled with an “Ожидание отмены…” label once clicked; the builder checks cancellation between additional feature-creation/update calls and aborts the shared transaction at the next safe checkpoint. An in-progress COM/Inventor call cannot be interrupted mid-call. After the feature transaction has committed, use Inventor Undo (Ctrl+Z) rather than the cancel button. Test rollback in Inventor 2027 before relying on this behavior.


### Terminal fragment threshold update (experimental)
The terminal cleanup policy measures from an endpoint to the nearest edge of a vent-slot band on either angular side. This fixes start-end cases where the one-directional search could report 53° despite a 23° residual at the adjacent boundary. The cleanup limit is one quarter of the nominal centre-to-centre slot sector plus a 1° angular allowance; the clear opening (sector minus slot width) is still logged separately. For four 14° slots, this makes the effective limit 23.5° (nominal quarter of 90° plus 1°). Verify the resulting start-side Delete Face + Heal operations visually in Inventor 2027.
