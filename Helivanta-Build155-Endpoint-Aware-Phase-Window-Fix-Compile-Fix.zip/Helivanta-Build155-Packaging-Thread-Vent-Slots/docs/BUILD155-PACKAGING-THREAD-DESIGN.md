# Build155 — Packaging / Bottle Thread (semi-standard): design and prototype boundary

Status: **engineering preflight prototype only**. This change adds an Inventor-independent parameter policy and regression tests. It does not yet expose the family in the UI or create persistent Inventor geometry. Do not treat Build155 as a feature-complete release.

## Terminology and nominal model

- **Pitch (P)**: axial distance between adjacent thread profiles on the same start.
- **Starts (N)**: number of interleaved helices; integer 1–12 in this prototype.
- **Lead (L)**: axial advance of one helix per full revolution. `L = P × N`.
- **Axial length** is measured along the selected cylinder; **turn count** is `length / lead`, not `length / pitch`.
- **Right/left hand** reverses helix handedness only; it does not change P, N, L or profile dimensions.
- **Reference diameter** is the selected cylinder diameter. The nominal profile height is `clamp(diameter × heightRatio, 0.15 mm, 2.5 mm)`, with `heightRatio` constrained to 0.005–0.06. The default ratio is 0.025. Both the ratio and absolute bounds must be visible to users; clamping must be shown in the preview/UI rather than hidden.
- Printing clearance is an independent, explicit parameter (prototype range 0–0.5 mm). It must not alter nominal profile height or nominal geometry silently. Its direction/application to a mating pair still needs a clearly defined UI contract.

## Radial direction and additive geometry proposal

The selected cylindrical face is the reference/root surface. The two roles are complementary:

- **External neck**: the rib crest radius is greater than the stock radius.
- **Internal cap**: the rib crest radius is less than the bore radius. This is a positive rib protruding into the opening, not a groove cut into the cap wall.

Proposed CAD strategy to prototype in Inventor 2027: create one closed trapezoidal profile in an axial-radial sketch plane. Its root/base must overlap the selected wall by a small, explicit embed depth (prototype calculation: `max(0.05 mm, 0.20 × profileHeight)`) so the resulting solid is fused. Create one additive `CoilFeature` per start using `kJoinOperation`, with evenly spaced start phases `360° × index / starts`; use the same enclosing transaction for all starts, metadata and browser grouping. Do not assume this succeeds merely because the API call returns: check feature health, solid-body count, and volume/solid continuity, then abort the transaction on any failure.

This strategy is a hypothesis to validate with a minimal disposable IPT before integration. In particular, confirm Inventor 2027 `CoilFeatures.AddByPitchAndRevolution` behavior for `kJoinOperation`, sketch-plane orientation, internal-face axis direction, phase placement, multi-start fusion and partial-turn ends. The existing builder's subtractive coil path is not to be repurposed by changing its operation flag globally.

## Wall and topology guards

- Require a reliable positive wall-thickness measurement before modelling; fail closed if measurement is unavailable.
- Prototype policy rejects measured wall thickness below 0.6 mm. This is a conservative preflight floor, not a universal engineering guarantee.
- Internal positive rib does not subtract wall material, but root overlap must be sufficient to fuse and must not cross into a neighboring wall/void or create a self-intersection.
- External positive rib must not be mistaken for a cut depth in existing wall guards.
- Reject non-finite/out-of-range diameter, pitch, starts, ratio, clearance, axial length, and turn count before starting a transaction.
- End/start treatment, overlap with shoulders, profile self-intersection and kernel health still require geometry-level validation. No automatic fallback to a cut groove is allowed.

## Metadata/edit integration still required

Before UI exposure, add an explicit family discriminator independent of `ThreadStandard` so the new family never enters official standard tables. Persist all family parameters (role, pitch, starts, handedness, diameter reference, ratio, resolved height, axial length/turns, start/end treatment, clearance preset/value and schema version). Preserve legacy JSON deserialization and `ThreadMetadataRecord` validation for existing families. Extend edit reconstruction, integrity reporting, feature naming/grouping, overlap isolation, and undo/redo selection snapshots without changing the existing thread branch.

## Drawing facts and claims

The supplied sheet title block says `PCO-1881 — Voluntary Standard, 28mm CSD Finish`. Its development view calls out right-hand, single-start thread, 2.70 mm pitch, 1°54′ helix angle and 650° depth-thread turn. The section includes Ø27.40 ±0.13 mm (T) and Ø24.20 mm (E), among other dimensions. These are observations from this sheet, not a complete profile definition for this semi-standard. The BERICAP note's two-start statement for a specific PUP NG 28/34 1881 MIB product remains unresolved against this single-start drawing; configurable starts avoids silently conflating the two.

Never claim PCO 1881 / BERICAP compatibility, sealing, pressure suitability, food-contact suitability or commercial interchangeability from this approximate configurable thread alone.

## Current prototype contents

- `src/PackagingThreadGeometryPolicy.cs`: pure parameter preflight, pitch/lead relationship, turn count and start phase policy.
- `tests/ThreadMetadataTest/Program.cs`: added pure-policy regression cases.
- CAD geometry/UI/metadata/edit/undo integration is intentionally not included until the additive coil prototype is validated in Inventor 2027.
