﻿# Thread tolerance classes and tapered-thread design (Build 61 engineering plan)

## Tolerance classes

`ThreadParams.ToleranceClass` now has a UI selector for ISO 6H (internal) and 6g (external), and the selected designation is persisted in metadata. It remains descriptive metadata only: ISO limit calculations and validation against dimensional allowance tables are not active yet. Implement the catalog as a separate, testable module keyed by standard, size, pitch, internal/external, and designation. Do not infer limits from the label alone. Keep separate data for tolerance grade/position, pitch-diameter limits, major/minor diameter limits, and standard edition. Unsupported combinations must be rejected with a clear message. Tolerance metadata must be persisted with the logical thread and surfaced in the integrity report. Start with a narrow verified subset (ISO metric 6H/6g), then add ANSI classes only when their dimensional allowance tables are represented and tested.

## Tapered threads

`ThreadParams.Tapered` and related fields remain data-only; this build deliberately does not enable conical geometry generation. Before geometry work, add a standard catalog mapping designation to taper ratio, reference plane/diameter, thread form, pitch, hand, and gauge length (for example, do not assume every pipe-thread family uses the same taper convention).

Recommended workflow: select a circular edge -> identify its owning conical/cylindrical face, plane, axis and body -> resolve standard and nominal designation -> calculate reference diameter and taper over axial length -> preview the cone and thread envelope -> validate wall thickness/intersections -> build transactionally -> persist the exact standard/designation/tolerance. For a standard that specifies 1:N diameter taper, convert consistently: diameter change = axial length / N; radius change is half of that. The reference plane/diameter and gauge length must come from that standard, not be guessed from the picked edge. The cone must be constructed from the selected edge as an explicit reference; do not simply apply a generic taper to the existing parallel-thread profile.

Implementation gates:

1. **Tolerance catalog** — unit tests for every supported designation/size; persist and display the designation; no geometry change solely from choosing a label until limit calculations are implemented.
2. **Edge-derived taper** — validate selected circular edge, axis, reference plane, standard ratio, and start/end diameters; reject ambiguous edges and unsupported standards.
3. **Preview** — draw the cone and thread envelope from the same calculated parameters as the builder; preview must not create persistent CAD features.
4. **Transactional build** — only after preview and guards pass, create the conical host/thread profile in one Inventor transaction, with rollback on any failure. Preserve the parallel-thread path unchanged.

No conical geometry algorithm or standard table is activated by this groundwork. Do not label conical threads as supported until these gates pass and Inventor runtime acceptance confirms them.
