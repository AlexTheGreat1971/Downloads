﻿# Build155 follow-up — crest-face Heal cleanup and guarded undo

## Why this follow-up exists
The prior experimental probe looked for faces using only axial position and angular sector. It did not constrain the radial location, so it could include unrelated side/root surfaces or fail the exactly-three-faces guard. The UI also disabled its action button after the build because it only represented cancellation-in-progress.

## Changes in this candidate
- Face selection uses the target fragment’s finite axial range and angular sector, then selects `kBSplineSurface` faces from that local window. It intentionally does not require the face to reach the nominal crest radius: the runtime log showed the three intended spline faces near the 11.0 mm stock radius and two planar slot/end walls in the same window.
- The diagnostic records scanned, axial, angular-sector, spline-top-surface and final candidate counts; accepted face indices; PointOnFace radius, face vertex radial range, station, angular location, vertex count, and surface type.
- The fallback angular-sector revolve cut is disabled in this candidate. If exactly three eligible faces are not identified or Heal fails and the feature can be safely removed, the main thread build is retained and the residual is explicitly logged. This is intentional: the former fallback could create `kDriverLostHealth` and obscure whether the requested native Heal method actually works.
- `DeleteFaceFeatures.Add(faceCollection, true)` is retained, and its feature health, volume delta, and solid-body count are checked.
- The feature transaction name is now a unique `Helivanta: упаковочная резьба (эксперимент) ...` name.
- After a successful build, the action button changes to **Отменить последнее построение**. It uses `TransactionManager.UndoTransaction()` only if the exact recorded packaging transaction is still the newest committed action and the same part is active. A timer updates availability; if another operation supersedes the build, the button is disabled. It must never undo an unrelated action.
- During an active build the same button continues to request cancellation. The geometry kernel still cannot be interrupted mid-call; the request is honored at a cancellation checkpoint.

## Validation status
- Static delimiter balance and source-level review performed in this environment.
- .NET compilation was not performed because the .NET SDK/compiler is unavailable here.
- Inventor 2027 runtime is not available here. The vertex-extent correction is based on the user's runtime diagnostic but must be verified in Inventor. The last log had 5 local axial/angular candidates: 2 `kPlaneSurface` walls and 3 `kBSplineSurface` faces. Confirm the log resolves to exactly those three highlighted top faces before Delete Face + Heal; if count is not 3, inspect the surface-type and local-window diagnostics rather than broadening blindly.
- The undo flow must be tested by building, clicking **Отменить последнее построение**, then testing a second case where another Inventor action occurs first. The latter must disable/refuse the Helivanta undo rather than rolling back the unrelated action.


## 2026-10-21 quarter-sector tail selection correction

The latest runtime log shows the end-2 tail at 17.444° in a 76° free sector (22.953%), which is below the strict 25% cutoff. A separate 23° fragment is 30.263% of the same 76° sector and must not be removed. The old geometry filter incorrectly rejected all five faces in the target local window because it demanded a radial match to the 11.55 mm thread crest even though the target faces measure near 11.0 mm stock radius.

The updated candidate selector uses the already-qualified `<25%` fragment plan, the finite axial window, the sweep angular window, and `SurfaceTypeEnum.kBSplineSurface`. In the supplied log's target window, this separates three spline faces (the three manually selected top faces) from two planar slot/end walls. Delete Face + Heal is called only when exactly three such faces are found. Runtime validation must confirm that the current Inventor topology repeats this pattern and that the three candidates are exactly the manually selected faces before declaring success. If the topology changes and it does not produce exactly three, the code logs the candidates and skips deletion rather than risking adjacent valid thread.
